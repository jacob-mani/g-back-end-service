package com.ford.grid.aspect;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.*;
import org.springframework.stereotype.Component;

import java.util.Collection;

@Aspect
@Component
@Slf4j
public class LoggingAspect {
    @Pointcut("execution(* com.ford.grid.controller..*(..)) || execution(* com.ford.grid.service..*(..))")
    public void applicationPackagePointCut() {
    }

    @Before("applicationPackagePointCut()")
    public void logMethodEntry(JoinPoint joinPoint) {
        log.info(">> Entering: {}.{}() with args: {}", joinPoint.getSignature().getDeclaringTypeName(), joinPoint.getSignature().getName(), joinPoint.getArgs());
    }

    @AfterReturning(pointcut = "applicationPackagePointCut()", returning = "result")
    public void logMethodExit(JoinPoint joinPoint, Object result) {
        String resultInfo;
        if (result instanceof Collection) {
            resultInfo = "Collection(size=" + ((Collection<?>) result).size() + ")";
        } else if (result != null && result.getClass().isArray()) {
            resultInfo = "Array(length=" + java.lang.reflect.Array.getLength(result) + ")";
        } else if (result != null && result.toString().length() > 500) {
            resultInfo = result.getClass().getSimpleName() + "(toString length > 500)";
        } else {
            resultInfo = String.valueOf(result);
        }
        log.info(">> Exiting: {}.{}() with result: {}",
                joinPoint.getSignature().getDeclaringTypeName(),
                joinPoint.getSignature().getName(),
                resultInfo);
    }

    @AfterThrowing(pointcut = "applicationPackagePointCut()", throwing = "ex")
    public void logMethodException(JoinPoint joinPoint, Exception ex) {
        log.error("!! Exception in: {}.{}()- {}", joinPoint.getSignature().getDeclaringTypeName(), joinPoint.getSignature().getName(), ex.getMessage(), ex);
    }
}
