package com.ford.grid.common;

import com.ford.cloudnative.base.api.StandardErrorResponse;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
@ApiResponses(value = {@ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(mediaType = "application/json", schema = @Schema(implementation = StandardErrorResponse.class))),
        @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content(mediaType = "application/json", schema = @Schema(implementation = StandardErrorResponse.class))),
        @ApiResponse(responseCode = "403", description = "Forbidden", content = @Content(mediaType = "application/json", schema = @Schema(implementation = StandardErrorResponse.class))),
        @ApiResponse(responseCode = "404", description = "Resource Not Found", content = @Content(mediaType = "application/json", schema = @Schema(implementation = StandardErrorResponse.class))),
        @ApiResponse(responseCode = "405", description = "Method Not Found", content = @Content(mediaType = "application/json", schema = @Schema(implementation = StandardErrorResponse.class))),
        @ApiResponse(responseCode = "406", description = "Not Acceptable", content = @Content(mediaType = "application/json", schema = @Schema(implementation = StandardErrorResponse.class))),
        @ApiResponse(responseCode = "415", description = "Unsupported media type", content = @Content(mediaType = "application/json", schema = @Schema(implementation = StandardErrorResponse.class))),
        @ApiResponse(responseCode = "429", description = "Too Many Requests", content = @Content(mediaType = "application/json", schema = @Schema(implementation = StandardErrorResponse.class))),
        @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = StandardErrorResponse.class))),
        @ApiResponse(responseCode = "503", description = "Application is down", content = @Content(mediaType = "application/json", schema = @Schema(implementation = StandardErrorResponse.class))),
        @ApiResponse(responseCode = "200", description = "Request is Success"),
        @ApiResponse(responseCode = "default" /*default*/, description = "Error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = StandardErrorResponse.class)))})
public @interface SystemWideResponses {
}
