package com.ford.grid.constants;

public class AzureAuthConstants {

    private AzureAuthConstants() {}

    public static final String DLS_TYPE = "DLS";
    public static final String AUTH = "Authorization";
    public static final String CONTENT_TYPE = "Content-Type";
    public static final String CONTENT_TYPE_JSON = "application/json";
    public static final String GRANT_TYPE = "grant_type";
    public static final String CLIENT_CREDENTIALS = "client_credentials";
    public static final String JWT_BEARER = "urn:ietf:params:oauth:grant-type:jwt-bearer";
    public static final String ASSERTION = "assertion";
    public static final String CLIENT_ID = "client_id";
    public static final String CLIENT_SECRET = "client_secret";
    public static final String RESOURCE = "resource";
    public static final String FORD_PROXY_SERVER = "internet.ford.com";
    public static final String TOKEN_GENERATION_FAILED = "Azure AD token generation failed.";
    public static final int FORD_PROXY_PORT = 83;
    public static final String ATTACHMENT = "attachment";
    public static final String CONTENT_LENGTH = "Content-Length";
    public static final String HEADER_VALUE = "0";
    public static final String APPLICATION_X_WWW_FORM_URLENCODED = "application/x-www-form-urlencoded";
    public static final String SCOPE = "scope";
    public static final String AZURE_URL = "https://login.microsoftonline.com/c990bb7a-51f4-439b-bd36-9c07fb1041c0/oauth2/v2.0/token";
    public static final String BEARER = "Bearer ";
    public static final String DLS_ROLE_ASSIGNMENTS = "/DLS/api/v3/RoleAssignments";
    public static final String IBM_CLIENT = "X-IBM-Client-Id";
    public static final String DLS_API_FAILED = "Azure DLS API failed.";
    public static final String ACCESS_TOKEN = "access_token";

    // ServiceNow field names
    public static final String SYS_ID = "sys_id";
    public static final String SYS_CLASS_NAME = "sys_class_name";
    public static final String SHORT_DESCRIPTION = "short_description";
    public static final String RESULT = "result";

    // ServiceNow upload body keys
    public static final String TABLE_NAME_KEY = "table_name";
    public static final String TABLE_SYS_ID_KEY = "table_sys_id";
    public static final String FILE_KEY = "file";

    // ServiceNow sysparm query
    public static final String SYSPARM_QUERY_CONTAINS = "request.numberCONTAINS";
    public static final String SYSPARM_QUERY = "sysparm_query";
    public static final String SYSPARM_FIELDS = "sysparm_fields";
    public static final String USER_NAME = "user_name";

    // getTableSysId poll-loop tuning
    /** Maximum number of attempts when polling ServiceNow for a newly created record. */
    public static final int SYS_ID_POLL_MAX_ATTEMPTS = 4;
    /** Base delay in milliseconds between poll attempts (doubled on each retry). */
    public static final long SYS_ID_POLL_BASE_DELAY_MS = 1_000L;

    // Error messages
    public static final String TABLE_SYS_ID_FAILED = "Unable to retrieve ServiceNow table sys_id.";
    public static final String TITLE_UPDATE_FAILED = "ServiceNow ticket title update failed.";
    public static final String FILE_UPLOAD_FAILED = "ServiceNow file upload failed.";
    public static final String SYSTEM_ID_FAILED = "Unable to retrieve ServiceNow system user id.";

    // ARC Graph api added
    //Graph Constants
    public static final String GRAPH_SCOPE = "https://graph.microsoft.com/.default";
    public static final String GRAPH_BASE_URL = "https://graph.microsoft.com/v1.0";
    public static final String SITE_HOST_AND_PATH = "azureford.sharepoint.com:/sites/FieldServiceActions/";
    public static final String FOLDER_PATH = "Bulletins & Letters/Test";
    public static final String UP_DOC_FOLDER_PATH = "Bulletins & Letters/Test/uploaded";
    public static final String SHAREPOINT_SITE_BASE_URL = "https://azureford.sharepoint.com/sites/FieldServiceActions";
    public static final String SHAREPOINT_DOCUMENT_LIBRARY = "Shared Documents";
}
