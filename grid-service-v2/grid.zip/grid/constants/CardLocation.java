package com.ford.grid.constants;

import lombok.Getter;

@Getter
public enum CardLocation {
    INVESTIGATION("CheckList-Investigation"),
    FOURTEEN_D("CheckList-14D"),
    CCRG("CheckList-CCRG"),
    CSF("CheckList-CSF"),
    FRC("CheckList-FRC"),
    LAUNCH("CheckList-LAUNCH"),
    TRG("CheckList-TRG"),
    EMM("CheckList-EMM"),
    PIR("CheckList-PIR"),
    CONTACTS("Contacts"),
    ISSUE_CREATION("Issue Creation"),
    ISSUE_UPDATE("Issue Updated"),
    MAIL_TRACKING_SUMMARY("Mail Tracking Summary"),
    MEETING_NOTES("Meeting Notes"),
    SCOPE_INFO("Scope & Information"),
    WORKLOAD_WEIGHTAGE("WorkLoad Weightage"),
    FORUM_MINUTES("Forum Minutes"),
    PRE_AUTH("Pre Auth"),
    EPRC("CheckList-EPRC"),
    GOVERNMENT("CheckList-GOVERNMENT"),
    CAUSAL_INFORMATION("Causal Information"),
    KEY_DATES("Key Dates"),
    PSNL_DASHBOARD("PSNL Dashboard"),
    VERN("VERN"),
    COLLAB1("collab1"),
    ARC_DOCK_GEN_COLLAB1("Collab 1"),
    ARC_DOCK_GEN_COLLAB2("Collab 2"),
    OD_LETTER_DOC_GEN_COMPLETED("OD Letter Doc Generation Completed")
            ;

    private final String changeLocation;
    
    CardLocation(String changeLocation) {
        this.changeLocation = changeLocation;
    }
}