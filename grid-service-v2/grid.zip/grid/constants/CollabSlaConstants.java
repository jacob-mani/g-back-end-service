package com.ford.grid.constants;

/**
 * Constants used by the Collab SLA reminder service.
 */
public final class CollabSlaConstants {

    private CollabSlaConstants() {}

    // Status values
    public static final String STATUS_PENDING = "pending";
    public static final String STATUS_PENDING_DISPLAY = "Pending";

    // Default / fallback values
    public static final String NOT_AVAILABLE = "N/A";
    public static final String NOTIFICATION_TYPE = "Not-Applicable";

    // Subject formatting
    public static final String SUBJECT_SEPARATOR = " – ";

    // Template variable keys
    public static final String KEY_COLLAB_ID = "collabId";
    public static final String KEY_COLLAB_LABEL = "collabLabel";
    public static final String KEY_FILE_NAME = "fileName";
    public static final String KEY_FILE_SOURCE = "fileSource";
    public static final String KEY_APPROVER_ROLE = "approverRole";
    public static final String KEY_STATUS = "status";

    // Thymeleaf context variable names
    public static final String CTX_ISSUE_NUMBER = "issueNumber";
    public static final String CTX_APPROVER_NAME = "approverName";
    public static final String CTX_SLA_HOURS = "slaHours";
    public static final String CTX_CAMPAIGN_NAME = "campaignName";
    public static final String CTX_UI_BASE_URL = "uiBaseUrl";
    public static final String CTX_ISSUE_LINK = "issueLink";
    public static final String CTX_PENDING_DOCUMENTS = "pendingDocuments";
    public static final String CTX_PENDING_COUNT = "pendingCount";

    // Log messages
    public static final String LOG_SCAN_START = "ApprovalReminder – scanning for pending approvers";
    public static final String LOG_REMINDER_SENT = "SLA reminder sent to {} for issue={}, pending documents={}";
    public static final String LOG_SEND_FAILED = "Failed to send SLA reminder for issue={}, approver={}: {}";
    public static final String LOG_SUMMARY_FORMAT = "Approval reminder scan complete. Issues scanned: %d, No.Of Reminders sent: %d";
    public static final String ERR_SEND_FAILED_PREFIX = "Failed to send SLA reminder email to ";
    public static final boolean activeOdCollectionTrue = true;
    public static final boolean activeOdCollectionFalse = false;
}

