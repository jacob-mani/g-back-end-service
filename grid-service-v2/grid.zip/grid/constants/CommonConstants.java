package com.ford.grid.constants;

import java.util.List;
import java.util.Map;

/**
 * A utility class that holds common constant values used throughout the application.
 */
public class CommonConstants {
    public static final String WERS_GROUP_CODE = "14";
    public static final String YES_Y = "Y";
    public static final String STATUS_ACTIVE = "Active";
    public static final String FILE_CREATION_DATE_FORMATTER = "yyyy-MM-dd_HH:mm:ss";

    public static final String CHECKLIST_EPRC_DEFECTREPORT = "/checklist/inv/eprc/eprc-defect-report";
    public static final String CHECKLIST_EPRC_FACTSHEET = "/checklist/inv/eprc/eprc-fact-sheet";

    //Notification Constants
    public static final String DOCUMENT_NOTIFICATION_PERF = "notification_preferences";
    public static final String CDS_ID = "cdsid";
    public static final String NOTIFICATION_PREFERENCES_ITEM = "notificationPreferencesItem";
    public static final String NOTIFICATION_TYPE = "notificationType";
    public static final String NOTIFICATION_NAME = "notificationName";
    public static final String CHECKLIST_PATH = "checklistPath";

    // Forum Type Constants
    public static final String FORUM_TYPE_CCRG = "1";
    public static final String FORUM_TYPE_CSF = "2";
    public static final String FORUM_TYPE_EPRC = "3";
    public static final String FORUM_TYPE_GOVT = "4";
    public static final String FORUM_TYPE_PIR = "6";

    public static final String FORUM_CCRG = "ccrg";
    public static final String FORUM_CSF = "csf";
    public static final String FORUM_EPRC = "eprc";
    public static final String FORUM_EPRC_FORUM_MINUTES= "forumMinutes";
    public static final String FORUM_GOVT = "gov";
    public static final String FORUM_PIR = "pir";

    public static final String AGENDA_TYPE_GCCRG = "gccrg";
    public static final String AGENDA_TYPE_GCSF = "gcsf";
    public static final String AGENDA_TYPE_GEPRC = "geprc";
    public static final String AGENDA_TYPE_GPIR = "gpir";
    public static final String AGENDA_TYPE_FRC = "frc";
    public static final String AGENDA_TYPE_GOVERNMENT = "government";

    // Forums that share the same template and support multi-selection
    public static final String AGENDA_TYPE_CCRG = "ccrg";
    public static final String AGENDA_TYPE_CSF = "csf";
    public static final String AGENDA_TYPE_EPRC = "eprc";
    public static final String AGENDA_TYPE_PIR = "pir";
    public static final java.util.Set<String> MULTI_SELECT_ALLOWED_AGENDA_TYPES =
            java.util.Collections.unmodifiableSet(new java.util.HashSet<>(java.util.Arrays.asList(
                    AGENDA_TYPE_CCRG, AGENDA_TYPE_CSF, AGENDA_TYPE_EPRC, AGENDA_TYPE_PIR)));

    // Pre-Auth Tab Type Constants
    public static final int PRE_AUTH_TAB_TYPE_2 = 2;
    public static final int PRE_AUTH_TAB_TYPE_3 = 3;
    public static final int PRE_AUTH_TAB_TYPE_4 = 4;

    // Forum Contact Roles as ArrayLists
    public static final List<String> CCRG_FORUM_CONTACTS =
            List.of("asoLead", "assistDirector", "ccrgChair", "monitor", "trgScheduler", "ccrgAttorney");

    public static final List<String> CSF_FORUM_CONTACTS =
            List.of("csfLead", "csfChair", "csfCoChair", "csfAttorney");

    public static final List<String> EPRC_FORUM_CONTACTS =
            List.of("eprcLead", "eprcChair", "eprcAso", "eprcOgc", "eprcPd", "sh&c", "eprcAttorney", "reportedBy", "approvedBy");

    public static final List<String> GOVT_FORUM_CONTACTS =
            List.of("govnLead", "invManager");

    public static final String ATTORNEY = "attorney";

    public static final List<String> PIR_FORUM_CONTACTS =
            List.of("asoLead", "assistDirector", "pirChair", "monitor", "pirAttorney");

    // Issue Contact Specific Titles
    public static final List<String> ISSUE_DEFAULT_CONTACTS = List.of("implLead", "implManager", "ccm", "cce", "productionSta", "vo", "asoSme", "ota", "qualityEngineer");

    //Meeting notes constants
    public static final String ID = "_id";
    public static final String ISSUE_NUMBER = "issueNumber";
    public static final String IMPL_ID = "implId";
    public static final String POPULATION_ID = "populationId";
    public static final String VERN_NUMBER = "vernNumber";
    public static final String VERN_REVISION = "vernRevision";
    public static final String MEETING_NOTES_COLLECTION = "meeting_notes";
    public static final String SEQUENCE_ID = "sequenceId";
    public static final String CLOSURE_NOTE_NO_REVIEW = "Closure Note - No Review";
    public static final String CLOSURE_NOTE_TITLE = "Closure Note";
    public static final String CATEGORY_GENERAL = "general";
    public static final String CATEGORY_REGION_FSA = "regionandfsa";
    public static final String CATEGORY_GENERAL_ROLE = "role";
    public static final String CATEGORY_REGION_FSA_TITLE = "title";
    public static final String CATEGORY_TRG = "trg";
    public static final String CATEGORY_FRC = "frc";
    public static final String CATEGORY_EMM_TR = "emmortr";
    public static final String CATEGORY_REGION_FSA_UPPERCASE = "REGIONANDFSA";
    public static final String CATEGORY_GENERAL_UPPERCASE = "GENERAL";
    public static final String CATEGORY_TRG_UPPERCASE = "TRG";
    public static final String CATEGORY_FRC_UPPERCASE = "FRC";
    public static final String CATEGORY_QUESTIONNAIRE = "questionnaire";

    public static final String CARD_EDIT_STATUS = "cardBeingEdited";
    public static final String CARD_EDIT_BY = "currentlyEditedBy";


    //Forum Status Constants
    public static final String FORUM_ACTIVE = "Active";
    public static final String FORUM_MONITOR = "Monitor";
    public static final String FORUM_CONCLUDED = "Concluded";
    public static final String FORUM_NOTES_PENDING = "Notes Pending";
    public static final String FORUM_PENDING_REGULATOR_ALIGNMENT = "Pending Regulator Alignment";
    public static final String FORUM_POST_FSA_MONITOR = "Post FSA Monitor";
    public static final String FORUM_CONCLUDE_WITH_FSA = "Conclude with FSA";

    /** Returns true for statuses that represent a pending closure-note review. */
    public static boolean isNotesPendingStatus(String status) {
        return FORUM_NOTES_PENDING.equals(status) || FORUM_PENDING_REGULATOR_ALIGNMENT.equals(status);
    }

    public static final String FD_ACTIVE = "Active";
    public static final String FD_PENDING_CLOSURE = "Pending Closure";
    public static final String FD_CLOSED = "Closed";

    public static final List<String> FORUM_CCRG_APPROVERS = List.of("asoLead", "supervisor", "ccrgChair", "ccrgAttorney");
    public static final List<String> FORUM_EPRC_APPROVERS = List.of("eprcLead", "supervisor", "eprcChair", "eprcAttorney");
    public static final List<String> FORUM_PIR_APPROVERS = List.of("pirLead", "pirChair", "pirAttorney");

    public static final String REVIEW_COMPLETED = "Completed";
    public static final String REVIEW_PENDING = "Pending";
    public static final String REVIEW_APPROVED = "Approved";
    public static final String REVIEW_APPROVED_WITH_EDIT = "Approved with edits";
    public static final String REVIEW_REJECTED = "Rejected";
    public static final String REVIEW_NOT_APPROVED = "Not Approved";

    // Date formats commonly used in document generation
    public static final String DATE_FORMAT_MMDDYYYY = "MM/dd/yyyy";

    // FRC specific constants
    public static final String FRC = "frc";

    // Status constants
    public static final String PENDING = "Pending";
    public static final String DOC_GEN_READY = "READY";
    public static final String DOC_GEN_PENDING = "PENDING";
    public static final String DOC_GEN_STATUS_DRAFT_PENDING = "DraftPending";
    public static final String DOC_GEN_STATUS_REVIEWER_PENDING = "ReviewerPending";
    public static final String DOC_GEN_STATUS_NOTES_PENDING = "NotesPending";
    public static final String DOC_GEN_STATUS_PENDING = "Pending";
    public static final String DOC_GEN_STATUS_COMPLETED = "Completed";
    public static final String DOC_TYPE_PART573 = "PART573";
    public static final String DOC_GEN_STAGE_COMPLETED = "COMPLETED";
//    public static final String STATUS_ACTIVE = "Active";
    public static final String NHTSA = "NHTSA";
    public static final String REPAIR_MOBILE  = "MOBILE_REPAIR";
    public static final String REPAIR_RENTAL  = "INCLUDES_RENTAL";
    public static final String REPAIR_TOWING  = "INCLUDES_TOWING";
    public static final String UTF_8 = "utf-8";
    public static final String VEHICLES = "vehicles";
    public static final String ASO = "Automotive Safety Office (ASO)";

    //FDQuestionnaire
    public static final String FD_1_TITLE = "1. Problem Description";
    public static final String FD_2_TITLE = "2. Root cause & 13. Preliminary Assessment of Prevent Action";
    public static final String FD_3_TITLE = "3. Problem investigation / verification data";
    public static final String FD_4_TITLE = "4. Corrective Actions taken & 5.Verify Effectiveness of Corrective Actions";
    public static final String FD_6_TITLE = "6. Suspect vehicle population Rationale";
    public static final String FD_7_TITLE = "7. Existing Service Parts Purge";
    public static final String FD_8_TITLE = "8. Assessment of effect on vehicle operation";
    public static final String FD_9_TITLE = "9. Description of concern solution";
    public static final String FD_10_TITLE = "10. Description of Program parts/Software";
    public static final String FD_11_TITLE = "11. Vendor involvement";
    public static final String FD_12_TITLE = "12. Financial Implications";
    public static final String FD_PENDING_STATUS = "Pending";
    public static final String FD_IN_PROGRESS_STATUS = "In Progress";

    //Audit Constants
    public static final String AUDIT_ISSUE_CREATED = "New Issue Created";
    public static final String AUDIT_ISSUE_UPDATED = "Issue Updated";
    public static final String AUDIT_CREATED_AT = "createdAt";
    public static final String AUDIT_UPDATED_AT = "updatedAt";
    public static final String AUDIT_CREATED_BY = "createdBy";
    public static final String AUDIT_UPDATED_BY = "updatedBy";
    public static final String AUDIT_STATUS = "status";
    public static final String JSON_KEY_ROOT = "root";
    public static final String AUDIT_KEY_UPDATED_BY_SYSTEM = "SYSTEM";
    public static final String AUTO_SAVED_BY_SYSTEM = "Auto Saved By System";

    public static final String GRID_MESSAGE = "GRID_";
    public static final String FONT_COLOR = "000000";
    public static final String CLASS = "class";
    public static final String WORD_DOCUMENT_TYPE = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
    public static final String CCRG_CHAIR = "ccrgChair";
    public static final String PIR_CHAIR = "pirChair";
    public static final String ASSISTANT_DIRECTOR = "assistDirector";
    public static final String CCRG_ATTORNEY = "ccrgAttorney";
    public static final String PIR_ATTORNEY = "pirAttorney";
    public static final String N_A = "NA";
    public static final String CCRG = "ccrg";
    public static final String CSF = "csf";
    public static final String EPRC = "eprc";
    public static final String FONT_LIGHT_PATH = "assets/fonts/FordAntennaWGL-Light.otf";
    public static final String EXCEPTION_MESSAGE = "Exception: ";
    public static final String LOGO_PNG_PATH = "assets/images/ford-logo.png";


    public static final String INCLUDE = "Include";
    public static final String INVESTIGATION = "Investigation";

    public static final Map<String, String> regionNameMap = Map.of(
            "NA", "North America",
            "SA", "South America",
            "EU", "Europe",
            "IMG", "International Markets Group",
            "GCH", "Greater China"
    );

    public static final String FCSD_SCM_ROLE = "scm";
    public static final String FCSD_SEO_ROLE = "seo";
    public static final String FCSD_PURCHASING_ROLE = "purchasing";
    public static final String FCSD_RSP_ROLE = "rsp";

    public static final Map<String, String> TRANSIENT_ROLES = Map.ofEntries(
            Map.entry("aso", "ASO"),
            Map.entry("ccm", "CCM"),
            Map.entry("cce", "CCE"),
            Map.entry("ogc", "OGC"),
            Map.entry("psl", "PS&L"),
            Map.entry("csf", "CSF"),
            Map.entry("eprc", "EPRC"),
            Map.entry(FCSD_SEO_ROLE, "FCSD-SEO"),
            Map.entry(FCSD_RSP_ROLE, "FCSD-RSP"),
            Map.entry(FCSD_SCM_ROLE, "FCSD-SCM"),
            Map.entry(FCSD_PURCHASING_ROLE, "FCSD-PURCHASING"),
            Map.entry("executive", "FCSD Executive Summary Notes")
    );

    public static final String INVESTIGATION_ANALYSIS_TITLE = "Investigation Analysis";
    public static final String FONT_LIGHT = "Ford Antenna Light";
    public static final String FONT_MEDIUM = "Ford Antenna Medium";
    public static final String FORD_ARIAL = "Arial";
    public static final String FIELD_NAME = "name";
    public static final String REGEX_ARRAY_INDEX = "\\[\\d+\\]";

    public static final String EMISSION_PROBLEM_REVIEW_COMMITTEE = "Emissions Problem Review Committee (EPRC)";
    public static final String LEAD_INVESTIGATOR = "Lead Investigator";
    public static final String EPRC_CHAIR = "EPRC Chair";
    public static final String TEST_EMAIL_MESSAGE = "THIS IS A TEST EMAIL - NO ACTION REQUIRED. ";

    public static final String PART573_EXCEPTION = "Exception Occurs While Creating Part573.";

    public static final String GROUP_14D_AUTHOR = "14dAuthor"; // As per your instruction
    public static final String GROUP_PROGRAM_MANAGER = "programManager";
    public static final String GROUP_RSP_ANALYST = "rspAnalyst";
    public static final String TEST_ENV_SUFFIX = "(GRID INTEGRATION TESTING - CAN BE DELETED)";

    public static final String DOCUMENT_FEEDBACK = "feedback";

    // Feedback constants
    public static final String FEEDBACK_STATUS_ACTIVE = "Active";
    public static final String FEEDBACK_CREATED_BY_UNKNOWN = "Unknown";

    // User Preferences constants
    public static final String DOCUMENT_USER_PREFERENCES = "user_preferences";

    // Feedback custom filter condition values
    public static final String FILTER_CONDITION_IS = "Is";
    public static final String FILTER_CONDITION_IS_NOT = "Is not";

    // Feedback filter categories available for custom filter dropdowns
    public static final List<String> FILTER_CATEGORIES = List.of("status", "feedbackType", "areaAffected", "responseUrgency");

    // Feedback filter conditions available for custom filter dropdowns
    public static final List<String> FILTER_CONDITION = List.of(FILTER_CONDITION_IS, FILTER_CONDITION_IS_NOT);

    // Build Agenda Sort Field Names
    public static final String SORT_FIELD_ISSUE_NUMBER = "issuenumber";
    public static final String SORT_FIELD_ISSUE_DESCRIPTION = "issuedescription";
    public static final String SORT_FIELD_AGENDA_TYPE = "agendatype";
    public static final String SORT_FIELD_LEAD_REGION = "leadregion";
    public static final String SORT_FIELD_SEGMENT = "segment";
    public static final String SORT_FIELD_DURATION = "duration";
    public static final String SORT_FIELD_MEETING_START_TIME = "meetingstarttime";
    public static final String SORT_FIELD_START_END_TIME = "startendtime";
    public static final String SORT_FIELD_TOGGLE_BUTTON = "togglebutton";
    public static final String SORT_FIELD_ISSUE_PHASE = "issuephase";
    public static final String SORT_FIELD_ISSUE_RELATED_ITEMS = "issuerelateditems";
    public static final String SORT_FIELD_MEETING_DATE = "meetingdate";
    public static final String SORT_FIELD_MODEL_YEAR = "modelyear";
    public static final String SORT_FIELD_VEHICLE_LINE = "vehicleline";

    // Lead region code for South America - the only lead region that requires FCSD review
    public static final String LEAD_REGION_SA = "SA";

    // Lead Region display name map (region code → full name)
    public static final Map<String, String> LEAD_REGION_MAP = Map.of(
            "NA", "North America",
            "SA", "South America",
            "EU", "Europe",
            "IMG", "International Markets Group",
            "GCH", "Greater China"
    );

    public static final String DATE_FORMAT_DDMMMYYYY = "dd-MMM-yyyy";
    public static final String DATE_FORMAT_YYYYMMDD = "yyyy-MM-dd";
    public static final String DATE_FORMAT_MMMDD_YYYY = "MMM dd, yyyy";
    public static final String MONITOR_COMEBACK_JOB_NAME = "monitor-comeback-date-job";

    public static final String INITIAL_DRAFT_DESC="Initial Draft completed";
    public static final String COLLAB1_DESC="Collab 1 completed";
    public static final String COLLAB2_DESC="Collab 2 completed";
    public static final String INITIAL_DRAFT="initial_draft";
    public static final String COLLAB1="collab1";
    public static final String COLLAB2="collab2";
    public static final String GENERATE_DRAFT="GENERATE_DRAFT";
}