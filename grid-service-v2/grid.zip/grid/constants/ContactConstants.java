package com.ford.grid.constants;

import java.util.Map;

public interface ContactConstants {
    String CCE_TITLE = "cce";
    String MANAGER_TITLE = "manager";
    String FDAUTHOR_TITLE = "14dAuthor";
    String PRE_INVESTIGATION_LEAD_TITLE = "preInvestigationLead";
    String SUPERVISOR_TITLE = "supervisor";
    String CCM_CONTACT = "ccmContact";
    String CCE_CONTACT = "cceContact";
    String ASO_ENGINEER = "asoEngineer";
    String DRI_CONTACT = "driContact";
    String RESPONSIBLE_DIRECTOR = "responsibleDirector";
    String TRG_PRESENTER = "trgPresenter";
    String CRITICAL_PARTICIPANT_SUPPORT = "criticalParticipantSupport";
    String ASO_MONITOR_RESPONSIBLE = "monitor";
    String ASO_LEAD_INVESTIGATOR = "asoLead";
    String RSP_ANALYST = "rspAnalyst";
    String FCSD_PROGRAM_MANAGER = "programManager";
    String EPRC_LEAD_INVESTIGATOR = "eprcLead";
    String PIR_LEAD_INVESTIGATOR = "pirLead";
    String PROGRAM_MANAGER = "Program Manager";
    String FORD_CUSTOMER_SERVICE_DIVISION_FCSD = "Ford Customer Service Division (FCSD)";
    String CRITICAL_CONCERN_MANAGEMENT_CCM = "Critical Concern Management (CCM)";
    String CCE = "CCE";
    String CCM = "CCM";
    String ROOT_CAUSE_OWNERS = "Root Cause Owners";
    String CUSTOMER_SATISFACTION_FORUM_CSF = "Customer Satisfication Forum (CSF)";
    String AUTOMOTIVE_SAFETY_OFFICE_ASO = "Automotive Safety Office (ASO)";
    String EMISSIONS_PROBLEM_REVIEW_COMMITTEE_EPRC = "Emissions Problem Review Committee (EPRC)";
    String EPRC_CHAIR = "EPRC Chair";
    String CSF_CHAIR = "CSF Chair";
    String GCAMP_COORDINATOR = "gcampCoordinator";
    String PSL_SUPPLY_CHAIN = "PS&L Supply Chain";
    String PSL_SUPPLY_CHAIN_ID = "supplyChain";
    String PURCHASE_LEAD_ID = "purchaseLead";
    String SERVICE_STA_ID = "serviceSta";
    String PRODUCTION_STA_ID = "productionSta";
    String IMPL_LEAD_ID = "implLead";
    String CCM_ID = "ccm";
    String EPRC_CHAIR_ID = "eprcChair";
    String CSF_CHAIR_ID = "csfChair";
    String CCRG_CHAIR_ID = "ccrgChair";

    // Part573/Government Document Contact Titles
    String ASO_LEAD_INVESTIGATOR_TITLE = "asoLead";
    String CCRG_CHAIR_TITLE = "ccrgChair";
    String ASSISTANT_DIRECTOR_TITLE = "assistantDirector";
    String CCRG_ATTORNEY_TITLE = "ccrgAttorney";

    String CSF_TRG_EMM_Scheduler = "csfTrgScheduler";
    String EPRC_TRG_EMM_Scheduler = "eprcTrgScheduler";
    String TRG_EMM_Scheduler = "trgScheduler";
    String ROOT_CAUSE_OWNER = "director";
    String FRC_PRESENTER = "frcPresenter";

    // Regional Participation: value → display label mapping
    Map<String, String> REGIONAL_PARTICIPATION_LABELS = Map.of(
            "NA-Meeting Participation Only", "NA",
            "SA-Meeting Participation Only", "SA",
            "EU-Meeting Participation Only", "EU",
            "CHN-Meeting Participation Only", "CHN"
    );
}
