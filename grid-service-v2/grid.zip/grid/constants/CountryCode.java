package com.ford.grid.constants;

public enum CountryCode {
	
	NA("North America", "NA"), 
	EU("Europe", "EU"),
	SA("South America", "SA"), 
	IMG("International Markets Group", "IMG"),
	IMG_GROUPS("International Market Groups", "IMG"), 
	GCH("Greater China", "GCH");

	private final String label;
	private final String value;

	private CountryCode(String label, String value) {
		this.label = label;
		this.value = value;
	}

	public static String getValue(String label) {
		for (CountryCode e : values()) {
			if (e.label.equals(label)) {
				return e.value;
			}
		}
		return null;
	}
	
	public static String getLabel(String val) {
		for (CountryCode e : values()) {
			if (e.value.equals(val)) {
				return e.label;
			}
		}
		return null;
	}
	
	public static String getFullCountry(String val) {
		for (CountryCode e : values()) {
			if (e.value.equals(val)) {
				return e.value +" - "+e.label;
			}
		}
		return null;
	}
	
	public String getLabel() {
		return label;
	}
	
	public String getValue() {
		return value;
	}
}