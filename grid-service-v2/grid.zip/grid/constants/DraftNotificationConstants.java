package com.ford.grid.constants;

/**
 * Constants used by the Draft Notification service.
 */
public final class DraftNotificationConstants {

    private DraftNotificationConstants() {}

    // Notification type — bypass user preference check
    public static final String NOTIFICATION_TYPE_NOT_APPLICABLE = "Not-Applicable";

    // Subject prefix
    public static final String SUBJECT_PREFIX = "Action Request: FSA ";

    // Default fallback values
    public static final String DEFAULT_TITLE_DESCRIPTION = "\u2014";
    public static final String DEFAULT_RECIPIENT_NAME = "User";

    // Template name
    public static final String TEMPLATE_DRAFT_NOTIFICATION = "Template_Draft_Notification";

    // Template variable keys
    public static final String CTX_FSA_NUMBER = "fsaNumber";
    public static final String CTX_FSA_TYPE = "fsaType";
    public static final String CTX_TITLE_DESCRIPTION = "titleDescription";
    public static final String CTX_DOCUMENT_LINKS = "documentLinks";
    public static final String CTX_REVIEW_DEADLINE = "reviewDeadline";
    public static final String CTX_RECIPIENT_NAME = "recipientName";

    // Document detail map keys
    public static final String KEY_FILE_NAME = "fileName";
    public static final String KEY_FILE_LINK = "fileLink";

    // Validation error codes
    public static final String ERR_NO_ISSUE_NUMBER = "NoIssueNumber";
    public static final String ERR_NO_FSA_NUMBER = "NoFsaNumber";
    public static final String ERR_NO_FSA_TYPE = "NoFsaType";
    public static final String ERR_ISSUE_NOT_FOUND = "IssueNotFound";
    public static final String ERR_DRAFT_NOTIFICATION_FAILED = "DraftNotificationFailed";

    // Validation error messages
    public static final String MSG_ISSUE_NUMBER_EMPTY = "Issue number must not be empty";
    public static final String MSG_FSA_NUMBER_EMPTY = "FSA number must not be empty";
    public static final String MSG_FSA_TYPE_EMPTY = "FSA type must not be empty";
    public static final String MSG_ISSUE_NOT_FOUND_PREFIX = "No contacts found for issue '";
    public static final String MSG_DRAFT_NOTIFICATION_FAILED_PREFIX = "Failed to send draft notification email: ";

    // Software type switch values
    public static final String SOFTWARE_FDRS = "FDRS";
    public static final String SOFTWARE_IDS = "IDS";
    public static final String SOFTWARE_OTA = "OTA";
    public static final String SOFTWARE_SETI = "SETI";

    // URL query parameter
    public static final String FILE_QUERY_PARAM = "file=";

    // Review deadline business days
    public static final int REVIEW_DEADLINE_BUSINESS_DAYS = 2;

    // Email regex patterns
    public static final String REGEX_EMAIL_IN_BRACKETS = "<([^>]+)>";
    public static final String REGEX_PLAIN_EMAIL = "[\\w.+-]+@[\\w.-]+\\.[a-zA-Z]{2,}";

    // Ford email domain
    public static final String FORD_EMAIL_SUFFIX = "@ford.com";

    // Contact type
    public static final String CONTACT_TYPE_TO = "TO";
    public static final String CONTACT_TYPE_CC = "CC";

    // Contact category keys (must match "category" field in draft_notification_contacts collection)
    public static final String CAT_GCAMP = "GCAMP";
    public static final String CAT_PSL_SUPPLY = "PSL_SUPPLY";
    public static final String CAT_LABOR_OPS = "LABOR_OPS";
    public static final String CAT_DSSH = "DSSH";
    public static final String CAT_TYRES = "TYRES";
    public static final String CAT_TECH_INSTRUCTIONS = "TECH_INSTRUCTIONS";
    public static final String CAT_BOSCH = "BOSCH";
    public static final String CAT_SERVICE_TOOLS = "SERVICE_TOOLS";
    public static final String CAT_BEV = "BEV";
    public static final String CAT_SOFTWARE_BASE = "SOFTWARE_BASE";
    public static final String CAT_SOFTWARE_FDRS = "SOFTWARE_FDRS";
    public static final String CAT_SOFTWARE_IDS = "SOFTWARE_IDS";
    public static final String CAT_SOFTWARE_OTA = "SOFTWARE_OTA";
    public static final String CAT_SOFTWARE_SETI = "SOFTWARE_SETI";
    public static final String CAT_ESST = "ESST";
    public static final String CAT_STATIC = " ";
}

