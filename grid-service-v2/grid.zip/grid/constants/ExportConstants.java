package com.ford.grid.constants;

import com.itextpdf.io.font.constants.StandardFonts;

public class ExportConstants {

    public static final int
            TWIPS_PER_INCH = 1440;

    public static final String BLUE_COLOR_FRC = "95C8D8";
    public static final String GREY_COLOR_FRC = "C6C6C6";
    public static final String SELECT_YES_NO = "Select Yes/No";
    public static final String SELECT_AN_OPTION = "Select an option";
    public static final String SELECT_LEVEL = "Select Level";
    public static final int HEADER_FONT_SIZE = 12;
    public static final int FOOTER_FONT_SIZE = 8;
    public static final int BODY_FONT_SIZE = 10;
    public static final int BODY_FONT_SIZE_11 = 11;
    public static final String DATE_FORMAT_YYYYMMMDD = "yyyy MMM dd";
    public static final String FOOTER_REVISION = "Revision: HIL 25.01 Template_V1.0";
    public static final String FOOTER_CREATED_BY = "CREATED BY: ";
    public static final String FOOTER_DATE_CREATED = "Date Created: ";
    public static final String FOOTER_NUM_PAGES_MERGE_FORMAT = "NUMPAGES \\* MERGEFORMAT";
    public static final String FOOTER_PAGE_NO_MERGE_FORMAT = "PAGE \\* MERGEFORMAT";
    public static final String FOOTER_PAGE_TXT_OF = " of ";
    public static final String FOOTER_PAGE_TXT = "Page ";
    public static final String FOOTER_GIS2 = "GIS2 Classification: ";
    public static final String FOOTER_GIS1 = "GIS1 Item Number: 23.03";
    public static final String FOOTER_ORIGINATOR = "Originator: Global Recall Implementation Database ";
    public static final String HEADER_TITLE_LR = "Lead Region: ";
    public static final String BLUE_COLOR = "00245c";
    public static final String BLACK_COLOR = "000000";
    public static final String AGENDA_COLOR = "833C0B";
    public static final String AGENDA_ROW = "D9E2F3";
    public static final String AGENDA_DRAFT_COLOR = "4472C4";
    public static final String FONT_LIGHT = "Ford Antenna Light";
    public static final String FONT_LIGHT_PATH = "assets/fonts/FordAntennaWGL-Light.otf";
    public static final String FONT_MEDIUM = "Ford Antenna Medium";

    public static final String TIMES_NEW = "Times New Roman";

    public static final String FORD_ARIAL = "Arial";
    public static final String FONT_MEDIUM_PATH = "assets/fonts/FordAntennaWGL-Medium.otf";
    public static final String OFFICIAL_HDR_TTL = "GRID Official Report ";
    public static final String CLOSURE_RVW_DOC_DRA = "CCRG Closure Note Draft";
    public static final String CLOSURE_RVW_DOC_DRAFT = "CCRG Closure Note - Draft";
    public static final String HEADER_BLUE_COLOR = "00245c";
    public static final String NOTE_HEADER_BLUE_COLOR = "002060";
    public static final String NOTE_LABEL_BLUE_COLOR = "1f3864";
    public static final String HEADER_BLACK_COLOR = "000000";
    public static final String FOOTER_GIS2_VALUE = "Confidential";
    public static final String DESCRIPTION_HEADER = "Description: ";
    public static final String SEGMENT_HEADER = "Segment: ";
    public static final String AFFECTED_VEHICLES_HEADER = "Affected Vehicles: ";
    public static final String FSA_HEADER = "FSA Number: ";
    public static final String INV_TML_CON_HEADER = "Investigation Timeline and Contacts:";
    public static final String DATES_HEADER = "Dates";
    public static final String CONTACTS_HEADER = "Contacts";
    public static final String OPENED_DATE_HEADER = "Open Date: ";
    public static final String CLOSED_DATE_HEADER = "CCRG Closed Date: ";
    public static final String RCO_HEADER = "Root Cause Owner: ";
    public static final String NOTES_HEADER = "Meeting Notes:";
    public static final String FORD_COND_MEDIUM = "Ford Antenna Cond Medium";
    public static final String FORD_COND_LIGHT = "Ford Antenna Cond Light";
    public static final String FORD_COND_LIGHT_PATH_ARIALN_TTF = "assets/fonts/ArialTh.ttf";
    public static final String FORD_COND_LIGHT_PATH = "assets/fonts/FordAntennaCondWGL-Light.otf";
    public static final String LOGO_PATH = "assets/images/fordlogo.jpg";
    public static final String LOGO_PNG_PATH = "assets/images/ford-logo.png";
    public static final String STAMP_PNG_PATH = "assets/images/stamp.png";
    public static final String ERIN_SIGN_PNG_PATH = "assets/images/erin_signature.png";
    public static final String POTENTIALLY_AFFECTED = "assets/images/markets-affected/potentially-affected.png";
    public static final String REGION_AFFECTED = "assets/images/markets-affected/region-affected.png";
    public static final String REQUIRED_INFO = "assets/images/required-information-part573.png";

    public static final String REGIONS = "Regions";

    public static final String PROGRAM = "Program Duration (time/mileage):";
    public static final String REGION_NOT_AFFECTED = "assets/images/markets-affected/region-not-affected.png";
    public static final String POTENTIALLY_AFFECTED_2X = "assets/images/markets-affected/potentially-affected-2x.png";
    public static final String REGION_AFFECTED_2X = "assets/images/markets-affected/region-affected-2x.png";
    public static final String REGION_NOT_AFFECTED_2X = "assets/images/markets-affected/region-not-affected-2x.png";
    public static final String CCRG_TITLE = "Critical Concern Review Group (CCRG) Meeting Agenda";
    public static final String EPRC_TITLE = "Environmental Problem Review Committee (EPRC) Meeting Agenda";
    public static final String CSF_TITLE = "Customer Satisfaction Forum (CSF) Meeting Agenda";
    public static final String TRG_TITLE = "Technical Review Group (TRG) Meeting Agenda";
    public static final String GOVERNMENT_TITLE = "Government Meeting Agenda";
    public static final String LEAD_REGION = "Lead Region:  ";
    public static final String EXTERNAL_ORGANIZATION = "External Organization: ";
    public static final String APPROVING_REGION = "Approving Region:  ";
    public static final String TT_LEAD_REGION = "Lead Region";
    public static final String TT_TIME_EST = "Time (EST)";
    public static final String DATE_TIME = "Date | Time:  ";
    public static final String DATE_LABEL = "Date:  ";
    public static final String DATE_RANGE_LABEL = "Date Range:  ";
    public static final String OTHER_TOPICS = "Other Topics";
    public static final String GCCRG_TITLE = "Global Critical Concern Review Group (GCCRG) Meeting Agenda";

    public static final String GCSF_TITLE = "Global Customer Satisfication Forum (GCSF) Meeting Agenda";
    public static final String FRC_FACTSHEET_TITLE = "Field Review Committee – Fact Sheet";
    public static final String Part573_TITLE = "PART 573 Document";
    public static final String DRAFT = "DRAFT";
    public static final String CONCERN_DESCRIPTION = "Concern Description:";
    public static final String EFFECT_ON_VEHICLE_CUSTOMER = "Effect on Vehicle/Customer:";
    public static final String EFFECT_ON_VEHICLE_CUSTOMER_CONTENT = "An I4 Cylinder Block with insufficient seal on Main Oil Galley Plug at the rear of the Cylinder Block will result in an Oil Leak into the Transmission Bell Housing.  Customer will experience an oil leak beneath vehicle, and Malfunction Indicator Light (MIL) for low oil pressure, which may result in engine seizure due to lack of oil.";
    public static final String ROOT_CAUSE = "Root Cause:";
    public static final String CARD6B = "Suspect Vehicle Population";
    public static final String QUALITY_INDICATOR = "Quality Indicator System Data (Indicate by country or region)";
    public static final String ICA = "Interim Corrective Action";
    public static final String FIELD_REPORT = "Field Reports (Indicate by Country or Region)";
    public static final String NUMBER_ACCIDENT = "Number of accident/fires and injuries attributed to this condition";
    public static final String ROOT_CAUSE_CONTENT = "Root Cause: Still Under Investigation \n" +
            "\n" +
            "Technical- tool was broken on Op 20 spindle 4 which did not allow the block to have the min full thread depth on hole 855\n" +
            "\n" +
            "Detection- Out of tolerance thread gauge check was not reacted to appropriately by production. No Non-Conformance Report (NCR) or containment activity was initiated.\n" +
            "  \n" +
            "Systemic- No checks and balances in place to ensure containment activities are initiated and carried out. Nemak did not follow their documented procedures for containment activities post tooling breaks/repairs.\n";
    public static final String SERVICE_FIX = "Service Fix:";
    public static final String SERVICE_FIX_CONTENT = "";
    public static final String RECOMMENDED_DEMO = "Recommended Demo/Delivery Hold:";
    public static final String MOBILE_SERVICE_REPAIR_CAPABLE = "Mobile Service Repair Capable:";
    public static final String MOBILE_SERVICE_REPAIR_ASSESSMENT_LEVEL = "Mobile Service Repair Assessment Level:";
    public static final String LEVEL = " Level #";
    public static final String PICKUP = "Pick Up and Delivery:";
    public static final String RENTALS = "Rentals:";
    public static final String RENTALS_FUNDED_BY = "Rentals Funded By:";

    public static final String SUPPLIER = "Supplier Responsibility:";

    public static final String PRESENTING = "Presenting Organization:";

    public static final String PRELIMINARY_PREVENT_ACTION = "Preliminary Prevent Action:";
    public static final String PRELIMINARY_PREVENT_ACTION_CONTENT_TABLE = "Prevent actions are still under investigation and will be completed per the PAC process.\n" +
            "\n" +
            "ICA – CEP reviewed the list of suspect blocks from Nemak and determined what blocks had been assembled into engines and vehicles.  All suspect engines, assembled into vehicles had shipped from VO to Dealers and (3) loose blocks at CEP were placed on Quarantine. (31-Jan-2023)\n" +
            "ICA – CEP reviewed rundown traces from the suspect window of 25 blocks.  The first (4) blocks from the suspect window were deemed ok based on torque rundown traces.  This reduced the suspect window from 25 to 21, ((3) loose blocks quarantined at CEP, (2) engines rejected at CEP Oil Cavity Leak Test (OCLT), (2) engines captured at VO, (14) assembled into vehicles and shipped to Dealers)  (01-Feb-2023)\n" +
            "ICA – 3rd Party 100% Gaging all I4 Block holes 855 and 955 (01-Feb-2023) at Nemak AL\n" +
            "ICA – CEP reduced auto R/D retries in station from 5 to 1, which allows 1 auto retry in station, if rundown fails after retry, block is rejected off the line for review (02-Feb-2023)\n";
    public static final String YES = "Yes";
    public static final String STA = "STA";
    public static final String RATIONALE_FOR_MARKETS = "Rationale for Markets Not Included:";
    public static final String RATIONALE_FOR_MARKETS_CONTENT = "(Describe reasons for excluding markets, if applicable)";
    public static final String INCLUDED_MARKET_DETAIL = "Included Market Detail:";
    public static final String COUNTRY = "Country";
    public static final String FORD_NORTH_AMERICA = "FORD - NORTH AMERICA";
    public static final String UNITED_STATES = "UNITED STATES";
    public static final String CHILE = "CHILE";
    public static final String FSAO_SPANISH_COUNTRIES = "FSAO - SPANISH COUNTRIES";
    public static final String RECOMMENDED_ACTION_TYPE = "Recommended Action Type:";
    public static final String GLOBAL_DIRECTOR = "Emily Frascaroli, Global Director";
    public static final String GOVERNMENT_INVESTIGATION = "Government Investigation:";
    public static final String PROGRAM_DURATION = "Program Duration (time/mileage):";
    public static final String NA = "n/a";
    public static final String ONE_YEAR = "1 year";
    public static final String EMPTY = "";
    public static final String NOT_APPLICABLE = "n/a";
    public static final String EUROPE = "Europe";

    public static final String EXPLORER = "Explorer";
    public static final String BRONCO = "Bronco";
    public static final String RANGER = "Ranger";
    public static final String YEAR = "2023";
    public static final String ELEVEN = "11";
    public static final String TWO = "2";
    public static final String CHICAGO = "Chicago";
    public static final String MICHIGAN = "Michigan";
    public static final String DATE_1 = "05-Dec-2022 through 24-Jan-2023";
    public static final String DATE_2 = "03-Dec-2022 through 05-Dec-2022";
    public static final String DATE_3 = "08-Dec-2022";
    public static final String GREATER_CHINA = "Greater China";
    public static final String IMG = "International Markets Group";
    public static final String NORTH_AMERICA = "North America";
    public static final String SOUTH_AMERICA = "South America";
    public static final String REGULATORY_INFLUENCED = "Regulatory Influenced:";
    public static final String SUBJECT = "Subject/Issue: ";
    public static final String FOOTER_ATTACHMENT = "Attachment FAF03-170-X";
    public static final String FOOTER_DATE_ISSUED = "Date Issued: 2020/09/18";
    public static final String FOOTER_DATE_REVISED = "Date Revised:2021/11/08";
    public static final String POPULATION_TITLE = "Population";
    public static final String FOURTEEN = "14(total)";
    public static final String ZERO = "0";
    public static final String THIRTEEN = "13";
    public static final String ONE = "1";
    public static final String VEHICLES = "Vehicles";
    public static final String MY = "MY";
    public static final String MODEL_YEAR = "Model Year";
    public static final String APPROX_VOL = "Approx. Vol.";
    public static final String ASSEMBLY_PLANT = "Assembly Plant";
    public static final String BUILD_DATE_RANGE = "Build Date Range";
    public static final String BUILD_DATE_START = "Build Date Start";
    public static final String BUILD_DATE_END = "Build Date End";

    public static final String ID = "ID";
    public static final String DESCRIPTION = "Description";
    public static final String OBJECTIVE = "Objective";
    public static final String TT_REGION_AFFECTED = "Regions Affected";
    public static final String TT_REGIONS = "NA | EU | SA | IMG | GCH";
    public static final String LEAD = "Lead";
    public static final String EST = "EST";
    public static final String ZERO_DURATION = "0";

    public static final String ISSNBR = "Issue ID";
    public static final String ISSTTL = "Issue Title";
    public static final String IMPTTL = "Implementation Title";
    public static final String FSANUM = "FSA Number";
    public static final String PREAUTH = "Pre Auth";
    public static final String FRCAPPR = "FRC Approval";
    public static final String FRCAPPRDATE = "FRC Approval Date(s)";
    public static final String POPULATION = "Population(s)";
    public static final String OVERVIEW = "Overview";
    public static final String NEXTLINE = "\n";

    // Export Mail Tracking
    public static final String MAIL_SUMMARY = "Mail Tracking Summary";
    public static final String AFFECTED_REGION = "Affected Region";

    public static final String EFFECTONVEHICLE = "Effect on Vehicle Operation";
    public static final String WARNINGINDICTOR = "Warnings or Indicators";
    public static final String REGULATORYIMPACT = "Regulatory Impact";

    public static final String RootCauseA = "Specific Root Cause";
    public static final String RootCauseB = "Root Cause Detection";
    public static final String RootCauseC = "Systemic Root Cause";

    public static final String[] REGULATION_PART = {"part 85", "part 1068"};
    public static final String GEPRC_TITLE = "Global Environmental Problem Review Committee (GEPRC) Meeting Agenda";
    public static final String FONT = StandardFonts.TIMES_ROMAN;

    public static final String INDUSTRY = "Industry";
    public static final String DEFECT_CATEGORY = "Defect Category";
    public static final String MANUFACTURER_REPORT_NAME = "Manufacturer Report Name";
    public static final String MANUFACTURER_REPORT_IDENTIFIER = "Manufacturer Report Identifier";
    public static final int FONT_SIZE_STANDARD = 10;
    public static final int FONT_SIZE_EXTRA_SMALL = 8;
    public static final int FONT_SIZE_SMALL = 9;
    public static final int FONT_SIZE_TINY = 7;
    public static final String CHRONOLOGY_HEADER = "Chronology:";
    public static final String PHASE_HEADER = "Phase";
    public static final String FORUM_HEADER = "Forum";
    public static final String MEETING_DATE_HEADER = "Meeting Date";
    public static final String TITLE_HEADER = "Title";
    public static final String NOTE_HEADER = "Notes:";
    private ExportConstants() {
    }


}
