package com.ford.grid.constants;

public interface FRCFactSheetConstants {

    // Statuses
    String STATUS_DRAFT_PENDING = "DraftPending";
    String STATUS_REVIEWER_PENDING = "ReviewerPending";
    String STATUS_NOTES_PENDING = "NotesPending";
    String STATUS_PENDING = "Pending";
    String STATUS_COMPLETED = "Completed";
    String STATUS_REJECTED = "Rejected";
    String STATUS_CONCLUDED = "Concluded";

    // Role definition IDs
    String ROLEDEFID_READ = "1073741826";
    String ROLEDEFID_EDIT = "1073741830";

    //access types
    String EDIT_ACCESS = "edit";
    String READ_ACCESS = "read";

    // SharePoint API paths
    String API_GET_FOLDER = "GetFolderByServerRelativeUrl('";
    String API_GET_FILE = "GetFileByServerRelativeUrl('";
    String API_BREAK_ROLE_INHERITANCE = "')/ListItemAllFields/breakroleinheritance(true)";
    String API_ADD_ROLE_ASSIGNMENT = "')/ListItemAllFields/roleassignments/addroleassignment(principalid=";
    String API_REMOVE_ROLE_ASSIGNMENT = "')/ListItemAllFields/roleassignments/removeroleassignment(principalid=";
    String API_SITE_USERS_BY_EMAIL = "SiteUsers/getByEmail('";
    String API_SITE_GROUPS_USERS = "sitegroups(4)/users";

    // File naming
    String FILE_SUFFIX = " Fact Sheet Draft -";
    String FILE_EXTENSION_DOCX = ".docx";
    String FILE_VERSION_PREFIX = "-V";

    // Response codes
    String RESPONSE_SUCCESS = "200";
    String RESPONSE_FAILURE = "500";

    // Email templates and notification names
    String EMAIL_NOTIFICATION_DRAFT_READY = "FRC Factsheet Initial Draft Ready";
    String EMAIL_NOTIFICATION_ACCESS_MODIFIED = "FRC Factsheet access modified";
    String EMAIL_TEMPLATE_ACCESS = "Template_FRC_FactSheet_Access";
    String EMAIL_TEMPLATE_DELETE = "Template_FRC_FactSheet_Delete";
    String EMAIL_TEMPLATE_ACCESS_MODIFIED = "Template_FRC_FactSheet_Access_Modified";

}

