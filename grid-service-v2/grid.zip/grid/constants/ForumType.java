package com.ford.grid.constants;

public enum ForumType {
    CCRG("1"),
    CSF("2"),
    EPRC("3"),
    GOVT("4"),
    FD("5"),
    PIR("6");

    private final String code;

    ForumType(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    public static ForumType fromCode(String code) {
        for (ForumType type : values()) {
            if (type.code.equals(code)) {
                return type;
            }
        }
        throw new IllegalArgumentException("Unknown forum type code: " + code);
    }

    public static ForumType fromName(String name) {
        for (ForumType type : values()) {
            if (type.name().equalsIgnoreCase(name)) {
                return type;
            }
        }
        throw new IllegalArgumentException("Unknown forum type name: " + name);
    }

    public static ForumType fromNameOrCode(String value) {
        for (ForumType type : values()) {
            if (type.name().equalsIgnoreCase(value) || type.code.equals(value)) {
                return type;
            }
        }
        throw new IllegalArgumentException("Unknown forum type: " + value);
    }
}
