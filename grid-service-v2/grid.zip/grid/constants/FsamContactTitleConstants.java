package com.ford.grid.constants;

import java.util.LinkedHashMap;
import java.util.Map;

public class FsamContactTitleConstants {

    private FsamContactTitleConstants() {}

    // ── CCRG ──
    public static final String CCRG_CHAIR = "ccrgChair";

    // ── CSF ──
    public static final String CSF_CHAIR  = "csfChair";

    // ── EPRC ──
    public static final String EPRC_CHAIR = "eprcChair";

    // ── GOVT — agency based chair titles ──
    // agency value → contact title in contacts[]
    public static final Map<String, String> GOVT_AGENCY_CHAIR_MAP;
    static {
        GOVT_AGENCY_CHAIR_MAP = new LinkedHashMap<>();
        GOVT_AGENCY_CHAIR_MAP.put("NHTSA",   "invManagerNHTSA");
        GOVT_AGENCY_CHAIR_MAP.put("TC",      "invManagerTC");
        GOVT_AGENCY_CHAIR_MAP.put("KBA",     "invManagerKBA");
        GOVT_AGENCY_CHAIR_MAP.put("KATRI",   "invManagerKATRI");
        GOVT_AGENCY_CHAIR_MAP.put("MLIT",    "invManagerMLIT");
        GOVT_AGENCY_CHAIR_MAP.put("DVSA",    "invManagerDVSA");
        GOVT_AGENCY_CHAIR_MAP.put("ARAI",    "invManagerARAI");
        GOVT_AGENCY_CHAIR_MAP.put("CCNZ",    "invManagerCCNZ");
        GOVT_AGENCY_CHAIR_MAP.put("NZTA",    "invManagerNZTA");
        GOVT_AGENCY_CHAIR_MAP.put("CARB",    "invManagerCARB");
        GOVT_AGENCY_CHAIR_MAP.put("EPA",     "invManagerEPA");
        GOVT_AGENCY_CHAIR_MAP.put("DOT",     "invManagerDOT");
        GOVT_AGENCY_CHAIR_MAP.put("MOTC",    "invManagerMOTC");
        GOVT_AGENCY_CHAIR_MAP.put("SERNAC",  "invManagerSERNAC");
        GOVT_AGENCY_CHAIR_MAP.put("DNDC",    "invManagerDNDC");
        GOVT_AGENCY_CHAIR_MAP.put("VCCA",    "invManagerVCCA");
        GOVT_AGENCY_CHAIR_MAP.put("ACCC",    "invManagerACCC");
        GOVT_AGENCY_CHAIR_MAP.put("ROP",     "invManagerROP");
        GOVT_AGENCY_CHAIR_MAP.put("TISI",    "invManagerTISI");
        GOVT_AGENCY_CHAIR_MAP.put("CIQ",     "invManagerCIQ");
        GOVT_AGENCY_CHAIR_MAP.put("SIC",     "invManagerSIC");
        GOVT_AGENCY_CHAIR_MAP.put("DPAC",    "invManagerDPAC");
        GOVT_AGENCY_CHAIR_MAP.put("MORTH",   "invManagerMORTH");
        GOVT_AGENCY_CHAIR_MAP.put("MVPD",    "invManagerMVPD");
        GOVT_AGENCY_CHAIR_MAP.put("PROCON",  "invManagerPROCON");
        GOVT_AGENCY_CHAIR_MAP.put("INDECOPI","invManagerINDECOPI");
        GOVT_AGENCY_CHAIR_MAP.put("SUNDDE",  "invManagerSUNDDE");
        GOVT_AGENCY_CHAIR_MAP.put("BTRCP",   "invManagerBTRCP");
        GOVT_AGENCY_CHAIR_MAP.put("DPDC",    "invManagerDPDC");
        GOVT_AGENCY_CHAIR_MAP.put("DITRDDC", "invManagerDITRDC");
        GOVT_AGENCY_CHAIR_MAP.put("MOLIT",   "invManagerMOLIT");
        GOVT_AGENCY_CHAIR_MAP.put("MOT",     "invManagerMOT");
        GOVT_AGENCY_CHAIR_MAP.put("MC",      "invManagerMC");
        GOVT_AGENCY_CHAIR_MAP.put("MP",      "invManagerMP");
        GOVT_AGENCY_CHAIR_MAP.put("MOIT",    "invManagerMOIT");
        GOVT_AGENCY_CHAIR_MAP.put("MOE",     "invManagerMOE");
        GOVT_AGENCY_CHAIR_MAP.put("VR",      "invManagerVR");
        GOVT_AGENCY_CHAIR_MAP.put("NCC",     "invManagerNCC");
        GOVT_AGENCY_CHAIR_MAP.put("MTRS",    "invManagerMTRS");
        GOVT_AGENCY_CHAIR_MAP.put("OCPB",    "invManagerOCPB");
    }

    // ── Root cause owner groupId in customContacts ──
    public static final String ROOT_CAUSE_OWNERS = "rootCauseOwners";

    /**
     * Resolve GOVT chair title based on agency.
     * "NHTSA" → "invManagerNHTSA"
     * "TC"    → "invManagerTC"
     * If agency not found → fallback "invManagerNHTSA"
     */
    public static String resolveGovtChairTitle(String agency) {
        if (agency == null || agency.isBlank()) {
            return "invManagerNHTSA";           // default fallback
        }
        return GOVT_AGENCY_CHAIR_MAP.getOrDefault(
                agency.trim().toUpperCase(),
                "invManager" + agency.trim()); // dynamic fallback
    }
}

