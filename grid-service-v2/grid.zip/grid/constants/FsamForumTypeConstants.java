package com.ford.grid.constants;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class FsamForumTypeConstants {

    private FsamForumTypeConstants() {}

    // ── View stores forumType as numeric strings ──
    public static final String FORUM_CCRG = "1";
    public static final String FORUM_CSF  = "2";
    public static final String FORUM_EPRC = "3";
    public static final String FORUM_GOVT = "4";
    public static final String FORUM_PIR  = "6";

    // ── Numeric → Label mapping ──
    public static final Map<String, String> FORUM_TYPE_LABEL_MAP;
    static {
        FORUM_TYPE_LABEL_MAP = new LinkedHashMap<>();
        FORUM_TYPE_LABEL_MAP.put("1", "CCRG");
        FORUM_TYPE_LABEL_MAP.put("2", "CSF");
        FORUM_TYPE_LABEL_MAP.put("3", "EPRC");
        FORUM_TYPE_LABEL_MAP.put("4", "GOVT");
        FORUM_TYPE_LABEL_MAP.put("6", "PIR");
    }

    // ── Label → Numeric mapping (for query building) ──
    public static final Map<String, String> FORUM_LABEL_TO_CODE_MAP;
    static {
        FORUM_LABEL_TO_CODE_MAP = new LinkedHashMap<>();
        FORUM_LABEL_TO_CODE_MAP.put("CCRG",       "1");
        FORUM_LABEL_TO_CODE_MAP.put("CSF",         "2");
        FORUM_LABEL_TO_CODE_MAP.put("EPRC",        "3");
        FORUM_LABEL_TO_CODE_MAP.put("GOVT",        "4");
        FORUM_LABEL_TO_CODE_MAP.put("GOVERNMENT",  "4");
        FORUM_LABEL_TO_CODE_MAP.put("PIR",         "6");
    }

    // ── All forum codes for fetching everything ──
    public static final List<String> ALL_FORUM_CODES =
            new ArrayList<>(FORUM_TYPE_LABEL_MAP.keySet()); // ["1","2","3","4"]

    /**
     * Converts label to view code.
     * "CCRG" → "1", "CSF" → "2", "EPRC" → "3", "GOVT" → "4"
     * Returns input as-is if already a code.
     */
    public static String toForumCode(String input) {
        if (input == null) return null;
        return FORUM_LABEL_TO_CODE_MAP.getOrDefault(
                input.trim().toUpperCase(), input.trim());
    }

    /**
     * Converts view code to label.
     * "1" → "CCRG", "2" → "CSF", "3" → "EPRC", "4" → "GOVT"
     * Returns input as-is if not found.
     */
    public static String toForumLabel(String code) {
        if (code == null) return null;
        return FORUM_TYPE_LABEL_MAP.getOrDefault(code.trim(), code.trim());
    }

    /**
     * Converts list of labels to list of view codes.
     * ["CCRG", "CSF"] → ["1", "2"]
     */
    public static List<String> toForumCodes(List<String> labels) {
        if (labels == null || labels.isEmpty()) return ALL_FORUM_CODES;
        List<String> codes = new ArrayList<>();
        for (String label : labels) {
            codes.add(toForumCode(label));
        }
        return codes;
    }
}