package com.ford.grid.constants;

public interface GovDocumentsConstants {

    // ── Document Types ────────────────────────────────────────────────────
    String DOC_TYPE_PART573 = "PART573";
    String DOC_TYPE_TC      = "TC";

    // ── Workflow Statuses (docStatus / request.status) ───────────────────
    String STATUS_DRAFT_PENDING     = "DraftPending";
    String STATUS_REVIEWER_PENDING  = "ReviewerPending";
    String STATUS_NOTES_PENDING     = "NotesPending";
    String STATUS_PENDING           = "Pending";
    String STATUS_COMPLETED         = "Completed";
    String STATUS_REJECTED          = "Rejected";
    String STATUS_CONCLUDED         = "Concluded";

    // ── Approval Status values (stored in Part573File.approvalStatus) ────
    String APPROVAL_STATUS_DRAFT_REVIEW_PENDING    = "DRAFT_REVIEW_PENDING";
    String APPROVAL_STATUS_DRAFT_REVIEW_REJECTED   = "DRAFT_REVIEW_REJECTED";
    String APPROVAL_STATUS_APPROVAL_PENDING        = "APPROVAL_PENDING";
    String APPROVAL_STATUS_APPROVAL_REJECTED       = "APPROVAL_REJECTED";
    String APPROVAL_STATUS_FINAL_REVIEW_PENDING    = "FINAL_REVIEW_PENDING";
    String APPROVAL_STATUS_FINAL_REVIEW_REJECTED   = "FINAL_REVIEW_REJECTED";
    String APPROVAL_STATUS_APPROVED_FOR_SIGNATURE  = "APPROVED_FOR_SIGNATURE";
    String APPROVAL_STATUS_SENT_TO_DOCUSIGN        = "SENT_TO_DOCUSIGN";
    String APPROVAL_STATUS_SIGNED                  = "SIGNED";
    String APPROVAL_STATUS_CONCLUDED               = "CONCLUDED";

    // ── Per-stage status flags ────────────────────────────────────────────
    String STAGE_STATUS_PENDING  = "PENDING";
    String STAGE_STATUS_APPROVED = "APPROVED";
    String STAGE_STATUS_REJECTED = "REJECTED";

    // ── DocuSign ──────────────────────────────────────────────────────────
    String DOCUSIGN_STATUS_SENT      = "sent";
    String DOCUSIGN_STATUS_COMPLETED = "completed";
    String DOCUSIGN_EMAIL_SUBJECT    = "Important: Part 573 Document ready to sign";
    String DOCUSIGN_EMAIL_SUBJECT_TC = "Important: TC Document ready to sign";
    String DOCUSIGN_SIGN_DOC_ID      = "1";
    String DOCUSIGN_SIGN_PAGE        = "1";
    String DOCUSIGN_SIGN_X           = "40";
    String DOCUSIGN_SIGN_Y           = "640";
    String DOCUSIGN_RECIPIENT_ID     = "1";
    String DOCUSIGN_FILE_EXTENSION   = "docx";
    String DOCUSIGN_API_PATH         = "/v2.1/accounts/";
    String DOCUSIGN_ENVELOPES_PATH   = "/envelopes/";
    String DOCUSIGN_DOCUMENTS_PATH   = "/documents/1";

    // ── Email / Audit ─────────────────────────────────────────────────────
    String FORD_EMAIL_DOMAIN      = "@ford.com";
    String SYSTEM_USER            = "SYSTEM";
    String PART573_LEADS_KEY      = "PART_573_LEADS";
    String TC_LEADS_KEY           = "TC_LEADS";

    // ── GCS paths ─────────────────────────────────────────────────────────
    String GCS_PART573_FOLDER = "Part573/";
    String GCS_TC_FOLDER      = "TcDoc/";

    // ── Mail template names ───────────────────────────────────────────────
    String TEMPLATE_PART573_APPROVAL_REQUEST    = "Template_Part573_Approval_Request";
    String TEMPLATE_PART573_CREATION            = "Template_Part573_Creation_Notification";
    String TEMPLATE_TC_CREATION                 = "Template_TC_Creation_Notification";

    // DocuSign — signature request (sent to signer when doc goes to DocuSign)
    String TEMPLATE_PART573_DOCUSIGN_NOTIFICATION = "Template_DocuSign_Notification";
    String TEMPLATE_TC_DOCUSIGN_NOTIFICATION      = "Template_TC_DocuSign_Notification";

    // DocuSign — signed completion (sent to leads when DocuSign reports completed)
    String TEMPLATE_PART573_DOCUSIGN_SIGNED = "docusign-signed-notification";
    String TEMPLATE_TC_DOCUSIGN_SIGNED      = "docusign-tc-signed-notification";

    // ── Mail notification names ───────────────────────────────────────────
    String NOTIFICATION_NAME_PART573_CREATED  = "Part573 Document Created";
    String NOTIFICATION_NAME_PART573_APPROVAL = "Part 573 Approval Request";

    // ── SharePoint API paths ──────────────────────────────────────────────
    String API_GET_FOLDER            = "GetFolderByServerRelativeUrl('";
    String API_GET_FILE              = "GetFileByServerRelativeUrl('";
    String API_BREAK_ROLE_INHERITANCE = "')/ListItemAllFields/breakroleinheritance(true)";
    String API_ADD_ROLE_ASSIGNMENT    = "')/ListItemAllFields/roleassignments/addroleassignment(principalid=";
    String API_REMOVE_ROLE_ASSIGNMENT = "')/ListItemAllFields/roleassignments/removeroleassignment(principalid=";
    String API_SITE_USERS_BY_EMAIL    = "SiteUsers/getByEmail('";
    String API_SITE_GROUPS_USERS      = "sitegroups(4)/users";

    // ── Permission types ──────────────────────────────────────────────────
    String EDIT_ACCESS = "Edit";
    String READ_ACCESS = "Read";

    // ── SharePoint role definition IDs ────────────────────────────────────
    String ROLEDEFID_READ = "1073741826";
    String ROLEDEFID_EDIT = "1073741830";

}
