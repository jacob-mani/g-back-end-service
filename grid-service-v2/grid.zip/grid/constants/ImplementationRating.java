package com.ford.grid.constants;

import com.fasterxml.jackson.annotation.JsonCreator;
import lombok.Getter;

@Getter
public enum ImplementationRating {
    RED("Red"),
    YELLOW("Yellow"),
    GREEN("Green");

    private final String displayName;

    ImplementationRating(String displayName) {
        this.displayName = displayName;
    }
    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static ImplementationRating fromDisplayName(String displayName) {
        for (ImplementationRating rating : ImplementationRating.values()) {
            if (rating.displayName.equalsIgnoreCase(displayName)) {
                return rating;
            }
        }
        throw new IllegalArgumentException("Invalid implementation rating: " + displayName);
    }
}
