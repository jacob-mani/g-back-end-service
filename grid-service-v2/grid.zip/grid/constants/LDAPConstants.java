package com.ford.grid.constants;

public interface LDAPConstants {
    String UID = "uid";
    String EMPLOYEE = "ou=Employee,ou=People,o=Ford,c=US";
    String FIRST_NAME = "givenName";
    String LAST_NAME = "sn";
    String DISPLAY_NAME = "fordDisplayName";
    String[] FIND_NAME = new String[]{UID, DISPLAY_NAME, FIRST_NAME, LAST_NAME};
    int SEARCH_RESULT_SIZE = 100;
}