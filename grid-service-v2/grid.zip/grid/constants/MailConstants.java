package com.ford.grid.constants;

public interface MailConstants {
    String FORD_COM = "@ford.com";
    String TEST_MAIL_SUBJECT_PREFIX = "THIS IS A TEST EMAIL - NO ACTION REQUIRED.";
    String ISSUE_NUMBER = "issueNumber";

    String FILE_NAME = "fileName";
    String BASE_URL = "BaseURL";
    String CHECKLIST_PATH_CONSTANT = "checklistPath";
    String CHECKLIST_URL = "/checklist";

    String EMAIL_NOTIFICATION_TYPE = "action";

    String EMAIL_FAILED="Send email failed >>> Pre Auth Approval";
    // Mail sender
    String MAIL_SENDER_GRIDDEV = "griddev";

    String NOTIFICATION_NAME_GCAMP_APPROVAL_COMPLETED = "Template_GCAMP_Approval_Completion";
    String NOTIFICATION_POPULATION_CHANGE = "Population Change Post FRC Approval";

    // Mail subject prefixes
    String SUBJECT_PRE_AUTH_APPROVAL = " PreAuthorization Approval Mail - ";

    // Mail templates
    String TEMPLATE_PRE_AUTHORIZATION_NOTES_NOTIFICATION = "Template_PreAuthorization_Notes_Notification";
    String TEMPLATE_APPROVAL_FINANCE = "Template_Approval_Finance";
    String TEMPLATE_PRE_AUTHORIZATION_APPROVAL = "Template_PreAuthorization_Approval";
    String TEMPLATE_VERN_EXTRACT_REVIEW = "Template_Vern_Extract_Review";
    String TEMPLATE_FDRREPORT_REVIEW="Template_FDRReport_Review";

    // Mail context variables
    String CONTEXT_FILE_URL = "fileURL";
    String CONTEXT_ISSUE_NUMBER = "issueNumber";
    String CONTEXT_FSA_NUMBER = "fsaNumber";
    String CONTEXT_FORUM_TYPE = "forumType";
    String CONTEXT_NOTES = "notes";

    // Notification types
    String NOTIFICATION_TYPE_ACTION_USER = "Action - user";
    String NOTIFICATION_TYPE_ACTION_INFO = "Action - Info";
    String NOTIFICATION_TYPE_ACTION = "action";

    // Notification names
    String NOTIFICATION_NAME_PRE_AUTH_STEP_2 = "Pre Auth Step 2";
    String NOTIFICATION_NAME_PRE_AUTH_STEP_3 = "Pre Auth Step 3";
    String NOTIFICATION_NAME_PRE_AUTH_STEP_4 = "Pre Auth Step 4";
    String NOTIFICATION_NAME_PRE_AUTH_STEP_6 = "Pre Auth Finance Approval";
    String NOTIFICATION_NAME_PRE_AUTH_STEP_7 = "Pre Auth Step 7";
    String NOTIFICATION_NAME_GOVERNMENT_NHTSA_MONITOR_UPDATED = "Government-NHTSA Monitor Updated";
    String NOTIFICATION_NAME_GOVERNMENT_TC_MONITOR_UPDATED = "Government-TC Monitor Updated";
    String NOTIFICATION_NAME_VERN_EXTRACT_REVIEW = "VERN Review Pending";
    String NOTIFICATION_EMM = "EMM Requested";

    // Mail subject
    String SUBJECT_VERN_EXTRACT_REVIEW = "VERN Extract Review for Issue ";
    String REFRESH_IN_STOCK_SUBMITTED= "Refresh In Stock Submitted";
    String REFRESH_IN_STOCK_RECEIVED= "Refresh In Stock Received";

    // Notification names — must match the notificationName field in MongoDB notification_preferences collection exactly
    // DB notificationId=61, type="action"
    String CCM_REVIEW_COMPLETED= "Closure Notes Review Completed for GRID";
    // DB notificationId=60, type="action"
    String CCM_REVIEW_PENDING= "Closure Notes Review Needed";
    // DB notificationId=84, type="Action - Info"
    String FACT_SHEET_REVIEW_COMPLETED= "Fact Sheet Final Review Completed";
    // DB notification type for FACT_SHEET_REVIEW_COMPLETED (id=84)
    String NOTIFICATION_TYPE_FACT_SHEET_REVIEW_COMPLETED= NOTIFICATION_TYPE_ACTION_INFO;
    // DB notificationId=73, type="action"
    String FACT_SHEET_REJECTION= "Fact Sheet Rejected";
    // DB notificationId=72, type="action"
    String FACT_SHEET_APPROVAL_REQUEST= "Added for Fact Sheet Review";
    // DB notificationId=71, type="action"
    String FACT_SHEET_READY_FOR_FINAL_REVIEW= "Fact Sheet Ready for Final Review";
    // DB notificationId=66, type="action"
    String FACT_SHEET_ACCESS_GRANTED= "FRC Factsheet Initial Draft Ready";
    // DB notificationId=67, type="action"
    String FACT_SHEET_ACCESS_MODIFIED= "FRC Factsheet access modified";

    // DB notificationId=41, type="Action - Info"
    String NOTIFICATION_NAME_PARTS_CONFIRMED = "Parts Confirmed";
    // DB notificationId=42, type="Action - Info"
    String NOTIFICATION_NAME_PARTS_REQUESTED = "Parts Requested";
    // DB notificationId=43, type="Action - Info"
    String NOTIFICATION_NAME_PARTS_REVOKED = "Parts Revoked";
    // DB notificationId=83, type="Action - Info"
    String NOTIFICATION_NAME_PURCHASING_SUPPORT_STATUS = "Purchasing Support Required Status";
    // DB notificationId=25, type="Action - user"
    String NOTIFICATION_NAME_FSA_STOP_SHIP = "FSA has Stop ship number";
    // DB notificationId=50, type="Action"
    String NOTIFICATION_TYPE_FDR_REVIEW = "Action";
    // DB notificationId=50, name
    String NOTIFICATION_NAME_FDR_REVIEW = "Submit FSA for FDR Review for Issue Number";

    // Weekly Report
    String WEEKLY_REPORT_SUBJECT = "Details of GRID ID which has the FSA & Stop ship no";
    String TEMPLATE_WEEKLY_REPORT = "Template_Weekly_Report";
    String NOTIFICATION_NAME_WEEKLY_STOP_SHIP_REPORT = "Weekly Stop Ship FSA Report";
}