package com.ford.grid.constants;

import java.util.Optional;

public enum NotificationTypesConstants {

	NFT01("1", "14D Requested"),
	NFT02("2", "14D Scheduled"),
	NFT03("3", "Added to Issue Contacts"),
	NFT04("4", "Affected Regions Identified"),
	NFT05("5", "Approval Required for EPRC Fact Sheet"),
	NFT06("6", "CCRG Closure Review"),
	NFT07("7", "CCRG Monitor Updated"),
	NFT08("8", "CCRG Post FSA Monitor Updated"),
	NFT09("9", "CCRG Requested"),
	NFT10("10", "CCRG Scheduled"),
	NFT11("11", "Confirm Cost Estimate"),
	NFT12("12", "CSF Monitor Updated"),
	NFT13("13", "CSF Requested"),
	NFT14("14", "CSF Scheduled"),
	NFT15("15", "EMM/TR Requested"),
	NFT16("16", "EMM/TR Scheduled"),
	NFT17("17", "EPRC Defect Report Approval Request"),
	NFT18("18", "EPRC Monitor Updated"),
	NFT19("19", "EPRC Requested"),
	NFT20("20", "EPRC Scheduled"),
	NFT21("21", "FRC Fact Sheet Upload Request"),
	NFT22("22", "FRC Memo Scheduled"),
	NFT23("23", "FRC Requested"),
	NFT24("24", "FRC Scheduled"),
	NFT25("25", "FSA has Stop ship number"),
	NFT26("26", "GCCRG Scheduled"),
	NFT27("27", "GCSF Scheduled"),
	NFT28("28", "Government Submission Due"),
	NFT29("29", "Government-CARB Requested"),
	NFT30("30", "Government-DPAC Monitor Updated"),
	NFT31("31", "Government-NHTSA Monitor Updated"),
	NFT32("32", "Government-NHTSA Requested"),
	NFT33("33", "Government-NHTSA Scheduled"),
	NFT34("34", "Government-TC Monitor Updated"),
	NFT35("35", "Government-TC Requested"),
	NFT36("36", "Government-TC Scheduled"),
	NFT37("37", "Launch Initiated"),
	NFT38("38", "New issue added to My Issues"),
	NFT39("39", "New user requested for access"),
	NFT40("40", "Owner Letter Due"),
	NFT41("41", "Parts Confirmed"),
	NFT42("42", "Parts Requested"),
	NFT43("43", "Parts Revoked"),
	NFT44("44", "Pre Auth Step 1"),
	NFT45("45", "Pre Auth Step 2"),
	NFT46("46", "Pre Auth Step 3"),
	NFT47("47", "Pre Auth Step 4"),
	NFT48("48", "Pre Auth Step 7"),
	NFT49("49", "Schedule TRG Due"),
	NFT50("50", "Submit FSA for FDR Review for Issue Number"),
	NFT51("51", "Supplement Initiated"),
	NFT52("52", "TRG Requested"),
	NFT53("53", "TRG Scheduled"),
	NFT54("54", "VERN Extract Received"),
	NFT55("55", "VERN Review Pending"),
	
	NFT56("56", "Potential OTA Capability Required"),
	NFT57("57", "OTA JIRA request completed"),
	NFT58("58", "Approval required for EPRC Defect Report"),
	NFT59("59", "EPRC Defect Report Approved"),
	NFT60("60", "Closure Notes review Needed"),
	NFT61("61", "Closure Notes review Completed for GRID"),
	NFT62("62", "Pre Auth Finance Approval"),
	NFT63("63", "VERN Extract Received / Refresh In Stock Received"),
	NFT64("64", "Population Change Post FRC Approval"),
	NFT65("65", "Part Cost needed for Pre-Auth"),
	NFT66("66", "FRC Factsheet Initial Draft Ready"),
	NFT67("67", "FRC Factsheet access modified"),
	NFT68("68", "Fact Sheet Collab needed"),
	NFT69("69", "Fact Sheet returned to draft"),
	NFT70("70", "Fact Sheet Approved for Final Review"),
	NFT71("71", "Fact Sheet Ready for Final Review"),
	NFT72("72", "Added for Fact Sheet Review"),
	NFT73("73", "Fact Sheet Rejected"),
	NFT74("74", "PAC is Approved"),
	NFT75("75", "Issue set to Monitor"),
	NFT76("76", "Refresh In Stock Received"),
	NFT77("77", "Refresh In Stock Submitted"),
	NFT78("78", "EPRC FactSheet Submission"),
	NFT79("79", "OTA FSA approval notification for GRID Issue"),
	NFT80("80", "FRC Reminder"),

	NFT81("81", "Quality Problem Solver Engineer Assigned"),
	NFT82("82", "Dealer Notification for Extended Timings Due"),
	NFT83("83", "Purchasing Support Required Status"),
	NFT84("84", "Fact Sheet Final Review Completed");
	private final String id;
	private final String name;
	
	public String getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	NotificationTypesConstants(String id, String name) {
		this.id = id;
		this.name = name;
	}
	
	public static Optional<String> findNameById(String id) {
		for (NotificationTypesConstants e : values()) {
			if (e.id.equals(id)) {
				return Optional.of(e.name);
			}
		}
		return Optional.empty();
	}

	public static Optional<String> findIdByName(String name) {
		for (NotificationTypesConstants e : values()) {
			if (e.name.equals(name)) {
				return Optional.of(e.id);
			}
		}
		return Optional.empty();
	}

	public static String getNameById(String id) {
		return findNameById(id).orElse(null);
	}

	public static String getIdByName(String name) {
		return findIdByName(name).orElse(null);
	}

	/**
	 * @deprecated Use {@link #getNameById(String)} or {@link #findNameById(String)}.
	 */
	@Deprecated
	public static String getId(String id) {
		return getNameById(id);
	}

	/**
	 * @deprecated Use {@link #getIdByName(String)} or {@link #findIdByName(String)}.
	 */
	@Deprecated
	public static String getName(String name) {
		return getIdByName(name);
	}
}
