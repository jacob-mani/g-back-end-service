package com.ford.grid.constants;

/**
 * Constants for PSNL Dashboard.
 */
public interface PSNLDashboardConstants {

    // Program types
    String PROGRAM_TYPE_NON_APPROVED = "nonApproved";
    String PROGRAM_TYPE_APPROVED = "approved";
    String PROGRAM_TYPE_LAUNCHED = "launched";

    // Part transfer
    String TRANSFER_INFO_FORMAT = "Requested from %s to %s by %s on %s";
    String DUPLICATE_COUNTRY_TRANSFER_ERROR = "Countries already transferred for part %s from %s: %s";
    String TRANSFER_NOT_FOUND_ERROR = "Part transfer request not found with id: %s";
    String CONFIRM_PARTS_REQUIRED_ERROR = "No data found for populationId: %s. Please confirm parts in Card 9.";

     // Part transfer mail
    String PARTS_REQUESTED_SUBJECT = "Parts Requested";
    String PARTS_REQUESTED_TEMPLATE = "Template_PSNL_Parts_Requested";
    String PARTS_REVOKED_SUBJECT = "Parts Revoked";
    String PARTS_REVOKED_TEMPLATE = "Template_PSNL_Parts_Revoked";

    // Purchasing support required status mail
    String PURCHASING_SUPPORT_SUBJECT_PREFIX = "Status Change: ";
    String PURCHASING_SUPPORT_TEMPLATE = "Template_PSNL_Purchasing_Support_Status";

    // Excel export
    String EXCEL_REPORT_RESPONSE = "Report will be sent to your email shortly";
    String EXCEL_MAIL_SUBJECT = "Generated Part report";
    String EXCEL_MAIL_TEMPLATE = "Template_PSNL_Part_Report";
    String EXCEL_SHEET_OVERVIEW = "Overview";
    String EXCEL_SECTION_PARTS_OVERVIEW = "PARTS OVERVIEW";
    String EXCEL_SECTION_VEHICLE_PROFILE = "VEHICLE PROFILE";
    String EXCEL_SECTION_REGION_PARTS = "REGION-LEVEL PART DETAILS";
    String EXCEL_SECTION_COUNTRY_BREAKDOWN = "COUNTRY-LEVEL BREAKDOWN";
    String EXCEL_PARTS_PROCURED_PREFIX = "Parts Procured - ";

    // Bulk report
    String EXCEL_BULK_MAIL_SUBJECT = "Overall Part Report";
    String EXCEL_BULK_SHEET_NAME = "Overall Part Report";
    String EXCEL_BULK_FAILURE_SUBJECT = "PSNL Bulk Report - Generation Failed";
    String EXCEL_BULK_FAILURE_TEMPLATE = "Template_PSNL_Bulk_Report_Failure";
}
