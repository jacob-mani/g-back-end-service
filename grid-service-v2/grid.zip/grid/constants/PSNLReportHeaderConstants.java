package com.ford.grid.constants;

import java.util.List;

/**
 * Constants for PSNL Report Excel headers.
 * To reorder columns, simply reorder entries in HEADERS list.
 * No code changes needed in row builder - it uses header names as map keys.
 */
public final class PSNLReportHeaderConstants {

    private PSNLReportHeaderConstants() {
        // Utility class - prevent instantiation
    }

    public static final String ACTUAL_DATE = "Actual Date";
    public static final String CAUSAL_PART = "Causal Part";
    public static final String CRITICAL_PART = "Critical Part";
    public static final String CRITICAL_PART_LAUNCH_STRATEGY = "Critical Part Launch Strategy";
    public static final String ENGINEERING_PART_NUMBER = "Engineering Part Number";
    public static final String ESCALATION_TO_LEADERSHIP = "Escalation To Leadership";
    public static final String FCSD_PURCHASE_LEAD = "FCSD Purchase Lead";
    public static final String FINIS_CODE = "Finis Code";
    public static final String FORECAST = "Forecast";
    public static final String FREIGHT_METHOD = "Freight Method";
    public static final String FSA_NO = "FSA No";
    public static final String FSA_TYPE = "FSA Type";
    public static final String IMPLEMENTATION_LEAD = "Implementation Lead";
    public static final String IMPLEMENTATION_NAME = "Implementation Name";
    public static final String IMPL_ID = "Impl Id";
    public static final String ISSUE_NO = "Issue No";
    public static final String ISSUE_TITLE = "Issue Title";
    public static final String KIT_REQUIRED = "Kit Required";
    public static final String LAUNCH_QTY_SOLD = "Launch Qty Sold";
    public static final String LAUNCH_QTY_TOTAL = "Launch Qty Total";
    public static final String LAUNCH_QTY_UNSOLD = "Launch Qty UnSold";
    public static final String LEAD_TIME_MONTH = "Lead Time Month";
    public static final String MARKET_COUNTRY = "Market Country";
    public static final String MODEL_YEAR_BRAND_VEHICLE_LINE = "Model Year Brand Vehicle Line";
    public static final String NET_IN_STOCK_QUANTITY = "Net In Stock Quantity";
    public static final String ONE_TIME_PART = "One Time Part";
    public static final String ORDER_QUANTITY = "Order Quantity";
    public static final String OVERALL_PARTS_AVAILABLE_STATUS_COMMENTS = "Overall Parts Available Status Comments";
    public static final String PART_COMMENT = "Part Comment";
    public static final String PART_NAME = "Part Name";
    public static final String PART_OK = "Part Ok";
    public static final String PART_QTY_SOLD = "Part Qty Sold";
    public static final String PART_QTY_TOTAL = "Part Qty Total";
    public static final String PART_QTY_UNSOLD = "Part Qty UnSold";
    public static final String PART_STATUS = "Part Status";
    public static final String PART_TYPE = "Part Type";
    public static final String PARTS_CONFIRM_COMMENTS = "Parts Confirm Comments";
    public static final String PARTS_CONFIRMED_BY = "Parts Confirmed By";
    public static final String PARTS_CONFIRMED_ON = "Parts Confirmed On";
    public static final String PARTS_PRICE = "Parts Price";
    public static final String PDC = "PDC";
    public static final String POPULATION_ID = "Population Id";
    public static final String POTENTIAL_FSA_TYPE = "Potential FSA Type";
    public static final String PRE_AUTH_APPROVED_BY = "Pre Auth Approved By";
    public static final String PRE_AUTH_APPROVED_DATE = "Pre Auth Approved Date";
    public static final String PRE_AUTH_REQUESTED_BY = "Pre Auth Requested By";
    public static final String PRE_AUTH_REQUESTED_DATE = "Pre Auth Requested Date";
    public static final String PRODUCTION_STA = "Production STA";
    public static final String PROGRAM_TYPE = "Program Type";
    public static final String PSL_SUPPLY_CHAIN = "PS&L Supply Chain";
    public static final String PSNL_SIGNOFF_DATE = "PSNL Signoff Date";
    public static final String PURCHASING_NOTES = "Purchasing Notes";
    public static final String PURCHASING_SUPPORT_REQUIRED = "Purchasing Support Required";
    public static final String REGION = "Region";
    public static final String RELATED_DAMAGED_PART = "Related Damaged Part";
    public static final String REQUESTED_BY = "Requested By";
    public static final String REQUESTED_DATE = "Requested Date";
    public static final String REQUESTED_REGION = "Requested Region";
    public static final String RSP_ANALYST = "RSP Analyst";
    public static final String SCM_NOTES = "SCM Notes";
    public static final String SCM_RATING = "SCM Rating";
    public static final String SERVICE_PART_NUMBER = "Service Part Number";
    public static final String SERVICE_STA = "Service STA";
    public static final String SOLD_VEHICLE_COUNT = "Sold Vehicle Count";
    public static final String STOCK_STATUS = "Stock Status";
    public static final String SUPPLIER_CODE = "Supplier Code";
    public static final String SUPPLIER_NAME = "Supplier Name";
    public static final String TARGET_QUARTER = "Target Quarter";
    public static final String TOTAL_VEHICLE_COUNT = "Total Vehicle Count";
    public static final String UNSOLD_VEHICLE_COUNT = "UnSold Vehicle Count";
    public static final String VERN_NO = "Vern No";
    public static final String CON_PDC_MAP = "Country PDC Mapping";
    public static final String PDC_CON_MAP = "PDC Country Mapping";

    /**
     * Ordered list of headers for Bulk (Overall) Report.
     * Reorder entries below to change column order in Excel.
     */
    public static final List<String> HEADERS = List.of(
            ACTUAL_DATE,
            CAUSAL_PART,
            CRITICAL_PART,
            CRITICAL_PART_LAUNCH_STRATEGY,
            ENGINEERING_PART_NUMBER,
            ESCALATION_TO_LEADERSHIP,
            FCSD_PURCHASE_LEAD,
            FINIS_CODE,
            FORECAST,
            FREIGHT_METHOD,
            FSA_NO,
            FSA_TYPE,
            IMPLEMENTATION_LEAD,
            IMPLEMENTATION_NAME,
            IMPL_ID,
            ISSUE_NO,
            ISSUE_TITLE,
            KIT_REQUIRED,
            LAUNCH_QTY_SOLD,
            LAUNCH_QTY_TOTAL,
            LAUNCH_QTY_UNSOLD,
            LEAD_TIME_MONTH,
            MARKET_COUNTRY,
            MODEL_YEAR_BRAND_VEHICLE_LINE,
            NET_IN_STOCK_QUANTITY,
            ONE_TIME_PART,
            ORDER_QUANTITY,
            OVERALL_PARTS_AVAILABLE_STATUS_COMMENTS,
            PART_COMMENT,
            PART_NAME,
            PART_OK,
            PART_QTY_SOLD,
            PART_QTY_TOTAL,
            PART_QTY_UNSOLD,
            PART_STATUS,
            PART_TYPE,
            PARTS_CONFIRM_COMMENTS,
            PARTS_CONFIRMED_BY,
            PARTS_CONFIRMED_ON,
            PARTS_PRICE,
            PDC,
            POPULATION_ID,
            POTENTIAL_FSA_TYPE,
            PRE_AUTH_APPROVED_BY,
            PRE_AUTH_APPROVED_DATE,
            PRE_AUTH_REQUESTED_BY,
            PRE_AUTH_REQUESTED_DATE,
            PRODUCTION_STA,
            PROGRAM_TYPE,
            PSL_SUPPLY_CHAIN,
            PSNL_SIGNOFF_DATE,
            PURCHASING_NOTES,
            PURCHASING_SUPPORT_REQUIRED,
            REGION,
            RELATED_DAMAGED_PART,
            REQUESTED_BY,
            REQUESTED_DATE,
            REQUESTED_REGION,
            RSP_ANALYST,
            SCM_NOTES,
            SCM_RATING,
            SERVICE_PART_NUMBER,
            SERVICE_STA,
            SOLD_VEHICLE_COUNT,
            STOCK_STATUS,
            SUPPLIER_CODE,
            SUPPLIER_NAME,
            TARGET_QUARTER,
            TOTAL_VEHICLE_COUNT,
            UNSOLD_VEHICLE_COUNT,
            VERN_NO,
            CON_PDC_MAP,
            PDC_CON_MAP
    );
}


