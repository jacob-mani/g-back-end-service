package com.ford.grid.constants;

/**
 * Single source of truth for part data source identifiers.
 * Used across PCII, WERS, and manual part workflows.
 */
public final class PartSourceConstants {

    private PartSourceConstants() {
        // utility class - prevent instantiation
    }

    /** Part validated via PCII (Part Control Information Integration) */
    public static final String SOURCE_PCII = "PCII";

    /** Part validated via WERS (legacy DB2 parts database) */
    public static final String SOURCE_WERS = "WERS";

    /** Part entered manually (unverified - LOCAL/UNKNOWN decision) */
    public static final String SOURCE_MANUAL = "MANUAL";

    /** PCII search type - Engineering Part Number */
    public static final String PART_TYPE_EPN = "EPN";

    /** PCII search type - Global Service Part Number */
    public static final String PART_TYPE_GSPN = "GSPN";

    /** PCII search type - FINIS Code */
    public static final String PART_TYPE_EFINIS = "EFINIS";
}
