package com.ford.grid.constants;

public enum PartType {
    ALL,
    IS_SOFTWARE_PARTS,
    IS_CONFIGURATION,
    IS_VIN_EXCLUDE;


    public static PartType fromString(String partType) {
        try {
            return PartType.valueOf(partType.toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Invalid partType: " + partType);
        }
    }
}
