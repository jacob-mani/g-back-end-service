package com.ford.grid.constants;

import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

/**
 * Typed status for the software parts remedy shown on the face card (card - S/w Parts).
 * The JSON contract is preserved via {@link JsonValue} so the response serializes to
 * "Draft" / "Confirmed". Absent (null) when no fix is defined yet.
 */
@Getter
public enum SoftwarePartStatus {
    DRAFT("Draft"),
    CONFIRMED("Confirmed");

    @JsonValue
    private final String label;

    SoftwarePartStatus(String label) {
        this.label = label;
    }
}
