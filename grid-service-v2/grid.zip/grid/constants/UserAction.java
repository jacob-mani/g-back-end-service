package com.ford.grid.constants;

import lombok.Getter;

@Getter
public enum UserAction {
    CREATE("CREATE"),
    UPDATE("UPDATE"),
    DELETE("DELETE"),
    REOPENED("REOPENED");
    private final String action;

    UserAction(String action) {
        this.action = action;
    }
}