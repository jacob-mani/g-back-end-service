package com.ford.grid.constants;

public interface VERNConstants {
    String VERN_VEHICLE_LINES_SHEET = "Vehicle Line(s)";
    String VERN_VIN_GROUP = "VIN Group(s)";
    String VERN_BODY_STYLE = "Body Style";
    String VERN_ENGINE_CODE = "Engine Code";
    String VERN_FLEET_BY_VEHICLE_LINE = "Fleet by Vehicle Line";
    String VERN_SOLD_UNSOLD_SHEET = "Sold_UnSold";
    String VERN_VEHICLE_COUNT_BY_COUNTRY = "Vehicle Count By Country";
    String VERN_PRODUCTION_DATE_BY_PLANT = "Production Dates By Plant";
    String VERN_VEHICLE_LINE_BY_PLANT = "Vehicle Line By Plant";
    String VERN_COUNTRY_BY_PLANT = "Country By Plant";
    String VERN_PDC_BY_VIN_GROUP = "PDC By VIN Group";
    String VERN_SOLD_STATE_PROV = "Originally Sold State_Province";
    String VERN_VIN_RANGE_BY_PLANT = "VIN Range By Plant";

    String VERN_VEHICLE_UNSOLD = "UnSold";
    String VERN_YEAR_ID = "gridYearId";
    String VERN_SEQUENCE_ID = "gridSequenceId";
    String VERN_IMPLEMENTATION_ID = "gridImplementationId";
    String VERN_VERSION = "version";
    String VERN_REVISION = "revision";
    String VERN_NUMBER = "vernNumber";
    String VERN_SUPPLEMENT_ID = "supplementId";
    String VERN_REVISION_NUMBER = "vernRevisionNumber";
    String VERN_GLOBAL_FSA_NUMBER = "globalFSANumber";
    String VERN_SUCCESS_RESPONSE_STATUS = "Success";
    String VERN_SUCCESS_RESPONSE_DESC = "200 Vern Response received";
    String VERN_FAILURE_RESPONSE_STATUS = "Error";
    String ISSUE_TITLE = "title";
    String VERN_POPULATION_TYPE = "populationType";
    String POPULATION_TYPE_ORIGINAL = "Original";
    String POPULATION_TYPE_SUPPLEMENT = "Supplement";
    String VERN_RESPONSE_ACTION_E = "E";
    String YES_FLAG = "Y";
    String NO_FLAG = "N";
    String NOT_APPLICABLE = "NA";
    String EMPTY_STRING = "";
    String MODEL_YEAR = "MODEL YEAR";
    String PRODUCTION_DATE = "PRODUCTION DATE";
    String ASSEMBLY_PLANT = "ASSEMBLY PLANT";
    String VEHICLE_LINE = "VEHICLE LINE";
    String BRAND = "BRAND";
    String HYPHEN_DELIMITER = "-";

    //Mail template constants
    String MAIL_TEMPLATE_NOTIFY_ASO_VERN_STATUS = "Template_VERN_ASO_Notify";
    String MAIL_TEMPLATE_VERN_DETAILS = "Template_VERN_Response";
    String MAIL_TEMPLATE_FSA_INITIATED = "Template_FSA_Initiated";
    String MAIL_TEMPLATE_LAUNCH_INITIATED = "Template_Launch_Initiated";

    //Mail subject constants
    String SUBJECT_FSA_INITIATED = "FSA Initiated";
    String SUBJECT_LAUNCH_INITIATED = "Launch Initiated";

    //Vern Status Constants
    String TRANSIENT = "Transient";
    String OFFICIAL = "Official";
    String SUPERSEDED = "Superseded";
    String LAUNCHED = "Launched";

    //Date constant
    String DATE_FORMAT_YYYYMMDD = "yyyy-MM-dd";

    //VFD constants
    String VFD_FILE_PATH = "VFDFiles";
    String SYSTEM_GCAMP = "GCAMP";
    String HARDWARE_PROFILE_NAME= "profileName";
}
