package com.ford.grid.constants;

import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

/**
 * Typed outcome for the VERN extract review state shown on the face card (card 6).
 * The JSON contract is preserved via {@link JsonValue} so the response still
 * serializes to "N/A" / "Pending" / "Done".
 */
@Getter
public enum VernExtractReviewStatus {
    NOT_APPLICABLE("N/A"),
    PENDING("Pending"),
    DONE("Done");

    @JsonValue
    private final String label;

    VernExtractReviewStatus(String label) {
        this.label = label;
    }
}
