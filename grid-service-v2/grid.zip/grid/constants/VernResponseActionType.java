package com.ford.grid.constants;

import lombok.Getter;

@Getter
public enum VernResponseActionType {
    C("Created Global FSA"),
    U("Updated Global FSA with new Version"),
    E("VERN Extract and Count"),
    O("Vern Confirmed / Official"),
    F("Local FSA created for Region/Hub");

    private final String actionDescription;

    VernResponseActionType(String actionDescription) {
        this.actionDescription = actionDescription;
    }
}