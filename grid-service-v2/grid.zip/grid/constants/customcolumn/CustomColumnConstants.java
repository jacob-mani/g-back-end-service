package com.ford.grid.constants.customcolumn;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Constants for the Custom Column / Custom View feature.
 * Contains collection names, sentinel values, and allowed field lists for view_by_issue.
 */
public class CustomColumnConstants {

    private CustomColumnConstants() {
        // Utility class — no instantiation
    }

    // -------------------------------------------------------------------------
    // Collection names
    // -------------------------------------------------------------------------

    public static final String VIEW_COLLECTION = "view_by_issue";
    public static final String BASE_COLLECTION = "recall_issue";
    public static final String FORUM_INVESTIGATION_VIEW_COLLECTION = "view_by_forum";
    public static final String POPULATION_VIEW_COLLECTION = "view_by_population";
    public static final String LAUNCH_VIEW_COLLECTION = "view_by_launch";
    public static final String REPAIR_PROFILE_VIEW_COLLECTION = "view_by_repairProfile";
    public static final String SW_PARTS_VIEW_COLLECTION = "view_by_swParts";
    public static final String FSA_VIEW_COLLECTION = "view_by_fsa";
    public static final String CONTACTS_VIEW_COLLECTION = "view_by_issue_contacts";
    /**
     * Source collection for contacts — used by myIssues to find user's cdsId in contacts.
     */
    public static final String ISSUE_CONTACTS_COLLECTION = "issue_contacts";
    public static final String PREFS_COLLECTION = "user_custom_preferences";

    // Materialized view collection names (refreshed by scheduler)
    public static final String LAUNCH_MAT_COLLECTION = "view_by_launch_mat";
    public static final String ISSUE_MAT_COLLECTION = "view_by_issue_mat";
    public static final String FORUM_MAT_COLLECTION = "view_by_forum_mat";
    public static final String POPULATION_MAT_COLLECTION = "view_by_population_mat";
    public static final String REPAIR_PROFILE_MAT_COLLECTION = "view_by_repairProfile_mat";
    public static final String SW_PARTS_MAT_COLLECTION = "view_by_swParts_mat";
    public static final String FSA_MAT_COLLECTION = "view_by_fsa_mat";
    public static final String HW_PARTS_MAT_COLLECTION = "view_by_hwParts_mat";

    /**
     * Collection to track materialized view refresh status (start time, end time, document count).
     */
    public static final String MAT_STATUS_COLLECTION = "custom_view_materialize_status";

    // -------------------------------------------------------------------------
    // Contact column constants
    // -------------------------------------------------------------------------

    /**
     * Mandatory column auto-injected when any contact column is in activeColumns.
     */
    public static final String CONTACT_REGION_COLUMN = "contactRegion";

    /**
     * All contact title column names — these map to contacts[].title in view_by_issue_contacts.
     * This is the UNION of contact titles across ALL views (issue, forum, doc, population, launch, repairProfile).
     */
    public static final Set<String> CONTACT_COLUMN_TITLES = Set.of(
            "asoSme", "assistDirector", "bev", "cce", "ccm", "ccmTest1",
            "ccrgAttorney", "ccrgChair", "chief",
            "csfAttorney", "csfChair", "csfCoChair", "csfLead",
            "diagnosticProducts", "director",
            "eprcAso", "eprcAttorney", "eprcChair", "eprcLead", "eprcOgc", "eprcPd",
            "fcs", "frcAdmin", "frcPresenter", "gcampCoordinator",
            "govnLeadACCC", "govnLeadARAI", "govnLeadBTRCP", "govnLeadCARB",
            "govnLeadCCNZ", "govnLeadCIQ", "govnLeadDITRDC", "govnLeadDNDC",
            "govnLeadDOT", "govnLeadDPAC", "govnLeadDPDC", "govnLeadDVSA",
            "govnLeadEPA", "govnLeadINDECOPI", "govnLeadKATRI", "govnLeadKBA",
            "govnLeadMC", "govnLeadMLIT", "govnLeadMOE", "govnLeadMOIT",
            "govnLeadMOLIT", "govnLeadMORTH", "govnLeadMOT", "govnLeadMOTC",
            "govnLeadMP", "govnLeadMTRS", "govnLeadMVPD", "govnLeadNCC",
            "govnLeadNHTSA", "govnLeadNZTA", "govnLeadOCPB", "govnLeadPROCON",
            "govnLeadROP", "govnLeadSERNAC", "govnLeadSIC", "govnLeadSUNDDE",
            "govnLeadTC", "govnLeadTISI", "govnLeadVCCA", "govnLeadVR",
            "implLead", "implManager",
            "implTest1", "implTest2", "implTest3", "implTest4", "implTest5",
            "implTest7", "implTest8", "implTest9", "implTest10", "implTest12",
            "invManagerKBA", "invManagerNHTSA", "invManagerTC",
            "mailCoordinator", "manager", "monitor", "ota", "pacAuthor",
            "productionSta", "programManager", "purchaseLead",
            "qualityEngineer", "qualityLead", "reportedBy", "rspAnalyst",
            "serviceSta", "shAndC", "supervisor", "supplyChain", "supporting",
            "techAuthor", "test", "trgScheduler", "vld", "vo"
    );

    // -------------------------------------------------------------------------
    // Sentinel
    // -------------------------------------------------------------------------

    /**
     * Stored in activeColumns to signal "fetch every field from view_by_issue".
     */
    public static final String SELECT_ALL = "*";

    // -------------------------------------------------------------------------
    // MongoDB document field name constants
    // -------------------------------------------------------------------------

    public static final String FIELD_ID = "_id";
    public static final String FIELD_CDS_ID = "cdsId";
    public static final String FIELD_CUSTOM_VIEW_NAME = "customViewName";
    public static final String FIELD_VIEW_TYPE = "viewType";
    public static final String FIELD_MY_ISSUES = "myIssues";
    public static final String FIELD_ACTIVE_COLUMNS = "activeColumns";
    public static final String FIELD_COMBINED_FILTER_QUERY = "combinedFilterQuery";
    public static final String FIELD_ISSUE_NUMBER = "issueNumber";
    public static final String FIELD_ISSUE_NO = "issueNumber";
    public static final String FIELD_ISSUE_CREATED_BY = "issueCreatedBy";

    // -------------------------------------------------------------------------
    // Repeated MongoDB document field names (avoids SonarQube string-literal duplication)
    // -------------------------------------------------------------------------

    public static final String FIELD_AFFECTED_REGIONS = "affectedRegions";
    public static final String FIELD_CONTACTS = "contacts";
    public static final String FIELD_CONTACTS_CDS_ID = "contacts.cdsid";
    public static final String FIELD_TITLE = "title";
    public static final String FIELD_NAME = "name";
    public static final String FIELD_METADATA = "metadata";
    public static final String FIELD_DATA = "data";
    public static final String FIELD_TOTAL = "total";
    public static final String FIELD_REGION = "region";
    public static final String FIELD_IMPACTED_REGION = "impactedRegion";

    // -------------------------------------------------------------------------
    // Field lists
    // -------------------------------------------------------------------------

    /**
     * Complete ordered list of all fields available in the {@code view_by_issue} MongoDB view.
     * Used when activeColumns == ["*"] (SELECT_ALL mode).
     * Add new fields here as the view grows.
     */
    public static final List<String> ALL_VIEW_BY_ISSUE_FIELDS = Arrays.asList(
            "issueNumber",
            "issueTitle",
            "issueDescription",
            "leadRegion",
            "segment",
            "issueOpenDate",
            "issueCreatedBy",
            "issueCreationDate",
            "relatedItems",
            "issueCurrentPhase",
            "patientZeroDate",
            "icaDate",
            "pcaDate",
            "affectedRegions",
            "commodity",
            "stopship",
            "affectedVehicleLine",
            "affectedModelYear",
            "affectedBrand",
            "assemblyPlants",
            "causalType",
            "causalFunction",
            "causalTypeOther",
            "functionOther",
            "govtInvestigation",
            "forums",
            "ccrgOpenDate",
            "ccrgForumStatus",
            "csfOpenDate",
            "csfForumStatus",
            "eprcOpenDate",
            "eprcForumStatus",
            "pirOpenDate",
            "pirForumStatus",
            "ccrgNoOfDaysInOpen",
            "ccrgNoOfDaysInMonitor",
            "csfNoOfDaysInOpen",
            "csfNoOfDaysInMonitor",
            "eprcNoOfDaysInOpen",
            "eprcNoOfDaysInMonitor",
            "pirNoOfDaysInOpen",
            "pirNoOfDaysInMonitor",
            "ccrgConcludedDate",
            "csfConcludedDate",
            "eprcConcludedDate",
            "pirConcludedDate",
            "pirConcludedDate",
            "govForumKickOff",
            "14DOpenDate",
            "14DCloseDate",
            "14DCloseBy",
            "14DMeetingDates",
            "14DRecentMeetingDate",
            "fd1Status",
            "fd1UpdatedDate",
            "fd1UpdatedBy",
            "fd2Status",
            "fd2UpdatedDate",
            "fd2UpdatedBy",
            "fd3Status",
            "fd3UpdatedDate",
            "fd3UpdatedBy",
            "fd4Status",
            "fd4UpdatedDate",
            "fd4UpdatedBy",
            "fd6Status",
            "fd6UpdatedDate",
            "fd6UpdatedBy",
            "fd7Status",
            "fd7UpdatedDate",
            "fd7UpdatedBy",
            "fd8Status",
            "fd8UpdatedDate",
            "fd8UpdatedBy",
            "fd11Status",
            "fd11UpdatedDate",
            "fd11UpdatedBy",
            "14DAge",
            "emmTrgOpenDate",
            "emmTrgMeetingDates",
            "emmTrgRecentMeetingDate",
            "14DRecentMeetingNotesDate",
            "14DRecentMeetingNotesTitle",
            "14DRecentMeetingNotes",
            "trgRecentMeetingNotesDate",
            "trgRecentMeetingNotesTitle",
            "trgRecentMeetingNotes",
            "makeModelModelYear",
            "trgOpenDate",
            "trgMeetingDates",
            "trgRecentMeetingDate",
            "trgMeetingType",
            "trgRecentMeetingType",
            "trgRecentMeetingTitle",
            "trgRecentCcrgTeam",
            "trgRecentDuration",
            "transientNotesAso",
            "transientNotesCsf",
            "transientNotesEprc",
            "transientNotesCcm",
            "transientNotesCce",
            "transientNotesOgc",
            "transientNotesPsl",
            "transientNotesFcsdSeo",
            "transientNotesFcsdRsp",
            "transientNotesFcsdScm",
            "transientNotesFcsdPurchasing",
            "transientNotesExecutiveSummaryNotes",
            "ccrgFirstMeetingDate",
            "csfFirstMeetingDate",
            "eprcFirstMeetingDate",
            "pirFirstMeetingDate",
            "noOfDaysCcrgTo14D",
            "noOfDaysCsfTo14D",
            "noOfDaysEprcTo14D",
             "noOfDaysPirTo14D",
            "noOfDaysCcrgToTrg",
            "noOfDaysCsfToTrg",
            "noOfDaysEprcToTrg",
            "noOfDays14DToTrg",
            "fsa",
            "trgCreationDate",
            "rcDate",
            "praDate",
            // Contact columns — resolved from view_by_issue_contacts
            "contactRegion",
            "asoSme", "assistDirector", "bev", "cce", "ccm", "ccmTest1",
            "ccrgAttorney", "ccrgChair", "chief",
            "csfAttorney", "csfChair", "csfCoChair", "csfLead",
            "diagnosticProducts", "director",
            "eprcAso", "eprcAttorney", "eprcChair", "eprcLead", "eprcOgc", "eprcPd",
            "fcs", "frcAdmin", "frcPresenter", "gcampCoordinator",
            "govnLeadACCC", "govnLeadARAI", "govnLeadBTRCP", "govnLeadCARB",
            "govnLeadCCNZ", "govnLeadCIQ", "govnLeadDITRDC", "govnLeadDNDC",
            "govnLeadDOT", "govnLeadDPAC", "govnLeadDPDC", "govnLeadDVSA",
            "govnLeadEPA", "govnLeadINDECOPI", "govnLeadKATRI", "govnLeadKBA",
            "govnLeadMC", "govnLeadMLIT", "govnLeadMOE", "govnLeadMOIT",
            "govnLeadMOLIT", "govnLeadMORTH", "govnLeadMOT", "govnLeadMOTC",
            "govnLeadMP", "govnLeadMTRS", "govnLeadMVPD", "govnLeadNCC",
            "govnLeadNHTSA", "govnLeadNZTA", "govnLeadOCPB", "govnLeadPROCON",
            "govnLeadROP", "govnLeadSERNAC", "govnLeadSIC", "govnLeadSUNDDE",
            "govnLeadTC", "govnLeadTISI", "govnLeadVCCA", "govnLeadVR",
            "implLead", "implManager",
            "implTest1", "implTest2", "implTest3", "implTest4", "implTest5",
            "implTest7", "implTest8", "implTest9", "implTest10", "implTest12",
            "invManagerKBA", "invManagerNHTSA", "invManagerTC",
            "mailCoordinator", "manager", "monitor", "ota", "pacAuthor",
            "productionSta", "programManager", "purchaseLead",
            "qualityEngineer", "qualityLead", "reportedBy", "rspAnalyst",
            "serviceSta", "shAndC", "supervisor", "supplyChain", "supporting",
            "techAuthor", "test", "trgScheduler", "vld", "vo"
    );

    /**
     * Subset of known string-typed fields safe for regex search.
     * Excludes Date, Integer, and Array fields to avoid MongoDB $regex type errors.
     */
    public static final List<String> SEARCHABLE_STRING_FIELDS = Arrays.asList(
            "issueNumber",
            "issueTitle",
            "issueDescription",
            "relatedItems",
            "leadRegion",
            "issueCurrentPhase",
            "segment",
            "commodity",
            "causalType",
            "causalFunction",
            "causalTypeOther",
            "functionOther",
            "stopship",
            "globalFsa",
            "fsaNumber"
    );


    //Added for customview for documents constants

    public static final String VIEW_COLLECTION_DOC = "view_by_documents";


    /**
     * Complete ordered list of all fields available in the {@code view_by_documents} MongoDB view.
     * When {@code activeColumns} contains only {@value #SELECT_ALL}, this list is used as the
     * effective column set. Add new fields here as the view grows.
     */
    public static final List<String> ALL_VIEW_BY_DOC_FIELDS = Arrays.asList(
            "issueNumber",
            "implId",
            "populationId",
            "populationType",
            "location",
            "section",
            "documentId",
            "documentName",
            "uploadedUser",
            "uploadedLocalDate",
            "notificationType",
            "fsaNo",
            "region",
            // Contact columns (resolved from view_by_issue_contacts via region match)
            "contactRegion",
            "asoSme", "assistDirector", "bev", "cce", "ccm", "ccmTest1",
            "ccrgAttorney", "ccrgChair", "chief",
            "csfAttorney", "csfChair", "csfCoChair", "csfLead",
            "diagnosticProducts", "director",
            "eprcAso", "eprcAttorney", "eprcChair", "eprcLead", "eprcOgc", "eprcPd",
            "fcs", "frcAdmin", "frcPresenter", "gcampCoordinator",
            "govnLeadACCC", "govnLeadARAI", "govnLeadBTRCP", "govnLeadCARB",
            "govnLeadCCNZ", "govnLeadCIQ", "govnLeadDITRDC", "govnLeadDNDC",
            "govnLeadDOT", "govnLeadDPAC", "govnLeadDPDC", "govnLeadDVSA",
            "govnLeadEPA", "govnLeadINDECOPI", "govnLeadKATRI", "govnLeadKBA",
            "govnLeadMC", "govnLeadMLIT", "govnLeadMOE", "govnLeadMOIT",
            "govnLeadMOLIT", "govnLeadMORTH", "govnLeadMOT", "govnLeadMOTC",
            "govnLeadMP", "govnLeadMTRS", "govnLeadMVPD", "govnLeadNCC",
            "govnLeadNHTSA", "govnLeadNZTA", "govnLeadOCPB", "govnLeadPROCON",
            "govnLeadROP", "govnLeadSERNAC", "govnLeadSIC", "govnLeadSUNDDE",
            "govnLeadTC", "govnLeadTISI", "govnLeadVCCA", "govnLeadVR",
            "implLead", "implManager",
            "implTest1", "implTest2", "implTest3", "implTest4", "implTest5",
            "implTest7", "implTest8", "implTest9", "implTest10", "implTest12",
            "invManagerKBA", "invManagerNHTSA", "invManagerTC",
            "mailCoordinator", "manager", "monitor", "ota", "pacAuthor",
            "productionSta", "programManager", "purchaseLead",
            "qualityEngineer", "qualityLead", "reportedBy", "rspAnalyst",
            "serviceSta", "shAndC", "supervisor", "supplyChain", "supporting",
            "techAuthor", "test", "trgScheduler", "vld", "vo"
    );
    public static final List<String> VIEW_BY_DOC_SEARCHABLE_STR_FIELDS = Arrays.asList(
            "issueNumber",
            "populationType",
            "location",
            "documentId",
            "documentName",
            "fsaNo"
    );
    // -------------------------------------------------------------------------
    // view_by_forum field lists
    // -------------------------------------------------------------------------

    /**
     * Complete ordered list of all fields available in the {@code view_by_forum} MongoDB view.
     * Used when activeColumns == ["*"] (SELECT_ALL mode).
     */
    public static final List<String> ALL_VIEW_BY_FORUM_INVESTIGATION_FIELDS = Arrays.asList(
            "issueNumber",
            "issueTitle",
            "issueOpenDate",
            "issueDescription",
            "segment",
            "leadRegion",
            "affectedRegion",
            "affectedVehicleLine",
            "affectedModelYear",
            "affectedBrand",
            "assemblyPlants",
            "makeModelModelYear",
            "forum",
            "isForumGov",
            "govAgency",
            "govInitAssignment",
            "govInitDueDate",
            "govRecentAssignment",
            "govRecentDueDate",
            "govDueDates",
            "forumStatus",
            "forumOpenDate",
            "forumMeetingDates",
            "forumRecentMeetingDate",
            "forumReOpenedDates",
            "forumPostFsaMonitor",
            "forumNoOfDaysInOpen",
            "forumIntialReOpenDate",
            "forumRecentReOpenDate",
            "forumReOpenedCount",
            "forumMeetingsCount",
            "forumConcludedDate",
            "forumConcludedToFsa",
            "forumConcludedToFsaNo",
            "globalForumOpenDate",
            "globalForumMeetingDates",
            "globalForumRecentMeetingDate",
            "globalForumNoOfMeetings",
            "fsamFlag",
            "fsamStatus",
            "recentMeetingNotesTitle",
            "recentMeetingNotes",
            "recentMeetingNotesAuthor",
            "recentMeetingNotesDate",
            "preAuthKickOff",
            "ccrgInitFindings",
            "ccrgVoqAnalysis",
            "ccrgWarrantyAnalysis",
            "ccrgHighSeverityFieldReports",
            "ccrgConnectedVehicleData",
            "ccrgFootPrintAnalysis",
            "ccrgProjections",
            "ccrgReliabilityAnalysis",
            "ccrgFieldReport",
            "ccrgComponentTesting",
            "ccrgSubSystemTesting",
            "ccrgVehicleTesting",
            "ccrgQualitySystemData",
            "ccrgRootCause",
            "ccrgContainmentAct",
            "ccrgCustomerExp",
            "ccrgSafetyImpact",
            "ccrgWarningIndicators",
            "ccrgTesting",
            "ccrgNoRiskReason",
            "ccrgClosureFsa",
            "ccrgApproxGlobalVol",
            // Contact columns — resolved from view_by_issue_contacts
            "contactRegion",
            "asoSme", "assistDirector", "bev", "cce", "ccm", "ccmTest1",
            "ccrgAttorney", "ccrgChair", "chief",
            "csfAttorney", "csfChair", "csfCoChair", "csfLead",
            "diagnosticProducts", "director",
            "eprcAso", "eprcAttorney", "eprcChair", "eprcLead", "eprcOgc", "eprcPd",
            "fcs", "frcAdmin", "frcPresenter", "gcampCoordinator",
            "govnLeadACCC", "govnLeadARAI", "govnLeadBTRCP", "govnLeadCARB",
            "govnLeadCCNZ", "govnLeadCIQ", "govnLeadDITRDC", "govnLeadDNDC",
            "govnLeadDOT", "govnLeadDPAC", "govnLeadDPDC", "govnLeadDVSA",
            "govnLeadEPA", "govnLeadINDECOPI", "govnLeadKATRI", "govnLeadKBA",
            "govnLeadMC", "govnLeadMLIT", "govnLeadMOE", "govnLeadMOIT",
            "govnLeadMOLIT", "govnLeadMORTH", "govnLeadMOT", "govnLeadMOTC",
            "govnLeadMP", "govnLeadMTRS", "govnLeadMVPD", "govnLeadNCC",
            "govnLeadNHTSA", "govnLeadNZTA", "govnLeadOCPB", "govnLeadPROCON",
            "govnLeadROP", "govnLeadSERNAC", "govnLeadSIC", "govnLeadSUNDDE",
            "govnLeadTC", "govnLeadTISI", "govnLeadVCCA", "govnLeadVR",
            "implLead", "implManager",
            "implTest1", "implTest2", "implTest3", "implTest4", "implTest5",
            "implTest7", "implTest8", "implTest9", "implTest10", "implTest12",
            "invManagerKBA", "invManagerNHTSA", "invManagerTC",
            "mailCoordinator", "manager", "monitor", "ota", "pacAuthor",
            "productionSta", "programManager", "purchaseLead",
            "qualityEngineer", "qualityLead", "reportedBy", "rspAnalyst",
            "serviceSta", "shAndC", "supervisor", "supplyChain", "supporting",
            "techAuthor", "test", "trgScheduler", "vld", "vo"
    );

    /**
     * Forum-specific fields in view_by_forum that vary per forum row.
     * When none of these fields are in activeColumns, we deduplicate by issueNo
     * to return one record per issue instead of multiple forum rows.
     */
    public static final List<String> FORUM_SPECIFIC_FIELDS = Arrays.asList(
            "forum",
            "isForumGov",
            "govAgency",
            "govInitAssignment",
            "govInitDueDate",
            "govRecentAssignment",
            "govRecentDueDate",
            "govDueDates",
            "forumStatus",
            "forumOpenDate",
            "forumMeetingDates",
            "forumRecentMeetingDate",
            "forumReOpenedDates",
            "forumPostFsaMonitor",
            "forumNoOfDaysInOpen",
            "forumIntialReOpenDate",
            "forumRecentReOpenDate",
            "forumReOpenedCount",
            "forumMeetingsCount",
            "forumConcludedDate",
            "forumConcludedToFsa",
            "forumConcludedToFsaNo",
            "globalForumOpenDate",
            "globalForumMeetingDates",
            "globalForumRecentMeetingDate",
            "globalForumNoOfMeetings",
            "fsamFlag",
            "fsamStatus",
            "recentMeetingNotesTitle",
            "recentMeetingNotes",
            "recentMeetingNotesAuthor",
            "recentMeetingNotesDate",
            "preAuthKickOff",
            "ccrgInitFindings",
            "ccrgVoqAnalysis",
            "ccrgWarrantyAnalysis",
            "ccrgHighSeverityFieldReports",
            "ccrgConnectedVehicleData",
            "ccrgFootPrintAnalysis",
            "ccrgProjections",
            "ccrgReliabilityAnalysis",
            "ccrgFieldReport",
            "ccrgComponentTesting",
            "ccrgSubSystemTesting",
            "ccrgVehicleTesting",
            "ccrgQualitySystemData",
            "ccrgRootCause",
            "ccrgContainmentAct",
            "ccrgCustomerExp",
            "ccrgSafetyImpact",
            "ccrgWarningIndicators",
            "ccrgTesting",
            "ccrgNoRiskReason",
            "ccrgClosureFsa",
            "ccrgApproxGlobalVol"
    );

    /**
     * Subset of known string-typed fields in {@code view_by_forum} safe for regex search.
     * Excludes Date, Integer, and Array fields to avoid MongoDB $regex type errors.
     */
    public static final List<String> SEARCHABLE_FORUM_INVESTIGATION_STRING_FIELDS = Arrays.asList(
            "issueNumber",
            "issueTitle",
            "issueDescription",
            "leadRegion",
            "forum"
    );

    // -------------------------------------------------------------------------
    // view_by_population field lists
    // -------------------------------------------------------------------------

    /**
     * Complete ordered list of all fields available in the {@code view_by_population} MongoDB view.
     * Source: issue_implementation → $unwind populations.
     * Used when activeColumns == ["*"] (SELECT_ALL mode).
     * Add new fields here as the view grows.
     */
    public static final List<String> ALL_VIEW_BY_POPULATION_FIELDS = Arrays.asList(
            "issueNumber",
            "implId",
            "fsaNumber",
            "globalFsa",
            "populationId",
            "populationType",
            "potentialFsaName",
            "potentialFsaType",
            "issueTitle",
            "issueDescription",
            "issueOpenDate",
            "leadRegion",
            "fd9Status",
            "fd9UpdatedDate",
            "fd9UpdatedBy",
            "fd10Status",
            "fd10UpdatedDate",
            "fd10UpdatedBy",
            "trgInitMeetingDate",
            "trgRecentMeetingDate",
            "trgRecentMeetingType",
            "trgRecentMeetingUrgency",
            "trgRecentMeetingTitle",
            "trgRecentCcrgTeam",
            "trgRecentDuration",
            "trgRecentCriticalParticipantSupp",
            "trgRecentOtherParticipants",
            "trgRecentScheduledStatus",
            "trgMeetingDates",
            "trgCreationDate",
            "noOfDaysCcrgToTrg",
            "noOfDaysCsfToTrg",
            "noOfDaysEprcToTrg",
            "noOfDays14DToTrg",
            "noOfDays14DToFrc",
            "noOfDaysTrgToFrc",
            "frcFactSheetTargetDate",
            "frcFactSheetRecentDraftCompDate",
            "frcFactSheetRecentRevCompDate",
            "frcInitMeetingDate",
            "frcRecentMeetingDate",
            "frcMeetingDates",
            "frcRecentApprRegion",
            "frcRecentDealBulletinTiming",
            "frcRecentDraftTitle",
            "frcRecentApprovalSentToGCAMP",
            "frcMemoInitMeetingDate",
            "frcMemoRecentMeetingDate",
            "frcMemoMeetingDates",
            "trgRecentMeetingNotesDate",
            "trgRecentMeetingNotesTitle",
            "trgRecentMeetingNotes",
            "frcRecentMeetingNotesDate",
            "frcRecentMeetingNotesTitle",
            "frcRecentMeetingNotes",
            "vernNoWithRev",
            "vernStatus",
            "soldUnits",
            "unSoldUnits",
            "totalUnits",
            "impactedRegion",
            "impactedMarket",
            "impactedVehicleLine",
            // Contact columns (resolved from view_by_issue_contacts via impactedRegion match)
            "contactRegion",
            "asoSme", "assistDirector", "bev", "cce", "ccm", "ccmTest1",
            "ccrgAttorney", "ccrgChair", "chief",
            "csfAttorney", "csfChair", "csfCoChair", "csfLead",
            "diagnosticProducts", "director",
            "eprcAso", "eprcAttorney", "eprcChair", "eprcLead", "eprcOgc", "eprcPd",
            "fcs", "frcAdmin", "frcPresenter", "gcampCoordinator",
            "govnLeadACCC", "govnLeadARAI", "govnLeadBTRCP", "govnLeadCARB",
            "govnLeadCCNZ", "govnLeadCIQ", "govnLeadDITRDC", "govnLeadDNDC",
            "govnLeadDOT", "govnLeadDPAC", "govnLeadDPDC", "govnLeadDVSA",
            "govnLeadEPA", "govnLeadINDECOPI", "govnLeadKATRI", "govnLeadKBA",
            "govnLeadMC", "govnLeadMLIT", "govnLeadMOE", "govnLeadMOIT",
            "govnLeadMOLIT", "govnLeadMORTH", "govnLeadMOT", "govnLeadMOTC",
            "govnLeadMP", "govnLeadMTRS", "govnLeadMVPD", "govnLeadNCC",
            "govnLeadNHTSA", "govnLeadNZTA", "govnLeadOCPB", "govnLeadPROCON",
            "govnLeadROP", "govnLeadSERNAC", "govnLeadSIC", "govnLeadSUNDDE",
            "govnLeadTC", "govnLeadTISI", "govnLeadVCCA", "govnLeadVR",
            "implLead", "implManager",
            "implTest1", "implTest2", "implTest3", "implTest4", "implTest5",
            "implTest7", "implTest8", "implTest9", "implTest10", "implTest12",
            "invManagerKBA", "invManagerNHTSA", "invManagerTC",
            "mailCoordinator", "manager", "monitor", "ota", "pacAuthor",
            "productionSta", "programManager", "purchaseLead",
            "qualityEngineer", "qualityLead", "reportedBy", "rspAnalyst",
            "serviceSta", "shAndC", "supervisor", "supplyChain", "supporting",
            "techAuthor", "test", "trgScheduler", "vld", "vo"
    );

    /**
     * Subset of known string-typed fields in {@code view_by_population} safe for regex search.
     * Excludes Date, Integer, Boolean, and Array fields to avoid MongoDB $regex type errors.
     * Add new string fields here as the view grows.
     */
    public static final List<String> SEARCHABLE_POPULATION_STRING_FIELDS = Arrays.asList(
            "issueNumber",
            "fsaNumber",
            "globalFsa",
            "populationType",
            "potentialFsaName",
            "potentialFsaType",
            "issueTitle",
            "issueDescription",
            "leadRegion",
            "trgRecentMeetingType",
            "frcFactSheetTargetDate",
            "frcFactSheetRecentDraftCompDate",
            "frcFactSheetRecentRevCompDate",
            "impactedRegion"
    );

    // -------------------------------------------------------------------------
    // view_by_launch field lists
    // -------------------------------------------------------------------------

    /**
     * Complete ordered list of all fields available in the {@code view_by_launch} MongoDB view.
     * Source: issue_implementation → $unwind populations.
     * Used when activeColumns == ["*"] (SELECT_ALL mode).
     * Add new fields here as the view grows.
     */
    public static final List<String> ALL_VIEW_BY_LAUNCH_FIELDS = Arrays.asList(
            // Core fields from issue_implementation collection
            "issueNumber",
            "implId",
            "fsaNumber",
            "globalFsa",
            "populationId",
            "populationType",
            "potentialFsaName",
            "potentialFsaType",
            // Fields from recall_issue lookup
            "issueTitle",
            "issueDescription",
            "issueOpenDate",
            "leadRegion",
            // Fields from vern_count lookup
            "impactedRegion",
            // Fields from launch activity lookups
            "submissionType",
            "notificationType",
            "referenceNo",
            "nhtsaVin",
            "fordVin",
            "marketsApplicable",
            "repairDetails",
            "recTargetDate",
            "revisedTargetDate",
            "actualNotificationDate",
            "reasonForDelay",
            "govtSubLaunchActivityStatus",
            "ownerNotifLaunchActivityStatus",
            "dealerBullLaunchActivityStatus",
            "govtSubLaunchActivity",
            "ownerNotifLaunchActivity",
            "dealerBulletLaunchActivity",
            // Contact columns (resolved from view_by_issue_contacts via impactedRegion match)
            "contactRegion",
            "asoSme", "assistDirector", "bev", "cce", "ccm", "ccmTest1",
            "ccrgAttorney", "ccrgChair", "chief",
            "csfAttorney", "csfChair", "csfCoChair", "csfLead",
            "diagnosticProducts", "director",
            "eprcAso", "eprcAttorney", "eprcChair", "eprcLead", "eprcOgc", "eprcPd",
            "fcs", "frcAdmin", "frcPresenter", "gcampCoordinator",
            "govnLeadACCC", "govnLeadARAI", "govnLeadBTRCP", "govnLeadCARB",
            "govnLeadCCNZ", "govnLeadCIQ", "govnLeadDITRDC", "govnLeadDNDC",
            "govnLeadDOT", "govnLeadDPAC", "govnLeadDPDC", "govnLeadDVSA",
            "govnLeadEPA", "govnLeadINDECOPI", "govnLeadKATRI", "govnLeadKBA",
            "govnLeadMC", "govnLeadMLIT", "govnLeadMOE", "govnLeadMOIT",
            "govnLeadMOLIT", "govnLeadMORTH", "govnLeadMOT", "govnLeadMOTC",
            "govnLeadMP", "govnLeadMTRS", "govnLeadMVPD", "govnLeadNCC",
            "govnLeadNHTSA", "govnLeadNZTA", "govnLeadOCPB", "govnLeadPROCON",
            "govnLeadROP", "govnLeadSERNAC", "govnLeadSIC", "govnLeadSUNDDE",
            "govnLeadTC", "govnLeadTISI", "govnLeadVCCA", "govnLeadVR",
            "implLead", "implManager",
            "implTest1", "implTest2", "implTest3", "implTest4", "implTest5",
            "implTest7", "implTest8", "implTest9", "implTest10", "implTest12",
            "invManagerKBA", "invManagerNHTSA", "invManagerTC",
            "mailCoordinator", "manager", "monitor", "ota", "pacAuthor",
            "productionSta", "programManager", "purchaseLead",
            "qualityEngineer", "qualityLead", "reportedBy", "rspAnalyst",
            "serviceSta", "shAndC", "supervisor", "supplyChain", "supporting",
            "techAuthor", "test", "trgScheduler", "vld", "vo"
    );

    /**
     * Subset of known string-typed fields in {@code view_by_launch} safe for regex search.
     * Excludes Date, Integer, Boolean, and Array fields to avoid MongoDB $regex type errors.
     * Add new string fields here as the view grows.
     */
    public static final List<String> SEARCHABLE_LAUNCH_STRING_FIELDS = Arrays.asList(
            "issueNumber",
            "implId",
            "fsaNumber",
            "populationId",
            "populationType",
            "potentialFsaName",
            "potentialFsaType",
            "issueTitle",
            "issueDescription",
            "leadRegion",
            "impactedRegion",
            "submissionType",
            "notificationType",
            "referenceNo",
            "nhtsaVin",
            "fordVin",
            "marketsApplicable",
            "repairDetails",
            "reasonForDelay",
            "govtSubLaunchActivityStatus",
            "ownerNotifLaunchActivityStatus",
            "dealerBullLaunchActivityStatus",
            "govtSubLaunchActivity",
            "ownerNotifLaunchActivity",
            "dealerBulletLaunchActivity",
            // Contact region and contact name fields (string-based)
            "contactRegion",
            "asoSme", "assistDirector", "bev", "cce", "ccm", "ccmTest1",
            "ccrgAttorney", "ccrgChair", "chief",
            "csfAttorney", "csfChair", "csfCoChair", "csfLead",
            "diagnosticProducts", "director",
            "eprcAso", "eprcAttorney", "eprcChair", "eprcLead", "eprcOgc", "eprcPd",
            "fcs", "frcAdmin", "frcPresenter", "gcampCoordinator",
            "govnLeadACCC", "govnLeadARAI", "govnLeadBTRCP", "govnLeadCARB",
            "govnLeadCCNZ", "govnLeadCIQ", "govnLeadDITRDC", "govnLeadDNDC",
            "govnLeadDOT", "govnLeadDPAC", "govnLeadDPDC", "govnLeadDVSA",
            "govnLeadEPA", "govnLeadINDECOPI", "govnLeadKATRI", "govnLeadKBA",
            "govnLeadMC", "govnLeadMLIT", "govnLeadMOE", "govnLeadMOIT",
            "govnLeadMOLIT", "govnLeadMORTH", "govnLeadMOT", "govnLeadMOTC",
            "govnLeadMP", "govnLeadMTRS", "govnLeadMVPD", "govnLeadNCC",
            "govnLeadNHTSA", "govnLeadNZTA", "govnLeadOCPB", "govnLeadPROCON",
            "govnLeadROP", "govnLeadSERNAC", "govnLeadSIC", "govnLeadSUNDDE",
            "govnLeadTC", "govnLeadTISI", "govnLeadVCCA", "govnLeadVR",
            "implLead", "implManager",
            "implTest1", "implTest2", "implTest3", "implTest4", "implTest5",
            "implTest7", "implTest8", "implTest9", "implTest10", "implTest12",
            "invManagerKBA", "invManagerNHTSA", "invManagerTC",
            "mailCoordinator", "manager", "monitor", "ota", "pacAuthor",
            "productionSta", "programManager", "purchaseLead",
            "qualityEngineer", "qualityLead", "reportedBy", "rspAnalyst",
            "serviceSta", "shAndC", "supervisor", "supplyChain", "supporting",
            "techAuthor", "test", "trgScheduler", "vld", "vo"
    );

    // -------------------------------------------------------------------------
    // view_by_repairProfile field lists
    // -------------------------------------------------------------------------

    /**
     * Complete ordered list of all fields available in the {@code view_by_repairProfile} MongoDB view.
     * Source: recall_issue → issue_implementation → $unwind populations → vehicle_profiles → vehicle_parts → part_master.
     * Used when activeColumns == ["*"] (SELECT_ALL mode).
     * Add new fields here as the view grows.
     */
    public static final List<String> ALL_VIEW_BY_REPAIR_PROFILE_FIELDS = Arrays.asList(
            "issueNumber",
            "issueTitle",
            "affectedRegion",
            "leadRegion",
            "implId",
            "fsaNumber",
            "populationId",
            "populationType",
            "potentialFsaType",
            "globalFsa",
            "potentialFsaName",
            "vernNumber",
            "vernRevision",
            "profileName",
            "multiRepairs",
            "labourHour",
            "remedyExplanation",
            "profileVehicleLine",
            "profileMarket",
            "impactedVehicleCount",
            "region",
            "soldUio",
            "soldResponseRate",
            "soldLaunchQuantity",
            "unSoldUio",
            "unSoldResponseRate",
            "unSoldLaunchQuantity",
            "relatedDamagedPart",
            "oneTimePart",
            "causalPart",
            "partStatus",
            "partType",
            "partProfileId",
            "qtyPerRepair",
            "partReplaceRate",
            "engineeringPartNumber",
            "servicePartNumber",
            "finisCode",
            "partName",
            "profileWersValue1",
            "profileWersValue2",
            "profileWersValue3",
            "profileWersValue4",
            "profileWersValue5",
            "profileWersValue6",
            "profileWersValue7",
            "profileWersValue8",
            "profileWersValue9",
            "profileWersValue10",
            "profileWersAttribute1",
            "profileWersAttribute2",
            "profileWersAttribute3",
            "profileWersAttribute4",
            "profileWersAttribute5",
            "profileWersAttribute6",
            "profileWersAttribute7",
            "profileWersAttribute8",
            "profileWersAttribute9",
            "profileWersAttribute10",
            // Contact columns (resolved from view_by_issue_contacts via region match)
            "contactRegion",
            "asoSme", "assistDirector", "bev", "cce", "ccm", "ccmTest1",
            "ccrgAttorney", "ccrgChair", "chief",
            "csfAttorney", "csfChair", "csfCoChair", "csfLead",
            "diagnosticProducts", "director",
            "eprcAso", "eprcAttorney", "eprcChair", "eprcLead", "eprcOgc", "eprcPd",
            "fcs", "frcAdmin", "frcPresenter", "gcampCoordinator",
            "govnLeadACCC", "govnLeadARAI", "govnLeadBTRCP", "govnLeadCARB",
            "govnLeadCCNZ", "govnLeadCIQ", "govnLeadDITRDC", "govnLeadDNDC",
            "govnLeadDOT", "govnLeadDPAC", "govnLeadDPDC", "govnLeadDVSA",
            "govnLeadEPA", "govnLeadINDECOPI", "govnLeadKATRI", "govnLeadKBA",
            "govnLeadMC", "govnLeadMLIT", "govnLeadMOE", "govnLeadMOIT",
            "govnLeadMOLIT", "govnLeadMORTH", "govnLeadMOT", "govnLeadMOTC",
            "govnLeadMP", "govnLeadMTRS", "govnLeadMVPD", "govnLeadNCC",
            "govnLeadNHTSA", "govnLeadNZTA", "govnLeadOCPB", "govnLeadPROCON",
            "govnLeadROP", "govnLeadSERNAC", "govnLeadSIC", "govnLeadSUNDDE",
            "govnLeadTC", "govnLeadTISI", "govnLeadVCCA", "govnLeadVR",
            "implLead", "implManager",
            "implTest1", "implTest2", "implTest3", "implTest4", "implTest5",
            "implTest7", "implTest8", "implTest9", "implTest10", "implTest12",
            "invManagerKBA", "invManagerNHTSA", "invManagerTC",
            "mailCoordinator", "manager", "monitor", "ota", "pacAuthor",
            "productionSta", "programManager", "purchaseLead",
            "qualityEngineer", "qualityLead", "reportedBy", "rspAnalyst",
            "serviceSta", "shAndC", "supervisor", "supplyChain", "supporting",
            "techAuthor", "test", "trgScheduler", "vld", "vo"
    );

    /**
     * Subset of known string-typed fields in {@code view_by_repairProfile} safe for regex search.
     * Excludes Date, Integer, Boolean, and Array fields to avoid MongoDB $regex type errors.
     * Add new string fields here as the view grows.
     */
    public static final List<String> SEARCHABLE_REPAIR_PROFILE_STRING_FIELDS = Arrays.asList(
            "issueNumber",
            "issueTitle",
            "affectedRegion",
            "leadRegion",
            "implId",
            "fsaNumber",
            "populationId",
            "populationType",
            "potentialFsaType",
            "potentialFsaName",
            "profileName",
            "multiRepairs",
            "remedyExplanation",
            "profileVehicleLine",
            "profileMarket",
            "region",
            "relatedDamagedPart",
            "partStatus",
            "partType",
            "engineeringPartNumber",
            "servicePartNumber",
            "finisCode",
            "partName",
            "profileWersValue1",
            "profileWersValue2",
            "profileWersValue3",
            "profileWersValue4",
            "profileWersValue5",
            "profileWersValue6",
            "profileWersValue7",
            "profileWersValue8",
            "profileWersValue9",
            "profileWersValue10"
    );

    // -------------------------------------------------------------------------
    // view_by_swParts field lists
// -------------------------------------------------------------------------

    /**
     * Complete ordered list of all fields available in the {@code view_by_swParts} MongoDB view.
     * Source: issue_implementation → software_myPgm_ied_version → software_fsa_myPgm_gvms.
     * Used when activeColumns == ["*"] (SELECT_ALL mode).
     */
    public static final List<String> ALL_VIEW_BY_SW_PARTS_FIELDS = Arrays.asList(
            "issueNumber",
            "implId",
            "populationId",
            "populationType",
            "fsaNumber",
            "globalFsa",
            "fsaType",
            "isManualPopulation",
            "iedVersionNumber",
            "iedPublishedDate",
            "iedPublishedBy",
            "modelYear",
            "programCode",
            "vinExcludeFlag",
            "includeSoftwareFlag",
            "softwareOnlyFlag",
            "configFlag",
            "configNodes",
            "wersNoticeNo",
            "engPartNo",
            // Contact columns (resolved from view_by_issue_contacts)
            "contactRegion",
            "asoSme", "assistDirector", "bev", "cce", "ccm", "ccmTest1",
            "ccrgAttorney", "ccrgChair", "chief",
            "csfAttorney", "csfChair", "csfCoChair", "csfLead",
            "diagnosticProducts", "director",
            "eprcAso", "eprcAttorney", "eprcChair", "eprcLead", "eprcOgc", "eprcPd",
            "fcs", "frcAdmin", "frcPresenter", "gcampCoordinator",
            "govnLeadACCC", "govnLeadARAI", "govnLeadBTRCP", "govnLeadCARB",
            "govnLeadCCNZ", "govnLeadCIQ", "govnLeadDITRDC", "govnLeadDNDC",
            "govnLeadDOT", "govnLeadDPAC", "govnLeadDPDC", "govnLeadDVSA",
            "govnLeadEPA", "govnLeadINDECOPI", "govnLeadKATRI", "govnLeadKBA",
            "govnLeadMC", "govnLeadMLIT", "govnLeadMOE", "govnLeadMOIT",
            "govnLeadMOLIT", "govnLeadMORTH", "govnLeadMOT", "govnLeadMOTC",
            "govnLeadMP", "govnLeadMTRS", "govnLeadMVPD", "govnLeadNCC",
            "govnLeadNHTSA", "govnLeadNZTA", "govnLeadOCPB", "govnLeadPROCON",
            "govnLeadROP", "govnLeadSERNAC", "govnLeadSIC", "govnLeadSUNDDE",
            "govnLeadTC", "govnLeadTISI", "govnLeadVCCA", "govnLeadVR",
            "implLead", "implManager",
            "implTest1", "implTest2", "implTest3", "implTest4", "implTest5",
            "implTest7", "implTest8", "implTest9", "implTest10", "implTest12",
            "invManagerKBA", "invManagerNHTSA", "invManagerTC",
            "mailCoordinator", "manager", "monitor", "ota", "pacAuthor",
            "productionSta", "programManager", "purchaseLead",
            "qualityEngineer", "qualityLead", "reportedBy", "rspAnalyst",
            "serviceSta", "shAndC", "supervisor", "supplyChain", "supporting",
            "techAuthor", "test", "trgScheduler", "vld", "vo"
    );

    /**
     * Subset of known string-typed fields in {@code view_by_swParts} safe for regex search.
     * These are the fields the user requested to be searchable.
     */
    public static final List<String> SEARCHABLE_SW_PARTS_STRING_FIELDS = Arrays.asList(
            "issueNumber",
            "fsaNumber",
            "globalFsa",
            "fsaType",
            "programCode",
            "modelYear",
            "configNodes",
            "wersNoticeNo",
            "engPartNo"
    );

    // -------------------------------------------------------------------------
// view_by_launch: field-to-collection category sets (for direct-query mode)
// -------------------------------------------------------------------------

    /**
     * Fields that exist directly on issue_implementation (base document).
     */
    public static final Set<String> LAUNCH_IMPL_BASE_FIELDS = Set.of(
            "issueNumber", "implId", "fsaNumber", "globalFsa"
    );

    /**
     * Fields derived from issue_implementation.populations[] embedded array.
     */
    public static final Set<String> LAUNCH_POPULATION_FIELDS = Set.of(
            "populationId", "populationType", "potentialFsaName"
    );

    /**
     * Fields from potential_type collection (lookup by potentialIssueType key).
     */
    public static final Set<String> LAUNCH_POTENTIAL_TYPE_FIELDS = Set.of("potentialFsaType");

    /**
     * Fields from recall_issue collection.
     */
    public static final Set<String> LAUNCH_RECALL_ISSUE_FIELDS = Set.of(
            "issueTitle", "issueDescription", "issueOpenDate", "leadRegion"
    );

    /**
     * Fields from vern_count collection.
     */
    public static final Set<String> LAUNCH_VERN_FIELDS = Set.of("impactedRegion");

    /**
     * Fields exclusive to launch_Gov_Region_Details.
     */
    public static final Set<String> LAUNCH_GOVT_SUB_EXCLUSIVE_FIELDS = Set.of(
            "govtSubLaunchActivityStatus", "govtSubLaunchActivity", "referenceNo",
            "nhtsaVin", "fordVin"
    );

    /**
     * Fields exclusive to launch_region_owner_notifications.
     */
    public static final Set<String> LAUNCH_OWNER_NOTIF_EXCLUSIVE_FIELDS = Set.of(
            "ownerNotifLaunchActivityStatus", "ownerNotifLaunchActivity"
    );

    /**
     * Fields exclusive to launch_dealer_bulletin.
     */
    public static final Set<String> LAUNCH_DEALER_BULL_EXCLUSIVE_FIELDS = Set.of(
            "dealerBullLaunchActivityStatus", "dealerBulletLaunchActivity"
    );

    /**
     * Fields shared across govt/owner/dealer launch entries — any of the 3 collections can produce these.
     */
    public static final Set<String> LAUNCH_SHARED_NOTIFICATION_FIELDS = Set.of(
            "submissionType", "notificationType", "recTargetDate", "revisedTargetDate",
            "actualNotificationDate", "marketsApplicable", "repairDetails", "reasonForDelay"
    );

    /**
     * Source collection name for issue_implementation (used by direct-query mode).
     */
    public static final String ISSUE_IMPLEMENTATION_COLLECTION = "issue_implementation";

    // -------------------------------------------------------------------------
    // view_by_fsa: all known fields and searchable fields
    // -------------------------------------------------------------------------

    /**
     * All known fields in the {@code view_by_fsa} materialized view.
     * Must match the final $project in view_by_fsaJS.js.
     */
    public static final List<String> ALL_VIEW_BY_FSA_FIELDS = Arrays.asList(
            "issueNumber",
            "implId",
            "populationId",
            "populationType",
            "potentialFsaName",
            "potentialFsaType",
            "fsaNo",
            "fsaStatus",
            "globalFsa",
            "stopShip",
            "issueTitle",
            "issueDescription",
            "issueOpenDate",
            "leadRegion",
            "labourCost",
            "materialCost",
            "overallEstimatedCost",
            "impactedRegion",
            "impactedModelYear",
            "impactedVehicleLines",
            "impactedBrand",
            "makeModelModelYear",
            "totalSold",
            "totalUnsold",
            "totalUnits",
            "latestvernNumber",
            "latestvernRevision",
            "vernCount",
            "govtSubmissionRegionId",
            "govtSubmissionRegionStatus",
            "dealerbulletinRegionId",
            "dealerbulletinRegionStatus",
            "ownerNotificationRegionId",
            "ownerNotificationRegionStatus",
            "govtLaunchActivity",
            "dealerBulletinLaunchActivity",
            "ownerNotificationLaunchActivity",
            "impactedRegionCompLaunchActivity",
            "impactedRegionNotCompLaunchActivity"
    );

    /**
     * Subset of known string-typed fields in {@code view_by_fsa} safe for regex search.
     */
    public static final List<String> SEARCHABLE_FSA_STRING_FIELDS = Arrays.asList(
            "issueNumber",
            "implId",
            "populationId",
            "populationType",
            "potentialFsaName",
            "potentialFsaType",
            "fsaNo",
            "fsaStatus",
            "globalFsa",
            "stopShip",
            "issueTitle",
            "issueDescription",
            "leadRegion"
    );

    public static final List<String> STANDARD_TAB_FIELDS = Arrays.asList(
            "issueNumber",
            "issueTitle",
            "issueDescription",
            "leadRegion",
            "issueCurrentPhase",
            "fsaNumber"
    );

    // -------------------------------------------------------------------------
    // view_by_hwParts field lists
    // -------------------------------------------------------------------------

    /**
     * Complete ordered list of all fields available in the {@code view_by_hwParts} MongoDB view.
     * Source: issue_implementation → populations → vehicle_parts → part_master + psnl_details + issue_contacts.
     * Used when activeColumns == ["*"] (SELECT_ALL mode).
     */
    public static final List<String> ALL_VIEW_BY_HW_PARTS_FIELDS = Arrays.asList(
            "issueNumber",
            "implId",
            "populationId",
            "populationType",
            "potentialFsaName",
            "potentialFsa",
            "fsaNo",
            "globalFsa",
            "potentialIssueType",
            "market",
            "psnlRegion",
            "psnlSignoffDate",
            "scmRating",
            "psnlPartDetails",
            "relatedDamagedPart",
            "oneTimePart",
            "causalPart",
            "partStatus",
            "partType",
            "engineeringPartNumber",
            "servicePartNumber",
            "finisCode",
            "partName",
            // UI alias names (mapped from DB field names in service layer)
            "hwPart",
            "implementationNumber",
            "populationNumber",
            "fsaNumber",
            "region",
            "fcsdPurchaseLead",
            "preAuthApprovedBy",
            "preAuthApprovedDate",
            "preAuthRequestedBy",
            "preAuthRequestedDate",
            "pslSignoffDate",
            "pslSupplyChain",
            "scmPurchasingRating",
            "sta",
            "totalVehicleUnits",
            "totalVehicleSold",
            "totalVehicleUnsold",
            "totalQuantity",
            "launchQuantity",
            "partOk",
            "netInStockQuantity",
            "oneTimePartQty",
            "orderQuantity",
            "overallPartsAvailableStatusComments",
            "partComment",
            "partStatusDetail",
            "partQtySold",
            "partQtyTotal",
            "partQtyUnsold",
            "partsPrice",
            "eta",
            "targetDate",
            "actualDate",
            "criticalPart",
            "supplierCode",
            "supplierName",
            // Contact columns (resolved from view_by_issue_contacts via region match)
            "contactRegion",
            "implementationLead",
            "purchaseLead",
            "rspAnalyst"
    );

    /**
     * UI field name → DB (materialized view) field name mapping for HW Parts view.
     * Used to translate user-saved activeColumns to actual collection field names.
     */
    public static final Map<String, String> HW_PARTS_UI_TO_DB_FIELD_MAP = Map.ofEntries(
            Map.entry("implementationNumber", "implId"),
            Map.entry("populationNumber", "populationId"),
            Map.entry("fsaNumber", "fsaNo"),
            Map.entry("region", "psnlRegion"),
            Map.entry("fcsdPurchaseLead", "purchaseLead"),
            Map.entry("pslSignoffDate", "psnlSignoffDate"),
            Map.entry("scmPurchasingRating", "scmRating"),
            Map.entry("partComment", "psnlPartDetails.partComments"),
            Map.entry("partOk", "psnlPartDetails.partOk"),
            Map.entry("netInStockQuantity", "psnlPartDetails.netInStockQuantity"),
            Map.entry("orderQuantity", "psnlPartDetails.orderQuantity")
    );

    /**
     * Subset of known string-typed fields in {@code view_by_hwParts} safe for regex search.
     * Excludes Date, Object (psnlPartDetails), and Boolean fields to avoid MongoDB $regex type errors.
     */
    public static final List<String> SEARCHABLE_HW_PARTS_STRING_FIELDS = Arrays.asList(
            "issueNumber",
            "implId",
            "populationId",
            "populationType",
            "potentialFsaName",
            "potentialFsa",
            "fsaNo",
            "globalFsa",
            "potentialIssueType",
            "market",
            "psnlRegion",
            "scmRating",
            "relatedDamagedPart",
            "partStatus",
            "partType",
            "engineeringPartNumber",
            "servicePartNumber",
            "finisCode",
            "partName",
            // UI alias names (mapped to DB fields during search)
            "implementationNumber",
            "populationNumber",
            "fsaNumber",
            "region",
            "scmPurchasingRating",
            "hwPart",
            "criticalPart",
            "supplierCode",
            "supplierName"
    );
}

