package com.ford.grid.constants.dashboard;

public interface CustomViewConstants {
    String ISSUE_NO = "issueNo";
    String FSA_NO = "fsaNo";
    String SORT_KEY = "value";
    String VIEW_BY = "viewBy";
}