package com.ford.grid.constants.dashboard;

public enum IssuesColumns {

    c1("Issue #", 1), c2("Issue Title", 2), c3("Affected Vehicles", 3), c4("Lead Region", 4), c5("Forum", 5),
    c6("Issue Type", 6), c7("Current Phase", 7), c8("Days Open", 8), c9("Region Affected", 9), c10("Related Items", 10),
    c11("Segment", 11), c12("Source", 12), c13("Description", 13), c14("Causal Type", 14), c15("CCRG Status", 15),
    c16("EPRC Status", 16), c17("CSF Status", 17), c18("Next Review (Type)", 18), c19("Next Review (Date)", 19),
    c20("Gov. FollowUp Date", 20), c21("Last Review (Date)", 21), c22("Last Review (Type)", 22),
    c23("CCRG Open Date", 23), c24("EPRC Open Date", 24), c25("CSF Open Date", 25),
    c26("CCRG Closure Review", 26), c27("EPRC Closure Review", 27), c28("14D Requested Date", 28), c29("X Number", 29),
    c30("Approx. Global Volume", 30), c31("FRC Date", 31), c32("Field Service Action #", 32), c33("CCE", 33),
    c34("CCM", 34), c35("ASO Lead Investigator", 35), c36("CCRG Chair", 36), c37("EPRC Chair", 37),
    c38("CSF Chair", 38), c39("FCSD Program Manager", 39), c40("RSP Analyst", 40), c41("GCAMP Coordinator", 41),
    c42("PS&L Supply Chain", 42), c43("Diagnostic Service Prod", 43), c44("Technical Author", 44),
    c45("Root Cause Owner", 45), c46("14D Author", 46), c47("External Organization", 47), c48("GOVT Status", 48),
    c49("FSAM Flag", 49), c50("Days Open in CCRG", 50), c51("Days Open in CSF", 51), c52("Days Open in EPRC", 52),
    c53("Days Open in GOV", 53),
    c54("Transient Notes - ASO", 54), c55("Transient Notes - EPRC", 55), c56("Transient Notes - CSF", 56),
    c57("Transient Notes - CCM", 57),
    c58("RSP Comments", 58), c59("Transient Notes - PS&L", 59), c60("Transient Notes - OGC", 60),
    c61("14D Status", 61), c62("14D Close Date", 62),
    c63("GOV Lead Investigator", 63), c64("CSF Lead Investigator", 64), c65("EPRC Lead Investigator", 65),
    c66("Investigation Manager", 66),
    c67("Days in Monitor - CCRG", 67), c68("Days in Monitor - CSF", 68), c69("Days in Monitor - EPRC", 69),
    c70("Days in Monitor - GOV", 70),
    c71("14D Age", 71), c72("Approving Region", 72), c73("Monitor comeback date - CCRG", 73),
    c74("Monitor Set date - CCRG", 74),
    c75("Monitor comeback date - CSF", 75), c76("Monitor Set date - CSF", 76),
    c77("Monitor comeback date - EPRC", 77), c78("Monitor Set date - EPRC", 78),
    c79("Monitor comeback date - GOV", 79), c80("Monitor Set date - GOV", 80), c81("Causal Function", 81),
    c82("CCRG Meeting Dates", 82), c83("CSF Meeting Dates", 83), c84("EPRC Meeting Dates", 84),
    c85("GCCRG Meeting Dates", 85), c86("GCSF Meeting Dates", 86), c87("14D Meeting Dates", 87),
    c88("TRG Meeting Dates", 88), c89("FRC Meeting Dates", 89), c90("Gov Meeting Dates", 90),
    c91("EMM Meeting Dates", 91), c92("EPRC Fact Sheet", 92),
    c93("Implementation lead", 93), c94("Implementation Manager", 94), c95("Help Required", 95),
    c96("CCRG Meeting notes", 96),
    c97("EPRC Meeting notes", 97), c98("CSF Meeting notes", 98), c99("GOV Meeting notes", 99),
    c100("Last TRG", 100), c101("Date Added", 101),
    c102("60 Day Ageing", 102), c103("90 Day Ageing", 103), c104("Total Ageing CCRG", 104),
    c105("Total Ageing EPRC", 105), c106("Total Ageing CSF", 106),
    c107("Total Ageing GOVERNMENT", 107), c108("Status CCRG + 45", 108), c109("Status EPRC + 45", 109),
    c110("Status CSF + 45", 110), c111("Status GOV + 45", 111),
    c112("Status CCRG + 60", 112), c113("Status EPRC + 60", 113), c114("Status CSF + 60", 114),
    c115("Status GOV + 60", 115),
    c116("TRG Count", 116), c117("Recovery Plan", 117), c118("Days in Post FSA Monitor CCRG", 118),
    c119("Days in Post FSA Monitor CSF", 119), c120("Days in Post FSA Monitor EPRC", 120), c121("Mobile Repair", 121),
    c122("Includes Rental", 122), c123("Includes Towing", 123),
    c124("CCRG- Monitor Back To Active", 124), c125("CSF- Monitor Back To Active", 125),
    c126("EPRC- Monitor Back To Active", 126), c127("GOV- Monitor Back To Active", 127),
    c128("FSA No", 128), c129("Issue #", 129), c130("Issue Title", 130), c131("Description", 131),
    c132("Affected Vehicle Lines", 132), c133("Lead Region", 133),
    c134("14D Requested Date", 134), c135("FSA Type", 135),
    c136("TRG date (Type)", 136), c137("TRG date (Population)", 137),
    c138("FCSD Purchase Lead", 138),
    c139("NA - Launch Activity Complete", 139),
    c140("SA -  Launch Activity Complete", 140), c141("EU - Launch Activity Complete", 141),
    c142("IMG - Launch Activity Complete", 142), c143("GCN - Launch Activity Complete", 143),
    c144("PAC Author", 144), c145("Quality Problem Solving Engineer", 145), c146("PAC Process", 146),
    c147("Causal Parts", 147), c148("Causal Part", 148),


    c203("NA - Owner Notification Remedy Avail Legacy Target", 203),
    c204("NA - Owner Notification Remedy Avail Legacy Actual", 204), c205("NA - Owner Notification No Remedy Avail Target", 205),
    c206("NA - Owner Notification No Remedy Avail Actual", 206), c207("NA - Owner Notification Follow-up Target", 207),
    c208("NA - Owner Notification Actual", 208), c209("NA - Owner Notification Remedy Avail Inspection Target", 209),
    c210("NA - Owner Notification Remedy Avail Inspection Actual", 210), c211("EU - Owner Notification Remedy Avail Legacy Target", 211),
    c212("EU - Owner Notification Remedy Avail Legacy Actual", 212), c213("EU - Owner Notification No Remedy Avail Target", 213),
    c214("EU - Owner Notification No Remedy Avail Actual", 214), c215("EU - Owner Notification Follow-up Target", 215),
    c216("EU - Owner Notification Actual", 216), c217("EU - Owner Notification Remedy Avail Inspection Target", 217),
    c218("EU - Owner Notification Remedy Avail Inspection Actual", 218), c219("SA - Owner Notification Remedy Avail Legacy Target", 219),
    c220("SA - Owner Notification Remedy Avail Legacy Actual", 220), c221("SA - Owner Notification No Remedy Avail Target", 221),
    c222("SA - Owner Notification No Remedy Avail Actual", 222), c223("SA - Owner Notification Follow-up Target", 223),
    c224("SA - Owner Notification Actual", 224), c225("SA - Owner Notification Remedy Avail Inspection Target", 225),
    c226("SA - Owner Notification Remedy Avail Inspection Actual", 226), c227("IMG - Owner Notification Remedy Avail Legacy Target", 227),
    c228("IMG - Owner Notification Remedy Avail Legacy Actual", 228), c229("IMG - Owner Notification No Remedy Avail Target", 229),
    c230("IMG - Owner Notification No Remedy Avail Actual", 230), c231("IMG - Owner Notification Follow-up Target", 231),
    c232("IMG - Owner Notification Actual", 232), c233("IMG - Owner Notification Remedy Avail Inspection Target", 233),
    c234("IMG - Owner Notification Remedy Avail Inspection Actual", 234),
    c235("GCH - Owner Notification Remedy Avail Legacy Target", 235), c236("GCH - Owner Notification Remedy Avail Legacy Actual", 236),
    c237("GCH - Owner Notification No Remedy Avail Target", 237), c238("GCH - Owner Notification No Remedy Avail Actual", 238),
    c239("GCH - Owner Notification Follow-up Target", 239), c240("GCH - Owner Notification Actual", 240),
    c241("GCH - Owner Notification Remedy Avail Inspection Target", 241),
    c242("GCH - Owner Notification Remedy Avail Inspection Actual", 242),
    c250("Mobile Repair", 250),
    c251("Includes Rental", 251),

    c252("Includes Towing", 252), c254("Regions Affected", 254),


    c255("NA - Govt Notification", 255),
    c256("SA - Govt Notification", 256),
    c257("EU - Govt Notification", 257),
    c258("IMG - Govt Notification", 258),
    c259("GCN - Govt Notification", 259),
    c260("NA - Owner Notification", 260),
    c261("SA - Owner Notification", 261),
    c262("EU - Owner Notification", 262),
    c263("IMG - Owner Notification", 263),
    c264("GCN - Owner Notification", 264),
    c265("NA - Dealer Bulletin", 265),
    c266("SA - Dealer Bulletin", 266),
    c267("EU - Dealer Bulletin", 267),
    c268("IMG - Dealer Bulletin", 268),
    c269("GCN - Dealer Bulletin", 269),


    c270("NA - Parts Availability", 270),
    c271("SA - Parts Availabililty", 271),
    c272("EU - Parts Availabililty", 272),
    c273("IMG - Parts Availability", 273),
    c274("GCN - Parts Availability", 274),


    c275("NA - Total Units", 275), c276("NA - Sold", 276), c277("NA - Unsold", 277), c278("EU - Total Units", 278),
    c279("EU - Sold", 279), c280("EU - Unsold", 280), c281("SA - Total Units", 281), c282("SA - Sold", 282),
    c283("SA - Unsold", 283), c284("IMG - Total Units", 284), c285("IMG - Sold", 285), c286("IMG - Unsold", 286),
    c287("GCH - Total Units", 287), c288("GCH - Sold ", 288), c289("GCH - Unsold", 289),
    c290("FRC to Launch", 290),
    c291("NA Parts Confirmed", 291),
    c292("SA Parts Confirmed", 292),
    c293("EU Parts Confirmed", 293),
    c294("IMG Parts Confirmed", 294),
    c295("GCN Parts Confirmed", 295),

    c330("NA - Internal Awareness Notification (EU only) Target Date", 330),
    c331("NA - Internal Awareness Notification (EU only) Actual Submission Date", 331),
    c332("NA - Dealer Awareness Notification Target Date", 332),
    c333("NA - Dealer Awareness Notification Actual Submission Date", 333),
    c334("NA - Advanced Dealer Notification Target Date", 334),
    c335("NA - Advanced Dealer Notification Actual Submission Date", 335),
    c336("NA - Full Bulletin Launch Target Date", 336),
    c337("NA - Full Bulletin Launch Actual Submission Date", 337),
    c338("EU - Internal Awareness Notification (EU only) Target Date", 338),
    c339("EU - Internal Awareness Notification (EU only) Actual Submission Date", 339),
    c340("EU - Dealer Awareness Notification Target Date", 340),
    c341("EU - Dealer Awareness Notification Actual Submission Date", 341),
    c342("EU - Advanced Dealer Notification Target Date", 342),
    c343("EU - Advanced Dealer Notification Actual Submission Date", 343),
    c344("EU - Full Bulletin Launch Target Date", 344),
    c345("EU - Full Bulletin Launch Actual Submission Date", 345),
    c346("SA - Internal Awareness Notification (EU only) Target Date", 346),
    c347("SA - Internal Awareness Notification (EU only) Actual Submission Date", 347),
    c348("SA - Dealer Awareness Notification Target Date", 348),
    c349("SA - Dealer Awareness Notification Actual Submission Date", 349),
    c350("SA - Advanced Dealer Notification Target Date", 350),
    c351("SA - Advanced Dealer Notification Actual Submission Date", 351),
    c352("SA - Full Bulletin Launch Target Date", 352),
    c353("SA - Full Bulletin Launch Actual Submission Date", 353),
    c354("IMG - Internal Awareness Notification (EU only) Target Date", 354),
    c355("IMG - Internal Awareness Notification (EU only) Actual Submission Date", 355),
    c356("IMG - Dealer Awareness Notification Target Date", 356),
    c357("IMG - Dealer Awareness Notification Actual Submission Date", 357),
    c358("IMG - Advanced Dealer Notification Target Date", 358),
    c359("IMG - Advanced Dealer Notification Actual Submission Date", 359),
    c360("IMG - Full Bulletin Launch Target Date", 360),
    c361("IMG - Full Bulletin Launch Actual Submission Date", 361),
    c362("GCH - Internal Awareness Notification (EU only) Target Date", 362),
    c363("GCH - Internal Awareness Notification (EU only) Actual Submission Date", 363),
    c364("GCH - Dealer Awareness Notification Target Date", 364),
    c365("GCH - Dealer Awareness Notification Actual Submission Date", 365),
    c366("GCH - Advanced Dealer Notification Target Date", 366),
    c367("GCH - Advanced Dealer Notification Actual Submission Date", 367),
    c368("GCH - Full Bulletin Launch Target Date", 368),
    c369("GCH - Full Bulletin Launch Actual Submission Date", 369),

    c370("Critical Part Launch Strategy", 370),


    c400("VERN Requested", 400), c401("VERN Submitted to GCAMP", 401), c402("Extract Received from GCAMP", 402),
    c403("Pre-Auth Request Date", 403), c404("Pre-Auth Approved Date", 404), c405("PS&L Sign-Off Date", 405),

    c410("Gov Submission Dates", 410), c411("Dealer Bulletin Dates", 411), c412("Owner Notification Dates", 412),


    c415("Implementation Type", 415),
    c416("OTA Indicator", 416),
    c417("Implementation Name", 417),
    c418("Stopship No tagged to Implementation", 418),

    c425("Transient Notes NA ASO", 425), c426("Transient Notes NA CSF", 426), c427("Transient Notes NA FCSD-SEO", 427),
    c428("Transient Notes NA OGC", 428), c429("Transient Notes NA CCM", 429), c430("Transient Notes NA PS&L", 430),
    c431("Transient Notes NA EPRC", 431), c432("Transient Notes NA FCSD-RSP", 432),
    c433("Transient Notes NA FCSD-SCM", 433), c434("Transient Notes NA FCSD-PURCHASING", 434),
    c435("Transient Notes NA FCSD-Executive summary notes", 435),

    c436("Transient Notes EU ASO", 436), c437("Transient Notes EU CSF", 437), c438("Transient Notes EU FCSD-SEO", 438),
    c439("Transient Notes EU OGC", 439), c440("Transient Notes EU CCM", 440), c441("Transient Notes EU PS&L", 441),
    c442("Transient Notes EU EPRC", 442), c443("Transient Notes EU FCSD-RSP", 443),
    c444("Transient Notes EU FCSD-SCM", 444), c445("Transient Notes EU FCSD-PURCHASING", 445),
    c446("Transient Notes EU FCSD-Executive summary notes", 446),

    c447("Transient Notes SA ASO", 447), c448("Transient Notes SA CSF", 448), c449("Transient Notes SA FCSD-SEO", 449),
    c450("Transient Notes SA OGC", 450), c451("Transient Notes SA CCM", 451), c452("Transient Notes SA PS&L", 452),
    c453("Transient Notes SA EPRC", 453), c454("Transient Notes SA FCSD-RSP", 454),
    c455("Transient Notes SA FCSD-SCM", 455), c456("Transient Notes SA FCSD-PURCHASING", 456),
    c457("Transient Notes SA FCSD-Executive summary notes", 457),

    c458("Transient Notes IM ASO", 458), c459("Transient Notes IM CSF", 459), c460("Transient Notes IM FCSD-SEO", 460),
    c461("Transient Notes IM OGC", 461), c462("Transient Notes IM CCM", 462), c463("Transient Notes IM PS&L", 463),
    c464("Transient Notes IM EPRC", 464), c465("Transient Notes IM FCSD-RSP", 465),
    c466("Transient Notes IM FCSD-SCM", 466), c467("Transient Notes IM FCSD-PURCHASING", 467),
    c468("Transient Notes IM FCSD-Executive summary notes", 468),

    c469("Transient Notes GC ASO", 469), c470("Transient Notes GC CSF", 470), c471("Transient Notes GC FCSD-SEO", 471),
    c472("Transient Notes GC OGC", 472), c473("Transient Notes GC CCM", 473), c474("Transient Notes GC PS&L", 474),
    c475("Transient Notes GC EPRC", 475), c476("Transient Notes GC FCSD-RSP", 476),
    c477("Transient Notes GC FCSD-SCM", 477), c478("Transient Notes GC FCSD-PURCHASING", 478),
    c479("Transient Notes GC FCSD-Executive summary notes", 479),
    c485("FDR Reportable Flag", 485),
    c486("FRC Approved Date", 486),

    c490("Model Years Affected", 490),
    c491("Brands Affected", 491),
    c492("GCAMP Global FSA #", 492),

    c493("Causal Type", 493),
    c494("Causal Function", 494),

    c495("Segment", 495),
    c498("FSA Launch Date", 498),
    c499("Estimated Total Cost", 499),
    c500("Date Added", 500),
    c501("Parts Info Exist", 501),
    c502("FSA Status", 502),


    c505("CCRG Pre-Authorization", 505),
    c506("CSF Pre-Authorization", 506),
    c507("EPRC Pre-Authorization", 507),
    c508("CCRG Pre-Authorization", 508),
    c509("CSF Pre-Authorization", 509),
    c510("EPRC Pre-Authorization", 510),
    c511("SCM/Purchasing Rating", 511),
    c512("Escalation to Leadership", 512),
    c513("Supplier GSDB", 513),
    c514("Supplier Name", 514),
    c515("Purchasing Support Required", 515),
    c516("Purchasing Support Required", 516),
    c517("SCM Comments", 517),
    c518("SCM Comments", 518),
    c519("Purchasing Comments", 519),
    c520("Purchasing Comments", 520),
    c521("Projection Date", 521),
    c522("Critical Part", 522),
    c523("Critical Part", 523),
    c524("Critical Part Launch Strategy", 524),


    c525("SCM/Purchasing Rating", 525),
    c526("Escalation to Leadership", 526),
    c527("Supplier GSDB", 527),
    c528("Supplier Name", 528),
    c529("Projection Date", 529),
    c530("STA", 530),
    c531("STA Fsa", 531),


    c532("Sold Units", 532),
    c533("UnSold Units", 533),
    c534("Sold Units", 534),
    c535("UnSold Units", 535),

    c536("Pre-Authorization", 536),
    c537("Pre-Authorization", 537),
    c538("Parts Comment", 538),
    c539("Parts Comment", 539),
    c543("ICA Date", 543),
    c544("PCA Date", 544),
    c545("Patient Zero Date", 545),

    c540("Overall Monitor days - CCRG", 540),
    c541("Overall Monitor days - CSF", 541),
    c542("Overall Monitor days - EPRC", 542),


    c546("Log (NA) Critical Part", 546),
    c547("Log (NA) Critical Part Launch Strategy", 547),
    c548("Log (NA) SCM/Purchasing Rating", 548),
    c549("Log (NA) Escalation to Leadership", 549),
    c550("Log (NA) Purchasing Support Required", 550),
    c551("Log (NA) Part Ok", 551),

    c552("Log (NA) Critical Part", 552),
    c553("Log (NA) Critical Part Launch Strategy", 553),
    c554("Log (NA) SCM/Purchasing Rating", 554),
    c555("Log (NA) Escalation to Leadership", 555),
    c556("Log (NA) Purchasing Support Required", 556),
    c557("Log (NA) Part Ok", 557),

    c558("NHTSA VIN Look Up Review", 558),
    c559("NHTSA VIN Look Up Review", 559),

    c560("VIN Look Up Review", 560),
    c561("VIN Look Up Review", 561),


    c565("PSL Sign Off Date", 565),
    c566("PSL Sign Off Date", 566),

    c567("Monitor Comeback Date", 567),


    c568("Interim Corrective Action(ICA)", 568),
    c569("Permanent Corrective Action(PCA)", 569),
    c596("TRG Meeting Status", 596),
    c600("TRG Opened Date", 600),

    c570("Specific Root Cause filled out date", 570),
    c571("14D PRA filled out Date", 571),

    c572("MAKE MODEL MODEL YEAR", 572),
    c573("Make Model Model Year", 573),

    c574("Root Cause Director", 574),
    c575("Source Information - Stop Ship#", 575),
    c576("14D Author Fsa", 576),
    c577("PAC Author", 577),

    c578("RSP Analyst Fsa", 578),
    c579("Implementation lead Fsa", 579),
    c580("Implementation Manager", 580),
    c581("PS&L Supply Chain Fsa", 581),
    c582("FCSD Purchase Lead Fsa", 582),
    c583("Related Items", 583),
    c584("14D to TRG Days", 584),
    c585("14D to TRG Days", 585),
    c586("TRG to FRC Days", 586),
    c587("TRG to FRC Days", 587),

    c588("FRC to NA Owner Notification RM Days", 588),
    c589("FRC to SA Owner Notification RM Days", 589),
    c590("FRC to EU Owner Notification RM Days", 590),
    c591("FRC to IMG Owner Notification RM Days", 591),
    c592("FRC to GCH Owner Notification RM Days", 592),

    c593("CCRG Reopened Date", 593),
    c594("CSF Reopened Date", 594),
    c595("EPRC Reopened Date", 595),

    c597("CCRG Attorney", 597),
    c598("EPRC Attorney", 598),
    c599("CSF Attorney", 599),
    c601("GCAMP Coordinator", 601),
    c602("Quality Lead", 602),
    c603("Regulation Number", 603),
    c605("TRG Request Creation Date", 605),
    c606("Root Cause Director", 606),
    c607("Quality Problem Solving Engineer Added Date", 607),
    c608("TRG Request Notes", 608),
    c609("Legal Assistant", 609),
    c610("Service STA", 610),

    c611("TRG Meeting Type", 611),
    c612("CCRG FSAM Status", 612),
    c613("CSF FSAM Status", 613),
    c614("EPRC FSAM Status", 614),
    c615("CCRG FSAM Flag", 615),
    c616("CSF FSAM Flag", 616),
    c617("EPRC FSAM Flag", 617),
    c618("GOVT FSAM Flag", 618),
    c619("FD1 Status", 619),
    c620("FD1 Last Updated", 620),
    c621("FD2 Status", 621),
    c622("FD2 Last Updated", 622),
    c623("FD3 Status", 623),
    c624("FD3 Last Updated", 624),
    c625("FD4 Status", 625),
    c626("FD4 Last Updated", 626),
    c627("FD6 Status", 627),
    c628("FD6 Last Updated", 628),
    c629("FD7 Status", 629),
    c630("FD7 Last Updated", 630),
    c631("FD8 Status", 631),
    c632("FD8 Last Updated", 632),
    c633("FD11 Status", 633),
    c634("FD11 Last Updated", 634),
    c635("Specific Root Cause", 635),
    c636("Detection Root Cause", 636),
    c637("Systemic Root Cause", 637),
    c638("CSF TRG/EMM Scheduler ", 638),
    c639("EPRC TRG/EMM Scheduler ", 639);


    private final String columnName;

    private final Integer id;

    public static final String CAUSAL_TYPE = "Causal Type";

    public static final String CAUSAL_FUNCTION = "Causal Function";

    public static final String SOURCE = "Source";

    public static final String SEGMENT = "Segment";

    public static final String RELATED_ITEMS = "Related Items";

    public static final String AFFECTED_VEHICLES = "Affected Vehicles";

    public static final String REGION_AFFECTED = "Region Affected";

    public static final String ISSUE_TYPE = "Issue Type";

    public static final String LEAD_REGION = "Lead Region";

    public static final String LAUNCH_REGIONS = "Launch Regions";

    public static final String CURRENT_PHASE = "Current Phase";

    public static final String DESCRIPTION = "Description";

    public static final String ISSUE_TITLE = "Issue Title";

    public static final String CSF_STATUS = "CSF Status";

    public static final String EPRC_STATUS = "EPRC Status";

    public static final String CCRG_STATUS = "CCRG Status";

    public static final String CCRG_CLOSURE_REVIEW = "CCRG Closure Review";

    public static final String EPRC_CLOSURE_REVIEW = "EPRC Closure Review";

    public static final String LAST_REVIEW_TYPE = "Last Review (Type)";

    public static final String LAST_REVIEW_DATE = "Last Review (Date)";

    public static final String NEXT_REVIEW_DATE = "Next Review (Date)";

    public static final String NEXT_REVIEW_TYPE = "Next Review (Type)";

    public static final String FIELD_SERVICE_ACTION = "Field Service Action #";

    public static final String FRC_DATE = "FRC Date";

    public static final String APPROX_GLOBAL_VOLUME = "Approx. Global Volume";

    public static final String X_NUMBER = "X Number";

    public static final String _14D_KICK_OFF_DATE = "14D Requested Date";

    public static final String GOV_FOLLOW_UP_DATE = "Gov. FollowUp Date";

    public static final String DAYS_OPEN = "Days Open";

    public static final String ISSUE = "Issue #";

    public static final String TECHNICAL_AUTHOR = "Technical Author";

    public static final String SUPERVISOR = "Supervisor";

    public static final String ROOT_CAUSE_OWNER = "Root Cause Owner";

    public static final String ROOT_CAUSE_DIRECTOR = "Root Cause Director";

    public static final String SOURCE_INFORMATION_STOP_SHIP = "Source Information - Stop Ship#";

    public static final String PS_L_SUPPLY_CHAIN = "PS&L Supply Chain";

    public static final String GCAMP_COORDINATOR = "GCAMP Coordinator";

    public static final String QUALITY_LEAD = "Quality Lead";

    public static final String CSF_TRG_SCHEDULER = "CSF TRG/EMM Scheduler ";

    public static final String EPRC_TRG_SCHEDULER = "EPRC TRG/EMM Scheduler ";

    public static final String SERVICE_STA = "Service STA";

    public static final String LEGAL_ASSISTANT = "Legal Assistant";

    public static final String PROGRAM_MANAGER = "Program Manager";

    public static final String FCSD_PROGRAM_MANAGER = "FCSD Program Manager";

    public static final String ANALYST = "RSP Analyst";

    public static final String ANALYST_FSA = "RSP Analyst Fsa";

    public static final String Implementation_leadFsa = "Implementation lead Fsa";

    public static final String PSL_Supply_Chain_Fsa = "PS&L Supply Chain Fsa";

    public static final String FCSD_Purchase_Lead_Fsa = "FCSD Purchase Lead Fsa";

    public static final String _14DAuthor_Fsa = "14D Author Fsa";

    public static final String FCSD_ANALYST = "RSP Analyst";

    public static final String DIAGNOSTIC_SERVICE_PROD = "Diagnostic Service Prod";

    public static final String CSF_CHAIR = "CSF Chair";

    public static final String EPRC_CHAIR = "EPRC Chair";

    public static final String CCRG_CHAIR = "CCRG Chair";

    public static final String PAC_AUTHOR = "PAC Author";

    public static final String QPSE = "Quality Problem Solving Engineer";

    public static final String PAC_PROCESS = "PAC Process";

    public static final String CCM = "CCM";

    public static final String CCE = "CCE";

    public static final String _14D_AUTHOR = "14D Author";

    public static final String ASO_LEAD_INVESTIGATOR = "ASO Lead Investigator";

    public static final String LEAD_INVESTIGATOR = "Lead Investigator";

    public static final String NA = "NA";

    public static final String SA = "SA";

    public static final String EU = "EU";

    public static final String IMG = "IMG";

    public static final String GCH = "GCH";

    public static final String CCRG_NOTES = "ASO";

    public static final String CCRG_ENG = "ENG (CCRG)";

    public static final String CCRG_CCRG = "Chair (CCRG)";

    public static final String CCRG_OGC = "OGC (CCRG)";

    public static final String CCRG_ATTORNEY = "CCRG Attorney";

    public static final String EPRC_NOTES = "EPRC";

    public static final String EPRC_ENG = "ENG (EPRC)";

    public static final String EPRC_EPRC = "Chair (EPRC)";

    public static final String EPRC_OGC = "OGC (EPRC)";

    public static final String EPRC_ATTORNEY = "EPRC Attorney";

    public static final String CSF_ATTORNEY = "CSF Attorney";

    public static final String FORUM = "Forum";

    public static final String CCRG_OPENED_DATE = "CCRG Open Date";

    public static final String EPRC_OPENED_DATE = "EPRC Open Date";

    public static final String CSF_OPENED_DATE = "CSF Open Date";

    public static final String EXTERNAL_ORG = "External Organization";

    public static final String GOVT_STATUS = "GOVT Status";

    public static final String CCRG_FSAM_STATUS = "CCRG FSAM Status";
    public static final String CSF_FSAM_STATUS = "CSF FSAM Status";
    public static final String EPRC_FSAM_STATUS = "EPRC FSAM Status";

    public static final String CCRG_FSAM_FLAG = "CCRG FSAM Flag";
    public static final String CSF_FSAM_FLAG = "CSF FSAM Flag";
    public static final String EPRC_FSAM_FLAG = "EPRC FSAM Flag";
    public static final String GOVT_FSAM_FLAG = "GOVT FSAM Flag";

    public static final String FD1_STATUS = "FD1 Status";
    public static final String FD1_LASTUPDATED = "FD1 Last Updated";
    public static final String FD2_STATUS = "FD2 Status";
    public static final String FD2_LASTUPDATED = "FD2 Last Updated";
    public static final String FD3_STATUS = "FD3 Status";
    public static final String FD3_LASTUPDATED = "FD3 Last Updated";
    public static final String FD4_STATUS = "FD4 Status";
    public static final String FD4_LASTUPDATED = "FD4 Last Updated";
    public static final String FD6_STATUS = "FD6 Status";
    public static final String FD6_LASTUPDATED = "FD6 Last Updated";
    public static final String FD7_STATUS = "FD7 Status";
    public static final String FD7_LASTUPDATED = "FD7 Last Updated";
    public static final String FD8_STATUS = "FD8 Status";
    public static final String FD8_LASTUPDATED = "FD8 Last Updated";
    public static final String FD11_STATUS = "FD11 Status";
    public static final String FD11_LASTUPDATED = "FD11 Last Updated";


    public static final String FSAM_FLAG = "FSAM Flag";

    public static final String FD_STATUS = "14D Status";
    public static final String FD_CLOSURE = "14D Close Date";

    public static final String GOV_INV_MGR = "Investigation Manager";
    public static final String GOV_LEAD_INV = "GOV Lead Investigator";
    public static final String CSF_LEAD_INV = "CSF Lead Investigator";
    public static final String EPRC_LEAD_INV = "EPRC Lead Investigator";

    public static final String TRANSIENTNOTES_ASO = "Transient Notes - ASO";
    public static final String TRANSIENTNOTES_EPRC = "Transient Notes - EPRC";
    public static final String TRANSIENTNOTES_CSF = "Transient Notes - CSF";
    public static final String TRANSIENTNOTES_CCM = "Transient Notes - CCM";
    public static final String TRANSIENTNOTES_FCSD_RSP = "RSP Comments";
    public static final String TRANSIENTNOTES_PSL = "Transient Notes - PS&L";
    public static final String TRANSIENTNOTES_OGC = "Transient Notes - OGC";
    public static final String implementation_lead = "Implementation Lead";

    public static final String IMPLEMENTATION_LEAD = "Implementation lead";
    public static final String implementation_manager = "Implementation Manager";
    public static final String DAYS_OPEN_IN_CCRG = "Days Open in CCRG";
    public static final String DAYS_OPEN_IN_CSF = "Days Open in CSF";
    public static final String DAYS_OPEN_IN_EPRC = "Days Open in EPRC";
    public static final String DAYS_OPEN_IN_GOV = "Days Open in GOV";
    public static final String CCRG_SUFFIX = " - CCRG";
    public static final String CSF_SUFFIX = " - CSF";
    public static final String EPRC_SUFFIX = " - EPRC";
    public static final String GOVT_SUFFIX = " - GOV";
    public static final String DAYS_IN_MONITOR = "Days in Monitor";
    public static final String DAYS_IN_MONITOR_CCRG = DAYS_IN_MONITOR + CCRG_SUFFIX;
    public static final String DAYS_IN_MONITOR_CSF = DAYS_IN_MONITOR + CSF_SUFFIX;
    public static final String DAYS_IN_MONITOR_EPRC = DAYS_IN_MONITOR + EPRC_SUFFIX;
    public static final String DAYS_IN_MONITOR_GOVT = DAYS_IN_MONITOR + GOVT_SUFFIX;
    public static final String _14D_Age = "14D Age";
    public static final String APPROVING_REGION = "Approving Region";

    public static final String MONITOR_COMBACK = "Monitor comeback date";
    public static final String MONITOR_START = "Monitor Set date";
    public static final String MONITOR_COMBACK_CCRG = MONITOR_COMBACK + CCRG_SUFFIX;
    public static final String MONITOR_START_CCRG = MONITOR_START + CCRG_SUFFIX;
    public static final String MONITOR_COMBACK_CSF = MONITOR_COMBACK + CSF_SUFFIX;
    public static final String MONITOR_START_CSF = MONITOR_START + CSF_SUFFIX;
    public static final String MONITOR_COMBACK_EPRC = MONITOR_COMBACK + EPRC_SUFFIX;
    public static final String MONITOR_START_EPRC = MONITOR_START + EPRC_SUFFIX;
    public static final String MONITOR_COMBACK_GOVT = MONITOR_COMBACK + GOVT_SUFFIX;
    public static final String MONITOR_START_GOVT = MONITOR_START + GOVT_SUFFIX;

    public static final String OVERALL_MONITOR_CCRG = "Overall Monitor days - CCRG";
    public static final String OVERALL_MONITOR_CSF = "Overall Monitor days - CSF";

    public static final String OVERALL_MONITOR_EPRC = "Overall Monitor days - EPRC";

    public static final String MEETING_DATES_SUFFIX = " Meeting Dates";

    public static final String CCRG_MEETINGS = "CCRG" + MEETING_DATES_SUFFIX;
    public static final String CSF_MEETINGS = "CSF" + MEETING_DATES_SUFFIX;
    public static final String EPRC_MEETINGS = "EPRC" + MEETING_DATES_SUFFIX;
    public static final String GCCRG_MEETINGS = "GCCRG" + MEETING_DATES_SUFFIX;
    public static final String GCSF_MEETINGS = "GCSF" + MEETING_DATES_SUFFIX;
    public static final String FD_MEETINGS = "14D" + MEETING_DATES_SUFFIX;
    public static final String TRG_MEETINGS = "TRG" + MEETING_DATES_SUFFIX;
    public static final String FRC_MEETINGS = "FRC" + MEETING_DATES_SUFFIX;
    public static final String GOV_MEETINGS = "Gov" + MEETING_DATES_SUFFIX;
    public static final String EMM_MEETINGS = "EMM" + MEETING_DATES_SUFFIX;

    public static final String ASO = "ASO";
    public static final String ENG = "ENG";
    public static final String CCRG = "CCRG";
    public static final String OGC = "OGC";
    public static final String CPLT = "CPLT";

    public static final String EPRC_FACT_SHEET = "EPRC Fact Sheet";
    public static final String IP = "IP";
    public static final String REV = "REV";
    public static final String PA = "PA";
    public static final String CPLTD = "CPLTD";
    public static final String INPROGRESS = "In Progress";
    public static final String REVIEW = "Review";
    public static final String PENDING_APPROVAL = "Pending-Approval";
    public static final String COMPLETED = "Completed";

    public static final String MONITOR_SET_DATE_CCRG = "Monitor Set date - CCRG";

    public static final String MONITOR_SET_DATE_CSF = "Monitor Set date - CSF";

    public static final String MONITOR_SET_DATE_EPRC = "Monitor Set date - EPRC";

    public static final String MONITOR_SET_DATE_GOV = "Monitor Set date - GOV";

    public static final String MONITOR_COMEBACK_DATE_CCRG = "Monitor comeback date - CCRG";

    public static final String MONITOR_COMEBACK_DATE_CSF = "Monitor comeback date - CSF";

    public static final String MONITOR_COMEBACK_DATE_EPRC = "Monitor comeback date - EPRC";

    public static final String MONITOR_COMEBACK_DATE_GOV = "Monitor comeback date - GOV";

    public static final String MONITOR_COMEBACK_DATE = "Monitor Comeback Date";

    public static final String CCRG_MEETING_DATES = "CCRG Meeting Dates";

    public static final String CSF_MEETING_DATES = "CSF Meeting Dates";

    public static final String EMM_MEETING_DATES = "EMM Meeting Dates";

    public static final String EPRC_MEETING_DATES = "EPRC Meeting Dates";

    public static final String FRC_MEETING_DATES = "FRC Meeting Dates";

    public static final String GCCRG_MEETING_DATES = "GCCRG Meeting Dates";

    public static final String GCSF_MEETING_DATES = "GCSF Meeting Dates";

    public static final String GOV_MEETING_DATES = "Gov Meeting Dates";

    public static final String TRG_MEETING_DATES = "TRG Meeting Dates";

    public static final String FD_14_MEETINGS_DATE = "14D Meeting Dates";

    public static final String CCRG_MONITOR_DAYS = "Days in Monitor - CCRG";

    public static final String CSF_MONITOR_DAYS = "Days in Monitor - CSF";

    public static final String EPRC_MONITOR_DAYS = "Days in Monitor - EPRC";

    public static final String GOV_MONITOR_DAYS = "Days in Monitor - GOV";

    public static final String HELP_REQUIRED = "Help Required";
    public static final String LAST_TRG = "Last TRG";
    public static final String DATE_ADDED = "Date Added";
    public static final String Sixty_DAY_AGEING = "60 Day Ageing";
    public static final String Ninety_DAY_AGEING = "90 Day Ageing";
    public static final String TOTAL_AGEING_CCRG = "Total Ageing CCRG";
    public static final String TOTAL_AGEING_EPRC = "Total Ageing EPRC";
    public static final String TOTAL_AGEING_CSF = "Total Ageing CSF";
    public static final String TOTAL_AGEING_GOV = "Total Ageing GOVERNMENT";
    public static final String CCRG_STATUS_PLUS_45 = "Status CCRG + 45";
    public static final String EPRC_STATUS_PLUS_45 = "Status EPRC + 45";
    public static final String CSF_STATUS_PLUS_45 = "Status CSF + 45";
    public static final String GOV_STATUS_PLUS_45 = "Status GOV + 45";
    public static final String CCRG_STATUS_PLUS_60 = "Status CCRG + 60";
    public static final String EPRC_STATUS_PLUS_60 = "Status EPRC + 60";
    public static final String CSF_STATUS_PLUS_60 = "Status CSF + 60";
    public static final String GOV_STATUS_PLUS_60 = "Status GOV + 60";
    public static final String TRG_COUNT = "TRG Count";
    public static final String RECOVERY_PLAN = "Recovery Plan";

    public static final String MOBILE_REPAIR = "Mobile Repair";

    public static final String INCLUDES_RENTAL = "Includes Rental";

    public static final String INCLUDES_TOWING = "Includes Towing";

    public static final String REGULATION_NUMBER = "Regulation Number";
    public static final String TRG_REQUESTED_CREATION_DATE = "TRG Request Creation Date";
    public static final String QUALITY_PROBLEM_SOLVING_ENGINEER_ADDED_DATE = "Quality Problem Solving Engineer Added Date";
    public static final String TRG_REQUEST_NOTES = "TRG Request Notes";
    public static final String CCRG_Concern_Comments = "CCRG Meeting notes";
    public static final String EPRC_Concern_Comments = "EPRC Meeting notes";
    public static final String CSF_Concern_Comments = "CSF Meeting notes";
    public static final String GOV_Concern_Comments = "GOV Meeting notes";

    public static final String DAYS_IN_POSTFSAMONITOR_CCRG = "Days in Post FSA Monitor CCRG";
    public static final String DAYS_IN_POSTFSAMONITOR_CSF = "Days in Post FSA Monitor CSF";
    public static final String DAYS_IN_POSTFSAMONITOR_EPRC = "Days in Post FSA Monitor EPRC";

    public static final String CCRG_MONITORBACKTOACTIVE = "CCRG- Monitor Back To Active";
    public static final String CSF_MONITORBACKTOACTIVE = "CSF- Monitor Back To Active";
    public static final String EPRC_MONITORBACKTOACTIVE = "EPRC- Monitor Back To Active";
    public static final String GOV_MONITORBACKTOACTIVE = "GOV- Monitor Back To Active";

    // FSA related columns
    public static final String FSA_NO = "FSA No";

    public static final String CAUSAL_PARTS_ISSUE = "Causal Parts";
    public static final String CAUSAL_PART = "Causal Part";
    public static final String POTENTIAL_TYPE = "FSA Type";
    public static final String NA_LAUNCH_ACTIVITY = "NA - Launch Activity Complete";

    public static final String SA_LAUNCH_ACTIVITY = "SA -  Launch Activity Complete";

    public static final String EU_LAUNCH_ACTIVITY = "EU - Launch Activity Complete";

    public static final String IMG_LAUNCH_ACTIVITY = "IMG - Launch Activity Complete";

    public static final String GCN_LAUNCH_ACTIVITY = "GCN - Launch Activity Complete";

    public static final String AFFECTED_VEHICLE_LINES = "Affected Vehicle Lines";

    public static final String TRG_DATE_TYPE = "TRG date (Type)";

    public static final String TRG_DATE_POPULATION = "TRG date (Population)";

    public static final String GCH_INTERIM_REMEDY_AVAILABLE_ACTUAL_SUBMISSION_DATE = "GCH - Owner Notification Remedy Avail Inspection Actual";

    public static final String IMG_INTERIM_REMEDY_AVAILABLE_ACTUAL_SUBMISSION_DATE = "IMG - Owner Notification Remedy Avail Inspection Actual";

    public static final String SA_INTERIM_REMEDY_AVAILABLE_ACTUAL_SUBMISSION_DATE = "SA - Owner Notification Remedy Avail Inspection Actual";

    public static final String EU_INTERIM_REMEDY_AVAILABLE_ACTUAL_SUBMISSION_DATE = "EU - Owner Notification Remedy Avail Inspection Actual";

    public static final String NA_INTERIM_REMEDY_AVAILABLE_ACTUAL_SUBMISSION_DATE = "NA - Owner Notification Remedy Avail Inspection Actual";

    public static final String GCH_INTERIM_REMEDY_AVAILABLE_TARGET_DATE = "GCH - Owner Notification Remedy Avail Inspection Target";

    public static final String IMG_INTERIM_REMEDY_AVAILABLE_TARGET_DATE = "IMG - Owner Notification Remedy Avail Inspection Target";

    public static final String SA_INTERIM_REMEDY_AVAILABLE_TARGET_DATE = "SA - Owner Notification Remedy Avail Inspection Target";

    public static final String EU_INTERIM_REMEDY_AVAILABLE_TARGET_DATE = "EU - Owner Notification Remedy Avail Inspection Target";

    public static final String NA_INTERIM_REMEDY_AVAILABLE_TARGET_DATE = "NA - Owner Notification Remedy Avail Inspection Target";

    public static final String GCH_FOLLOW_UP_ACTUAL_SUBMISSION_DATE = "GCH - Owner Notification Actual";

    public static final String IMG_FOLLOW_UP_ACTUAL_SUBMISSION_DATE = "IMG - Owner Notification Actual";

    public static final String SA_FOLLOW_UP_ACTUAL_SUBMISSION_DATE = "SA - Owner Notification Actual";

    public static final String EU_FOLLOW_UP_ACTUAL_SUBMISSION_DATE = "EU - Owner Notification Actual";

    public static final String NA_FOLLOW_UP_ACTUAL_SUBMISSION_DATE = "NA - Owner Notification Actual";

    public static final String GCH_FOLLOW_UP_TARGET_DATE = "GCH - Owner Notification Follow-up Target";

    public static final String IMG_FOLLOW_UP_TARGET_DATE = "IMG - Owner Notification Follow-up Target";

    public static final String SA_FOLLOW_UP_TARGET_DATE = "SA - Owner Notification Follow-up Target";

    public static final String EU_FOLLOW_UP_TARGET_DATE = "EU - Owner Notification Follow-up Target";

    public static final String NA_FOLLOW_UP_TARGET_DATE = "NA - Owner Notification Follow-up Target";

    public static final String GCH_NO_REMEDY_AVAILABLE_ACTUAL_SUBMISSION_DATE = "GCH - Owner Notification No Remedy Avail Actual";

    public static final String IMG_NO_REMEDY_AVAILABLE_ACTUAL_SUBMISSION_DATE = "IMG - Owner Notification No Remedy Avail Actual";

    public static final String SA_NO_REMEDY_AVAILABLE_ACTUAL_SUBMISSION_DATE = "SA - Owner Notification No Remedy Avail Actual";

    public static final String EU_NO_REMEDY_AVAILABLE_ACTUAL_SUBMISSION_DATE = "EU - Owner Notification No Remedy Avail Actual";

    public static final String NA_NO_REMEDY_AVAILABLE_ACTUAL_SUBMISSION_DATE = "NA - Owner Notification No Remedy Avail Actual";

    public static final String GCH_NO_REMEDY_AVAILABLE_TARGET_DATE = "GCH - Owner Notification No Remedy Avail Target";

    public static final String IMG_NO_REMEDY_AVAILABLE_TARGET_DATE = "IMG - Owner Notification No Remedy Avail Target";

    public static final String SA_NO_REMEDY_AVAILABLE_TARGET_DATE = "SA - Owner Notification No Remedy Avail Target";

    public static final String EU_NO_REMEDY_AVAILABLE_TARGET_DATE = "EU - Owner Notification No Remedy Avail Target";

    public static final String NA_NO_REMEDY_AVAILABLE_TARGET_DATE = "NA - Owner Notification No Remedy Avail Target";

    public static final String GCH_REMEDY_AVAILABLE_ACTUAL_SUBMISSION_DATE = "GCH - Owner Notification Remedy Avail Legacy Actual";

    public static final String IMG_REMEDY_AVAILABLE_ACTUAL_SUBMISSION_DATE = "IMG - Owner Notification Remedy Avail Legacy Actual";

    public static final String SA_REMEDY_AVAILABLE_ACTUAL_SUBMISSION_DATE = "SA - Owner Notification Remedy Avail Legacy Actual";

    public static final String EU_REMEDY_AVAILABLE_ACTUAL_SUBMISSION_DATE = "EU - Owner Notification Remedy Avail Legacy Actual";

    public static final String NA_REMEDY_AVAILABLE_ACTUAL_SUBMISSION_DATE = "NA - Owner Notification Remedy Avail Legacy Actual";

    public static final String GCH_REMEDY_AVAILABLE_TARGET_DATE = "GCH - Owner Notification Remedy Avail Legacy Target";

    public static final String IMG_REMEDY_AVAILABLE_TARGET_DATE = "IMG - Owner Notification Remedy Avail Legacy Target";

    public static final String SA_REMEDY_AVAILABLE_TARGET_DATE = "SA - Owner Notification Remedy Avail Legacy Target";

    public static final String EU_REMEDY_AVAILABLE_TARGET_DATE = "EU - Owner Notification Remedy Avail Legacy Target";

    public static final String NA_REMEDY_AVAILABLE_TARGET_DATE = "NA - Owner Notification Remedy Avail Legacy Target";

    public static final String PURCHASE_LEAD = "FCSD Purchase Lead";

    public static final String NA_GOVT_NOTIFY_ACTIVITY = "NA - Govt Notification";

    public static final String SA_GOVT_NOTIFY_ACTIVITY = "SA - Govt Notification";

    public static final String EU_GOVT_NOTIFY_ACTIVITY = "EU - Govt Notification";
    public static final String IMG_GOVT_NOTIFY_ACTIVITY = "IMG - Govt Notification";
    public static final String GCN_GOVT_NOTIFY_ACTIVITY = "GCN - Govt Notification";
    public static final String NA_OWNER_NOTIFY_ACTIVITY = "NA - Owner Notification";
    public static final String SA_OWNER_NOTIFY_ACTIVITY = "SA - Owner Notification";
    public static final String EU_OWNER_NOTIFY_ACTIVITY = "EU - Owner Notification";
    public static final String IMG_OWNER_NOTIFY_ACTIVITY = "IMG - Owner Notification";
    public static final String GCN_OWNER_NOTIFY_ACTIVITY = "GCN - Owner Notification";
    public static final String NA_DEALER_BULLETIN_ACTIVITY = "NA - Dealer Bulletin";
    public static final String SA_DEALER_BULLETIN_ACTIVITY = "SA - Dealer Bulletin";
    public static final String EU_DEALER_BULLETIN_ACTIVITY = "EU - Dealer Bulletin";
    public static final String IMG_DEALER_BULLETIN_ACTIVITY = "IMG - Dealer Bulletin";
    public static final String GCN_DEALER_BULLETIN_ACTIVITY = "GCN - Dealer Bulletin";
    public static final String NA_PARTS_AVAILABILITY = "NA - Parts Availability";
    public static final String SA_PARTS_AVAILABILITY = "SA - Parts Availabililty";
    public static final String EU_PARTS_AVAILABILITY = "EU - Parts Availabililty";
    public static final String IMG_PARTS_AVAILABILITY = "IMG - Parts Availability";
    public static final String GCN_PARTS_AVAILABILITY = "GCN - Parts Availability";

    public static final String FSA_REGIONS_AFFECTED = "Regions Affected";

    public static final String FRC_TO_LAUNCH = "FRC to Launch";

    public static final String NA_CONFIRMED_PARTS = "NA Parts Confirmed";
    public static final String SA_CONFIRMED_PARTS = "SA Parts Confirmed";
    public static final String IMG_CONFIRMED_PARTS = "IMG Parts Confirmed";
    public static final String EU_CONFIRMED_PARTS = "EU Parts Confirmed";
    public static final String GCH_CONFIRMED_PARTS = "GCN Parts Confirmed";

    public static final String NA_TOTAL_UNITS = "NA - Total Units";
    public static final String NA_TOTAL_SOLD = "NA - Sold";
    public static final String NA_TOTAL_UNSOLD = "NA - Unsold";

    public static final String EU_TOTAL_UNITS = "EU - Total Units";
    public static final String EU_TOTAL_SOLD = "EU - Sold";
    public static final String EU_TOTAL_UNSOLD = "EU - Unsold";

    public static final String SA_TOTAL_UNITS = "SA - Total Units";
    public static final String SA_TOTAL_SOLD = "SA - Sold";
    public static final String SA_TOTAL_UNSOLD = "SA - Unsold";

    public static final String IMG_TOTAL_UNITS = "IMG - Total Units";
    public static final String IMG_TOTAL_SOLD = "IMG - Sold";
    public static final String IMG_TOTAL_UNSOLD = "IMG - Unsold";

    public static final String GCH_TOTAL_UNITS = "GCH - Total Units";
    public static final String GCH_TOTAL_SOLD = "GCH - Sold ";
    public static final String GCH_TOTAL_UNSOLD = "GCH - Unsold";


    public static final String NA_INTERNAL_AWARNESS_TARGET_DT = "NA - Internal Awareness Notification (EU only) Target Date";
    public static final String NA_INTERNAL_AWARNESS_ACTL_CMPL_DT = "NA - Internal Awareness Notification (EU only) Actual Submission Date";
    public static final String NA_DEALER_AWARNESS_TARGET_DT = "NA - Dealer Awareness Notification Target Date";
    public static final String NA_DEALER_AWARNESS_ACTL_CMPL_DT = "NA - Dealer Awareness Notification Actual Submission Date";
    public static final String NA_ADVANCE_DEALER_NOTIFY_TARGET_DT = "NA - Advanced Dealer Notification Target Date";
    public static final String NA_ADVANCE_DEALER_NOTIFY_ACTL_CMPL_DT = "NA - Advanced Dealer Notification Actual Submission Date";
    public static final String NA_FULL_BULLETIN_LAUNCH_TARGET_DT = "NA - Full Bulletin Launch Target Date";
    public static final String NA_FULL_BULLETIN_LAUNCH_ACTL_CMPL_DT = "NA - Full Bulletin Launch Actual Submission Date";

    public static final String EU_INTERNAL_AWARNESS_TARGET_DT = "EU - Internal Awareness Notification (EU only) Target Date";
    public static final String EU_INTERNAL_AWARNESS_ACTL_CMPL_DT = "EU - Internal Awareness Notification (EU only) Actual Submission Date";
    public static final String EU_DEALER_AWARNESS_TARGET_DT = "EU - Dealer Awareness Notification Target Date";
    public static final String EU_DEALER_AWARNESS_ACTL_CMPL_DT = "EU - Dealer Awareness Notification Actual Submission Date";
    public static final String EU_ADVANCE_DEALER_NOTIFY_TARGET_DT = "EU - Advanced Dealer Notification Target Date";
    public static final String EU_ADVANCE_DEALER_NOTIFY_ACTL_CMPL_DT = "EU - Advanced Dealer Notification Actual Submission Date";
    public static final String EU_FULL_BULLETIN_LAUNCH_TARGET_DT = "EU - Full Bulletin Launch Target Date";
    public static final String EU_FULL_BULLETIN_LAUNCH_ACTL_CMPL_DT = "EU - Full Bulletin Launch Actual Submission Date";

    public static final String SA_INTERNAL_AWARNESS_TARGET_DT = "SA - Internal Awareness Notification (EU only) Target Date";
    public static final String SA_INTERNAL_AWARNESS_ACTL_CMPL_DT = "SA - Internal Awareness Notification (EU only) Actual Submission Date";
    public static final String SA_DEALER_AWARNESS_TARGET_DT = "SA - Dealer Awareness Notification Target Date";
    public static final String SA_DEALER_AWARNESS_ACTL_CMPL_DT = "SA - Dealer Awareness Notification Actual Submission Date";
    public static final String SA_ADVANCE_DEALER_NOTIFY_TARGET_DT = "SA - Advanced Dealer Notification Target Date";
    public static final String SA_ADVANCE_DEALER_NOTIFY_ACTL_CMPL_DT = "SA - Advanced Dealer Notification Actual Submission Date";
    public static final String SA_FULL_BULLETIN_LAUNCH_TARGET_DT = "SA - Full Bulletin Launch Target Date";
    public static final String SA_FULL_BULLETIN_LAUNCH_ACTL_CMPL_DT = "SA - Full Bulletin Launch Actual Submission Date";

    public static final String IMG_INTERNAL_AWARNESS_TARGET_DT = "IMG - Internal Awareness Notification (EU only) Target Date";
    public static final String IMG_INTERNAL_AWARNESS_ACTL_CMPL_DT = "IMG - Internal Awareness Notification (EU only) Actual Submission Date";
    public static final String IMG_DEALER_AWARNESS_TARGET_DT = "IMG - Dealer Awareness Notification Target Date";
    public static final String IMG_DEALER_AWARNESS_ACTL_CMPL_DT = "IMG - Dealer Awareness Notification Actual Submission Date";
    public static final String IMG_ADVANCE_DEALER_NOTIFY_TARGET_DT = "IMG - Advanced Dealer Notification Target Date";
    public static final String IMG_ADVANCE_DEALER_NOTIFY_ACTL_CMPL_DT = "IMG - Advanced Dealer Notification Actual Submission Date";
    public static final String IMG_FULL_BULLETIN_LAUNCH_TARGET_DT = "IMG - Full Bulletin Launch Target Date";
    public static final String IMG_FULL_BULLETIN_LAUNCH_ACTL_CMPL_DT = "IMG - Full Bulletin Launch Actual Submission Date";

    public static final String GCH_INTERNAL_AWARNESS_TARGET_DT = "GCH - Internal Awareness Notification (EU only) Target Date";
    public static final String GCH_INTERNAL_AWARNESS_ACTL_CMPL_DT = "GCH - Internal Awareness Notification (EU only) Actual Submission Date";
    public static final String GCH_DEALER_AWARNESS_TARGET_DT = "GCH - Dealer Awareness Notification Target Date";
    public static final String GCH_DEALER_AWARNESS_ACTL_CMPL_DT = "GCH - Dealer Awareness Notification Actual Submission Date";
    public static final String GCH_ADVANCE_DEALER_NOTIFY_TARGET_DT = "GCH - Advanced Dealer Notification Target Date";
    public static final String GCH_ADVANCE_DEALER_NOTIFY_ACTL_CMPL_DT = "GCH - Advanced Dealer Notification Actual Submission Date";
    public static final String GCH_FULL_BULLETIN_LAUNCH_TARGET_DT = "GCH - Full Bulletin Launch Target Date";
    public static final String GCH_FULL_BULLETIN_LAUNCH_ACTL_CMPL_DT = "GCH - Full Bulletin Launch Actual Submission Date";


    public static final String Critical_Part_Launch_Strategy = "Critical Part Launch Strategy";


    public static final String IMPLEMENTATION_TYPE = "Implementation Type";

    public static final String OTA_INDICATOR = "OTA Indicator";
    public static final String IMPLEMENTATION_NAME = "Implementation Name";
    public static final String STOPSHIP_SCOPE = "Stopship No tagged to Implementation";

    public static final String VERN_REQUESTED = "VERN Requested";
    public static final String VERN_SUBMITTED_TO_GCAMP = "VERN Submitted to GCAMP";
    public static final String VERN_EXTRACT_RECEIVED_FROM_GCAMP = "Extract Received from GCAMP";
    public static final String PRE_AUTH_REQUEST_DATE = "Pre-Auth Request Date";
    public static final String PRE_AUTH_APPROVED_DATE = "Pre-Auth Approved Date";
    //public static final String PSL_SIGNOFF_DATE = "PS&L Sign-Off Date";

    public static final String GOVT_SUBMISSION_DATES = "Gov Submission Dates";

    public static final String DEALER_BULLETIN_DATES = "Dealer Bulletin Dates";

    public static final String OWNER_NOTIFICATION_DATES = "Owner Notification Dates";

    public static final String SPECIFIC_ROOT_CAUSE = "Specific Root Cause";

    public static final String DETECTION_ROOT_CAUSE = "Detection Root Cause";

    public static final String SYSTEMIC_ROOT_CAUSE = "Systemic Root Cause";


    public static final String TRANSIENT_NOTES_NA_ASO = "Transient Notes NA ASO";
    public static final String TRANSIENT_NOTES_NA_CSF = "Transient Notes NA CSF";
    public static final String TRANSIENT_NOTES_NA_FCSD_SEO = "Transient Notes NA FCSD-SEO";
    public static final String TRANSIENT_NOTES_NA_OGC = "Transient Notes NA OGC";
    public static final String TRANSIENT_NOTES_NA_CCM = "Transient Notes NA CCM";
    public static final String TRANSIENT_NOTES_NA_PSL = "Transient Notes NA PS&L";
    public static final String TRANSIENT_NOTES_NA_EPRC = "Transient Notes NA EPRC";
    public static final String TRANSIENT_NOTES_NA_FCSD_RSP = "Transient Notes NA FCSD-RSP";
    public static final String TRANSIENT_NOTES_NA_FCSD_SCM = "Transient Notes NA FCSD-SCM";
    public static final String TRANSIENT_NOTES_NA_FCSD_PURCHASING = "Transient Notes NA FCSD-PURCHASING";
    public static final String TRANSIENT_NOTES_NA_FCSD_EXECUTIVE = "Transient Notes NA FCSD-Executive summary notes";


    public static final String TRANSIENT_NOTES_EU_ASO = "Transient Notes EU ASO";
    public static final String TRANSIENT_NOTES_EU_CSF = "Transient Notes EU CSF";
    public static final String TRANSIENT_NOTES_EU_FCSD_SEO = "Transient Notes EU FCSD-SEO";
    public static final String TRANSIENT_NOTES_EU_OGC = "Transient Notes EU OGC";
    public static final String TRANSIENT_NOTES_EU_CCM = "Transient Notes EU CCM";
    public static final String TRANSIENT_NOTES_EU_PSL = "Transient Notes EU PS&L";
    public static final String TRANSIENT_NOTES_EU_EPRC = "Transient Notes EU EPRC";
    public static final String TRANSIENT_NOTES_EU_FCSD_RSP = "Transient Notes EU FCSD-RSP";
    public static final String TRANSIENT_NOTES_EU_FCSD_SCM = "Transient Notes EU FCSD-SCM";
    public static final String TRANSIENT_NOTES_EU_FCSD_PURCHASING = "Transient Notes EU FCSD-PURCHASING";
    public static final String TRANSIENT_NOTES_EU_FCSD_EXECUTIVE = "Transient Notes EU FCSD-Executive summary notes";


    public static final String TRANSIENT_NOTES_SA_ASO = "Transient Notes SA ASO";
    public static final String TRANSIENT_NOTES_SA_CSF = "Transient Notes SA CSF";
    public static final String TRANSIENT_NOTES_SA_FCSD_SEO = "Transient Notes SA FCSD-SEO";
    public static final String TRANSIENT_NOTES_SA_OGC = "Transient Notes SA OGC";
    public static final String TRANSIENT_NOTES_SA_CCM = "Transient Notes SA CCM";
    public static final String TRANSIENT_NOTES_SA_PSL = "Transient Notes SA PS&L";
    public static final String TRANSIENT_NOTES_SA_EPRC = "Transient Notes SA EPRC";
    public static final String TRANSIENT_NOTES_SA_FCSD_RSP = "Transient Notes SA FCSD-RSP";
    public static final String TRANSIENT_NOTES_SA_FCSD_SCM = "Transient Notes SA FCSD-SCM";
    public static final String TRANSIENT_NOTES_SA_FCSD_PURCHASING = "Transient Notes SA FCSD-PURCHASING";
    public static final String TRANSIENT_NOTES_SA_FCSD_EXECUTIVE = "Transient Notes SA FCSD-Executive summary notes";


    public static final String TRANSIENT_NOTES_IMG_ASO = "Transient Notes IMG ASO";
    public static final String TRANSIENT_NOTES_IMG_CSF = "Transient Notes IMG CSF";
    public static final String TRANSIENT_NOTES_IMG_FCSD_SEO = "Transient Notes IMG FCSD-SEO";
    public static final String TRANSIENT_NOTES_IMG_OGC = "Transient Notes IMG OGC";
    public static final String TRANSIENT_NOTES_IMG_CCM = "Transient Notes IMG CCM";
    public static final String TRANSIENT_NOTES_IMG_PSL = "Transient Notes IMG PS&L";
    public static final String TRANSIENT_NOTES_IMG_EPRC = "Transient Notes IMG EPRC";
    public static final String TRANSIENT_NOTES_IMG_FCSD_RSP = "Transient Notes IMG FCSD-RSP";
    public static final String TRANSIENT_NOTES_IMG_FCSD_SCM = "Transient Notes IMG FCSD-SCM";
    public static final String TRANSIENT_NOTES_IMG_FCSD_PURCHASING = "Transient Notes IMG FCSD-PURCHASING";
    public static final String TRANSIENT_NOTES_IMG_FCSD_EXECUTIVE = "Transient Notes IMG FCSD-Executive summary notes";


    public static final String TRANSIENT_NOTES_GCH_ASO = "Transient Notes GCH ASO";
    public static final String TRANSIENT_NOTES_GCH_CSF = "Transient Notes GCH CSF";
    public static final String TRANSIENT_NOTES_GCH_FCSD_SEO = "Transient Notes GCH FCSD-SEO";
    public static final String TRANSIENT_NOTES_GCH_OGC = "Transient Notes GCH OGC";
    public static final String TRANSIENT_NOTES_GCH_CCM = "Transient Notes GCH CCM";
    public static final String TRANSIENT_NOTES_GCH_PSL = "Transient Notes GCH PS&L";
    public static final String TRANSIENT_NOTES_GCH_EPRC = "Transient Notes GCH EPRC";
    public static final String TRANSIENT_NOTES_GCH_FCSD_RSP = "Transient Notes GCH FCSD-RSP";
    public static final String TRANSIENT_NOTES_GCH_FCSD_SCM = "Transient Notes GCH FCSD-SCM";
    public static final String TRANSIENT_NOTES_GCH_FCSD_PURCHASING = "Transient Notes GCH FCSD-PURCHASING";
    public static final String TRANSIENT_NOTES_GCH_FCSD_EXECUTIVE = "Transient Notes GCH FCSD-Executive summary notes";

    public static final String FDR_REPORTABLE_FLAG = "FDR Reportable Flag";


    public static final String MODEL_YEARS_AFFECTED = "Model Years Affected";

    public static final String BRANDS_AFFECTED = "Brands Affected";
    public static final String FRC_APPROVED_DATE = "FRC Approved Date";

    public static final String GLOBAL_FSA = "GCAMP Global FSA #";

    public static final String ICA_DATE = "ICA Date";

    public static final String PCA_DATE = "PCA Date";

    public static final String PZ_DATE = "Patient Zero Date";

    public static final String TRG_MEETING_TYPE = "TRG Meeting Type";

    public static final String PCA = "Permanent Corrective Action(PCA)";
    public static final String ICA = "Interim Corrective Action(ICA)";
    public static final String TRG_MEETING_STATUS = "TRG Meeting Status";
    public static final String TRG_OPENED_DATE = "TRG Opened Date";

    public static final String DRAFT_FSA_TITLE = "Draft FSA Title";

    public static final String ISSUE_OPEN_DATE = "Issue Open Date";


    public static final String PARTS_INFO_EXIST = "Parts Info Exist";

    public static final String FSA_STATUS = "FSA Status";

    public static final String FSA_LAUNCH_DATE = "FSA Launch Date";
    public static final String ESTIMATED_TOTAL_COST = "Estimated Total Cost";


    public static final String CCRG_PRE_AUTH = "CCRG Pre-Authorization";

    public static final String CSF_PRE_AUTH = "CSF Pre-Authorization";

    public static final String EPRC_PRE_AUTH = "EPRC Pre-Authorization";


    public static final String SCM_PURCHASING_RATING = "SCM/Purchasing Rating";
    public static final String ESCALATION_TO_LEADERSHIP = "Escalation to Leadership";
    public static final String SUPPLIER_GSDC = "Supplier GSDB";
    public static final String SUPPLIER_NAME = "Supplier Name";
    public static final String SCM_CDSID = "SCM CDSID";
    public static final String RECALL_BUYER_CDSID = "Recall Buyer CDSID";
    public static final String IMPLEMENTATION_CDSID = "Implementation CDSID";
    public static final String PURCHASING_SUPPORT_REQUIRED = "Purchasing Support Required";
    public static final String SCM_COMMENTS = "SCM Comments";
    public static final String PURCHASING_COMMENT = "Purchasing Comments";
    public static final String PROJECTION_DATE = "Projection Date";
    public static final String CRITICAL_PART = "Critical Part";
    public static final String CRITICAL_PART_LAUNCH_STRATERGY = "Critical Part Launch Strategy";


    public static final String STA = "Production STA";
    public static final String STA_FSA = "STA Fsa";
    public static final String SUPPLY_CHAIN_LEAD = "Supply Chain Lead";
    public static final String PURCHASING_LEAD = "Purchasing Lead";
    public static final String RSP_LEAD = "RSP Lead";

    public static final String SOLD_UNITS = "Sold Units";

    public static final String UNSOLD_UNITS = "UnSold Units";

    public static final String PRE_AUTH = "Pre-Authorization";

    public static final String PARTS_COMMENT = "Parts Comment";

    public static final String PSL_SIGN_OFF_DATE = "PSL Sign Off Date";

    //Govt Submission NHTSA Agency VinlookUp Review

    public static final String NHTSA_VIN_LOOK_UP_REVIEW = "NHTSA VIN Look Up Review";

    public static final String FORD_VINLOOKUP_REVIEW = "VIN Look Up Review";

    //PSL Dashboard Log
    public static final String LOG_NA_SCM_PURCHASING_RATING = "Log (NA) SCM/Purchasing Rating";
    public static final String LOG_NA_CRITICAL_PART = "Log (NA) Critical Part";
    public static final String LOG_NA_CRITICAL_PART_LAUNCH_STRATEGY = "Log (NA) Critical Part Launch Strategy";
    public static final String LOG_NA_ESCALATION_TO_LEADERSHIP = "Log (NA) Escalation to Leadership";
    public static final String LOG_NA_PURCHASING_SUPPORT_REQUIRED = "Log (NA) Purchasing Support Required";
    public static final String LOG_NA_PART_OK = "Log (NA) Part Ok";


    public static final String MAKE_MODEL_MODEL_YEAR = "MAKE MODEL MODEL YEAR";
    public static final String MAKE_MODEL_MODEL_YEAR_ISSUE_VIEW = "Make Model Model Year";
    // Purchase Support Required Status
    public static final String ACTIVE = "Active";
    public static final String COMPLETE = "Complete";
    public static final String INVOICE_VALIDATION = "Invoice Validation";

    //14D section 2 Completed Dates
    public static final String praDate = "14D PRA filled out Date";
    public static final String dateCompleted = "Specific Root Cause filled out date";
    public static final String fd_Trg_Days = "14D to TRG Days";
    public static final String trg_Frc_Days = "TRG to FRC Days";
    public static final String CCRG_REOPENED_DATE = "CCRG Reopened Date";
    public static final String CSF_REOPENED_DATE = "CSF Reopened Date";
    public static final String EPRC_REOPENED_DATE = "EPRC Reopened Date";


    public static final String FRC_To_NA_Owner_Notification_RM_Days = "FRC to NA Owner Notification RM Days";
    public static final String FRC_To_SA_Owner_Notification_RM_Days = "FRC to SA Owner Notification RM Days";
    public static final String FRC_To_EU_Owner_Notification_RM_Days = "FRC to EU Owner Notification RM Days";
    public static final String FRC_To_IMG_Owner_Notification_RM_Days = "FRC to IMG Owner Notification RM Days";
    public static final String FRC_To_GCH_Owner_Notification_RM_Days = "FRC to GCH Owner Notification RM Days";


    private IssuesColumns(String columnName, Integer id) {
        this.columnName = columnName;
        this.id = id;
    }

    public String getColumnName() {
        return columnName;
    }

    public Integer getId() {
        return id;
    }

    public static Integer getId(String columnName) {
        for (IssuesColumns e : values()) {
            if (e.getColumnName().equals(columnName)) {
                return e.id;
            }
        }
        return null;
    }

    public static String getColumnName(Integer columnId) {
        for (IssuesColumns e : values()) {
            if (e.getId().equals(columnId)) {
                return e.getColumnName();
            }
        }
        return null;
    }
}