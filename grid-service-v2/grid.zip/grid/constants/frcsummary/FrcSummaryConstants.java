package com.ford.grid.constants.frcsummary;

public interface FrcSummaryConstants {
    String MEMO             = "memo";
    String FRCMEMOAGENDADETAILS = "frcMemoAgendaDetails";
    String FRCSCHEDULEDETAILS   = "frcScheduleDetails";
    String FRCMEETINGDATE       = "frcMeetingDate";
    String FRCAPPROVEDREGION    = "frcApprovedRegion";
    String VERNCOUNTS           = "vernCounts";
    String REGION               = "region";
    String ISSUETYPE            = "issueType";
}