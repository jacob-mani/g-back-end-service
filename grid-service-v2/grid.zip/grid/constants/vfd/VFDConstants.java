package com.ford.grid.constants.vfd;

import java.util.Map;

public interface VFDConstants {
    String VFD_DATA_MAPPING_COLLECTION = "vfd_file_data";
    String VERN_NUMBER = "vernNumber";
    String VERN_REVISION_PROFILE_SEL = "vernRevision";
    String VERN_VERSION = "version";
    String VERN_REVISION = "revision";
    String POPULATION_ID = "populationId";
    String MODEL_YEAR = "modelYear";
    String VEHICLE_LINE = "vehicleLine";
    String VEHICLE_LINE_DESC = "vehicleLineDesc";
    String REGION_DESC = "regionDesc";
    String CURRENT_COUNTRY = "currentCountry";
    String BRAND_CODE = "brandCode";
    String REGION = "region";
    String VEHICLE_SOLD_UNSOLD_FLAG = "vehicleSoldUnsoldFlag";
    String VIN_FSA_STATUS = "vinFsaStatus";
    String TOTAL_VEHICLE_COUNT = "totalVehicleCount";
    String TOTAL_VEHICLE_COUNT_SUM = "totalVehicleCountSum";
    String PROFILE_NAME = "profileName";
    String PROFILE_NAME_DEFAULT = "Default";
    String IS_SELECTABLE = "selectable";
    String IS_SELECTABLE_TRUE = "true";
    String IS_SELECTABLE_FALSE = "false";
    String PROFILE_STATUS = "status";

    String ATTRIBUTE_CODE1 = "attribute1";
    String ATTRIBUTE_CODE2 = "attribute2";
    String ATTRIBUTE_CODE3 = "attribute3";
    String ATTRIBUTE_CODE4 = "attribute4";
    String ATTRIBUTE_CODE5 = "attribute5";
    String ATTRIBUTE_CODE6 = "attribute6";
    String ATTRIBUTE_CODE7 = "attribute7";
    String ATTRIBUTE_CODE8 = "attribute8";
    String ATTRIBUTE_CODE9 = "attribute9";
    String ATTRIBUTE_CODE10 = "attribute10";

    Map<String, String> vfdRegionCodeDescriptionMap = Map.of(
            "NA", "FORD NORTH AMERICA",
            "SA", "FORD SOUTH AMERICA",
            "EU", "FORD OF EUROPE",
            "IMG", "FORD IMG",
            "GCH", "FORD GREATER CHINA"
    );

    String VFD_START_kEY_VIN = "VIN";
    String VFD_VALUE_EMPTY = "WERS-Not-Available";

    Map<String, String> vfdRequestMap = Map.of("modelYears", "modelYear",
            "vehicleLines", "vehicleLineDesc",
            "regions", "regionDesc",
            "countries", "currentCountry");

    // Inverted map: description -> code  e.g. "FORD NORTH AMERICA" -> "NA"
    Map<String, String> vfdRegionDescriptionToCodeMap = Map.of(
            "FORD NORTH AMERICA", "NA",
            "FORD SOUTH AMERICA", "SA",
            "FORD OF EUROPE", "EU",
            "FORD IMG", "IMG",
            "FORD GREATER CHINA", "GCH"
    );
}