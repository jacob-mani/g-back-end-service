package com.ford.grid.controller;

import com.ford.grid.common.SystemWideResponses;
import com.ford.grid.exception.GridException;
import com.ford.grid.model.dto.request.ContactGroupFieldRequest;
import com.ford.grid.model.dto.request.PreDefinedContactsRequest;
import com.ford.grid.model.dto.response.ContactGroupResponse;
import com.ford.grid.model.dto.response.PreDefinedContactsResponse;
import com.ford.grid.service.AdminService;
import io.swagger.v3.oas.annotations.Operation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;


import java.util.List;

@RestController
@RequestMapping("/api/v2/admin")
public class AdminController {

    private static final Logger LOGGER = LoggerFactory.getLogger(AdminController.class);

    @Autowired
    AdminService adminService;


    @GetMapping("getDomContacts")
    @Operation(summary = "Contacts", description = "Get Contacts for DOM ")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<List<ContactGroupResponse>> getDomContacts() {
        return ResponseEntity.ok(adminService.getDomContacts());

    }

    @GetMapping("getContactsByRegionSegment/{region}/{segment}")
    @Operation(summary = "Contacts", description = "Get Contacts by Region and Segment")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<List<PreDefinedContactsResponse>> getContactsByRegionSegment(@PathVariable String region,
                                                                                       @PathVariable String segment) {
        return ResponseEntity.ok(adminService.getContactsByRegionSegment(region, segment));

    }

    @PostMapping("saveContactDetails")
    @Operation(summary = "Contacts", description = "Save Contacts by Region and Segment")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<List<PreDefinedContactsResponse>> saveContactDetails(@RequestBody List<PreDefinedContactsRequest> contacts) throws GridException {
        List<PreDefinedContactsResponse> response = adminService.saveContactDetails(contacts);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PostMapping("dynamicContacts")
    @Operation(summary = "Contacts", description = "Dynamic Save Contacts")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<List<PreDefinedContactsResponse>> handleDynamicPreDefinedContacts(@RequestBody List<PreDefinedContactsRequest> contacts) throws GridException {
        List<PreDefinedContactsResponse> response = adminService.dynamicContact(contacts);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PostMapping("addContactGroupField")
    @Operation(summary = "Contacts", description = "Add Field to Contact Group")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<ContactGroupResponse> addFieldToContactGroup(@RequestBody ContactGroupFieldRequest request) {
        ContactGroupResponse saved = adminService.addFieldToContactGroup(request);
        return ResponseEntity.ok(saved);
    }


}

