package com.ford.grid.controller;

import com.ford.aps.core.exception.ApsClientException;
import com.ford.aps.core.mdp.MdpResponse;

import com.ford.grid.common.SystemWideResponses;
import com.ford.grid.service.ApsService;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/api/v2/aps")
@ConditionalOnProperty(name = "aps.auth.enabled", havingValue = "true")
public class ApsController {

	@Autowired
	ApsService apsService;

	@GetMapping("/apsPermissions")
	@Operation(summary = "Grid", description = "Grid Api")
	@SystemWideResponses
	public MdpResponse getUserPermissions() throws ApsClientException {
		return apsService.getUserPermissions();
	}

}
