package com.ford.grid.controller.AutoMailTrigger;

import com.ford.grid.service.NotifyMailSchedulerService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v2/scheduler")
@Slf4j
public class AutoMailTriggerController {

    private final NotifyMailSchedulerService notifyMailSchedulerService;

    public AutoMailTriggerController(NotifyMailSchedulerService notifyMailSchedulerService) {
        this.notifyMailSchedulerService = notifyMailSchedulerService;
    }

    // @GetMapping("/triggerMailGovtAndOwnerNotification")
    public void triggerMailGovtAndOwnerNotification() {

        log.info("calling Auto Mail Trigger Government and Owner Notification");

        try {
            notifyMailSchedulerService.generateMailsToIssues();

        } catch (Exception exception) {
            log.error("Failed - Auto Mail Trigger Government and Owner Notification ", exception);
        }
    }

}
