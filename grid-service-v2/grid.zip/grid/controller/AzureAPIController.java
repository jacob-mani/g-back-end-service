package com.ford.grid.controller;

import com.ford.grid.common.SystemWideResponses;
import com.ford.grid.service.AzureService;
import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v2/azure")
public class AzureAPIController {
    private static final Logger LOGGER = LoggerFactory.getLogger(AzureAPIController.class);

    private final AzureService azureService;

    @GetMapping("dls-roleassignments/{cdsId}")
    @Operation(summary = "Get dls role_assignments", description = "Get dls role_assignments ")
    @SystemWideResponses
    public ResponseEntity<Object> getUserRole(@PathVariable String cdsId) {

        return new ResponseEntity<>(azureService.dlsRoleAssignments(cdsId), HttpStatus.OK);
    }
}
