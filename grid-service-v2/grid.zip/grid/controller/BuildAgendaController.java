package com.ford.grid.controller;

import com.ford.grid.common.SystemWideResponses;
import com.ford.grid.constants.CommonConstants;
import com.ford.grid.model.dto.request.BuildAgendaMultiSelectRequest;
import com.ford.grid.model.dto.response.BuildAgendaResponse;
import com.ford.grid.service.BuildAgendaService;
import com.ford.grid.service.BuildAgendaDirectService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/v2/buildAgenda")
@AllArgsConstructor
public class BuildAgendaController {

    private final BuildAgendaService buildAgendaService;
    private final BuildAgendaDirectService buildAgendaDirectService;
    private static final Logger LOGGER = LoggerFactory.getLogger(BuildAgendaController.class);

    @PostMapping("/getListIssues")
    @Operation(summary = "Get List Issues", description = "POST API to retrieve List Issues by agendaType(s) and meetingDate. " +
            "Single agendaType uses existing logic. " +
            "Multi-select is only allowed for CCRG, CSF, EPRC (they share the same template).")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MyIssuesList','read')")
    public ResponseEntity<Page<BuildAgendaResponse>> getBuildAgenda(
            @Valid @RequestBody BuildAgendaMultiSelectRequest request) {

        // Defensively filter null/blank entries, then trim + lowercase — handles " CCRG " → "ccrg"
        // @NotBlank on the DTO catches these at validation time, but this guard prevents NPE
        // if validation is bypassed or a null slips through at runtime.
        List<String> normalizedTypes = request.getAgendaType().stream()
                .filter(s -> s != null && !s.isBlank())
                .map(s -> s.trim().toLowerCase())
                .toList();

        // If all entries were null/blank after filtering, treat as invalid request
        if (normalizedTypes.isEmpty()) {
            LOGGER.error("All agendaType entries were null or blank after normalization");
            return ResponseEntity.badRequest().build();
        }
        LocalDate meetingDate = request.getMeetingDate();
        String finalLeadRegion = request.getLeadRegion();

        LOGGER.info("Start of getBuildAgenda, agendaType(s): {}, meetingDate: {}, leadRegion: {}, page: {}, size: {}, sortBy: {}, direction: {}",
                normalizedTypes, meetingDate, finalLeadRegion, request.getPage(), request.getSize(), request.getSortBy(), request.getDirection());

        try {
            Sort sort = Sort.by(Sort.Direction.fromString(request.getDirection()), request.getSortBy());
            Pageable pageable = PageRequest.of(request.getPage(), request.getSize(), sort);

            // ── MULTI-SELECT path (CCRG / CSF / EPRC only) ──────────────────────
            if (normalizedTypes.size() > 1) {
                boolean allAllowed = normalizedTypes.stream()
                        .allMatch(CommonConstants.MULTI_SELECT_ALLOWED_AGENDA_TYPES::contains);

                if (!allAllowed) {
                    LOGGER.error("Invalid multi-select agendaTypes: {}. Only {} are allowed together.",
                            normalizedTypes, CommonConstants.MULTI_SELECT_ALLOWED_AGENDA_TYPES);
                    return ResponseEntity.badRequest().build();
                }

                // ccrg/csf/eprc are non-global — leadRegion is mandatory for DB query
                if (finalLeadRegion == null || finalLeadRegion.isBlank()) {
                    LOGGER.error("Missing required parameter 'leadRegion' for multi-select agendaTypes: {}", normalizedTypes);
                    return ResponseEntity.badRequest().build();
                }

                LOGGER.info("Multi-select path: delegating to getBuildAgenda(List) for types: {}", normalizedTypes);
                Page<BuildAgendaResponse> multiResponse = buildAgendaService.getBuildAgenda(normalizedTypes, meetingDate, finalLeadRegion, pageable);
                LOGGER.info("End of getBuildAgenda (multi-select), returned {} items", multiResponse.getTotalElements());
                return ResponseEntity.ok(multiResponse);
            }

            // ── SINGLE-SELECT path (existing logic unchanged) ────────────────────
            String singleAgendaType = normalizedTypes.get(0);
            String filterType = CommonConstants.AGENDA_TYPE_GOVERNMENT.equals(singleAgendaType) ? "agency" : "leadRegion";
            LOGGER.info("Single-select path: agendaType: {}, {}: {}", singleAgendaType, filterType, finalLeadRegion);

            boolean isGlobalAgendaType = CommonConstants.AGENDA_TYPE_GCCRG.equals(singleAgendaType)
                    || CommonConstants.AGENDA_TYPE_GCSF.equals(singleAgendaType)
                    || CommonConstants.AGENDA_TYPE_GEPRC.equals(singleAgendaType)
                    || CommonConstants.AGENDA_TYPE_GPIR.equals(singleAgendaType);

            Page<BuildAgendaResponse> response;
            if (finalLeadRegion == null || finalLeadRegion.isEmpty()) {
                if (!isGlobalAgendaType) {
                    String paramName = CommonConstants.AGENDA_TYPE_GOVERNMENT.equals(singleAgendaType) ? "agency" : "leadRegion";
                    LOGGER.error("Missing required parameter '{}' for agenda type: {}", paramName, singleAgendaType);
                    return ResponseEntity.badRequest().build();
                }
                // Call 2-parameter method for global agenda types
                response = buildAgendaService.getBuildAgenda(singleAgendaType, meetingDate, pageable);
            } else {
                // Call 3-parameter method for regional/government agenda types
                response = buildAgendaService.getBuildAgenda(singleAgendaType, meetingDate, finalLeadRegion, pageable);
            }

            LOGGER.info("End of getBuildAgenda, returned {} items", response.getTotalElements());
            return ResponseEntity.ok(response);

        } catch (Exception ex) {
            LOGGER.error("Unexpected error in getBuildAgenda, agendaType(s): {}, meetingDate: {}, leadRegion: {}",
                    normalizedTypes, meetingDate, finalLeadRegion, ex);
            return ResponseEntity.status(500).build();
        }
    }

    @PostMapping("/getListIssues/new")
    @Operation(summary = "Get List Issues (Direct)", description = "POST API to retrieve List Issues using direct collection queries (no MongoDB view). " +
            "Same contract as /getListIssues but uses BuildAgendaDirectService.")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MyIssuesList','read')")
    public ResponseEntity<Page<BuildAgendaResponse>> getBuildAgendaDirect(
            @Valid @RequestBody BuildAgendaMultiSelectRequest request) {

        List<String> normalizedTypes = request.getAgendaType().stream()
                .filter(s -> s != null && !s.isBlank())
                .map(s -> s.trim().toLowerCase())
                .toList();

        if (normalizedTypes.isEmpty()) {
            LOGGER.error("All agendaType entries were null or blank after normalization");
            return ResponseEntity.badRequest().build();
        }
        LocalDate meetingDate = request.getMeetingDate();
        String finalLeadRegion = request.getLeadRegion();

        LOGGER.info("[Direct] Start of getBuildAgenda, agendaType(s): {}, meetingDate: {}, leadRegion: {}, page: {}, size: {}, sortBy: {}, direction: {}",
                normalizedTypes, meetingDate, finalLeadRegion, request.getPage(), request.getSize(), request.getSortBy(), request.getDirection());

        try {
            Sort sort = Sort.by(Sort.Direction.fromString(request.getDirection()), request.getSortBy());
            Pageable pageable = PageRequest.of(request.getPage(), request.getSize(), sort);

            if (normalizedTypes.size() > 1) {
                boolean allAllowed = normalizedTypes.stream()
                        .allMatch(CommonConstants.MULTI_SELECT_ALLOWED_AGENDA_TYPES::contains);

                if (!allAllowed) {
                    LOGGER.error("Invalid multi-select agendaTypes: {}. Only {} are allowed together.",
                            normalizedTypes, CommonConstants.MULTI_SELECT_ALLOWED_AGENDA_TYPES);
                    return ResponseEntity.badRequest().build();
                }

                if (finalLeadRegion == null || finalLeadRegion.isBlank()) {
                    LOGGER.error("Missing required parameter 'leadRegion' for multi-select agendaTypes: {}", normalizedTypes);
                    return ResponseEntity.badRequest().build();
                }

                Page<BuildAgendaResponse> multiResponse = buildAgendaDirectService.getBuildAgenda(normalizedTypes, meetingDate, finalLeadRegion, pageable);
                LOGGER.info("[Direct] End of getBuildAgenda (multi-select), returned {} items", multiResponse.getTotalElements());
                return ResponseEntity.ok(multiResponse);
            }

            String singleAgendaType = normalizedTypes.get(0);

            boolean isGlobalAgendaType = CommonConstants.AGENDA_TYPE_GCCRG.equals(singleAgendaType)
                    || CommonConstants.AGENDA_TYPE_GCSF.equals(singleAgendaType)
                    || CommonConstants.AGENDA_TYPE_GEPRC.equals(singleAgendaType)
                    || CommonConstants.AGENDA_TYPE_GPIR.equals(singleAgendaType);

            Page<BuildAgendaResponse> response;
            if (finalLeadRegion == null || finalLeadRegion.isEmpty()) {
                if (!isGlobalAgendaType) {
                    String paramName = CommonConstants.AGENDA_TYPE_GOVERNMENT.equals(singleAgendaType) ? "agency" : "leadRegion";
                    LOGGER.error("Missing required parameter '{}' for agenda type: {}", paramName, singleAgendaType);
                    return ResponseEntity.badRequest().build();
                }
                response = buildAgendaDirectService.getBuildAgenda(singleAgendaType, meetingDate, pageable);
            } else {
                response = buildAgendaDirectService.getBuildAgenda(singleAgendaType, meetingDate, finalLeadRegion, pageable);
            }

            LOGGER.info("[Direct] End of getBuildAgenda, returned {} items", response.getTotalElements());
            return ResponseEntity.ok(response);

        } catch (Exception ex) {
            LOGGER.error("[Direct] Unexpected error in getBuildAgenda, agendaType(s): {}, meetingDate: {}, leadRegion: {}",
                    normalizedTypes, meetingDate, finalLeadRegion, ex);
            return ResponseEntity.status(500).build();
        }
    }
}