package com.ford.grid.controller;

import com.ford.grid.common.SystemWideResponses;
import com.ford.grid.model.entity.GridUsers;
import com.ford.grid.model.entity.UserDetails;
import com.ford.grid.repository.GridUserDao;
import com.ford.grid.service.CdsLookUpService;
import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;
import java.util.Objects;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v2/cdsLookup")
public class CDSLookUpController {
    private static final Logger LOGGER = LoggerFactory.getLogger(CDSLookUpController.class);

    private final CdsLookUpService cdsLookupService;
    private final GridUserDao gridUserDao;
    private final CacheManager cacheManager;

    @GetMapping("/{searchQuery}")
    @Operation(summary = "getUserDetailsByCDSID", description = "Get lookupEmployeeName for CDS ID ")
    @SystemWideResponses
    public ResponseEntity<List<UserDetails>> getUserDetailsBySearchQuery(@PathVariable final String searchQuery) {
        LOGGER.info("Start of getUserDetailsBySearchQuery in CDSLookUpController for the Query : {}", searchQuery);

        List<UserDetails> userDetailsByQuery = cdsLookupService.getUserDetailsBySearchQuery(StringUtils.trim(searchQuery));
        LOGGER.info("User Details: {}", userDetailsByQuery);
        LOGGER.info("End of getUserDetailsBySearchQuery in CDSLookUpController");

        return new ResponseEntity<>(userDetailsByQuery, HttpStatus.OK);
    }

    @GetMapping("/check-user-exist-in-grid/{query}")
    @Operation(summary = "check User exists", description = "Check user exists in Grid by CDS ID ")
    @SystemWideResponses
    //@PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Contacts','read')")
    public ResponseEntity<GridUsers> checkUserExistInGrid(@PathVariable String query) {

        GridUsers existingUser = gridUserDao.searchUserByCsdId(query);

        return new ResponseEntity<>(existingUser, HttpStatus.OK);

    }

    @GetMapping("/add-as-grid-user/if-not-exist/{query}")
    @Operation(summary = "Add User if not exists", description = "Add User if not exists ")
    @SystemWideResponses
    //@PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Contacts','read')")
    public ResponseEntity<UserDetails> addUserIfNotExist(@PathVariable String query) {

        GridUsers existingUser = gridUserDao.searchUserByCsdId(query);

        UserDetails newUser = null;

        if (Objects.isNull(existingUser)) {


            List<UserDetails> ldapNames = cdsLookupService.getUserDetailsBySearchQuery(StringUtils.trim(query));

            for(UserDetails user :  ldapNames ) {
                if (user.getCdsid().equalsIgnoreCase(query)) {
                    newUser = user;
                    GridUsers newUserToBeAdded = new GridUsers();
                    newUserToBeAdded.setCdsid(user.getCdsid());
                    newUserToBeAdded.setFirstName(user.getFirstName());
                    newUserToBeAdded.setLastName(user.getLastName());
                    newUserToBeAdded.setDisplayName(user.getDisplayName());
                    newUserToBeAdded.setAddedBy("SYSTEM");
                    newUserToBeAdded.setAddedOn(new Date().toString());
                    gridUserDao.saveNewUser(newUserToBeAdded);

                    Cache cache = cacheManager.getCache("grid-users");
                    if (null != cache) {
                        cache.invalidate();
                    }
                    gridUserDao.getAllUsers();
                }
            }

        }

        return new ResponseEntity<>(newUser, HttpStatus.OK);
    }
}