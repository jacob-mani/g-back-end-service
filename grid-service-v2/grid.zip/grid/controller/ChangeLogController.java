package com.ford.grid.controller;

import com.ford.grid.common.SystemWideResponses;
import com.ford.grid.exception.GridException;
import com.ford.grid.model.dto.request.ChangeLogRequest;
import com.ford.grid.model.dto.request.OdLetterNotificationUpsertRequest;
import com.ford.grid.model.entity.changelog.RecallHistory;
import com.ford.grid.service.IChangeLogService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

@RestController
@AllArgsConstructor
@RequestMapping("/api/v2/changeLog")
public class ChangeLogController {
    private static final Logger LOGGER = LoggerFactory.getLogger(ChangeLogController.class);

    private final IChangeLogService changeLogService;

    /**
     * Retrieves the recall history for a given issue number with pagination support.
     *
     * @param issueNumber the issue number to retrieve the recall history for
     * @param pageable    the pagination information
     * @return a ResponseEntity containing a page of RecallHistory objects
     */
    @GetMapping("/{issueNumber}")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:ChangeLog','read')")
    public ResponseEntity<Page<RecallHistory>> getRecallHistory(@PathVariable String issueNumber, Pageable pageable) {
        LOGGER.info("Start of  getRecallHistory : {}", issueNumber);
        Page<RecallHistory> allRevisionsForIssue = changeLogService.getRevisionPageableObjectsByIssueNumber(issueNumber, pageable);
        return ResponseEntity.ok(allRevisionsForIssue);
    }

    /**
     * Saves the change log information provided in the request body.
     *
     * @param changeLogRequest the request body containing change log information
     * @return a ResponseEntity containing the saved ChangeLogRequest object
     */
    @PostMapping()
    public ResponseEntity<ChangeLogRequest> saveAudit(@Valid @RequestBody ChangeLogRequest changeLogRequest) {
        LOGGER.info("Start of saveAudit : {}", changeLogRequest);

        changeLogService.saveChangeLogInformation(changeLogRequest);
        return ResponseEntity.ok(changeLogRequest);
    }

    /**
     * Downloads the Change Log report for the given issue number.
     *
     * @param issueNumber the issue number for which the Change Log report is generated
     * @return a ResponseEntity containing the Excel file as a downloadable stream
     *         with filename format: issueNumber_timestamp_ChangeLog.xlsx
     */
    @GetMapping("/report/{issueNumber}")
    @Operation(summary = "Export Change Log Report",
            description = "Generate Excel with Change Log sheet only. "
                    + "Returns the Excel file as a downloadable stream.")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:ChangeLog','read')")
    public ResponseEntity<StreamingResponseBody> exportChangeLogReport(
            @PathVariable String issueNumber) {
        LOGGER.info("Export change log report for issueNumber: {}", issueNumber);
        byte[] excelBytes = changeLogService.generateChangeLogReport(issueNumber);

        String timestamp = java.time.LocalDateTime.now()
                .format(java.time.format.DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
        String fileName = issueNumber + "_" + timestamp + "_ChangeLog.xlsx";

        StreamingResponseBody stream = outputStream -> outputStream.write(excelBytes);
        return ResponseEntity.ok()
                .header("Content-Disposition", "attachment; filename=\"" + fileName + "\"")
                .header("Access-Control-Expose-Headers", "Content-Disposition")
                .contentType(org.springframework.http.MediaType.parseMediaType(
                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                .body(stream);
    }


    @PostMapping("/collab/notify")
    public ResponseEntity<String> notifyCollabApprovers(
            @Valid @RequestBody OdLetterNotificationUpsertRequest request) throws GridException {

        LOGGER.info("Start of notifyCollabApprovers : {}", request);

        try {
            String response = changeLogService.notifyCollabApprovers(request);
            return ResponseEntity.ok(response);
        } catch (IllegalArgumentException ex) {
            LOGGER.warn("Invalid request for collab notification: {}", ex.getMessage());
            throw new GridException(HttpStatus.BAD_REQUEST,
                    "Invalid request for collab notification", ex.getMessage());
        } catch (Exception ex) {
            LOGGER.error("Unexpected error while notifying collab approvers: {}", ex.getMessage(), ex);
            throw new GridException(HttpStatus.INTERNAL_SERVER_ERROR,
                    "Failed to notify collab approvers", ex.getMessage());
        }
    }
}