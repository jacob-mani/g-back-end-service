package com.ford.grid.controller;

import com.ford.grid.common.SystemWideResponses;
import com.ford.grid.model.dto.request.CreateAgendaRequest;
import com.ford.grid.service.CreateAgendaDirectService;
import com.ford.grid.service.CreateAgendaService;
import io.swagger.v3.oas.annotations.Operation;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

@RestController
@RequestMapping("/api/v2/createAgenda")
@AllArgsConstructor
public class CreateAgendaController {

    private final CreateAgendaService createAgendaService;
    private final CreateAgendaDirectService createAgendaDirectService;
    private static final Logger LOGGER = LoggerFactory.getLogger(CreateAgendaController.class);

    @PostMapping("/exportAgendaPdf")
    @Operation(summary = "Create Agenda - Update RecallIssue and Export to PDF",
            description = "POST API that performs two operations: " +
                    "1. Updates RecallIssue entities with duration and keyParticipants for each issue. " +
                    "2. Exports the agenda to PDF from view_reports_build_agenda view. " +
                    "Toggle button flag can be set to 'ON' or 'OFF' in the request to include/exclude open issues in the PDF export.")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:AgendaBuild':'execute'})")
    public ResponseEntity<StreamingResponseBody> exportCreateAgendaToPdf(@RequestBody CreateAgendaRequest createAgendaRequest) {
        LOGGER.info("Start of exportCreateAgendaToPdf method - Update RecallIssue and PDF Export");
        LOGGER.info("Request data: {}, Toggle Button: {}", createAgendaRequest, createAgendaRequest.getToggleButton());

        try {
            ResponseEntity<StreamingResponseBody> response = createAgendaService.exportCreateAgendaToPdf(createAgendaRequest);
            LOGGER.info("End of exportCreateAgendaToPdf method - RecallIssue updated and PDF generated successfully with toggle: {}", createAgendaRequest.getToggleButton());
            return response;
        } catch (Exception ex) {
            LOGGER.error("Unexpected error in exportCreateAgendaToPdf method", ex);
            return ResponseEntity.status(500).build();
        }
    }

    @PostMapping("/exportAgendaPdf/new")
    @Operation(summary = "Create Agenda (Direct) - Independent PDF Export",
            description = "POST API using a fully independent direct PDF builder. " +
                    "Supports CCRG, CSF, EPRC, TRG, GCCRG, FRC, and multi-forum agenda exports. " +
                    "Does NOT delegate to CreateAgendaService — self-contained implementation.")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:AgendaBuild':'execute'})")
    public ResponseEntity<StreamingResponseBody> exportCreateAgendaToPdfDirect(@RequestBody CreateAgendaRequest createAgendaRequest) {
        LOGGER.info("[Direct] Start of exportCreateAgendaToPdf method");
        LOGGER.info("[Direct] Request data: {}, Toggle Button: {}", createAgendaRequest, createAgendaRequest.getToggleButton());

        try {
            ResponseEntity<StreamingResponseBody> response = createAgendaDirectService.exportAgendaPdf(createAgendaRequest);
            LOGGER.info("[Direct] End of exportCreateAgendaToPdf method - PDF generated successfully with toggle: {}", createAgendaRequest.getToggleButton());
            return response;
        } catch (Exception ex) {
            LOGGER.error("[Direct] Unexpected error in exportCreateAgendaToPdf method", ex);
            return ResponseEntity.status(500).build();
        }
    }

}
