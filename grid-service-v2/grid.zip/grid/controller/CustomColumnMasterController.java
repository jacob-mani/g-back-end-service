package com.ford.grid.controller;

import com.ford.grid.common.SystemWideResponses;
import com.ford.grid.exception.GridException;
import com.ford.grid.model.dto.request.CustomViewRequest;
import com.ford.grid.model.dto.request.ReorderTabRequest;
import com.ford.grid.model.dto.request.ShareCustomViewRequest;
import com.ford.grid.model.dto.request.customcolumn.UserTabRequest;
import com.ford.grid.model.dto.response.ContactFilterResponse;
import com.ford.grid.model.dto.response.CustomColumnMasterResponse;
import com.ford.grid.model.dto.response.CustomViewResponse;
import com.ford.grid.model.dto.response.FilterOptionsResponse;
import com.ford.grid.model.dto.response.UserTabsResponse;
import com.ford.grid.model.dto.response.ViewTypeResponse;
import com.ford.grid.service.CustomColumnMasterService;
import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;

import java.util.List;


@RestController
@RequestMapping("api/v2/advance/custom")
@RequiredArgsConstructor
public class CustomColumnMasterController {
    private static final Logger logger = LoggerFactory.getLogger(CustomColumnMasterController.class);

    private final CustomColumnMasterService service;

    @GetMapping("/getColumnsByViewType/{viewType}")
    @Operation(summary = "Get Custom column API", description = "Fetches Custom Column API by View Type")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<CustomColumnMasterResponse> getColumnsByViewType(
            @PathVariable String viewType) {
        logger.info("Fetching Custom Columns against each viewType: {}", viewType);

        try {
            CustomColumnMasterResponse responses = service.getColumnsByViewType(viewType);
            return ResponseEntity.ok(responses);
        } catch (GridException e) {
            logger.error("Error fetching columns for viewType {}: {}", viewType, e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @GetMapping("/getViewTypes")
    @Operation(summary = "Get all View Types", description = "Fetches all viewType and displayName from custom column config")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")

    public ResponseEntity<List<ViewTypeResponse>> getViewTypes() {
        logger.info("Fetching all viewTypes and displayNames");
        try {
            return ResponseEntity.ok(service.getViewTypes());
        } catch (GridException e) {
            logger.error("Error fetching viewTypes: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @GetMapping("/getFilterOptions/{viewType}")
    @Operation(summary = "Get Filter Options", description = "Fetches available filter categories, conditions, and criteria for a given viewType")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<FilterOptionsResponse> getFilterOptions(
            @PathVariable String viewType) {
        logger.info("Fetching filter options for viewType: {}", viewType);

        try {
            FilterOptionsResponse response = service.getFilterOptions(viewType);
            return ResponseEntity.ok(response);
        } catch (GridException e) {
            logger.error("Error fetching filter options for viewType {}: {}", viewType, e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @PostMapping("/saveCustomView")
    @Operation(summary = "Create Custom View", description = "Creates a new custom view for the user")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<CustomViewResponse> createCustomView(@RequestBody CustomViewRequest customViewRequest) {
        logger.info("Received create request: {}", customViewRequest);
        try {
            return new ResponseEntity<>(service.createCustomView(customViewRequest), HttpStatus.CREATED);
        } catch (GridException e) {
            logger.error("Error saving custom view: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @PostMapping("/userTabs")
    @Operation(summary = "Get User Tabs", description = "Fetches default and custom tabs for the logged-in user")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<UserTabsResponse> getCustomAndStandardUserTabs(@RequestBody UserTabRequest  userTabRequest) {
        logger.info("getCustomAndStandardUserTabs:{}",userTabRequest);
        return ResponseEntity.ok(service.getUserTabs());
    }

    @GetMapping("/userTabs")
    @Operation(summary = "Get User Tabs", description = "Fetches default and custom tabs for the logged-in user")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<UserTabsResponse> getUserTabs() {
        logger.info("Fetching user tabs");
        return ResponseEntity.ok(service.getUserTabs());
    }

    @GetMapping("/getCustomView")
    @Operation(summary = "Get Custom View by ID and ViewType",
            description = "Fetches a custom view record from user_custom_preferences by its _id and viewType")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<CustomViewResponse> getCustomViewByIdAndViewType(
            @RequestParam String id,
            @RequestParam String viewType) {
        logger.info("Fetching custom view by id: {} and viewType: {}", id, viewType);
        try {
            CustomViewResponse response = service.getCustomViewByIdAndViewType(id, viewType);
            return ResponseEntity.ok(response);
        } catch (GridException e) {
            logger.error("Error fetching custom view for id: {}, viewType: {}: {}", id, viewType, e.getMessage());
            return ResponseEntity.status(e.getStatus() != null ? e.getStatus() : HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @DeleteMapping("/deleteCustomView")
    @Operation(summary = "Delete Custom View",
            description = "Deletes a custom view from user_custom_preferences by its _id and viewType. " +
                    "The cdsId is resolved from the authenticated user — only the owner can delete their own view.")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<Void> deleteCustomView(
            @RequestParam String id) {
        logger.info("Delete custom view request - id: {}", id);
        try {
            service.deleteCustomView(id);
            return ResponseEntity.noContent().build();
        } catch (GridException e) {
            logger.error("Error deleting custom view for id: {}: {}", id, e.getMessage());
            return ResponseEntity.status(e.getStatus() != null ? e.getStatus() : HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @PostMapping("/shareCustomView")
    @Operation(summary = "Share Custom View by Cloning from sender to receiver",
            description = "Shares a custom view from the sender to the receiver. " +
                    "Looks up the source view by senderId + customViewName, creates an identical copy " +
                    "under the receiverId. Fails if the receiver already owns a view with the same name.")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<CustomViewResponse> shareCustomView(
            @RequestBody ShareCustomViewRequest shareRequest) throws GridException {
        logger.info("Clone custom view request - senderId: {}, receiverId: {}, customViewName: {}",
                shareRequest.getSenderId(), shareRequest.getReceiverId(), shareRequest.getCustomViewName());
        return new ResponseEntity<>(service.shareCustomView(shareRequest), HttpStatus.CREATED);
    }

    @GetMapping("/getContactsForFilter")
    @Operation(summary = "Get Contacts For Filter",
            description = "Fetches distinct contacts grouped by region from pre_defined_contacts for use in filter dropdowns")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<List<ContactFilterResponse>> getContactsForFilter() {
        logger.info("Fetching contacts for filter");
        try {
            List<ContactFilterResponse> response = service.getContactsForFilter();
            return ResponseEntity.ok(response);
        } catch (GridException e) {
            logger.error("Error fetching contacts for filter", e);
            return ResponseEntity.status(
                    e.getStatus() != null ? e.getStatus() : HttpStatus.INTERNAL_SERVER_ERROR
            ).build();
        }
    }

    @PutMapping("/reorderTabs")
    @Operation(summary = "Reorder Custom Tabs",
            description = "Updates the columnIndex of each specified tab to persist the user's drag-and-drop order.")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<Void> reorderTabs(@Valid @RequestBody ReorderTabRequest reorderTabRequest) {
        logger.info("Reorder tabs request: {}", reorderTabRequest);
        try {
            service.reorderTabs(reorderTabRequest);
            return ResponseEntity.ok().build();
        } catch (GridException e) {
            logger.error("Error reordering tabs: {}", e.getMessage());
            return ResponseEntity.status(e.getStatus() != null ? e.getStatus() : HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
}

