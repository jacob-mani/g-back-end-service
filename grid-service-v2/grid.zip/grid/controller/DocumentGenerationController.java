package com.ford.grid.controller;

import com.ford.grid.common.SystemWideResponses;
import com.ford.grid.exception.GridException;
import com.ford.grid.model.dto.response.CollabNotificationsResponse;
import com.ford.grid.model.dto.response.IssueRegionCountryResponse;
import com.ford.grid.model.dto.response.MasterOptionResponse;
import com.ford.grid.model.dto.response.RegionCountryMappingResponse;
import com.ford.grid.service.GRIDMasterService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.List;
import java.util.Map;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v2/document-generation")
@Tag(name = "Document Generation", description = "APIs for document generation details")
public class DocumentGenerationController {

    private static final Logger logger = LoggerFactory.getLogger(DocumentGenerationController.class);

    private final GRIDMasterService gridMasterService;

    /**
     * Retrieves all distinct brands and their brand codes.
     * Used to populate the Brand dropdown in Document Generation.
     *
     * @return ResponseEntity containing a map of brandCode -> brandName
     * @throws GridException if brands cannot be retrieved
     */
    @GetMapping("/getAllBrands")
    @Operation(summary = "Get All Brands", description = "Returns distinct brand names and brand codes for the Brand dropdown")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<Map<String, String>> getAllBrands() throws GridException {
        logger.info("Received request to retrieve all brands");
        try {
            Map<String, String> brands = gridMasterService.getDistinctBrandAndBrandCode();
            logger.info("Successfully retrieved {} brand(s)", brands.size());
            return ResponseEntity.ok(brands);
        } catch (Exception ex) {
            logger.error("Failed to retrieve brands. Error: {}", ex.getMessage(), ex);
            throw new GridException(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to retrieve brands", ex.getMessage());
        }
    }

    /**
     * Retrieves available markets for a given issue number.
     * Internally resolves the lead region for the issue and then fetches
     * region long/short codes for that lead region.
     * Used to populate the Market dropdown in Document Generation.
     *
     * @param issueNumber the issue number
     * @return ResponseEntity containing a list of RegionCountryMappingResponse objects,
     *         or an empty list if no lead region is found for the issue
     * @throws GridException if markets cannot be retrieved for the given issue number
     */
    @GetMapping("/getMarketsByIssue/{issueNumber}")
    @Operation(summary = "Get Markets by Issue Number",
            description = "Resolves the lead region for the issue and returns region long/short codes for the Market dropdown")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<List<RegionCountryMappingResponse>> getMarketsByIssue(@PathVariable String issueNumber) throws GridException {
        logger.info("Received request to retrieve markets for issueNumber: {}", issueNumber);
        try {
            String leadRegion = gridMasterService.getLeadRegionByIssueNumber(issueNumber).orElse(null);
            if (leadRegion == null) {
                logger.warn("No lead region found for issueNumber: {}", issueNumber);
                return ResponseEntity.ok(Collections.emptyList());
            }
            List<RegionCountryMappingResponse> markets = gridMasterService.getRegionLongAndShortCdByRegCode(leadRegion);
            logger.info("Successfully retrieved {} market(s) for issueNumber: {}", markets.size(), issueNumber);
            return ResponseEntity.ok(markets);
        } catch (Exception ex) {
            logger.error("Failed to retrieve markets for issueNumber: {}. Error: {}", issueNumber, ex.getMessage(), ex);
            throw new GridException(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to retrieve markets for issue number: " + issueNumber, ex.getMessage());
        }
    }

    /**
     * Retrieves the FSA number associated with the given issue number.
     * Used to populate the FSA button/field in Document Generation.
     *
     * @param issueNumber the issue number
     * @return ResponseEntity containing the FSA number string, or empty string if not found
     * @throws GridException if the FSA number cannot be retrieved
     */
    @GetMapping("/getFsaNumber/{issueNumber}")
    @Operation(summary = "Get FSA Number by Issue Number",
            description = "Returns the FSA number for the given issue number")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<String> getFsaNumber(@PathVariable String issueNumber) throws GridException {
        logger.info("Received request to retrieve FSA number for issueNumber: {}", issueNumber);
        try {
            String fsaNumber = gridMasterService.getFsaNumberByIssueNumber(issueNumber).orElse("");
            logger.info("Successfully retrieved FSA number for issueNumber: {}", issueNumber);
            return ResponseEntity.ok(fsaNumber);
        } catch (Exception ex) {
            logger.error("Failed to retrieve FSA number for issueNumber: {}. Error: {}", issueNumber, ex.getMessage(), ex);
            throw new GridException(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to retrieve FSA number for issue number: " + issueNumber, ex.getMessage());
        }
    }

    /**
     * Retrieves the issue title for the given issue number.
     * Used to populate the Title field in Document Generation.
     *
     * @param issueNumber the issue number
     * @return ResponseEntity containing the issue title string, or empty string if not found
     * @throws GridException if the issue title cannot be retrieved
     */
    @GetMapping("/getIssueTitle/{issueNumber}")
    @Operation(summary = "Get Issue Title by Issue Number",
            description = "Returns the issue title for the given issue number")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<String> getIssueTitle(@PathVariable String issueNumber) throws GridException {
        logger.info("Received request to retrieve issue title for issueNumber: {}", issueNumber);
        try {
            String title = gridMasterService.getIssueTitleByIssueNumber(issueNumber).orElse("");
            logger.info("Successfully retrieved issue title for issueNumber: {}", issueNumber);
            return ResponseEntity.ok(title);
        } catch (Exception ex) {
            logger.error("Failed to retrieve issue title for issueNumber: {}. Error: {}", issueNumber, ex.getMessage(), ex);
            throw new GridException(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to retrieve issue title for issue number: " + issueNumber, ex.getMessage());
        }
    }

    /**
     * Retrieves the issue type for the given issue number.
     * Used to populate the Type field in Document Generation.
     *
     * @param issueNumber the issue number
     * @return ResponseEntity containing the issue type string, or empty string if not found
     * @throws GridException if the issue type cannot be retrieved
     */
    @GetMapping("/getIssueType/{issueNumber}")
    @Operation(summary = "Get Issue Type by Issue Number",
            description = "Returns the issue type for the given issue number")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<String> getIssueType(@PathVariable String issueNumber) throws GridException {
        logger.info("Received request to retrieve issue type for issueNumber: {}", issueNumber);
        try {
            String issueType = gridMasterService.getIssueTypeByIssueNumber(issueNumber).orElse("");
            logger.info("Successfully retrieved issue type for issueNumber: {}", issueNumber);
            return ResponseEntity.ok(issueType);
        } catch (Exception ex) {
            logger.error("Failed to retrieve issue type for issueNumber: {}. Error: {}", issueNumber, ex.getMessage(), ex);
            throw new GridException(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to retrieve issue type for issue number: " + issueNumber, ex.getMessage());
        }
    }

    /**
     * Retrieves communication goals by type.
     * Used to populate the "What is the goal of this communication?" dropdown.
     *
     * @param communicationType accepted values: Dealer or Owner
     * @return ResponseEntity containing a filtered list of MasterOptionResponse objects
     * @throws GridException if communication goals cannot be retrieved
     */
    @GetMapping("/getAllCommunicationGoals")
    @Operation(summary = "Get All Communication Goals",
            description = "Returns communication goals by type from dealer or owner notification type collections")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<CollabNotificationsResponse> getAllCommunicationGoals(@RequestParam String communicationType) throws GridException {
        logger.info("Received request to retrieve communication goals for communicationType: {}", communicationType);
        try {
            CollabNotificationsResponse response = gridMasterService.getAllCommunicationGoals(communicationType);
            logger.info("Successfully retrieved communication goals for communicationType: {}", communicationType);
            return ResponseEntity.ok(response);
        } catch (Exception ex) {
            logger.error("Failed to retrieve communication goals for communicationType: {}. Error: {}", communicationType, ex.getMessage(), ex);
            throw new GridException(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to retrieve communication goals for type: " + communicationType, ex.getMessage());
        }
    }

    /**
     * Retrieves regions and countries by issue number.
     *
     * @param issueNumber the issue number
     * @return ResponseEntity containing region-country details for the issue.
     */
    @GetMapping("/regions-countries/{issueNumber}")
    @Operation(summary = "Get Regions and Countries by Issue Number", description = "Get Regions and Countries by Issue Number")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<IssueRegionCountryResponse> getRegionAndCountryByIssue(@PathVariable String issueNumber) throws GridException {
        return ResponseEntity.ok(gridMasterService.getRegionAndCountryByIssue(issueNumber));
    }

}
