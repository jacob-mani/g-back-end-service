package com.ford.grid.controller;

import com.ford.grid.common.SystemWideResponses;
import com.ford.grid.controller.arc.request.CollabTemplateRequest;
import com.ford.grid.controller.arc.response.CollabTemplateResponse;
import com.ford.grid.exception.DraftDocumentException;
import com.ford.grid.exception.GridException;
import com.ford.grid.model.dto.request.DataReadlinessRequest;
import com.ford.grid.model.dto.request.DocTemplateRequest;
import com.ford.grid.model.dto.request.DraftDocumentRequest;
import com.ford.grid.model.dto.request.GetTemplateFileRequest;
import com.ford.grid.model.dto.request.TemplateVersionHistoryRequest;
import com.ford.grid.model.dto.request.UploadGCSFileRequest;
import com.ford.grid.model.dto.response.*;
import com.ford.grid.service.DocumentTemplateService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.security.SecurityScheme;
import io.swagger.v3.oas.annotations.enums.SecuritySchemeType;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.time.LocalDateTime;
@RestController
@RequestMapping("/api/v2/documentgeneration")
@Validated
@SecurityScheme(
        name = "adfs",
        type = SecuritySchemeType.HTTP,
        scheme = "bearer",
        bearerFormat = "JWT"
)
@Tag(name = "Document Template Generator",
        description = "APIs for comprehensive document template based on region,market,brand and communication goal")
public class DocumentTemplateController {
    private static final Logger LOGGER = LoggerFactory.getLogger(DocumentTemplateController.class);

    @Autowired
    DocumentTemplateService documentTemplateService;


    @Operation(summary = "Get Document Templates",security = @SecurityRequirement(name = "adfs",
            scopes = {}))
    @ApiResponses(
            {
                    @ApiResponse(responseCode = "200", description = "OK", useReturnTypeSchema = true,
                            content = {@Content(mediaType = "application/json", array = @ArraySchema(schema = @Schema(implementation = DocTemplateResponse.class)))}),

                    @ApiResponse(responseCode = "400", description = "Bad Request, missing required fields.", useReturnTypeSchema = true,
                            content = {@Content (mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))}),

                    @ApiResponse(responseCode = "401", description = "Unauthorized.", useReturnTypeSchema = true,
                            content = {@Content (mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))}),

                    @ApiResponse(responseCode = "403", description = "Forbidden.", useReturnTypeSchema = true,
                            content = {@Content (mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))}),

                    @ApiResponse(responseCode = "404", description = "Method Not Found", useReturnTypeSchema = true,
                            content = {@Content (mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))}),

                    @ApiResponse(responseCode = "412", description = "Method Not Found", useReturnTypeSchema = true,
                            content = {@Content (mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))}),

                    @ApiResponse(responseCode = "415", description = "Bad Request, missing required fields.", useReturnTypeSchema = true,
                            content = {@Content (mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))}),

                    @ApiResponse(responseCode = "417", description = "Method Not Found", useReturnTypeSchema = true,
                            content = {@Content (mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))}),

                    @ApiResponse(responseCode = "422", description = "Method Not Found", useReturnTypeSchema = true,
                            content = {@Content (mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))}),

                    @ApiResponse(responseCode = "428", description = "Method Not Found", useReturnTypeSchema = true,
                            content = {@Content (mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))}),

                    @ApiResponse(responseCode = "429", description = "Bad Request, missing required fields.", useReturnTypeSchema = true,
                            content = {@Content (mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))}),

                    @ApiResponse(responseCode = "500", description = "Internal Server Error", useReturnTypeSchema = true,
                            content = {@Content (mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))})
            }
    )
    // ─── Endpoints ──────────────────────────────────────────────────────────

    /**
     * POST /api/v2/documentgeneration/getTemplates
     */
    @PostMapping("/getTemplates")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:CheckList','read')")
    public ResponseEntity<List<DocTemplateResponse>> getTemplates(@Valid @RequestBody DocTemplateRequest request) throws GridException {

        List<DocTemplateResponse> response = documentTemplateService.getDocumentTemplates(request);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @Operation(summary = "Get Data Readiness Details", security = @SecurityRequirement(name = "adfs", scopes = {}))
    @ApiResponses(
            {
                    @ApiResponse(responseCode = "200", description = "OK", useReturnTypeSchema = true,
                            content = {@Content(mediaType = "application/json", array = @ArraySchema(schema = @Schema(implementation = DataReadlinessResponse.class)))}),
                    @ApiResponse(responseCode = "400", description = "Bad Request, missing required fields.", useReturnTypeSchema = true,
                            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))}),
                    @ApiResponse(responseCode = "401", description = "Unauthorized.", useReturnTypeSchema = true,
                            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))}),
                    @ApiResponse(responseCode = "403", description = "Forbidden.", useReturnTypeSchema = true,
                            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))}),
                    @ApiResponse(responseCode = "500", description = "Internal Server Error", useReturnTypeSchema = true,
                            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))})
            }
    )
    @PostMapping("/getDataReadiness")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:CheckList','read')")
    public ResponseEntity<DataReadlinessResponse> getDataReadiness(@Valid @RequestBody DataReadlinessRequest request) throws GridException {
        LOGGER.info("Received request to get data readiness details for issueNumber: {}, implId: {}, populationId: {}",
                request.getIssueNumber(), request.getImplId(), request.getPopulationId());
        DataReadlinessResponse response = documentTemplateService.getDataReadlinesDetails(request);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @Operation(summary = "Generate Draft Document", security = @SecurityRequirement(name = "adfs", scopes = {}))
    @ApiResponses(
            {
                    @ApiResponse(responseCode = "202", description = "Accepted", useReturnTypeSchema = true,
                            content = {@Content(mediaType = "application/json")}),
                    @ApiResponse(responseCode = "400", description = "Bad Request, missing required fields.", useReturnTypeSchema = true,
                            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))}),
                    @ApiResponse(responseCode = "401", description = "Unauthorized.", useReturnTypeSchema = true,
                            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))}),
                    @ApiResponse(responseCode = "403", description = "Forbidden.", useReturnTypeSchema = true,
                            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))}),
                    @ApiResponse(responseCode = "404", description = "Not Found.", useReturnTypeSchema = true,
                            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))}),
                    @ApiResponse(responseCode = "500", description = "Internal Server Error", useReturnTypeSchema = true,
                            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))})
            }
    )
    @PostMapping("/generateDraftDocument")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:CheckList','read')")
    public ResponseEntity<GetTemplateFileResponse> generateDraftDocument(@Valid @RequestBody GetTemplateFileRequest request,
                                                      HttpServletRequest httpServletRequest) throws DraftDocumentException{
        LOGGER.info("Received request to generate draft document for issueNumber: {}, implId: {}, populationId: {}, templatePair: {}",
                request.getIssueNumber(), request.getImplId(), request.getPopulationId(), request.getTemplatePair());

        GetTemplateFileResponse response = documentTemplateService.getTemplateFileService(request, httpServletRequest);
        return new ResponseEntity<>(response, HttpStatus.OK);

    }

    @PostMapping(value = "/generateDraftDocumentResponse")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:CheckList','read')")
    public ResponseEntity<DraftDocumentResponse> generateDraftDocumentResponse(
            @Valid @ModelAttribute DraftDocumentRequest request,
            HttpServletRequest httpServletRequest) throws GridException {
        LOGGER.info("Received generated draft response payload for issueNumber: {}, fsaNumber: {}, fileName: {}",
                request.getIssueNumber(), request.getFsaNumber(), request.getFileName());
        DraftDocumentResponse draftResponse = documentTemplateService.saveDraftDocumentResponse(request, httpServletRequest);
        return new ResponseEntity<>(draftResponse, HttpStatus.OK);
    }
    @Operation(summary = "Upload Signed Document to GCS", security = @SecurityRequirement(name = "adfs", scopes = {}))
    @ApiResponses(
            {
                    @ApiResponse(responseCode = "200", description = "OK", useReturnTypeSchema = true,
                            content = {@Content(mediaType = "application/json", array = @ArraySchema(schema = @Schema(implementation = UploadGCSFileResponse.class)))}),
                    @ApiResponse(responseCode = "400", description = "Bad Request, missing required fields.", useReturnTypeSchema = true,
                            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))}),
                    @ApiResponse(responseCode = "401", description = "Unauthorized.", useReturnTypeSchema = true,
                            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))}),
                    @ApiResponse(responseCode = "403", description = "Forbidden.", useReturnTypeSchema = true,
                            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))}),
                    @ApiResponse(responseCode = "404", description = "Not Found.", useReturnTypeSchema = true,
                            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))}),
                    @ApiResponse(responseCode = "500", description = "Internal Server Error", useReturnTypeSchema = true,
                            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))})
            }
    )
    @PostMapping("/uploadSignedDocument")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:CheckList','read')")
    public ResponseEntity<?> uploadSignedDocument(@Valid @RequestBody UploadGCSFileRequest request) {
        LOGGER.info("Received request to upload signed document for issueNumber: {}, implId: {}, populationId: {}, fsaNumber: {}",
                request.getIssueNumber(), request.getImplId(), request.getPopulationId(), request.getFsaNumber());
        try {
            List<UploadGCSFileResponse> response = documentTemplateService.uploadDocuments(request);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (GridException e) {
            // Return an error body (a file is open/locked in SharePoint) with its message and status.
            HttpStatus status = e.getStatus() != null ? e.getStatus() : HttpStatus.INTERNAL_SERVER_ERROR;
            String message = e.getMessage() != null ? e.getMessage() : "Upload signed document failed.";
            LOGGER.error("uploadSignedDocument failed - issueNumber: {}, status: {}, message: {}",
                    request.getIssueNumber(), status, message);
            ErrorResponse errorResponse = new ErrorResponse(message, status.value(), LocalDateTime.now());
            return new ResponseEntity<>(errorResponse, status);
        }
    }

        @Operation(
                summary = "Add Document Templates",
                operationId = "addDocumentTemplates",
                security = @SecurityRequirement(name = "adfs", scopes = {}),
                requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                        required = true,
                        content = @Content(
                                mediaType = MediaType.MULTIPART_FORM_DATA_VALUE,
                                schema = @Schema(implementation = CollabTemplateRequest.class)
                        )
                )
        )
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "OK", useReturnTypeSchema = true,
                    content = {@Content(mediaType = "application/json",
                            array = @ArraySchema(maxItems = 100, schema = @Schema(implementation = CollabTemplateResponse.class)))}),
            @ApiResponse(responseCode = "413", description = "Payload Too Large.",
                    content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))})
    })
    @PostMapping(value = "/addTemplates", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Administration','update')")
    public ResponseEntity<List<CollabTemplateResponse>> addTemplates(@Valid @ModelAttribute CollabTemplateRequest request) throws GridException {

        List<CollabTemplateResponse> response = documentTemplateService.addDocumentTemplates(request);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
    @Operation(summary = "Get Template Version History",
            description = "Returns the full upload history for a specific template classification, " +
                    "including upload date and uploader CDSID for each version.",
            security = @SecurityRequirement(name = "adfs", scopes = {}))
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "OK", useReturnTypeSchema = true,
                    content = {@Content(mediaType = "application/json",
                            schema = @Schema(implementation = TemplateVersionHistoryResponse.class))}),
            @ApiResponse(responseCode = "400", description = "Bad Request, missing required fields.", useReturnTypeSchema = true,
                    content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))}),
            @ApiResponse(responseCode = "401", description = "Unauthorized.", useReturnTypeSchema = true,
                    content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))}),
            @ApiResponse(responseCode = "403", description = "Forbidden.", useReturnTypeSchema = true,
                    content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))}),
            @ApiResponse(responseCode = "404", description = "No version history found.", useReturnTypeSchema = true,
                    content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))}),
            @ApiResponse(responseCode = "500", description = "Internal Server Error", useReturnTypeSchema = true,
                    content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))})
    })
    @PostMapping("/getTemplateVersionHistory")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Administration','read')")
    public ResponseEntity<TemplateVersionHistoryResponse> getTemplateVersionHistory(
            @Valid @RequestBody TemplateVersionHistoryRequest request) throws GridException {
        LOGGER.info("Received request to get template version history - region: {}, market: {}, brand: {}, templateType: {}",
                request.getRegion(), request.getMarket(), request.getBrandType(),
                request.getTemplateType());
        TemplateVersionHistoryResponse response = documentTemplateService.getTemplateVersionHistory(request);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

}

