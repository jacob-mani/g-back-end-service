package com.ford.grid.controller;

import com.ford.grid.model.dto.request.DocumentFilterRequest;
import com.ford.grid.model.dto.request.ProdFileDownloadRequest;
import com.ford.grid.model.dto.response.LocationsResponse;
import com.ford.grid.model.dto.response.PagedDocumentResponse;
import com.ford.grid.model.dto.response.ProdFileDownloadResponse;
import com.ford.grid.service.DocumentViewService;
import com.ford.grid.service.impl.ProdFileDownloadService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;


import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;

import java.util.List;

@RestController
@RequestMapping("/api/v2/documents")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "Document View Management",
        description = "APIs for comprehensive document management across Issue, FD, Forum, Implementation, and Launch levels.")
public class DocumentViewController {

    private final DocumentViewService documentViewService;
    private final ProdFileDownloadService prodFileDownloadService;

    @PostMapping("/search")
    @Operation(
            summary = "Search documents with advanced filters and pagination",
            description = "Comprehensive document search across Issue Level, FD Level, and Forum Level views. " +
                    "Supports filtering by locations, document levels, with pagination and sorting capabilities.",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Documents retrieved successfully"),
                    @ApiResponse(responseCode = "400", description = "Invalid request parameters"),
                    @ApiResponse(responseCode = "404", description = "No documents found")
            }
    )
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<PagedDocumentResponse> searchDocuments(
            @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    description = "Document search filters with pagination",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = DocumentFilterRequest.class),
                            examples = @ExampleObject(
                                    name = "Search Example",
                                    value = "{\n" +
                                            "  \"issueNumber\": \"25-070\",\n" +
                                            "  \"locations\": [\"14D\", \"Investigation - CCRG\"],\n" +
                                            "  \"docLevel\": null,\n" +
                                            "  \"page\": 0,\n" +
                                            "  \"size\": 20,\n" +
                                            "  \"sortBy\": \"uploadedTime\",\n" +
                                            "  \"sortDirection\": \"DESC\"\n" +
                                            "}"
                            )
                    )
            )
            @Valid @RequestBody DocumentFilterRequest request) {

        log.info("Search documents request received: {}", request);

        // Empty locations [] means no location selected — return empty response immediately
        if (request.getLocations() != null && request.getLocations().isEmpty()) {
            log.info("Empty locations list — returning empty response for issue: {}", request.getIssueNumber());
            PagedDocumentResponse empty = PagedDocumentResponse.builder()
                    .documents(java.util.Collections.emptyList())
                    .totalElements(0L)
                    .totalPages(0)
                    .currentPage(request.getPage())
                    .pageSize(request.getSize())
                    .hasNext(false)
                    .hasPrevious(false)
                    .build();
            return ResponseEntity.ok(empty);
        }

        PagedDocumentResponse response = documentViewService.getDocuments(request);
        log.info("Search completed: {} documents found out of {} total",
                response.getDocuments().size(), response.getTotalElements());
        return ResponseEntity.ok(response);
    }

    @GetMapping("/locations/{issueNumber}")
    @Operation(
            summary = "Get available locations and document counts",
            description = "Retrieve all available locations/sections for document filtering with document counts per location. " +
                    "Aggregates data from Issue, FD, Forum, Implementation, and Launch level views. Returns empty array if no documents found.",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Locations retrieved successfully (empty array if no documents found)"),
                    @ApiResponse(responseCode = "400", description = "Invalid request parameters")
            }
    )
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<LocationsResponse> getAvailableLocations(
            @Parameter(description = "Issue Number (e.g., 25-070)", required = true, example = "25-070")
            @PathVariable @NotBlank String issueNumber) {

        long startTime = System.currentTimeMillis();
        log.info("Get locations request for issue: {}", issueNumber);

        LocationsResponse response = documentViewService.getAvailableLocations(issueNumber);

        long endTime = System.currentTimeMillis();
        long responseTime = endTime - startTime;

        log.info("Locations retrieved for issue {}: {} locations found in {}ms",
                issueNumber, response.getLocations().size(), responseTime);

        // Add response time header for monitoring
        return ResponseEntity.ok()
                .header("X-Response-Time-Ms", String.valueOf(responseTime))
                .body(response);
    }

    @GetMapping("/{issueNumber}")
    @Operation(
            summary = "Get documents using query parameters",
            description = "Alternative endpoint to get documents using query parameters instead of request body. " +
                    "Useful for simple filtering and direct URL access.",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Documents retrieved successfully"),
                    @ApiResponse(responseCode = "400", description = "Invalid query parameters"),
                    @ApiResponse(responseCode = "404", description = "No documents found")
            }
    )
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<PagedDocumentResponse> getDocumentsByParams(
            @Parameter(description = "Issue Number", required = true, example = "25-070")
            @PathVariable @NotBlank String issueNumber,

            @Parameter(description = "Locations to filter (comma-separated)",
                    example = "14D,Investigation - CCRG,Scope & Info")
            @RequestParam(required = false) List<String> locations,

            @Parameter(description = "Document level filter",
                    schema = @Schema(allowableValues = {"ISSUE", "FD", "FORUM", "IMPL", "LAUNCH"}))
            @RequestParam(required = false) String docLevel,

            @Parameter(description = "Page number (0-based)", example = "0")
            @RequestParam(defaultValue = "0") int page,

            @Parameter(description = "Page size (max 100)", example = "20")
            @RequestParam(defaultValue = "20") int size,

            @Parameter(description = "Sort by field",
                    schema = @Schema(allowableValues = {"uploadedTime", "documentName", "location", "section", "uploadedUser", "docLevel"}))
            @RequestParam(defaultValue = "uploadedTime") String sortBy,

            @Parameter(description = "Sort direction",
                    schema = @Schema(allowableValues = {"ASC", "DESC"}))
            @RequestParam(defaultValue = "DESC") String sortDirection) {

        // Limit page size to prevent large responses
        if (size > 100) {
            size = 100;
        }

        DocumentFilterRequest request = new DocumentFilterRequest();
        request.setIssueNumber(issueNumber);
        request.setLocations(locations);
        request.setDocLevel(docLevel);
        request.setPage(page);
        request.setSize(size);
        request.setSortBy(sortBy);
        request.setSortDirection(sortDirection);

        log.info("Get documents request via query params: {}", request);
        PagedDocumentResponse response = documentViewService.getDocuments(request);
        log.info("Query params search completed: {} documents found out of {} total",
                response.getDocuments().size(), response.getTotalElements());
        return ResponseEntity.ok(response);
    }

    @PostMapping("/download-prod-files")
    @Operation(
            summary = "Download files from Prod GCP bucket (Local Development Only)",
            description = "Downloads files from prod GCP bucket using signed URLs. " +
                    "This endpoint is for local development/testing purposes only. " +
                    "Pass a list of GCS file names and they will be downloaded to a local folder. " +
                    "Optionally upload the downloaded files to lower environment GCP bucket by setting uploadToLowerEnv=true.",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Download operation completed"),
                    @ApiResponse(responseCode = "400", description = "Invalid request parameters"),
                    @ApiResponse(responseCode = "500", description = "Download failed")
            }
    )
    public ResponseEntity<ProdFileDownloadResponse> downloadProdFiles(@Valid @RequestBody ProdFileDownloadRequest request) {

        log.info("Download prod files request received: {} files to download, uploadToLowerEnv: {}",
                request.getGcsFileNames() != null ? request.getGcsFileNames().size() : 0,
                request.isUploadToLowerEnv());

        ProdFileDownloadResponse response = prodFileDownloadService.downloadProdFiles(request);

        log.info("Download completed: {} success, {} failed out of {} total. Upload: {} success, {} failed",
                response.getSuccessCount(), response.getFailedCount(), response.getTotalFiles(),
                response.getUploadSuccessCount(), response.getUploadFailedCount());

        return ResponseEntity.ok(response);
    }

    @PostMapping("/upload-local-files")
    @Operation(
            summary = "Upload local files to lower environment GCP bucket via API (Local Development Only)",
            description = "Uploads files from a local folder to the lower environment GCP bucket via API signed URL. " +
                    "This method uses the preprod/qa/dev API endpoint to get a signed URL and upload the file, " +
                    "avoiding the need for direct GCP bucket credentials locally.",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Upload operation completed"),
                    @ApiResponse(responseCode = "400", description = "Invalid request parameters"),
                    @ApiResponse(responseCode = "500", description = "Upload failed")
            }
    )
    public ResponseEntity<ProdFileDownloadResponse> uploadLocalFiles(
            @Parameter(description = "Local folder path containing files to upload", required = true)
            @RequestParam String localFolderPath,
            @Parameter(description = "Optional GCS folder prefix for uploaded files")
            @RequestParam(required = false) String uploadFolderPrefix,
            @Parameter(description = "Bearer token for preprod/qa/dev API (required for upload)", required = true)
            @RequestParam String preprodToken,
            @Parameter(description = "Target environment: preprod, qa, or dev (default: preprod)")
            @RequestParam(required = false, defaultValue = "preprod") String targetEnv) {

        log.info("Upload local files request received: folder={}, prefix={}, targetEnv={}", localFolderPath, uploadFolderPrefix, targetEnv);

        ProdFileDownloadResponse response = prodFileDownloadService.uploadLocalFilesToLowerEnv(localFolderPath, uploadFolderPrefix, preprodToken, targetEnv);

        log.info("Upload completed: {} success, {} failed out of {} total",
                response.getUploadSuccessCount(), response.getUploadFailedCount(), response.getTotalFiles());

        return ResponseEntity.ok(response);
    }
}
