package com.ford.grid.controller;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ford.grid.common.SystemWideResponses;
import com.ford.grid.exception.GridException;
import com.ford.grid.model.dto.request.FRCSummaryExportRequest;
import com.ford.grid.model.dto.request.NHTSAnoticeSaveReqObj;
import com.ford.grid.model.dto.request.UploadClosureDocRequest;
import com.ford.grid.model.dto.response.UploadDocumentResponse;
import com.ford.grid.model.entity.KeyStatus;
import com.ford.grid.model.entity.PdfBasicDetail;
import com.ford.grid.model.entity.RecallIssue;
import com.ford.grid.repository.RecallIssueRepository;
import com.ford.grid.security.UserDetailProvider;
import com.ford.grid.service.DocumentUploadService;
import com.ford.grid.service.ExportService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import java.io.FileNotFoundException;
import java.util.List;
import java.util.Optional;

import static com.ford.grid.constants.CommonConstants.EXCEPTION_MESSAGE;

@RestController
@RequestMapping("/api/v2/export")
@RequiredArgsConstructor
public class ExportController {
    private static final Logger LOGGER = LoggerFactory.getLogger(ExportController.class);
    private final ExportService exportService;
    private final DocumentUploadService documentUploadService;
    private final RecallIssueRepository recallIssueRepository;
    private final ObjectMapper objectMapper;
    private final UserDetailProvider userDetailProvider;

    /**
     * API endpoint for downloading a document by its ID.
     * The file will be sent as an attachment.
     *
     * @param issueNumber The ID of the document to download.
     * @return The document as a byte stream.
     */
    @GetMapping("/closureNotedownload/{issueNumber}")
    @Operation(summary = "Export", description = "Export Get API with closureNotedownload")
    @SystemWideResponses
    public ResponseEntity<StreamingResponseBody> downloadClosureDocument
    (@PathVariable String issueNumber,
     @RequestParam(value = "forumType", required = false) String forumType,
     @RequestParam(value = "meetingNotesType", required = false) List<String> meetingNotesType,
     @RequestParam(value = "keyStatusArr", required = false) String keyStatusArray) {
        LOGGER.info("Attempting to download closure document for issueNumber: {}", issueNumber);
        ObjectMapper objectMapper = new ObjectMapper();
        List<KeyStatus> keyStatusArr = null;
        try {
            keyStatusArr = objectMapper.readValue(keyStatusArray, new TypeReference<>() {
            });
        } catch (Exception e) {
            LOGGER.error("keyStatusArr data not available: {}", e.getMessage(), e);
        }
        return exportService.downloadClosureReviewDoc(issueNumber, forumType, meetingNotesType, keyStatusArr);
    }

    /**
     * Download the CCRG OnePage Document for a given issue number.
     *
     * <p>This API endpoint generates and streams a PDF document containing
     * the CCRG OnePage summary details for the specified recall issue.
     *
     * @param issueNumber the recall issue number for which the CCRG document is to be downloaded
     * @param request     the HTTP servlet request object
     * @return ResponseEntity containing the streamed PDF file as a {@link StreamingResponseBody}
     * @throws GridException         if the issue is not found or PDF generation fails
     * @throws FileNotFoundException if the generated PDF file cannot be accessed
     */
    @GetMapping(value = "/ccrgDownload")
    @Operation(summary = "Download CCRG Document", description = "Downloads the CCRG OnePage summary document for the specified issue number.")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read'})")
    public ResponseEntity<StreamingResponseBody> CCRGOnePageDocument(@RequestParam("issueNumber") String issueNumber,
                                                                     HttpServletRequest request) throws GridException, FileNotFoundException {
        LOGGER.info("Received request to download CCRG OnePage document for issueNumber: {}", issueNumber);
        try {
            ResponseEntity<StreamingResponseBody> response = exportService.ccrgOnePageDocumentDownload(issueNumber, request);
            LOGGER.info("Successfully generated CCRG OnePage document for issueNumber: {}", issueNumber);
            return response;
        } catch (Exception ex) {
            LOGGER.error("Failed to generate CCRG OnePage document for issueNumber: {}. Error: {}", issueNumber, ex.getMessage(), ex);
            throw ex;
        }
    }

    /**
     * Downloads the 14D document for a given recall issue number.
     *
     * <p>This API endpoint generates and streams the 14D checklist document
     * as a PDF file for the specified recall issue. It ensures that only
     * authorized users with read access to the My Issues List can perform
     * this download.
     *
     * @param issueNumber the recall issue number for which the 14D document is to be downloaded
     * @param request     the HTTP servlet request object
     * @return ResponseEntity containing the streamed PDF file as a {@link StreamingResponseBody}
     * @throws GridException if the issue data is not found or the PDF generation fails
     */
    @PostMapping("/14DDownload")
    @Operation(summary = "Download 14D Document", description = "Downloads the 14D document for the specified issue number.")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read'})")
    public ResponseEntity<StreamingResponseBody> checkList14DPdfDownload(
            @RequestParam("issueNumber") String issueNumber,
            @RequestBody(required = false) PdfBasicDetail pdfBasicDetail,
            HttpServletRequest request) throws GridException {
        LOGGER.info("Received request to download 14D document for issueNumber: {}", issueNumber);
        try {
            ResponseEntity<StreamingResponseBody> response =
                    exportService.checkList14DPdfDownload(issueNumber, request, pdfBasicDetail);
            LOGGER.info("Successfully generated 14D document for issueNumber: {}", issueNumber);
            return response;
        } catch (GridException ex) {
            LOGGER.error("Failed to generate 14D document for issueNumber: {}. Error: {}", issueNumber, ex.getMessage(), ex);
            throw ex;
        } catch (Exception ex) {
            LOGGER.error("Failed to generate 14D document for issueNumber: {}. Error: {}", issueNumber, ex.getMessage(), ex);
            throw new GridException(HttpStatus.INTERNAL_SERVER_ERROR, EXCEPTION_MESSAGE,
                    "Failed to generate 14D document for issue number: " + issueNumber);
        }
    }

    /**
     * REST API endpoint to download an EPRC (EPA Emission Defect Information Report) document
     * for a given issue number and version type.
     *
     * <p>This endpoint handles the request to generate and stream the PDF document
     * for the specified issue. It performs authorization checks, handles exceptions,
     * and provides detailed logging for debugging and monitoring purposes.</p>
     *
     * @param issueNumber the unique identifier of the issue for which the EPRC document is requested
     * @param versionType the version/type of the EPRC document (e.g., Part85 or Part1068)
     * @param request     the HttpServletRequest object containing request details
     * @return ResponseEntity containing a StreamingResponseBody to stream the PDF content to the client
     * @throws GridException if no RecallIssue is found for the specified issue number or if an error occurs during PDF generation
     */
    @GetMapping("/eprc/defect-report")
    @Operation(summary = "Download EPRC Document", description = "Downloads the EPRC document for the specified issue number.")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read'})")
    public ResponseEntity<StreamingResponseBody> eprcDocumentDownload(
            @RequestParam("issueId") String issueNumber, @RequestParam("versionType") String versionType,
            HttpServletRequest request) throws GridException {
        LOGGER.info("Received request to download EPRC document for issueNumber: {}", issueNumber);
        try {
            ResponseEntity<StreamingResponseBody> response =
                    exportService.eprcReportDownload(issueNumber, versionType, request);
            LOGGER.info("Successfully generated EPRC document for issueNumber: {}", issueNumber);
            return response;
        } catch (Exception ex) {
            LOGGER.error("Failed to generate EPRC document for issueNumber: {}. Error: {}", issueNumber, ex.getMessage(), ex);
            throw new GridException(HttpStatus.BAD_REQUEST, EXCEPTION_MESSAGE,
                    "No RecallIssue found for issue number: " + issueNumber);
        }
    }

    /**
     * Downloads the EPRC Fact Sheet PDF for a given issue number and issue title.
     *
     * <p>This endpoint triggers the generation of the EPRC Fact Sheet document and streams the
     * resulting PDF back to the client. The PDF is generated dynamically without storing any
     * temporary files on disk. The method also includes authorization validation
     * using GRID security rules.</p>
     *
     * @param issueNumber the issue number for which the Fact Sheet is required
     * @param issueTitle  the title of the issue, used for PDF header/footer and metadata
     * @return ResponseEntity containing the PDF as a StreamingResponseBody
     * @throws GridException if PDF generation fails or the issue number is invalid
     */
    @GetMapping("/eprc-fact-sheet/{issueNumber}")
    @Operation(summary = "Download EPRC Fact Sheet",
            description = "Downloads the EPRC Fact Sheet for the specified issue number.")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read'})")
    public ResponseEntity<StreamingResponseBody> eprcFactSheetDownload(
            @PathVariable String issueNumber, @RequestParam(required = false) String issueTitle) throws GridException {
        LOGGER.info("Received request to download EPRC Fact Sheet for issueNumber={}, title={}", issueNumber, issueTitle);
        try {
            // Initiate export through service
            LOGGER.debug("Calling exportService.factSheetExport for issueNumber={}", issueNumber);
            Optional<RecallIssue> recallIssueOpt = recallIssueRepository.findByIssueNumberAndStatus(issueNumber, "Active");
            if (recallIssueOpt.isEmpty()) {
                LOGGER.error("No active RecallIssue found for issueNumber={}", issueNumber);
                throw new GridException(HttpStatus.NOT_FOUND, "Issue Not Found",
                        "No active recall issue found for issue number: " + issueNumber);
            }
            RecallIssue recallIssue = recallIssueOpt.get();
            String title = issueTitle != null ? issueTitle : recallIssue.getIssueTitle();

            LOGGER.debug("Calling exportService.factSheetExport for issueNumber={}, title={}", issueNumber, title);

            ResponseEntity<StreamingResponseBody> response =
                    exportService.factSheetExport(issueNumber, title);

            LOGGER.info("Successfully generated EPRC Fact Sheet for issueNumber={}", issueNumber);
            return response;
        } catch (Exception ex) {
            LOGGER.error("Failed to generate EPRC Fact Sheet for issueNumber={}. Error={}", issueNumber, ex.getMessage(), ex);
            throw new GridException(HttpStatus.BAD_REQUEST, EXCEPTION_MESSAGE, "No RecallIssue found for issue number: " + issueNumber);
        }
    }

    /**
     * Uploads the CCRG Closure Review Document to GCS and saves attachment reference
     * to the Forum Schedule collection.
     *
     * @param issueNumber      the issue number
     * @param meetingNotesType list of meeting note types
     * @param keyStatusArray   JSON string of key status array
     * @param uploadedBy       user CDSID who triggered the upload
     * @return ResponseEntity with upload result
     */
    @GetMapping("/closure/review/upload")
    @Operation(summary = "Upload Closure Review Document",
            description = "Uploads CCRG Closure Review Document to GCS and saves to Forum Schedule collection")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:Checklist':'read'})")
    public ResponseEntity<UploadDocumentResponse> uploadClosureDocument(
            @RequestParam("issueNumber") String issueNumber,
            @RequestParam(value = "meetingNotesType", required = false) List<String> meetingNotesType,
            @RequestParam("keyStatusArr") String keyStatusArray,
            @RequestParam("uploadedBy") String uploadedBy) throws GridException {

        LOGGER.info("Received request to upload Closure Review Document for issueNumber: {}", issueNumber);

        List<KeyStatus> keyStatusArr;
        try {
            keyStatusArr = objectMapper.readValue(keyStatusArray, new TypeReference<>() {
            });
        } catch (Exception e) {
            LOGGER.error("Failed to parse keyStatusArray: {}", e.getMessage(), e);
            throw new GridException(HttpStatus.INTERNAL_SERVER_ERROR, "Invalid Input",
                    "Failed to parse keyStatusArr: " + e.getMessage());
        }

        UploadDocumentResponse response = documentUploadService.uploadClosureReviewDoc(
                issueNumber, meetingNotesType, keyStatusArr, uploadedBy);

        LOGGER.info("Successfully uploaded Closure Review Document for issueNumber: {}", issueNumber);
        return ResponseEntity.ok(response);
    }

    /**
     * Uploads the CCRG Closure Review Document using POST request body.
     *
     * @param request the upload request containing issue number, meeting types, and key status
     * @return ResponseEntity with upload result
     */
    @PostMapping("/closure/review/upload")
    @Operation(summary = "Upload Closure Review Document (POST)",
            description = "Uploads CCRG Closure Review Document to GCS and saves to Forum Schedule collection")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:Checklist':'read'})")
    public ResponseEntity<UploadDocumentResponse> uploadClosureDocumentPost(
            @RequestBody UploadClosureDocRequest request) throws GridException {

        LOGGER.info("Received POST request to upload Closure Review Document for issueNumber: {}",
                request.getIssueNumber());

        UploadDocumentResponse response = documentUploadService.uploadClosureReviewDoc(request);

        LOGGER.info("Successfully uploaded Closure Review Document for issueNumber: {}",
                request.getIssueNumber());
        return ResponseEntity.ok(response);
    }

    /**
     * Uploads the 14D PDF Document to GCS and saves attachment reference
     * to the FDKickoff collection.
     *
     * @param pdfBasicDetail the PDF details including issue number and printed by
     * @return ResponseEntity with upload result
     */
    @PostMapping("/pdf/upload")
    @Operation(summary = "Upload 14D PDF Document",
            description = "Uploads 14D PDF Document to GCS and saves to FDKickoff collection")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:Checklist':'read'})")
    public ResponseEntity<UploadDocumentResponse> uploadPdfDocument(
            @RequestBody PdfBasicDetail pdfBasicDetail) throws GridException {

        LOGGER.info("Received request to upload 14D PDF Document for issueNumber: {}",
                pdfBasicDetail.getIssueNumber());

        UploadDocumentResponse response = documentUploadService.upload14DPdfDocument(pdfBasicDetail);

        LOGGER.info("Successfully uploaded 14D PDF Document for issueNumber: {}",
                pdfBasicDetail.getIssueNumber());
        return ResponseEntity.ok(response);
    }

    /**
     * Exports and downloads the FRC Summary report as a PDF document.
     *
     * <p>This API endpoint generates and streams the FRC Summary report
     * as a PDF file based on the provided export request details,
     * including date range, region, selected columns, and FRC summary data.</p>
     *
     * <p><b>Authorization:</b> Requires {@code GRID:Checklist} read access.</p>
     *
     * <p><b>Usage:</b></p>
     * <ul>
     *   <li>Client sends FRC Summary data along with export configuration</li>
     *   <li>Server generates the PDF and streams it back as a downloadable attachment</li>
     *   <li>If generation fails, a {@code 400 Bad Request} response is returned</li>
     * </ul>
     *
     * @param frcSummaryExportRequest the request body containing FRC summary export details such as:
     *                                <ul>
     *                                  <li>{@code createdBy} — CDSID of the user generating the report</li>
     *                                  <li>{@code frcDate} — specific FRC meeting date (optional)</li>
     *                                  <li>{@code fromDate} — start date of the date range (optional)</li>
     *                                  <li>{@code toDate} — end date of the date range (optional)</li>
     *                                  <li>{@code region} — region filter (optional)</li>
     *                                  <li>{@code exportColums} — map of column visibility flags</li>
     *                                  <li>{@code frcSummaryBOs} — list of FRC summary records to export</li>
     *                                </ul>
     * @return {@link ResponseEntity} containing the streamed PDF file as a {@link StreamingResponseBody}
     *         with appropriate content-disposition headers for download
     * @throws GridException if PDF generation fails or the request data is invalid
     */
    @PostMapping("/pdf/frc/summary")
    @Operation(summary = "Export FRC Summary PDF Document",
            description = "Generates and downloads FRC Summary as a PDF document")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:Checklist':'read'})")
    public ResponseEntity<StreamingResponseBody> exportFRCSummaryForPDF(
            @RequestBody FRCSummaryExportRequest frcSummaryExportRequest) throws GridException {
        LOGGER.info("Received request to export FRC Summary as PDF");
        try {
            ResponseEntity<StreamingResponseBody> response = exportService.exportFRCSummaryAsPDF(frcSummaryExportRequest);
            LOGGER.info("Successfully generated FRC Summary PDF");
            return response;
        } catch (StackOverflowError ex) {
            LOGGER.error("Failed to generate FRC Summary PDF — document too large (StackOverflowError)", ex);
            throw new GridException(HttpStatus.BAD_REQUEST, EXCEPTION_MESSAGE,
                    "The selected data is too large to export as PDF. Please use filters to reduce the selection size and try again.");
        } catch (Exception ex) {
            LOGGER.error("Failed to generate FRC Summary PDF. Error: {}", ex.getMessage(), ex);
            throw new GridException(HttpStatus.INTERNAL_SERVER_ERROR, EXCEPTION_MESSAGE,
                    "Failed to generate FRC Summary PDF: " + ex.getMessage());
        }
    }

    /**
     * Downloads the FRC Summary as an Excel document.
     *
     * <p>This API endpoint generates and streams the FRC Summary report
     * as an Excel (.xlsx) file based on the provided export request details,
     * including date range, region, selected columns, and FRC summary data.</p>
     *
     * @param frcSummaryExportRequest the request body containing FRC summary export details
     *                                such as date range, region, column selections, and FRC summary records
     * @return ResponseEntity containing the streamed Excel file as a {@link StreamingResponseBody}
     * @throws GridException if Excel generation fails or required data is missing
     */
    @PostMapping("/excel/frc/summary")
    @Operation(summary = "Export FRC Summary Excel Document",
            description = "Generates and downloads FRC Summary as an Excel document")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:Checklist':'read'})")
    public ResponseEntity<StreamingResponseBody> exportFRCSummaryForExcel(
            @RequestBody FRCSummaryExportRequest frcSummaryExportRequest) throws GridException {
        LOGGER.info("Received request to export FRC Summary as Excel");
        try {
            ResponseEntity<StreamingResponseBody> response = exportService.exportFRCSummaryAsExcel(frcSummaryExportRequest);
            LOGGER.info("Successfully generated FRC Summary Excel");
            return response;
        } catch (StackOverflowError ex) {
            LOGGER.error("Failed to generate FRC Summary Excel — document too large (StackOverflowError)", ex);
            throw new GridException(HttpStatus.BAD_REQUEST, EXCEPTION_MESSAGE,
                    "The selected data is too large to export as Excel. Please use filters to reduce the selection size and try again.");
        } catch (Exception ex) {
            LOGGER.error("Failed to generate FRC Summary Excel. Error: {}", ex.getMessage(), ex);
            throw new GridException(HttpStatus.INTERNAL_SERVER_ERROR, EXCEPTION_MESSAGE,
                    "Failed to generate FRC Summary Excel: " + ex.getMessage());
        }
    }


    @PostMapping("/report/fdr/nhtsa-notice")
    @Operation(summary = "Export FDR Report NHTSA Notice Document",
            description = "Generates and downloads FDR Report NHTSA Notice document")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:Checklist':'read'})")
    public ResponseEntity<StreamingResponseBody> exportNHTSANoticeInFdrReport(
            @RequestBody NHTSAnoticeSaveReqObj nhtsaNoticeSaveReqObj) throws GridException {
        return exportService.exportNHTSANoticeInFdrReportAsDocx(nhtsaNoticeSaveReqObj);
    }


    @GetMapping("/fdr/pdf-report")
    @Operation(summary = "Export FDR Report PDF Document",
            description = "Generates and downloads FDR Report as a PDF document")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:Checklist':'read'})")
    public ResponseEntity<StreamingResponseBody> exportFDRreportAsPDF(@RequestParam("contentType") String contentType) throws GridException {

        if (!org.springframework.util.StringUtils.hasText(contentType)) {
            LOGGER.error("exportFDRreportAsPDF: contentType is null or blank");
            throw new GridException(HttpStatus.BAD_REQUEST, "Missing content type", "contentType parameter is required");
        }

        if (userDetailProvider.getUser() == null || !org.springframework.util.StringUtils.hasText(userDetailProvider.getUser().getCdsID())) {
            LOGGER.error("exportFDRreportAsPDF: user identity could not be resolved");
            throw new GridException(HttpStatus.UNAUTHORIZED, "User identity not available", "CDS ID could not be resolved");
        }

        String userCdsId = userDetailProvider.getUser().getCdsID();
        LOGGER.info("Received request to export FDR Report as PDF for user: {}, contentType: {}", userCdsId, contentType);
        try {
            ResponseEntity<StreamingResponseBody> response = exportService.exportFDRreportAsPDF(contentType, userCdsId);
            LOGGER.info("Successfully generated FDR Report PDF for user: {}", userCdsId);
            return response;
        } catch (GridException ex) {
            throw ex;
        } catch (Exception ex) {
            LOGGER.error("Failed to generate FDR Report PDF for user: {}, contentType: {}. Error: {}",
                    userCdsId, contentType, ex.getMessage(), ex);
            throw new GridException(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to generate FDR Report PDF",
                    ex.getMessage() != null ? ex.getMessage() : ex.getClass().getName());
        }
    }

    @GetMapping("/fdrReport/excel")
    @ResponseBody
    public ResponseEntity<StreamingResponseBody> downloadFdrExcelInfo(@RequestParam("contentType") String contentType) throws Exception {
        return exportService.exportFdrReport(contentType);
    }

    /**
     * Downloads the 14D Checklist Excel for a given recall issue number.
     *
     * @param issueNumber the recall issue number for which the 14D document is to be downloaded
     * @return ResponseEntity containing the streamed Excel file as a {@link StreamingResponseBody}
     * @throws GridException if the issue data is not found or the PDF generation fails
     */
    @PostMapping("/14D-checklist-Download")
    @Operation(summary = "Download 14D Checklist Excel Document", description = "Downloads the 14D Checklist document for the specified issue number.")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read'})")
    public ResponseEntity<StreamingResponseBody> checkList14DExcelDownload(@RequestBody(required = false) PdfBasicDetail pdfBasicDetail) throws GridException {
        LOGGER.info("Received request to download 14D document for issueNumber: {}", pdfBasicDetail.getIssueNumber());
        try {
            ResponseEntity<StreamingResponseBody> response =
                    exportService.checkList14DExcelDownload(pdfBasicDetail.getIssueNumber(), pdfBasicDetail.getDisabledCards());
            LOGGER.info("Successfully generated 14D document for issueNumber: {}", pdfBasicDetail.getIssueNumber());
            return response;
        } catch (GridException ex) {
            LOGGER.error("Failed to generate 14D document for issueNumber: {}. Error: {}", pdfBasicDetail.getIssueNumber(), ex.getMessage(), ex);
            throw ex;
        } catch (Exception ex) {
            LOGGER.error("Failed to generate 14D document for issueNumber: {}. Error: {}", pdfBasicDetail.getIssueNumber(), ex.getMessage(), ex);
            throw new GridException(HttpStatus.INTERNAL_SERVER_ERROR, EXCEPTION_MESSAGE,
                    "Failed to generate 14D document for issue number: " + pdfBasicDetail.getIssueNumber());
        }
    }
}