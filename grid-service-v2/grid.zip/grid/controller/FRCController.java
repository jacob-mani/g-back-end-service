
package com.ford.grid.controller;

import com.ford.grid.common.SystemWideResponses;
import com.ford.grid.exception.GridException;
import com.ford.grid.model.dto.request.FRCMemoRequest;
import com.ford.grid.model.dto.request.FRCPacRequest;
import com.ford.grid.model.dto.request.FRCScheduleRequest;
import com.ford.grid.model.dto.response.FRCMemoResponse;
import com.ford.grid.model.dto.response.FRCPacResponse;
import com.ford.grid.model.dto.response.FRCScheduleResponse;
import com.ford.grid.service.FRCService;
import io.swagger.v3.oas.annotations.Operation;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@AllArgsConstructor
@RequestMapping("/api/v2/frc")
public class FRCController {
    private static final Logger LOGGER = LoggerFactory.getLogger(FRCController.class);

    private final FRCService frcService;

    @PostMapping("/saveFrcSchedule")
    @Operation(summary = "Save Frc Schedule", description = "save frc Schedule if record exists")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<FRCScheduleResponse> saveFrcSchedule(@RequestBody FRCScheduleRequest request) throws GridException {
        LOGGER.info("Start of save frc Schedule : {}", request);
        FRCScheduleResponse response = frcService.saveFrcSchedule(request);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/getFrcSchedule/{populationId}")
    @Operation(summary = "Get FRC Schedule", description = "Get FRC Schedule by issueNumber, implId and populationId")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<FRCScheduleResponse> getFrcSchedule(@PathVariable String populationId) {
        LOGGER.info("Get FRC Schedule for populationId: {}", populationId);
        FRCScheduleResponse response = frcService.getFrcSchedule(populationId);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/getBulkFrcSchedule")
    @Operation(summary = "Get Bulk FRC Schedules", description = "Get FRC Schedules for multiple populationIds in a single request")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<List<FRCScheduleResponse>> getBulkFrcSchedule(@RequestBody List<String> populationIds) {
        if (populationIds == null || populationIds.isEmpty()) {
            LOGGER.warn("Get Bulk FRC Schedules called with empty populationIds list");
            return ResponseEntity.badRequest().build();
        }
        LOGGER.info("Get Bulk FRC Schedules for {} populationIds", populationIds.size());
        List<FRCScheduleResponse> responses = frcService.getBulkFrcSchedule(populationIds);
        return ResponseEntity.ok(responses);
    }

    @PostMapping("/saveFrcMemo")
    @Operation(summary = "Save Frc Memo", description = "save frc memo if record exists")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<FRCMemoResponse> saveFrcMemo(@RequestBody FRCMemoRequest request) {
        LOGGER.info("Start of savefrcMemo : {}", request);
        FRCMemoResponse response = frcService.saveFrcMemo(request);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/getFrcMemo/{issueNumber}/{implId}/{populationId}")
    @Operation(summary = "Get FRC Memo", description = "Get FRC Memo by issueNumber, implId and populationId")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<FRCMemoResponse> getFrcMemo(
            @PathVariable String issueNumber,
            @PathVariable String implId,
            @PathVariable String populationId) {
        LOGGER.info("Get FRC Memo for issueNumber: {}, implId: {}, populationId: {}",
                issueNumber, implId, populationId);
        FRCMemoResponse response = frcService.getFrcMemo(issueNumber, implId, populationId);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/saveFrcPac")
    @Operation(summary = "Save frcPac", description = "save frc Pac if record exists")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<FRCPacResponse> saveFrcPac(@RequestBody FRCPacRequest request) {
        LOGGER.info("Start of saveFrcPac : {}", request);
        FRCPacResponse response = frcService.saveFrcPac(request);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/getFrcPac/{issueNumber}/{implId}/{populationId}")
    @Operation(summary = "Get FRC Pac", description = "Get FRC Pac by issueNumber and implId and populationId")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<FRCPacResponse> getFrcPac(
            @PathVariable String issueNumber,
            @PathVariable String implId,
            @PathVariable String populationId) {
        LOGGER.info("Get FRC Pac for issueNumber: {}, implId: {}",
                issueNumber, implId);
        FRCPacResponse response = frcService.getFrcPac(issueNumber, implId, populationId);
        return ResponseEntity.ok(response);
    }
}

