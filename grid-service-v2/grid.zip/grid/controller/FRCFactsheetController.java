package com.ford.grid.controller;


import com.ford.grid.common.SystemWideResponses;
import com.ford.grid.exception.GridException;
import com.ford.grid.mapper.FactsheetAIMapper;
import com.ford.grid.model.dto.request.FrcFactSheetApprovalRequest;
import com.ford.grid.model.dto.request.FrcFactSheetConcludeRequest;
import com.ford.grid.model.dto.request.FrcFactsheetChangePermissionRequest;
import com.ford.grid.model.dto.request.FrcFactsheetDownloadRequest;
import com.ford.grid.model.dto.request.FrcFactsheetRequest;
import com.ford.grid.model.dto.response.FactsheetAIResponse;
import com.ford.grid.model.dto.response.FrcFactSheetResponse;
import com.ford.grid.model.dto.response.FrcFactSheetSummaryResponse;
import com.ford.grid.model.entity.FactSheetCreateResponse;
import com.ford.grid.model.entity.FactsheetAIEntity;
import com.ford.grid.model.entity.PdfBasicDetail;
import com.ford.grid.service.FRCFactSheetService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import java.io.IOException;

@RestController
@RequestMapping("/api/v2/frcFactsheet")
public class FRCFactsheetController {
    private static final Logger LOGGER = LoggerFactory.getLogger(FRCFactsheetController.class);

    @Autowired
    FRCFactSheetService frcFactsheetService;

    @Autowired
    FactsheetAIMapper factsheetAiMapper;

    @PostMapping("/createFrcFactsheet")
    @Operation(summary = "FrcFactsheet", description = "Create Frc Factsheet")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<FrcFactSheetResponse> createFrcFactsheet(@RequestBody FrcFactsheetRequest factsheetReq) throws GridException {
        FrcFactSheetResponse response = frcFactsheetService.createFrcFactsheet(factsheetReq);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("getFrcFactsheet/{issueNumber}/{populationId}")
    @Operation(summary = "FrcFactsheet", description = "Get Frc Factsheet by issue number")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<FrcFactSheetResponse> getFrcFactsheet(@PathVariable String issueNumber, @PathVariable String populationId) throws GridException {
        return ResponseEntity.ok(frcFactsheetService.getFrcFactsheet(issueNumber, populationId));

    }

    @PostMapping("/downloadFile")
    @Operation(summary = "Download Frc Factsheet", description = "Download Frc Factsheet by issueNumber, implId, populationId, and fileName")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<StreamingResponseBody> downloadFile(
            @Valid @RequestBody FrcFactsheetDownloadRequest request) throws IOException, GridException {

        LOGGER.info("Download file request - issueNumber: {}, implId: {}, popId: {}, fileName: {}",
                request.getIssueNumber(), request.getImplId(), request.getPopulationId(), request.getFileName());

        return frcFactsheetService.downloadFile(request);
    }

    @PostMapping("/getFactsheetAIResponse")
    @Operation(summary = "Get FrcFactsheet AI Response ", description = "Get FrcFactsheet AI Response ")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<FactsheetAIResponse> getFactsheetAIResponse(
            @RequestBody @Valid PdfBasicDetail pdfRequest,
            HttpServletRequest request) throws GridException {

        if (pdfRequest == null || pdfRequest.getIssueNumber() == null) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }

        FactsheetAIResponse response = frcFactsheetService.getFactsheetAIResponse(pdfRequest, request);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }



    @PostMapping("/updateFactsheetAIResponse")
    @Operation(summary = "Update FrcFactsheet AI Response", description = "Update FrcFactsheet AI Response in database")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<Void> updateFactsheetAIResponse(
            @RequestBody @Valid FactsheetAIResponse factsheetAIResponseDto) {

        if (factsheetAIResponseDto == null) {
            LOGGER.error("Invalid request - factsheetAIResponse is null");
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }

        if (factsheetAIResponseDto.getPopulationId() == null || factsheetAIResponseDto.getPopulationId().isEmpty()) {
            LOGGER.error("Invalid request - populationId is required");
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }

        LOGGER.info("Updating AI response for populationId: {}, issueNumber: {}",
                factsheetAIResponseDto.getPopulationId(), factsheetAIResponseDto.getIssueNumber());


        FactsheetAIEntity entityResponse =
                factsheetAiMapper.toEntity(factsheetAIResponseDto);

        frcFactsheetService.updateFactsheetAIResponse(entityResponse);

        return new ResponseEntity<>(HttpStatus.OK);
    }

    @PostMapping("/addPermissions")
    @Operation(summary = "FrcFactsheet add permission ", description = "FrcFactsheet add permission")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<FactSheetCreateResponse> addPermissions(@Valid @RequestBody FrcFactsheetChangePermissionRequest request) {
       // LOGGER.info("Add permissions request for fileName: {}, cdsId: {}, type: {}, populationId: {}", fileName, cdsId, type, populationId);
        FactSheetCreateResponse response = null;
        for (String cdsId : request.getCdsId()) {
            response = frcFactsheetService.addPermission(request.getFileName(), cdsId, request.getAddType(),false, request.getPopulationId());
        }
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/breakInheritance")
    @Operation(summary = "FrcFactsheet breakInheritance", description = "FrcFactsheet breakInheritance")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<FactSheetCreateResponse> breakInheritance(@RequestParam String fileName) {
        LOGGER.info("Break inheritance request for fileName: {}", fileName);
        FactSheetCreateResponse response = frcFactsheetService.breakInheritance(fileName);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/removePermissions")
    @Operation(summary = "FrcFactsheet remove permission", description = "FrcFactsheet remove permission")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<FactSheetCreateResponse> removePermissions(@RequestParam String fileName, @RequestParam String cdsId, @RequestParam String type, @RequestParam String populationId) {
        LOGGER.info("Remove permissions request for fileName: {}, cdsId: {}, type: {}, populationId: {}", fileName, cdsId, type, populationId);
        FactSheetCreateResponse response = frcFactsheetService.removePermission(fileName, cdsId, type, false, populationId);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PostMapping("/changePermissions")
    @Operation(summary = "FrcFactsheet change permission", description = "FrcFactsheet change permission")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<FactSheetCreateResponse> changePermissions(@Valid @RequestBody FrcFactsheetChangePermissionRequest request) {
        LOGGER.info("Change permissions request for fileName: {}, cdsId: {}, removeType: {}, addType: {}, populationId: {}",
                request.getFileName(), request.getCdsId(), request.getRemoveType(), request.getAddType(), request.getPopulationId());
        FactSheetCreateResponse response = null;
        for (String cdsId : request.getCdsId()) {
            response = frcFactsheetService.changePermission(request.getFileName(), cdsId, request.getRemoveType(), request.getAddType(), request.getPopulationId());
        }
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PostMapping("/amendment")
    @Operation(summary = "FrcFactsheet Version Changes", description = "FrcFactsheet Version Changes")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<FactSheetCreateResponse> factsheetAmendment(@RequestParam String fileName, @RequestParam String idx) {
        LOGGER.info("Factsheet amendment request for fileName: {}, idx: {}", fileName, idx);
        return new ResponseEntity<>(frcFactsheetService.copyLatestFrcFactsheet(fileName, idx), HttpStatus.OK);
    }

    @PutMapping("/frcFactSheetApproval")
    @Operation(summary = "Approve FrcFactsheet", description = "Approve Frc Factsheet with approvers")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<FrcFactSheetResponse> frcFactSheetApproval(
            @RequestBody FrcFactSheetApprovalRequest request) throws GridException {
        FrcFactSheetResponse response = frcFactsheetService.frcFactSheetApproval(request);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/getFrcFactSheetSummary/{issueNumber}/{implId}/{populationId}")
    @Operation(summary = "Get Frc FactSheet Summary API", description = "Fetches Frc FactSheet Summary by issue number, impl id and population id")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<FrcFactSheetSummaryResponse> getFrcFactSheetSummary(
            @PathVariable String issueNumber, @PathVariable String implId, @PathVariable String populationId) throws GridException {
        LOGGER.info("Fetching FRC FactSheet Summary for issue: {}, implId: {}, populationId: {}", issueNumber, implId, populationId);
        FrcFactSheetSummaryResponse response = frcFactsheetService.getFrcFactSheetSummary(issueNumber, implId, populationId);
        return ResponseEntity.ok(response);
    }


    @PostMapping("/fetchLatestVersion")
    @Operation(summary = "Fetch and Update Latest Version",
            description = "Fetches the latest version of an existing factsheet, updates it with new data, and creates an amendment version on SharePoint")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<FactSheetCreateResponse> fetchLatestVersion(
            @Valid @RequestBody FrcFactsheetRequest request) throws IOException, GridException {
        LOGGER.info("Received fetchLatestVersion request for populationId: {}", request.getPopulationId());
        FactSheetCreateResponse response = frcFactsheetService.updateFactSheetVernCount(request);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PostMapping("/conclude")
    @Operation(summary = "Conclude FRC Fact Sheet",
            description = "Conclude FRC Fact Sheet file for a specific population and file version. Validates that approval is not required before concluding.")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<String> concludeFrcFactSheet(
            @Valid @RequestBody FrcFactSheetConcludeRequest request) throws GridException {
        LOGGER.info("Conclude FRC Fact Sheet request for populationId: {}, fileVersion: {}",
                request.getPopulationId(), request.getFileVersion());
        String response = frcFactsheetService.concludeFrcFactSheet(request);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}

