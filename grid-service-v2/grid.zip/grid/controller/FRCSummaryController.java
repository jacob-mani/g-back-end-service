package com.ford.grid.controller;

import com.ford.grid.common.SystemWideResponses;
import com.ford.grid.exception.GridException;
import com.ford.grid.model.dto.request.FRCSummaryRequest;
import com.ford.grid.model.dto.response.PagedResponse;
import com.ford.grid.model.entity.FRCSummaryResponse;
import com.ford.grid.service.FRCSummaryService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.util.List;

/**
 * REST Controller for FRC Summary operations.
 * <p>
 * The response is <b>always</b> a {@link PagedResponse}{@code <FRCSummaryResponse>} so the
 * OpenAPI schema and client contract are consistent regardless of whether pagination params
 * are supplied.
 * </p>
 * <ul>
 *   <li>With {@code page} + {@code size} — only the requested page is fetched from MongoDB
 *       (skip/limit at query level).</li>
 *   <li>Without {@code page} + {@code size} — all matching records are returned wrapped in a
 *       single-page {@link PagedResponse} ({@code page=0, size=totalElements, totalPages=1}).</li>
 *   <li>Supplying only one of {@code page} / {@code size} returns {@code 400 Bad Request}.</li>
 * </ul>
 */
@RestController
@RequestMapping("/api/v2/frc")
@RequiredArgsConstructor
public class FRCSummaryController {

    private static final Logger LOGGER = LoggerFactory.getLogger(FRCSummaryController.class);

    private final FRCSummaryService frcSummaryService;

    /**
     * Retrieves FRC Summary report data based on dynamic filter criteria.
     * <p>
     * At least one of {@code frcDate}, {@code fromDate+toDate}, {@code leadRegion},
     * or {@code affectedRegion} must be provided — an empty filter set returns {@code 400}.
     * </p>
     * <p>
     * <b>Pagination:</b> Supply <em>both</em> {@code page} and {@code size} together for a
     * DB-level paginated fetch. Omit <em>both</em> to receive all matching records wrapped in a
     * single-page response. Supplying only one of the two returns {@code 400 Bad Request}.
     * </p>
     *
     * @param request filter criteria encapsulated in {@link FRCSummaryRequest}
     * @param page    0-based page number (optional — omit for all results)
     * @param size    records per page, clamped 1–100 (optional — omit for all results)
     * @return {@link PagedResponse} of {@link FRCSummaryResponse} — always the same shape
     */
    @GetMapping("/summary")
    @Operation(summary = "Get FRC summary",
            description = "Returns FRC Summary records always wrapped in a PagedResponse. " +
                    "Supply page + size for DB-level paginated fetch; " +
                    "omit both to receive all results in a single page.")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<PagedResponse<FRCSummaryResponse>> getFRCSummaryReport(
            @ModelAttribute FRCSummaryRequest request,
            @Parameter(description = "0-based page number. Omit for all results.", example = "0")
            @RequestParam(required = false) Integer page,
            @Parameter(description = "Records per page (1–100). Omit for all results.", example = "20")
            @RequestParam(required = false) Integer size) {

        // Trim all incoming string params — empty strings ("") from query params become null-safe blanks
        String leadRegion     = request.getLeadRegion()     != null ? request.getLeadRegion().trim()     : null;
        String affectedRegion = request.getAffectedRegion() != null ? request.getAffectedRegion().trim() : null;
        String memoFilterFlag = request.getMemoFilterFlag() != null ? request.getMemoFilterFlag().trim() : null;
        String programType    = request.getProgramType()    != null ? request.getProgramType().trim()    : null;

        LOGGER.info("getFRCSummaryReport — frcDate={}, fromDate={}, toDate={}, " +
                        "leadRegion={}, affectedRegion={}, memoFilterFlag={}, programType={}, page={}, size={}",
                request.getFrcDate(), request.getFromDate(), request.getToDate(),
                leadRegion, affectedRegion, memoFilterFlag, programType, page, size);

        // Guard — page and size must be supplied together or both omitted
        if ((page == null) != (size == null)) {
            LOGGER.warn("Bad request — 'page' and 'size' must be supplied together; " +
                    "received page={}, size={}", page, size);
            return ResponseEntity.badRequest().build();
        }

        try {
            // Parse and validate date strings — throws GridException(BAD_REQUEST) on bad format
            LocalDate frcDate     = parseDateSafely(request.getFrcDate());
            LocalDate fromDate    = parseDateSafely(request.getFromDate());
            LocalDate toDate      = parseDateSafely(request.getToDate());

            // Guard — at least one mandatory filter must be present
            boolean hasFrcDate        = frcDate != null;
            boolean hasDateRange      = fromDate != null && toDate != null;
            boolean hasLeadRegion     = leadRegion != null && !leadRegion.isBlank();
            boolean hasAffectedRegion = affectedRegion != null && !affectedRegion.isBlank();
            boolean hasProgramType    = programType != null && !programType.isBlank();

            if (!hasFrcDate && !hasDateRange && !hasLeadRegion && !hasAffectedRegion && !hasProgramType) {
                LOGGER.warn("Request rejected — at least one of frcDate, fromDate+toDate, " +
                        "leadRegion, affectedRegion, or programType must be provided");
                return ResponseEntity.badRequest().build();
            }

            final PagedResponse<FRCSummaryResponse> result;

            if (page != null) {
                // DB-level pagination — skip/limit applied in MongoDB query
                result = frcSummaryService.getFrcSummaryPage(
                        frcDate, fromDate, toDate, leadRegion, affectedRegion, memoFilterFlag, programType,
                        page, size);
            } else {
                // Unpaged — fetch all, wrap in a single-page PagedResponse
                List<FRCSummaryResponse> all = frcSummaryService.getFrcSummaryList(
                        frcDate, fromDate, toDate, leadRegion, affectedRegion, memoFilterFlag, programType);
                int total = all == null ? 0 : all.size();
                result = PagedResponse.<FRCSummaryResponse>builder()
                        .content(all == null ? List.of() : all)
                        .totalElements(total)
                        .totalPages(total == 0 ? 0 : 1)
                        .currentPage(0)
                        .pageSize(total)
                        .hasNext(false)
                        .hasPrevious(false)
                        .build();
            }

            if (result.getTotalElements() == 0) {
                LOGGER.info("No FRC summary records found for the given filters — " +
                        "leadRegion={}, memoFilterFlag={}, page={}, size={}", leadRegion, memoFilterFlag, page, size);
            } else {
                LOGGER.info("Returning page {}/{} — {} record(s) on page, {} total",
                        result.getCurrentPage(), result.getTotalPages() - 1,
                        result.getContent().size(), result.getTotalElements());
            }
            return ResponseEntity.ok(result);

        } catch (GridException e) {
            LOGGER.warn("Bad request — {}", e.getMessage());
            return ResponseEntity.status(e.getStatus() != null ? e.getStatus() : HttpStatus.BAD_REQUEST).build();
        } catch (Exception e) {
            LOGGER.error("Unexpected error while fetching FRC summary report", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * Parses a date string in {@code yyyy-MM-dd} format into a {@link LocalDate}.
     * Returns {@code null} for null or blank input (treated as "no filter").
     * Throws {@link GridException} ({@code 400 BAD_REQUEST}) for a non-blank but unparseable value
     * so the controller returns {@code 400 Bad Request} instead of silently dropping the filter.
     *
     * @param dateStr the date string to parse
     * @return parsed {@link LocalDate}, or {@code null} if input is null/blank
     * @throws GridException if input is non-blank but cannot be parsed as {@code yyyy-MM-dd}
     */
    private LocalDate parseDateSafely(String dateStr) throws GridException {
        if (dateStr == null || dateStr.isBlank()) {
            return null;
        }
        try {
            return LocalDate.parse(dateStr.trim());
        } catch (Exception e) {
            throw new GridException(HttpStatus.BAD_REQUEST,
                    "Invalid date format",
                    "Invalid date format '" + dateStr.trim() + "' — expected yyyy-MM-dd",
                    e);
        }
    }
}
