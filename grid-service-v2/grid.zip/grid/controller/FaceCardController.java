package com.ford.grid.controller;

import com.ford.cloudnative.base.api.StandardErrorResponse;
import com.ford.grid.model.dto.response.facecard.FaceCardResponse;
import com.ford.grid.service.FaceCardService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@AllArgsConstructor
@Validated
@RequestMapping("/api/v2/face-card")
public class FaceCardController {

    private static final Logger LOGGER = LoggerFactory.getLogger(FaceCardController.class);

    private final FaceCardService faceCardService;

    @GetMapping("/{issueNumber}/{populationId}")
    @Operation(summary = "Get Face Card Details", description = "Get face card phase details for a given issue number and population id")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Request is Success"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(mediaType = "application/json", schema = @Schema(implementation = StandardErrorResponse.class))),
            @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content(mediaType = "application/json", schema = @Schema(type = "object", additionalProperties = Schema.AdditionalPropertiesValue.TRUE, example = "{\"Error\": \"Required Authorization header is missing\"}"))),
            @ApiResponse(responseCode = "403", description = "Forbidden", content = @Content(mediaType = "application/json", schema = @Schema(implementation = StandardErrorResponse.class))),
            @ApiResponse(responseCode = "404", description = "Resource Not Found", content = @Content(mediaType = "application/json", schema = @Schema(implementation = StandardErrorResponse.class))),
            @ApiResponse(responseCode = "405", description = "Method Not Found", content = @Content(mediaType = "application/json", schema = @Schema(implementation = StandardErrorResponse.class))),
            @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = StandardErrorResponse.class)))
    })
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MyIssuesList','read')")
    public ResponseEntity<FaceCardResponse> getFaceCardDetails(
            @Parameter(description = "Issue number identifier", required = true, schema = @Schema(maxLength = 50, pattern = "^[a-zA-Z0-9\\-]+$", example = "25-100"))
            @PathVariable @NotBlank @Size(max = 50) @Pattern(regexp = "^[a-zA-Z0-9\\-]+$") String issueNumber,
            @Parameter(description = "Population identifier", required = true, schema = @Schema(maxLength = 50, pattern = "^[a-zA-Z0-9\\-]+$", example = "25-100"))
            @PathVariable @NotBlank @Size(max = 50) @Pattern(regexp = "^[a-zA-Z0-9\\-]+$") String populationId) {
        LOGGER.info("Getting face card details for issueNumber: {}, populationId: {}", issueNumber, populationId);
        FaceCardResponse response = faceCardService.getFaceCardDetails(issueNumber, populationId);
        return ResponseEntity.ok(response);
    }
}

