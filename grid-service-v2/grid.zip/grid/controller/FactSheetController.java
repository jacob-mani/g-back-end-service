package com.ford.grid.controller;

import com.ford.grid.common.SystemWideResponses;
import com.ford.grid.exception.GridException;
import com.ford.grid.model.dto.request.EPRCFactSheetRequest;
import com.ford.grid.model.dto.response.EPRCFactSheetResponse;
import com.ford.grid.service.FactSheetService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@AllArgsConstructor
@RequestMapping("/api/v2/report")
public class FactSheetController {
    private static final Logger LOGGER = LoggerFactory.getLogger(FactSheetController.class);

    private final FactSheetService factSheetService;

    @PostMapping("/eprcFactSheetReport")
    @Operation(summary = "save EPRC FactSheet Report", description = "save EPRC FactSheet  SAVE API")
    @SystemWideResponses
    public ResponseEntity<EPRCFactSheetResponse> saveEprcFactSheet(@Valid @RequestBody EPRCFactSheetRequest eprcFactSheetRequest) throws GridException {
        LOGGER.info("Start of eprc Fact Sheet Report : {}", eprcFactSheetRequest);
        EPRCFactSheetResponse response = factSheetService.saveFactSheetReport(eprcFactSheetRequest);
        LOGGER.info("End of eprc Fact Sheet Report : {}", response);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/getEprcFactSheetReport/{issueNumber}")
    @Operation(summary = "Get EPRC FACT Sheet Report", description = "Fetch EPRC FactSheet Report by Issue Number")
    @SystemWideResponses
    public ResponseEntity<EPRCFactSheetResponse> getEPRCFactSheetByIssueNumber(@PathVariable String issueNumber) {
        LOGGER.info("Fetching EPRC FACT Sheet Report for issueNumber: {}", issueNumber);
        EPRCFactSheetResponse response = factSheetService.getEPRCFactSheetReportByIssueNumber(issueNumber);
        return ResponseEntity.ok(response);
    }


    @PutMapping("/updateEprcFactSheet")
    @Operation(summary = "Update EPRC FACT Sheet Report with approval mail", description = "Approval of EPRC Factsheet")
    @SystemWideResponses
    public ResponseEntity<EPRCFactSheetResponse> updateEprcFactSheet(@RequestBody EPRCFactSheetRequest eprcFactSheet) throws GridException {
        return new ResponseEntity<>(factSheetService.updateEprcFactSheet(eprcFactSheet),
                HttpStatus.OK);
    }



}

