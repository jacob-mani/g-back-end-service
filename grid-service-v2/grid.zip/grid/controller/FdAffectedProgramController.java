package com.ford.grid.controller;

import com.ford.grid.model.dto.request.FdAffectedProgramDto;
import com.ford.grid.service.FdAffectedProgramService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v2/fd/affectedProgram")
public class FdAffectedProgramController {
    @Autowired
    private FdAffectedProgramService fdService;

    @PostMapping(value = "/save")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist14DRCO','update')")
    public ResponseEntity<FdAffectedProgramDto> save(@RequestBody FdAffectedProgramDto request) {
        return new ResponseEntity<>(fdService.savefdAffectedProgram(request), HttpStatus.CREATED);
    }

    @GetMapping(value = "/getData/{issueNumber}")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MyIssuesList','read')")
    public ResponseEntity<FdAffectedProgramDto> getByIssueNumber(@PathVariable String issueNumber) {
        return new ResponseEntity<>(fdService.findByIssueNumber(issueNumber), HttpStatus.OK);
    }
}
