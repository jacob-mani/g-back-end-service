package com.ford.grid.controller;

import com.ford.grid.exception.GridException;
import com.ford.grid.model.dto.request.FdCorrectivePartDto;
import com.ford.grid.service.FdCorrectivePartService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v2/fd/correctivePart")
public class FdCorrectivePartController {
    @Autowired
    private FdCorrectivePartService fdService;

    @PostMapping(value = "/save")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist14DRCO','update')")
    public ResponseEntity<FdCorrectivePartDto> save(@Valid @RequestBody FdCorrectivePartDto request) throws GridException {
        return new ResponseEntity<>(fdService.saveFdCorrectivePart(request), HttpStatus.CREATED);
    }

    @GetMapping(value = "/getData/{issueNumber}")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MyIssuesList','read')")
    public ResponseEntity<FdCorrectivePartDto> getByIssueNumber(@PathVariable String issueNumber) {
        return new ResponseEntity<>(fdService.findByIssueNumber(issueNumber), HttpStatus.OK);
    }
}
