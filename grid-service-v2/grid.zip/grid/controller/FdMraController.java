package com.ford.grid.controller;

import com.ford.grid.model.dto.request.FdMraDto;
import com.ford.grid.service.FdMraService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v2/fd/mra")
public class FdMraController {
    @Autowired
    private FdMraService fdMraService;

    @PostMapping(value = "/save")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist14DRCO','update')")
    public ResponseEntity<FdMraDto> save(@Valid @RequestBody FdMraDto request) {
        return new ResponseEntity<>(fdMraService.saveFdMra(request), HttpStatus.CREATED);
    }

    @GetMapping(value = "/getData/{issueNumber}/{implId}")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MyIssuesList','read')")
    public ResponseEntity<FdMraDto> getByIssueNumberAndImplId(@PathVariable String issueNumber, @PathVariable String implId) {
        return new ResponseEntity<>(fdMraService.findByIssueNumberAndImplId(issueNumber, implId), HttpStatus.OK);
    }
}
