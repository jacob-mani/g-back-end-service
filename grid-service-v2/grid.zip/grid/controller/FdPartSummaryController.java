package com.ford.grid.controller;

import com.ford.grid.model.dto.request.FdPartSummaryDto;
import com.ford.grid.service.FdPartSummaryService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v2/fd/partSummary")
public class FdPartSummaryController {
    @Autowired
    private FdPartSummaryService fdPartSummaryService;

    @PostMapping(value = "/save")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist14DRCO','update')")
    public ResponseEntity<FdPartSummaryDto> save(@Valid @RequestBody FdPartSummaryDto request) {
        return new ResponseEntity<>(fdPartSummaryService.saveFdPartSummary(request), HttpStatus.CREATED);
    }

    @GetMapping(value = "/getData/{issueNumber}")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MyIssuesList','read')")
    public ResponseEntity<FdPartSummaryDto> getByIssueNumber(@PathVariable String issueNumber) {
        return new ResponseEntity<>(fdPartSummaryService.findByIssueNumber(issueNumber), HttpStatus.OK);
    }
}
