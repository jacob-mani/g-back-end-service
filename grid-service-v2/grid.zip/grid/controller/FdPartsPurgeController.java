package com.ford.grid.controller;

import com.ford.grid.exception.GridException;
import com.ford.grid.model.dto.request.FdPartsPurgeDto;
import com.ford.grid.service.FdPartsPurgeService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v2/fd/partsPurge")
public class FdPartsPurgeController {
    @Autowired
    private FdPartsPurgeService fdService;

    @PostMapping(value = "/save")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist14DRCO','update')")
    public ResponseEntity<FdPartsPurgeDto> save(@Valid @RequestBody FdPartsPurgeDto request) throws GridException {
        return new ResponseEntity<>(fdService.saveFdPartsPurge(request), HttpStatus.CREATED);
    }

    @GetMapping(value = "/getData/{issueNumber}")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MyIssuesList','read')")
    public ResponseEntity<FdPartsPurgeDto> getByIssueNumber(@PathVariable String issueNumber) {
        return new ResponseEntity<>(fdService.findByIssueNumber(issueNumber), HttpStatus.OK);
    }

}
