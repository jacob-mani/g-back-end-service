package com.ford.grid.controller;

import com.ford.grid.model.dto.request.FdQuestionnaire10Request;
import com.ford.grid.model.dto.response.FdQuestionnaire10Response;
import com.ford.grid.service.FdQuestionnaire10Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v2/fd/10")
public class FdQuestionnaire10Controller {

    @Autowired
    private FdQuestionnaire10Service fdService;


    @PostMapping(value = "/save")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist14DRCO','update') or @gridAuthorizeService.isAuthorized('GRID:Administration','update')")
    public ResponseEntity<FdQuestionnaire10Request> save(@RequestBody FdQuestionnaire10Request request) {
        return new ResponseEntity<>(fdService.saveFdQ10(request), HttpStatus.CREATED);
    }

    @GetMapping(value = "/getData/{issueNumber}/{implId}")
    public ResponseEntity<FdQuestionnaire10Response> getByIssueNumber(@PathVariable String issueNumber
            , @PathVariable String implId) {
        return new ResponseEntity<>(fdService.findByKeys(issueNumber, implId), HttpStatus.OK);
    }

    @PostMapping(value = "/updateStatus")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist14DRCO','update') or @gridAuthorizeService.isAuthorized('GRID:Administration','update')")
    public ResponseEntity<FdQuestionnaire10Request> updateStatus(@RequestBody FdQuestionnaire10Request request) {
        return new ResponseEntity<>(fdService.updateStatus(request), HttpStatus.OK);
    }
}
