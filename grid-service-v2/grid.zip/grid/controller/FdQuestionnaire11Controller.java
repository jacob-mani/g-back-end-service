package com.ford.grid.controller;

import com.ford.grid.model.dto.request.FdQuestionnaire11Dto;
import com.ford.grid.service.FdQuestionnaire11Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v2/fd/11")
public class FdQuestionnaire11Controller {
    @Autowired
    private FdQuestionnaire11Service fdQuestionnaire11Service;

    @PostMapping(value = "/save")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist14DRCO','update') or @gridAuthorizeService.isAuthorized('GRID:Administration','update')")
    public ResponseEntity<FdQuestionnaire11Dto> save(@RequestBody FdQuestionnaire11Dto request) {
        FdQuestionnaire11Dto savedDto = fdQuestionnaire11Service.saveFdQ11(request);
        return new ResponseEntity<>(savedDto, HttpStatus.CREATED);
    }

    @GetMapping(value = "/getData/{issueNumber}")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MyIssuesList','read')")
    public ResponseEntity<FdQuestionnaire11Dto> getByIssueNumber(@PathVariable String issueNumber) {
        FdQuestionnaire11Dto fdQ11Dto = fdQuestionnaire11Service.findByIssueNumber(issueNumber);
        return new ResponseEntity<>(fdQ11Dto, HttpStatus.OK);
    }

    @PostMapping(value = "/updateStatus")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist14DRCO','update') or @gridAuthorizeService.isAuthorized('GRID:Administration','update')")
    public ResponseEntity<FdQuestionnaire11Dto> updateStatus(@RequestBody FdQuestionnaire11Dto request) {
        FdQuestionnaire11Dto fdQ11Dto = fdQuestionnaire11Service.updateStatus(request);
        return new ResponseEntity<>(fdQ11Dto, HttpStatus.OK);
    }
}
