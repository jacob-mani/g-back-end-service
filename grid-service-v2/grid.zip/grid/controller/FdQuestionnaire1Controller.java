package com.ford.grid.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ford.grid.model.dto.request.FdQuestionnaire1Dto;
import com.ford.grid.service.FdQuestionnaire1Service;

@RestController
@RequestMapping("/api/v2/fd/1")
public class FdQuestionnaire1Controller {
    private static final Logger LOGGER = LoggerFactory.getLogger(FdQuestionnaire1Controller.class);
    @Autowired
    private FdQuestionnaire1Service fdService;

    @PostMapping(value = "/save")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist14DRCO','update') or @gridAuthorizeService.isAuthorized('GRID:Administration','update')")
    public ResponseEntity<FdQuestionnaire1Dto> save(@RequestBody FdQuestionnaire1Dto request) {
        // LOGGER.info(request.toString());
        // LOGGER.info(concernDiscoveredDocs.size() + " files received.");
        FdQuestionnaire1Dto savedDto = fdService.saveFdQ1(request);
        return new ResponseEntity<>(savedDto, HttpStatus.CREATED);
    }

    @GetMapping(value = "/getData/{issueNumber}")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MyIssuesList','read')")
    public ResponseEntity<FdQuestionnaire1Dto> getByIssueNumber(@PathVariable String issueNumber) {
        FdQuestionnaire1Dto fdQ1Dto = fdService.findByIssueNumber(issueNumber);
        return new ResponseEntity<>(fdQ1Dto, HttpStatus.OK);
    }

    @PostMapping(value = "/updateStatus")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist14DRCO','update') or @gridAuthorizeService.isAuthorized('GRID:Administration','update')")
    public ResponseEntity<FdQuestionnaire1Dto> updateStatus(@RequestBody FdQuestionnaire1Dto request) {
        FdQuestionnaire1Dto fdQ1Dto = fdService.updateStatus(request);
        return new ResponseEntity<>(fdQ1Dto, HttpStatus.OK);
    }
}
