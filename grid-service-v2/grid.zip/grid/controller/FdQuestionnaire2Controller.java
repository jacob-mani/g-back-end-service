package com.ford.grid.controller;

import com.ford.grid.model.dto.request.FdQuestionnaire2Dto;
import com.ford.grid.service.FdQuestionnaire2Service;
import lombok.AllArgsConstructor;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v2/fd/2")
@AllArgsConstructor
public class FdQuestionnaire2Controller {

    private final FdQuestionnaire2Service fdQ2Service;

    @GetMapping(value = "/getData/{issueNumber}")
    public ResponseEntity<FdQuestionnaire2Dto> getByIssueNumber(@PathVariable String issueNumber) {
        FdQuestionnaire2Dto fdQ2Request = fdQ2Service.findByIssueNumber(issueNumber);
        return new ResponseEntity<>(fdQ2Request, HttpStatus.OK);
    }

    @PostMapping(value = "/save")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist14DRCO','update') or @gridAuthorizeService.isAuthorized('GRID:Administration','update')")
    public ResponseEntity<FdQuestionnaire2Dto> saveFdQuestionnaire2(@RequestBody FdQuestionnaire2Dto request) {
        return new ResponseEntity<>(fdQ2Service.saveFdQuestionnaire2(request), HttpStatus.CREATED);
    }

    @PostMapping(value = "/updateStatus")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist14DRCO','update') or @gridAuthorizeService.isAuthorized('GRID:Administration','update')")
    public ResponseEntity<FdQuestionnaire2Dto> updateStatus(@RequestBody FdQuestionnaire2Dto request) {
        FdQuestionnaire2Dto fdQ2Dto = fdQ2Service.updateStatus(request);
        return new ResponseEntity<>(fdQ2Dto, HttpStatus.OK);
    }
}
