package com.ford.grid.controller;

import com.ford.grid.model.dto.request.FdQuestionnaire3Dto;
import com.ford.grid.service.FdQuestionnaire3Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/api/v2/fd/3")
public class FdQuestionnaire3Controller {
  private static final Logger LOGGER = LoggerFactory.getLogger(FdQuestionnaire3Controller.class);
  @Autowired
  private FdQuestionnaire3Service fdService;

  @PostMapping(value = "/save")
  @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist14DRCO','update') or @gridAuthorizeService.isAuthorized('GRID:Administration','update')")
  public ResponseEntity<FdQuestionnaire3Dto> save(@RequestBody FdQuestionnaire3Dto request) {
    FdQuestionnaire3Dto savedDto = fdService.saveFdQuestionnaire3(request);
    return new ResponseEntity<>(savedDto, HttpStatus.CREATED);
  }

  @GetMapping(value = "/getData/{issueNumber}")
  @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MyIssuesList','read')")
  public ResponseEntity<FdQuestionnaire3Dto> getByIssueNumber(@PathVariable String issueNumber) {
    FdQuestionnaire3Dto fdQ3Dto = fdService.findByIssueNumber(issueNumber);
    return new ResponseEntity<>(fdQ3Dto, HttpStatus.OK);
  }

  @PostMapping(value = "/updateStatus")
  @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist14DRCO','update') or @gridAuthorizeService.isAuthorized('GRID:Administration','update')")
  public ResponseEntity<FdQuestionnaire3Dto> updateStatus(@RequestBody FdQuestionnaire3Dto request) {
    FdQuestionnaire3Dto fdQ3Dto = fdService.updateStatus(request);
    return new ResponseEntity<>(fdQ3Dto, HttpStatus.OK);
  }
}
