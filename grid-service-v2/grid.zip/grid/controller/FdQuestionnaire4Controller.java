package com.ford.grid.controller;

import com.ford.grid.model.dto.request.FdQuestionnaire4Dto;
import com.ford.grid.service.FdQuestionnaire4Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v2/fd/4")
public class FdQuestionnaire4Controller {
    @Autowired
    private FdQuestionnaire4Service fdService;

    @PostMapping(value = "/save")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist14DRCO','update') or @gridAuthorizeService.isAuthorized('GRID:Administration','update')")
    public ResponseEntity<FdQuestionnaire4Dto> save(@RequestBody FdQuestionnaire4Dto request) {
        return new ResponseEntity<>(fdService.saveFdQ4(request), HttpStatus.CREATED);
    }

    @GetMapping(value = "/getData/{issueNumber}")
    public ResponseEntity<FdQuestionnaire4Dto> getByIssueNumber(@PathVariable String issueNumber) {
        return new ResponseEntity<>(fdService.findByIssueNumber(issueNumber), HttpStatus.OK);
    }

    @PostMapping(value = "/updateStatus")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist14DRCO','update') or @gridAuthorizeService.isAuthorized('GRID:Administration','update')")
    public ResponseEntity<FdQuestionnaire4Dto> updateStatus(@RequestBody FdQuestionnaire4Dto request) {
        return new ResponseEntity<>(fdService.updateStatus(request), HttpStatus.OK);
    }
}
