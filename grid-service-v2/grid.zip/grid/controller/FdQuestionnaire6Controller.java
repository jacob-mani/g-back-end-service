package com.ford.grid.controller;

import com.ford.grid.model.dto.request.FdQuestionnaire6Request;
import com.ford.grid.model.dto.response.FDQuestionnaire6PopulationDetail;
import com.ford.grid.model.dto.response.FdQuestionnaire6Response;
import com.ford.grid.service.FdQuestionnaire6Service;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Controller for handling FD Questionnaire 6 related operations.
 * Provides REST endpoints for saving, retrieving, and updating FD Questionnaire 6 data.
 */
@RestController
@RequestMapping("/api/v2/fd/6")
@RequiredArgsConstructor
public class FdQuestionnaire6Controller {

    private static final Logger logger = LoggerFactory.getLogger(FdQuestionnaire6Controller.class);

    private final FdQuestionnaire6Service fdService;

    /**
     * Saves FD Questionnaire 6 data.
     *
     * @param request the FdQuestionnaire6Request containing the questionnaire data to be saved
     * @return ResponseEntity containing the saved FdQuestionnaire6Request with HTTP status 201 (CREATED)
     */
    @PostMapping(value = "/save")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist14DRCO','update') or @gridAuthorizeService.isAuthorized('GRID:Administration','update')")
    public ResponseEntity<FdQuestionnaire6Request> save(@RequestBody FdQuestionnaire6Request request) {
        logger.info("Received request to save FD Questionnaire 6 data");
        FdQuestionnaire6Request savedRequest = fdService.saveFdQ6(request);
        logger.info("Successfully saved FD Questionnaire 6 data");
        return new ResponseEntity<>(savedRequest, HttpStatus.CREATED);
    }

    /**
     * Retrieves FD Questionnaire 6 data by issue number.
     *
     * @param issueNumber the issue number to search for
     * @return ResponseEntity containing the FdQuestionnaire6Response with HTTP status 200 (OK)
     */
    @GetMapping(value = "/getData/{issueNumber}")
    public ResponseEntity<FdQuestionnaire6Response> getByIssueNumber(@PathVariable String issueNumber) {
        logger.info("Received request to retrieve FD Questionnaire 6 data for issue number: {}", issueNumber);
        FdQuestionnaire6Response response = fdService.findByIssueNumber(issueNumber);
        logger.info("Successfully retrieved FD Questionnaire 6 data for issue number: {}", issueNumber);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    /**
     * Updates the status of FD Questionnaire 6.
     *
     * @param request the FdQuestionnaire6Request containing the updated status information
     * @return ResponseEntity containing the updated FdQuestionnaire6Request with HTTP status 200 (OK)
     */
    @PostMapping(value = "/updateStatus")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist14DRCO','update') or @gridAuthorizeService.isAuthorized('GRID:Administration','update')")
    public ResponseEntity<FdQuestionnaire6Request> updateStatus(@RequestBody FdQuestionnaire6Request request) {
        logger.info("Received request to update status for FD Questionnaire 6");
        FdQuestionnaire6Request updatedRequest = fdService.updateStatus(request);
        logger.info("Successfully updated status for FD Questionnaire 6");
        return new ResponseEntity<>(updatedRequest, HttpStatus.OK);
    }

    /**
     * Retrieves Card 6 population details for a specific issue number.
     *
     * @param issueNumber the issue number to retrieve Card 6 details for
     * @return ResponseEntity containing a list of FDQuestionnaire6PopulationDetail with HTTP status 200 (OK)
     */
    @GetMapping(value = "/card6/{issueNumber}")
    public ResponseEntity<List<FDQuestionnaire6PopulationDetail>> getCard6Detail(@PathVariable String issueNumber)  {
        logger.info("Received request to retrieve Card 6 details for issue number: {}", issueNumber);
        List<FDQuestionnaire6PopulationDetail> details = fdService.getCard6Detail(issueNumber);
        logger.info("Successfully retrieved {} Card 6 detail(s) for issue number: {}", details.size(), issueNumber);
        return new ResponseEntity<>(details, HttpStatus.OK);
    }
}
