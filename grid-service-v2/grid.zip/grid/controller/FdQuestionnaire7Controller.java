package com.ford.grid.controller;


import com.ford.grid.model.dto.request.FdQuestionnaire7Dto;

import com.ford.grid.service.FdQuestionnaire7Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/api/v2/fd/7")
public class FdQuestionnaire7Controller {

        private static final Logger LOGGER = LoggerFactory.getLogger(FdQuestionnaire7Controller.class);
        @Autowired
        private FdQuestionnaire7Service fd7Service;

        @PostMapping(value = "/save")
        @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist14DRCO','update') or @gridAuthorizeService.isAuthorized('GRID:Administration','update')")
        public ResponseEntity<FdQuestionnaire7Dto> save(@RequestBody FdQuestionnaire7Dto request) {
            FdQuestionnaire7Dto savedDto = fd7Service.saveFdQuestionnaire7(request);
            return new ResponseEntity<>(savedDto, HttpStatus.CREATED);
        }

        @GetMapping(value = "/getData/{issueNumber}")
        @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MyIssuesList','read')")
        public ResponseEntity<FdQuestionnaire7Dto> getByIssueNumber(@PathVariable String issueNumber) {
            FdQuestionnaire7Dto fdQ7Dto = fd7Service.findByIssueNumber(issueNumber);
            return new ResponseEntity<>(fdQ7Dto, HttpStatus.OK);
        }

        @PostMapping(value = "/updateStatus")
        @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist14DRCO','update') or @gridAuthorizeService.isAuthorized('GRID:Administration','update')")
        public ResponseEntity<FdQuestionnaire7Dto> updateStatus(@RequestBody FdQuestionnaire7Dto request) {
            FdQuestionnaire7Dto fdQ7Dto = fd7Service.updateStatus(request);
            return new ResponseEntity<>(fdQ7Dto, HttpStatus.OK);
        }

}
