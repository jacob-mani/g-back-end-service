package com.ford.grid.controller;


import com.ford.grid.model.dto.request.FdQuestionnaire8Dto;
import com.ford.grid.service.FDQuestionnaire8Service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;



@RestController
@RequestMapping("/api/v2/fd/8")
public class FdQuestionnaire8Controller {


        private static final Logger LOGGER = LoggerFactory.getLogger(FdQuestionnaire8Controller.class);
        @Autowired
        private FDQuestionnaire8Service fd8Service;

        @PostMapping(value = "/save")
        @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist14DRCO','update') or @gridAuthorizeService.isAuthorized('GRID:Administration','update')")
        public ResponseEntity<FdQuestionnaire8Dto> save(@RequestBody FdQuestionnaire8Dto request) {
            FdQuestionnaire8Dto savedDto = fd8Service.saveFdQ8(request);
            return new ResponseEntity<>(savedDto, HttpStatus.CREATED);
        }

        @GetMapping(value = "/getData/{issueNumber}")
        @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MyIssuesList','read')")
        public ResponseEntity<FdQuestionnaire8Dto> getByIssueNumber(@PathVariable String issueNumber) {
            FdQuestionnaire8Dto fdQ8Dto = fd8Service.findByIssueNumber(issueNumber);
            return new ResponseEntity<>(fdQ8Dto, HttpStatus.OK);
        }

        @PostMapping(value = "/updateStatus")
        @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist14DRCO','update') or @gridAuthorizeService.isAuthorized('GRID:Administration','update')")
        public ResponseEntity<FdQuestionnaire8Dto> updateStatus(@RequestBody FdQuestionnaire8Dto request) {
            FdQuestionnaire8Dto fdQ8Dto = fd8Service.updateStatus(request);
            return new ResponseEntity<>(fdQ8Dto, HttpStatus.OK);
        }

}
