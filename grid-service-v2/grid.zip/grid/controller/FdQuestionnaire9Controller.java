package com.ford.grid.controller;

import com.ford.grid.model.dto.request.FdQuestionnaire9Dto;
import com.ford.grid.service.FdQuestionnaire9Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v2/fd/9")
public class FdQuestionnaire9Controller {
    private static final Logger LOGGER = LoggerFactory.getLogger(FdQuestionnaire9Controller.class);

    @Autowired
    private FdQuestionnaire9Service fdService;

    @PostMapping(value = "/save")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist14DRCO','update') or @gridAuthorizeService.isAuthorized('GRID:Administration','update')")
    public ResponseEntity<FdQuestionnaire9Dto> save(@RequestBody FdQuestionnaire9Dto request) {
        LOGGER.info(request.toString());
        FdQuestionnaire9Dto savedDto = fdService.saveFdQ9(request);
        return new ResponseEntity<>(savedDto, HttpStatus.CREATED);
    }

    @GetMapping(value = "/getData/{issueNumber}/{implId}")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MyIssuesList','read')")
    public ResponseEntity<FdQuestionnaire9Dto> getByIssueNumber(@PathVariable String issueNumber, @PathVariable String implId) {
        FdQuestionnaire9Dto fdQ9Dto = fdService.findByIssueNumberandImplId(issueNumber, implId);
        return new ResponseEntity<>(fdQ9Dto, HttpStatus.OK);
    }

    @PostMapping(value = "/updateStatus")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist14DRCO','update') or @gridAuthorizeService.isAuthorized('GRID:Administration','update')")
    public ResponseEntity<FdQuestionnaire9Dto> updateStatus(@RequestBody FdQuestionnaire9Dto request) {
        FdQuestionnaire9Dto fdQ9Dto = fdService.updateStatus(request);
        return new ResponseEntity<>(fdQ9Dto, HttpStatus.OK);
    }
}
