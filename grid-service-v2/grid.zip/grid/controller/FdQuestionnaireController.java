package com.ford.grid.controller;

import com.ford.grid.common.SystemWideResponses;
import com.ford.grid.exception.GridException;
import com.ford.grid.model.dto.request.FdStatusRequest;
import com.ford.grid.model.dto.response.FdAuditResponse;
import com.ford.grid.model.dto.response.FdStatusResponse;
import com.ford.grid.service.FdQuestionnaireService;
import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/api/v2/fd")
@RequiredArgsConstructor
public class FdQuestionnaireController {

    private final FdQuestionnaireService fdQuestionnaireService;

    @Operation(summary = "Save Fd Status", description = "Accepts a FdStatusRequest object, saves it in the database, and returns the created FdStatusResponse.")
    @PostMapping("/saveFdStatus")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist14DRCO','update') or @gridAuthorizeService.isAuthorized('GRID:Administration','update')")
    public ResponseEntity<FdStatusResponse> saveForumStatus(@RequestBody FdStatusRequest fdStatusRequest) throws GridException {
        return new ResponseEntity<>(fdQuestionnaireService.saveFdStatus(fdStatusRequest), HttpStatus.OK);
    }

    @GetMapping("/getFdStatus/{issueNumber}")
    @Operation(summary = "Get FD Status", description = "GET API to retrieve FD Status data by issue number")
    @SystemWideResponses
    public ResponseEntity<FdStatusResponse> getAllForumStatus(
            @PathVariable String issueNumber) throws GridException {
        return new ResponseEntity<>(fdQuestionnaireService.getFdStatusResponse(issueNumber), HttpStatus.OK);
    }

    @GetMapping("/getFdStatusAudit/{issueNumber}")
    @Operation(summary = "Get FD Status Audit log for active version", description = "GET API to retrieve Forum Status audit data by issue number")
    @SystemWideResponses
    public ResponseEntity<List<FdAuditResponse>> getForumStatusAuditLog(
            @PathVariable String issueNumber) throws GridException {
        return new ResponseEntity<>(fdQuestionnaireService.getFdStatusAuditLogs(issueNumber), HttpStatus.OK);
    }

}
