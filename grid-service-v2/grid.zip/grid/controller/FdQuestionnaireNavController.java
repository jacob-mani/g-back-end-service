package com.ford.grid.controller;

import com.ford.grid.model.dto.response.FdQuestionnaireNavResponse;
import com.ford.grid.service.FdQuestionnaireNavService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api/v2/fd/common")
public class FdQuestionnaireNavController {

    @Autowired
    private FdQuestionnaireNavService fdService;


    @GetMapping({"/getData/{issueNumber}/{implId}"})
    public ResponseEntity<Map<String, FdQuestionnaireNavResponse>> findAllByIssueNumber(@PathVariable String issueNumber, @PathVariable String implId) {
        Map<String, FdQuestionnaireNavResponse> fdQuestionnaireNavResponse = fdService.findAllByIssueNumber(issueNumber, implId);
        return new ResponseEntity<>(fdQuestionnaireNavResponse, HttpStatus.OK);
    }
}
