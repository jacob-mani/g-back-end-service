package com.ford.grid.controller;

import com.ford.grid.common.SystemWideResponses;
import com.ford.grid.exception.GridException;
import com.ford.grid.model.dto.request.FdrActionRequest;
import com.ford.grid.model.dto.request.FdrModel;
import com.ford.grid.model.dto.request.NhtsaNoticeRequest;
import com.ford.grid.model.dto.response.NhtsaNoticeResponse;
import com.ford.grid.model.entity.fdr.NHTSAnotice;
import com.ford.grid.model.entity.SimilarVehiclesList;
import com.ford.grid.service.FDRReportService;
import com.ford.grid.util.RecallIssueUtil;
import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v2/fdr")
public class FdrController {

    private static final Logger LOGGER = LoggerFactory.getLogger(FdrController.class);
    private final FDRReportService fdrReportService;
    private final RecallIssueUtil recallIssueUtil;

    @PostMapping("/createSimilarVehiclesList")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:FDRReport','update')")
    public ResponseEntity<SimilarVehiclesList> createSimilarVehicle(@RequestBody SimilarVehiclesList similarVehiclesList) {
        return ResponseEntity.ok(fdrReportService.saveSimilarVehicle(similarVehiclesList));
    }

    @DeleteMapping("/deleteSimilarVehiclesList")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:FDRReport','update')")
    public ResponseEntity<Void> deleteSimilarVehicle(@RequestBody SimilarVehiclesList similarVehiclesList) {
        fdrReportService.deleteSimilarVehicle(similarVehiclesList);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/getSimilarVehiclesList")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:FDRReport','read')")
    public ResponseEntity<List<SimilarVehiclesList>> getSimilarVehiclesList() {
        return ResponseEntity.ok(fdrReportService.getVehicleList());
    }


    /**
     * Returns paginated FDR records filtered by state with optional global search.
     * Mirrors RecallIssueController.getAllIssues() pattern exactly:
     *   searchKey is optional, applied BEFORE pagination across ALL records.
     *
     * GET /api/v2/fdr/New?page=0&size=10
     * GET /api/v2/fdr/New?page=0&size=10&searchKey=26B16
     * GET /api/v2/fdr/SUBMITTED_FOR_REVIEW?page=0&size=10&sortBy=issueNumber&direction=DESC
     */
    @GetMapping("/{state}")
    @Operation(summary = "Get FDR Reports by State", description = "Returns paginated FDR records filtered by state with optional global search")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:FDRReport','read')")
    public ResponseEntity<Page<FdrModel>> reports(
            @PathVariable String state,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "issueNumber") String sortBy,
            @RequestParam(defaultValue = "DESC") String direction,
            @RequestParam(required = false) String searchKey) {

        LOGGER.info("reports: state={}, page={}, size={}, sortBy={}, direction={}, searchKey={}",
                state, page, size, sortBy, direction, searchKey);

        Sort sort = Sort.by(Sort.Direction.fromString(direction), sortBy);
        Pageable pageable = PageRequest.of(page, size, sort);

        return ResponseEntity.ok(fdrReportService.getReportsByState(state, pageable, searchKey));
    }

    /**
     * REQ 1: Only user-inputted fields in request body.
     * View data auto-fetched using fsaNumber + issueNumber.
     * Action examples: SUBMITTED_FOR_REVIEW, REVIEW_COMPLETED,
     *                  No Vehicles Needed, Does Not Apply, Not Applicable
     */
    @PostMapping("/performFdrAction/{action}")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:FDRReport','update')")
    public ResponseEntity<FdrModel> performFdrAction(
            @RequestBody FdrActionRequest request,
            @PathVariable String action) throws GridException {
        LOGGER.info("performFdrAction: fsaNumber={}, issueNumber={}, action={}",
                request.getFsaNumber(), request.getIssueNumber(), action);
        return ResponseEntity.ok(fdrReportService.performFdrAction(request, action));
    }

    /**
     * Save NHTSA notice. If action = REVIEW_COMPLETED, also updates fdr_state.
     */
    @PostMapping("/nhtsa-notice/{action}")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:FDRReport','update')")
    public ResponseEntity<NhtsaNoticeResponse> saveNhtsaNotice(@RequestBody NhtsaNoticeRequest request, @PathVariable String action) throws GridException {

        LOGGER.info("saveNhtsaNotice: fsaNumber={}, issueNumber={}, action={}",
                request.getFsaNumber(), request.getIssueNumber(), action);
        NhtsaNoticeResponse response = fdrReportService.saveNHTSAnotice(request, action);
        return ResponseEntity.ok(response);
    }


    /**
     * Get a single FDR record by fsaNumber + issueNumber.
     * Returns view data + enriched with fdr_state + nhtsa_notice.
     */
    @GetMapping("/{fsaNumber}/{issueNumber}")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:FDRReport','read')")
    public ResponseEntity<FdrModel> getFdrByFsaAndIssue(
            @PathVariable String fsaNumber,
            @PathVariable String issueNumber) throws GridException {
        LOGGER.info("getFdrByFsaAndIssue: fsaNumber={}, issueNumber={}", fsaNumber, issueNumber);
        return ResponseEntity.ok(fdrReportService.getFdrByFsaAndIssue(fsaNumber, issueNumber));
    }

    /**
     * Get saved NHTSA notice for a specific fsaNumber + issueNumber.
     */
    @GetMapping("/nhtsa-notice/{fsaNumber}/{issueNumber}")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:FDRReport','read')")
    public ResponseEntity<NHTSAnotice> getNhtsaNotice(
            @PathVariable String fsaNumber,
            @PathVariable String issueNumber) {
        return ResponseEntity.ok(fdrReportService.getNhtsaNotice(fsaNumber, issueNumber));
    }
}
