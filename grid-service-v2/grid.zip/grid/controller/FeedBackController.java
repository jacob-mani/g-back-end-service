package com.ford.grid.controller;

import com.ford.grid.exception.GridException;
import com.ford.grid.model.dto.request.FeedbackRequest;
import com.ford.grid.model.dto.request.TicketsCustomFilterNameDto;
import com.ford.grid.model.dto.response.FeedBackResponse;
import com.ford.grid.model.dto.response.FeedbackFilterCategoriesDto;
import com.ford.grid.service.FeedBackService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v2/feedBack")
public class FeedBackController {

    private static final Logger LOGGER = LoggerFactory.getLogger(FeedBackController.class);

    private final FeedBackService feedBackService;

    /**
     * Creates a new feedback record and submits a ServiceNow ticket.
     *
     * <p>Positive scenario: returns {@code 200 OK} with the saved {@link FeedBackResponse}.</p>
     * <p>Negative scenarios:
     * <ul>
     *   <li>{@code 400 Bad Request} – if {@code request} is null or {@code feedbackType} is blank.</li>
     *   <li>{@code 500 Internal Server Error} – if an unexpected error occurs during save.</li>
     * </ul>
     * </p>
     *
     * @param request the {@link FeedbackRequest} body containing feedback details; {@code feedbackType} is required
     * @return the appropriate {@link ResponseEntity}
     */
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read'})")
    @PostMapping("/create")
    @ResponseBody
    @Operation(summary = "Create Feedback",
               description = "POST API to submit a new feedback record and create a ServiceNow ticket")
    public ResponseEntity<FeedBackResponse> addNewFeedback(
            @RequestBody FeedbackRequest request) {

        if (request == null || request.getFeedbackType() == null || request.getFeedbackType().isBlank()) {
            LOGGER.warn("addNewFeedback called with null request body or missing feedbackType");
            return ResponseEntity.badRequest().build();
        }

        LOGGER.info("Start of addNewFeedback – feedbackType: {}, cdsId: {}",
                request.getFeedbackType(), request.getCdsId());

        try {
            FeedBackResponse response = feedBackService.saveNewFeedback(request);

            LOGGER.info("End of addNewFeedback – seqId: {}", response.getSeqId());
            return ResponseEntity.ok(response);

        } catch (GridException ge) {
            LOGGER.error("GridException in addNewFeedback – cdsId: {}, feedbackType: {}, message: {}",
                    request.getCdsId(), request.getFeedbackType(), ge.getMessage(), ge);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * Retrieves all feedback records that have a ServiceNow request ID,
     * sorted by creation date descending (newest first).
     * Optionally filters by the submitting user's CDS ID.
     *
     * @param cdsId the CDS ID to filter by; omit to return all records
     * @return {@code 200 OK} with list, {@code 204 No Content} if empty,
     *         or {@code 500} on error
     */
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read'})")
    @GetMapping("/get")
    @ResponseBody
    @Operation(summary = "Get All Feedbacks",
               description = "GET API to retrieve all feedback records with a ServiceNow request ID, optionally filtered by cdsId")
    public ResponseEntity<List<FeedBackResponse>> getAllFeedbacks(
            @RequestParam(name = "cdsId", required = false) String cdsId) {

        LOGGER.info("Start of getAllFeedbacks – cdsId: {}", cdsId);

        try {
            List<FeedBackResponse> responses = feedBackService.getAllFeedbacks(cdsId);

            if (responses.isEmpty()) {
                LOGGER.warn("No feedback records found for cdsId: {}", cdsId);
                return ResponseEntity.noContent().build();
            }

            LOGGER.info("End of getAllFeedbacks – returning {} record(s)", responses.size());
            return ResponseEntity.ok(responses);

        } catch (GridException ge) {
            LOGGER.error("GridException in getAllFeedbacks – cdsId: {}, message: {}",
                    cdsId, ge.getMessage(), ge);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * Retrieves feedback records that match a named custom filter saved in the
     * authenticated user's preferences.
     *
     * @param filterName the name of the saved custom filter tab to apply – required
     * @param cdsId      the CDS ID of the user – required
     * @return {@code 200 OK} with the matching list, {@code 204 No Content} if empty,
     *         {@code 400 Bad Request} if filterName or cdsId is blank,
     *         or {@code 500} on error
     */
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read'})")
    @GetMapping("/getCustomFilter")
    @ResponseBody
    @Operation(summary = "Get Custom Filter Feedbacks",
               description = "GET API to retrieve feedback records matching a named custom filter saved in the user's preferences")
    public ResponseEntity<List<FeedBackResponse>> getCustomFilterFeedbacks(
            @Parameter(description = "Name of the saved custom filter tab", required = true)
            @RequestParam(name = "tabName") String filterName,
            @Parameter(description = "CDS ID of the user", required = true)
            @RequestParam(name = "cdsId") String cdsId) {

        if (filterName == null || filterName.isBlank() || cdsId == null || cdsId.isBlank()) {
            LOGGER.warn("getCustomFilterFeedbacks called with blank filterName or cdsId");
            return ResponseEntity.badRequest().build();
        }

        LOGGER.info("Start of getCustomFilterFeedbacks – filterName: {}, cdsId: {}", filterName, cdsId);

        try {
            List<FeedBackResponse> responses = feedBackService.getCustomFilterFeedbacks(filterName, cdsId);

            if (responses.isEmpty()) {
                LOGGER.warn("No records matched custom filter '{}' for cdsId: {}", filterName, cdsId);
                return ResponseEntity.noContent().build();
            }

            LOGGER.info("End of getCustomFilterFeedbacks – returning {} record(s) for filterName: {}, cdsId: {}",
                    responses.size(), filterName, cdsId);
            return ResponseEntity.ok(responses);

        } catch (GridException ge) {
            LOGGER.error("GridException in getCustomFilterFeedbacks – filterName: {}, cdsId: {}, message: {}",
                    filterName, cdsId, ge.getMessage(), ge);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * Saves or updates named custom filter tabs in the authenticated user's preferences.
     *
     * @param customFilterNames the list of named custom filters to save – required
     * @param removeFlag        {@code "Y"} to replace all filters; any other value to merge
     * @param cdsId             the CDS ID of the user – required
     * @return {@code 200 OK} with the first saved filter, {@code 400 Bad Request} if the
     *         list is empty or cdsId is blank, or {@code 500} on error
     */
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read'})")
    @PutMapping("/saveCustomFilter")
    @ResponseBody
    @Operation(summary = "Save Custom Filter",
               description = "PUT API to save or update named custom filter tabs in the user's preferences. " +
                             "Pass removeFlag=Y to replace all filters, or any other value to merge.")
    public ResponseEntity<TicketsCustomFilterNameDto> saveCustomFilter(
            @RequestBody List<TicketsCustomFilterNameDto> customFilterNames,
            @Parameter(description = "Pass 'Y' to replace all saved filters; any other value merges", required = true)
            @RequestParam(name = "removeFlag") String removeFlag,
            @Parameter(description = "CDS ID of the user", required = true)
            @RequestParam(name = "cdsId") String cdsId) {

        if (customFilterNames == null || customFilterNames.isEmpty()) {
            LOGGER.warn("saveCustomFilter called with empty customFilterNames list");
            return ResponseEntity.badRequest().build();
        }

        if (cdsId == null || cdsId.isBlank()) {
            LOGGER.warn("saveCustomFilter called with blank cdsId");
            return ResponseEntity.badRequest().build();
        }

        LOGGER.info("Start of saveCustomFilter – cdsId: {}, removeFlag: {}", cdsId, removeFlag);

        try {
            feedBackService.saveCustomFilter(customFilterNames, removeFlag, cdsId);

            TicketsCustomFilterNameDto firstFilter = customFilterNames.stream()
                    .findFirst()
                    .orElse(null);

            LOGGER.info("End of saveCustomFilter – saved filter: '{}' for cdsId: {}",
                    firstFilter != null ? firstFilter.getFilterName() : "N/A", cdsId);
            return ResponseEntity.ok(firstFilter);

        } catch (GridException ge) {
            LOGGER.error("GridException in saveCustomFilter – cdsId: {}, removeFlag: {}, message: {}",
                    cdsId, removeFlag, ge.getMessage(), ge);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * Returns the available filter categories, conditions, and distinct status
     * criteria used to build custom feedback filters on the UI.
     *
     * @return {@code 200 OK} with {@link FeedbackFilterCategoriesDto}
     */
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read'})")
    @GetMapping("/getFilterCategories")
    @ResponseBody
    @Operation(summary = "Get Filter Categories",
               description = "GET API to retrieve available filter categories, conditions, and distinct status criteria for feedback custom filters")
    public ResponseEntity<FeedbackFilterCategoriesDto> getFilterCategories() {
        LOGGER.info("Start of getFilterCategories");
        FeedbackFilterCategoriesDto result = feedBackService.getFilterCategories();
        LOGGER.info("End of getFilterCategories");
        return ResponseEntity.ok(result);
    }

    /**
     * Updates all non-closed feedback tickets with the latest assignee and status
     * information from ServiceNow.
     *
     * <p>This endpoint triggers a batch update process that:
     * <ul>
     *   <li>Queries all feedback records that are not in "Closed" status</li>
     *   <li>Fetches current assignee and state information from ServiceNow for each ticket</li>
     *   <li>Updates the database with the latest information</li>
     * </ul>
     * </p>
     *
     * @return {@code 200 OK} with the list of updated {@link FeedBackResponse} records,
     *         or {@code 500} on error
     */
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read'})")
    @PutMapping("/updateTicketStateToDB")
    @ResponseBody
    @Operation(summary = "Update Ticket States from ServiceNow",
               description = "PUT API to update all non-closed feedback tickets with the latest assignee and status information from ServiceNow")
    public ResponseEntity<List<FeedBackResponse>> updateTicketStateToDB() {
        LOGGER.info("Start of updateTicketStateToDB endpoint");

        try {
            List<FeedBackResponse> updatedTickets = feedBackService.updateTicketStateToDB();
            LOGGER.info("End of updateTicketStateToDB endpoint – {} ticket(s) updated successfully", updatedTickets.size());
            return ResponseEntity.ok(updatedTickets);

        } catch (Exception e) {
            LOGGER.error("Exception in updateTicketStateToDB endpoint: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
}
