package com.ford.grid.controller;

import com.ford.grid.common.SystemWideResponses;
import com.ford.grid.exception.GridException;
import com.ford.grid.model.dto.request.ProgramFsaMappingRequest;
import com.ford.grid.model.dto.request.SoftwarePartsFsaRequest;
import com.ford.grid.model.dto.response.*;
import com.ford.grid.model.entity.SoftwareFsaMyPgmGvms;
import com.ford.grid.model.entity.SoftwareMyPgmIedVersion;
import com.ford.grid.security.UserDetailProvider;
import com.ford.grid.service.GvmsService;
import com.ford.grid.service.IEDService;
import com.ford.grid.service.impl.GvmsMigrationHelperService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.mail.MessagingException;
import lombok.AllArgsConstructor;
import org.apache.coyote.BadRequestException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@AllArgsConstructor
@RequestMapping("api/v2/fhm/softwareParts")
public class FhmSoftwarePartsController {
    private static final Logger LOGGER = LoggerFactory.getLogger(FhmSoftwarePartsController.class);

    private final GvmsService gvmsService;

    private final IEDService iedService;

    private final UserDetailProvider userDetailProvider;

    private final GvmsMigrationHelperService gvmsMigrationHelperService;

    @GetMapping("/fetchProgramCodeModelYear/{issueNumber}/{implId}/{populationId}/{partType}")
    @Operation(summary = "Get Software parts", description = "Get Software parts for program code model year")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MyIssuesList','read')")
    public ResponseEntity<List<SoftwareFsaMyPgmGvmsResponse>> fetchProgramCodeModelYear(@PathVariable String issueNumber, @PathVariable String implId, @PathVariable String populationId, @PathVariable String partType) {
        LOGGER.info("Started to Fetch Program Code and Model Year for Part Type: {}, populationId: {}", partType, populationId);
        List<SoftwareFsaMyPgmGvmsResponse> programFsaMappingResponse = gvmsService.fetchProgramModelYear(issueNumber, implId, populationId, partType);
        LOGGER.info("End to Fetch Program Code and Model Year for Part Type: {}. Result Size: {}", partType, programFsaMappingResponse.size());
        return new ResponseEntity<>(programFsaMappingResponse, HttpStatus.OK);
    }

    @GetMapping("/getIedSubmitData/{issueNumber}/{implId}")
    @Operation(summary = "Get Software parts", description = "Get IED submitted Data with Impl Id")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MyIssuesList','read')")
    public ResponseEntity<SoftwareMyPgmIedVersion> getIedSubmitData(@PathVariable String issueNumber, @PathVariable String implId) {
        LOGGER.info("Started to get IED submitted Data with Impl Id");
        SoftwareMyPgmIedVersion iedData = gvmsService.getMyProgramIEDVersionModel(issueNumber, implId);
        return new ResponseEntity<>(iedData, HttpStatus.OK);
    }

    @PostMapping("/checkModelYearProgramParts/{issueNumber}/{implId}/{populationId}/{globalFsa}")
    @Operation(summary = "Get Software parts", description = "To check IED Implementation for FSA")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MyIssuesList','read')")
    public ResponseEntity<String> checkModelYearProgramParts(@PathVariable String issueNumber, @PathVariable String implId, @PathVariable String populationId, @PathVariable String globalFsa, @RequestBody List<ProgramFsaMappingRequest> programData) {
        LOGGER.info("Started to check IED Implementation for populationId: {}", populationId);
        String message = gvmsService.checkModelYearProgramParts(issueNumber, implId, populationId, globalFsa, programData);
        return new ResponseEntity<>(message, HttpStatus.OK);
    }

    @PostMapping("/saveIvsModelYearProgramCode/{issueNumber}/{implId}/{populationId}")
    @Operation(summary = "Saves IVS Model Year Program Code data for a Impl Id.", description = "Accepts a list of program mapping data and persists the IVS Model Year Program Code")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MyIssuesList','read')")
    public ResponseEntity<Map<String, String>> saveIvsModelYearProgramCode(@PathVariable String issueNumber, @PathVariable String implId,
                                                                           @PathVariable String populationId,
                                                                           @RequestBody List<ProgramFsaMappingRequest> saveData) {
        LOGGER.info("Started saving IVS Model Year Program Code for Implementation ID: {}, populationId: {}", implId, populationId);
        boolean isSaved = gvmsService.saveIvsModelYearProgramCode(issueNumber, implId, populationId, saveData);
        Map<String, String> response = new HashMap<>();
        if (isSaved) {
            LOGGER.info("Data saved successfully for Implementation ID: {}", implId);
            response.put("message", "Data saved successfully");
            return ResponseEntity.ok(response);
        } else {
            LOGGER.error("Error saving data for Implementation ID: {}", implId);
            response.put("message", "Error saving data");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @PutMapping("/updateBucketFsa/{globalFsa}/{localFsa}")
    @Operation(summary = "Update bucket fsa details IVS Model Year Program Code data for a given Global FSA.", description = "Accepts a list of program mapping data and persists the IVS Model Year Program Code")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MyIssuesList','read')")
    public ResponseEntity<String> updateBucketLocalFsa(@PathVariable String globalFsa, @PathVariable String localFsa) {
        LOGGER.info("Started to update the buckets with Local FSA");
        String message = gvmsService.updateBucketFsa(globalFsa, localFsa);
        return new ResponseEntity<>("", HttpStatus.OK);
    }

    @PostMapping("/savePartsWithNotice/{issueNumber}/{implId}/{fsa}")
    @Operation(summary = "Saves parts with notice.", description = "Save parts with notice")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MyIssuesList','read')")
    @ResponseBody
    public ResponseEntity<WersResponse> saveParts(@PathVariable String issueNumber, @PathVariable String implId,
                                                  @RequestBody List<String> notices, @PathVariable String fsa) throws MessagingException, GridException {
        WersResponse responseDto = gvmsService.wersNoticesSaveJob(issueNumber, implId, fsa, notices);
        return new ResponseEntity<>(responseDto, HttpStatus.OK);
    }

    @PutMapping("/updateSoftwareParts/{issueNumber}/{implId}/{action}")
    @Operation(summary = "update software parts.", description = "Update software parts")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MyIssuesList','read')")
    @ResponseBody
    public ResponseEntity<WersResponse> updateSoftwareParts(@RequestBody  List<SoftwareFsaMyPgmGvms> softwareParts,
                                                            @RequestParam List<String> noticesToBeDeleted ,
                                                            @PathVariable String issueNumber, @PathVariable String implId,
                                                            @PathVariable String action) throws BadRequestException, GridException {
        String response =gvmsService.updateSoftwareParts(softwareParts, noticesToBeDeleted, issueNumber, implId, action);
        WersResponse responseDto = new WersResponse();
        responseDto.setMessage(response);
        return new ResponseEntity<>(responseDto, HttpStatus.OK);
    }

    @GetMapping("/getPartsWithNotice/{issueNumber}/{implId}")
    @Operation(summary = "Get Parts With Notice API", description = "Fetches Parts with Notice API by issue number,impl id")
    @SystemWideResponses
    public ResponseEntity<List<SoftwareFsaSavePartsResponse>> getPartsWithNotice(@PathVariable String issueNumber, @PathVariable String implId) {
        LOGGER.info("Fetching Parts With Notice API for issue number: {}, implementation id: {}", issueNumber, implId);
        List<SoftwareFsaSavePartsResponse> response = gvmsService.getNoticeParts(issueNumber, implId);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/checkIedVersion/{issueNumber}/{implementationId}/{populationId}")
    @Operation(summary = "Get data from IED Implementation", description = "GET API to retrieve IED Implementation by issue number, impl id and population id")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MyIssuesList','read')")
    @SystemWideResponses
    public ResponseEntity<SoftwareMyPgmIedVersion> checkIedVersion(@PathVariable String issueNumber, @PathVariable String implementationId, @PathVariable String populationId) {
        LOGGER.info("Started to check IED Implementation for populationId: {}", populationId);
        SoftwareMyPgmIedVersion idExists = iedService.checkIedVersion(issueNumber, implementationId, populationId);
        return new ResponseEntity<>(idExists, HttpStatus.OK);
    }

    @PostMapping("/sendIedMypParts/{issueNumber}/{implementationId}/{populationId}/{globalFsa}")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist14DRCO','update') or @gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    @Operation(summary = "Send IED Final Part Details", description = "API endpoint to Send IED Final Part Details")
    @SystemWideResponses
    public ResponseEntity<IEDFSABucketPartNumbersSubmitResponse> sendIEDFinalPartDetails(@PathVariable String issueNumber,
                                                                                         @PathVariable String implementationId,
                                                                                         @PathVariable String populationId,
                                                                                         @PathVariable String globalFsa) throws GridException {
        LOGGER.info("Received IED submit request: issueNumber={}, implementationId={}, populationId={}, fsa={}", issueNumber, implementationId, populationId, globalFsa);
        String cdsId = userDetailProvider.getUser().getCdsID();
        IEDFSABucketPartNumbersSubmitResponse response = iedService.sendIEDFinalPartDetails(issueNumber, implementationId, populationId, globalFsa, cdsId);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/getPreviewData/{issueNumber}/{implId}/{populationId}")
    @Operation(summary = "Get Preview Data", description = "Fetches Parts, Config data to display in preview by issue number,impl id, populationId")
    @SystemWideResponses
    public ResponseEntity<List<PartsMappingCombinedResponse>> getPreviewData(@PathVariable String issueNumber, @PathVariable String implId, @PathVariable String populationId) {
        LOGGER.info("Fetches Parts, Config data to display in preview for issue number: {}, implementation id: {}, populationId: {}", issueNumber, implId, populationId);
        List<PartsMappingCombinedResponse> response = gvmsService.getPreviewData(issueNumber, implId, populationId);
        return ResponseEntity.ok(response);
    }

    @GetMapping(value = "/exportPreviewData/{issueNumber}/{implId}/{populationId}",
            produces = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    @Operation(summary = "Export Preview Data", description = "Exports Parts, Config preview data as an Excel (.xlsx) file")
    @SystemWideResponses
    public ResponseEntity<byte[]> exportPreviewData(@PathVariable String issueNumber, @PathVariable String implId, @PathVariable String populationId) throws GridException {
        LOGGER.info("Exporting Preview Data to Excel for issue number: {}, implementation id: {}, populationId: {}", issueNumber, implId, populationId);
        byte[] excelBytes = gvmsService.exportPreviewDataToExcel(issueNumber, implId, populationId);
        LOGGER.info("Generated Excel export size (bytes): {} for issueNumber={}, implId={}, populationId={}",
                excelBytes != null ? excelBytes.length : 0, issueNumber, implId, populationId);
        String fileName = String.format("PreviewData_%s_%s_%s.xlsx",
                issueNumber.replaceAll("[^a-zA-Z0-9._-]", "_"),
                implId.replaceAll("[^a-zA-Z0-9._-]", "_"),
                populationId.replaceAll("[^a-zA-Z0-9._-]", "_"));

        return ResponseEntity.ok()
                .header(org.springframework.http.HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fileName + "\"")
                .contentType(org.springframework.http.MediaType.parseMediaType(
                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                .contentLength(excelBytes != null ? excelBytes.length : 0)
                .body(excelBytes);
    }

    /*  Below api used to set Parts ecuNodeID, partDid values in Parts save & ied collections as part of data migration  */
    @GetMapping("/migrate/softwareFsaSaveParts")
    @Operation(summary = "Migrate software Fsa Save Parts", description = "Data Migrate for the existing software Fsa Save Parts ")
    @SystemWideResponses
    public ResponseEntity<Map<String, List<String>>> migrateSoftwareFsaSaveParts() {
        LOGGER.info("Data Migrate for the existing software Fsa Save Parts");
        return gvmsService.migrateSoftwareFsaSaveParts();

    }

    /*  Below api used to set CONFIG data into ied collection as part of data migration  */
    @GetMapping("/migrate/configData")
    @Operation(summary = "Migrate Config Data", description = "Config Data Migrate for the existing IED data ")
    @SystemWideResponses
    public ResponseEntity<Map<String, List<String>>> migrateConfigData() {
        LOGGER.info("Data Migrate for the existing Config Data into IED");
        return gvmsService.migrateConfigData();

    }

    @PostMapping("/validateVsemPartsData/{issueNumber}/{implId}/{populationId}")
    @Operation(summary = "Validate Vsem Parts Data", description = "get Validate the VSEM Part ECU & Did")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MyIssuesList','read')")
    public ResponseEntity<Boolean> validateVsemPartsData(@PathVariable String issueNumber, @PathVariable String implId,
                                                         @PathVariable String populationId,
                                                         @RequestBody List<ProgramFsaMappingRequest> programData) throws GridException, BadRequestException {
        LOGGER.info("Validate VSEM Parts Data");
        boolean validateVsem  = gvmsService.validateVsemPartsData(issueNumber,implId, populationId, programData);
        return ResponseEntity.ok(validateVsem);
    }

    /*  Below api used to migrate partsData, isSubmitted flags for GVMS buckets, nodes & parts  */
    @GetMapping("/migrate/gvmsPartsData")
    @Operation(summary = "Migrate GVMS partsData & isSubmitted flags", description = "Data Migration: Builds partsData from parts myPgmFsaId, backfills isSubmitted on buckets, nodes & parts")
    @SystemWideResponses
    public ResponseEntity<Map<String, List<String>>> migrateGvmsPartsData() {
        LOGGER.info("Data Migrate for GVMS partsData & isSubmitted flags");
        return gvmsMigrationHelperService.migrateGvmsPartsData();
    }

}
