package com.ford.grid.controller;

import com.ford.grid.common.SystemWideResponses;
import com.ford.grid.model.dto.request.FinancialImplicationsRequest;
import com.ford.grid.model.dto.response.FinancialImplicationsResponse;
import com.ford.grid.service.FinancialImplicationsService;
import io.swagger.v3.oas.annotations.Operation;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@AllArgsConstructor
@RequestMapping("/api/v2/financeImpl")
public class FinancialImplicationsController {
    private static final Logger LOGGER = LoggerFactory.getLogger(FinancialImplicationsController.class);

    private final FinancialImplicationsService financialImplicationsService;

    @PostMapping("/saveFinanceImpl")
    @Operation(summary = "Save Financial Implications", description = "Update Financial Implications if record exists")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:AllIssues','update')")
    public ResponseEntity<FinancialImplicationsResponse> saveFinancialImplications(@RequestBody FinancialImplicationsRequest request) {
        LOGGER.info("Start of updateFinancialImplications : {}", request);
        FinancialImplicationsResponse response = financialImplicationsService.saveFinancialImplications(request);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/{issueNumber}/{implId}/{populationId}")
    @Operation(summary = "Get Financial Implications", description = "Get Financial Implications by issueNumber, implId and populationId")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MyIssuesList','read')")
    public ResponseEntity<FinancialImplicationsResponse> getFinancialImplications(
            @PathVariable String issueNumber,
            @PathVariable String implId,
            @PathVariable String populationId) {
        LOGGER.info("Getting financial implications for issueNumber: {}, implId: {}, populationId: {}",
                issueNumber, implId, populationId);
        FinancialImplicationsResponse response = financialImplicationsService.getFinancialImplications(
                issueNumber, implId, populationId);
        return ResponseEntity.ok(response);
    }
}
