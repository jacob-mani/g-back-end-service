package com.ford.grid.controller;

import com.ford.grid.common.SystemWideResponses;
import com.ford.grid.exception.GridException;
import com.ford.grid.model.dto.request.*;
import com.ford.grid.model.dto.response.*;
import com.ford.grid.model.entity.ForumAgenda;
import com.ford.grid.model.entity.GlobalForumAgenda;
import com.ford.grid.service.FdQuestionnaireService;
import com.ford.grid.service.ForumService;
import com.ford.grid.service.ForumStatusService;
import com.ford.grid.service.TrgService;
import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.List;
import java.util.Objects;

@RestController
@RequestMapping("/api/v2/forum")
@RequiredArgsConstructor
public class ForumController {
    private static final Logger logger = LoggerFactory.getLogger(ForumController.class);

    private final ForumService forumService;
    private final ForumStatusService forumStatusService;
    private final FdQuestionnaireService fdQuestionnaireService;
    private final TrgService trgService;

    @PostMapping("/scheduleForum")
    @Operation(summary = "Save Schedule Agenda Forum", description = "API endpoint to save forum details")
    @SystemWideResponses
    public ResponseEntity<ForumAgenda> scheduleForum(@RequestBody SchForumAgeRequest schForumAgeRequest) throws GridException {
        logger.info("Start of schedule agenda in ScheduleForumAgendaController");
        logger.info("Received request: {}", schForumAgeRequest);
        if (Objects.isNull(schForumAgeRequest))
            return ResponseEntity.badRequest().build();

        return new ResponseEntity<>(forumService.saveScheduleForum(schForumAgeRequest), HttpStatus.CREATED);
    }


    @GetMapping({"/getScheduleForumAgenda/{issueNumber}/{forumType}",
            "/getScheduleForumAgenda/{issueNumber}/{forumType}/{agency}"})
    @Operation(summary = "Get data from Schedule Forum", description = "GET API to retrieve CCRG data by issue number and forum type")
    @SystemWideResponses
    public ResponseEntity<List<SchForumAgeResponse>> getScheduleForumByIssueAndType(
            @PathVariable String issueNumber,
            @PathVariable String forumType,
            @PathVariable(required = false) String agency) {

        try {
            List<SchForumAgeResponse> responses = forumService.getByIssueNumberAndForumType(issueNumber, forumType, agency);

            if (responses.isEmpty()) {
                return ResponseEntity.noContent().build();
            }

            return ResponseEntity.ok(responses);
        } catch (Exception e) {
            logger.error("Error retrieving schedule forums: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @GetMapping("/getAgenciesByForum/{issueNumber}/{forumType}")
    @Operation(summary = "Get data from Schedule govt Forum agencies", description = "GET API to retrieve CCRG data by issue number and forum type")
    @SystemWideResponses
    public ResponseEntity<List<SchForumAgeResponse>> getAgenciesByForum(
            @PathVariable String issueNumber,
            @PathVariable String forumType) {
        try {
            List<SchForumAgeResponse> responses = forumService.getAgenciesByForum(issueNumber, forumType);
            if (responses.isEmpty()) {
                return ResponseEntity.noContent().build();
            }
            return ResponseEntity.ok(responses);
        } catch (Exception e) {
            logger.error("Error retrieving schedule forums: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @PostMapping("/globalScheduleForum")
    @Operation(summary = "Save Schedule global agenda Forum", description = "API endpoint to save global Agenda forum type details")
    @SystemWideResponses
    public ResponseEntity<GlobalForumAgenda> scheduleGlobalForum(@RequestBody GLSchForumAgeRequest globalRequest) throws GridException {
        logger.info("Start of scheduleForum in ScheduleForumAgendaController");
        logger.info("Received globalRequest: {}", globalRequest);
        if (Objects.isNull(globalRequest))
            return ResponseEntity.badRequest().build();

        return new ResponseEntity<>(forumService.saveByGlobalForumType(globalRequest), HttpStatus.CREATED);
    }

    @GetMapping({"/getGlobalScheduleForumAgenda/{issueNumber}/{forumType}",
            "/getGlobalScheduleForumAgenda/{issueNumber}/{forumType}/{agency}"})
    @Operation(summary = "Get data from Schedule Global forum agenda", description = "GET API to retrieve Global agenda data by issue number and forum type")
    @SystemWideResponses
    public ResponseEntity<GLSchForumAgeResponse> getGlobalScheduleForumAgenda(
            @PathVariable String issueNumber,
            @PathVariable String forumType, @PathVariable(required = false) String agency) {

        GLSchForumAgeResponse response = forumService.getGlobalByIssueNumberAndForumType(issueNumber, forumType, agency);

        if (response != null) {
            return new ResponseEntity<>(response, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }


    @PostMapping("createForumGovAction")
    @Operation(summary = "Create Forum Action", description = "Create Government  Forum Action API")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    @SystemWideResponses
    public ResponseEntity<ForumGovActionResponse> createGovForumAction(@RequestBody ForumGovActionRequest request) throws GridException {
        ForumGovActionResponse response = forumService.createForumGovAction(request);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @GetMapping("/getForumActions/{issueNumber}/{forumType}/{agency}")
    @Operation(summary = "Get data from Government Forum Action", description = "GET API to retrieve Government Forum Action data by issue number and forum type")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    @SystemWideResponses
    public ResponseEntity<ForumGovActionResponse> getForumGovAction(
            @PathVariable String issueNumber,
            @PathVariable String forumType, @PathVariable String agency) {

        ForumGovActionResponse response = forumService.getForumGovAction(issueNumber, forumType, agency);

        if (response != null) {
            return new ResponseEntity<>(response, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping("/fdKickoff")
    @Operation(summary = "Save fd Kickoff", description = "API endpoint to save fd Kickoff")
    @SystemWideResponses
    public ResponseEntity<FDKickoffResponse> fdKickoffSave(@RequestBody FDKickoffRequest fdKickoffRequest) {
        logger.info("Start of fdKickoff in ForumController");
        logger.info("Received fdKickoffRequest: {}", fdKickoffRequest);
        FDKickoffResponse response = forumService.savefdKickoff(fdKickoffRequest);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/fdKickoff/{issueNumber}")
    @Operation(summary = "Get fdKickoff", description = "getfdKickoff by Issue Number")
    @SystemWideResponses
    public ResponseEntity<FDKickoffResponse> fdKickoffget(@PathVariable String issueNumber) {
        logger.info("Fetching Fetching FD Kickoff for issueNumber: {}", issueNumber);
        FDKickoffResponse response = forumService.getfdKickoffByIssueNumber(issueNumber);
        return ResponseEntity.ok(response);
    }

    @PostMapping("forumCorrespondence")
    @Operation(summary = "Create Govt Forum Correspondence", description = "Create Government Forum Correspondence API")
    @SystemWideResponses
    public ResponseEntity<ForumCorrespondenceResponse> forumCorrespondence(@RequestBody ForumCorrespondenceRequest request) {
        ForumCorrespondenceResponse response = forumService.forumCorrespondence(request);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/getForumCorrespondence/{issueNumber}/{forumType}/{agency}")
    @Operation(summary = "Get data from Government Correspondence", description = "GET API to retrieve Government Forum Correspondence data by issue number and forum type")
    @SystemWideResponses
    public ResponseEntity<ForumCorrespondenceResponse> getForumCorrespondence(
            @PathVariable String issueNumber,
            @PathVariable String forumType, @PathVariable String agency) {

        ForumCorrespondenceResponse response = forumService.getForumCorrespondence(issueNumber, forumType, agency);

        if (response != null) {
            return new ResponseEntity<>(response, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    /**
     * REST endpoint to fetch a ForumConfirmRegulatoryImpact by issue number.
     *
     * @param issueNumber the unique issue number used to identify the record
     * @return ForumConfirmRegulatoryImpact matching the given issue number
     */
    @Operation(summary = "Fetch ForumConfirmRegulatoryImpact by issue number", description = "Returns a ForumConfirmRegulatoryImpact object that matches the provided issue number.")
    @GetMapping("/getForumConfirmRegulatoryImpact/{issueNumber}")
    public ResponseEntity<ForumConfirmRegulatoryImpactResponse> getForumConfirmRegulatoryImpact(@PathVariable String issueNumber) {
        return ResponseEntity.ok(forumService.getForumConfirmRegulatoryImpact(issueNumber));
    }

    /**
     * REST endpoint to create and store a new ForumConfirmRegulatoryImpact record.
     *
     * @param request the ForumConfirmRegulatoryImpactRequest object containing the details to be saved
     * @return ResponseEntity containing the saved ForumConfirmRegulatoryImpactResponse with HTTP status CREATED (201)
     */
    @Operation(summary = "Create ForumConfirmRegulatoryImpact", description = "Accepts a ForumConfirmRegulatoryImpactRequest object, saves it in the database, and returns the created ForumConfirmRegulatoryImpactResponse.")
    @PostMapping("/saveForumConfirmRegulatoryImpact")
    public ResponseEntity<ForumConfirmRegulatoryImpactResponse> save(@RequestBody ForumConfirmRegulatoryImpactRequest request) {
        return new ResponseEntity<>(forumService.forumConfirmRegulatoryImpact(request), HttpStatus.OK);
    }

    @GetMapping("/ccrgOnePageSummary/{issueNumber}/{region}")
    @Operation(summary = "Get CCRG Page One Summary", description = "Fetches CCRG One Page Summary by issue number and region")
    @SystemWideResponses
    public ResponseEntity<CCRGOneSummaryResponse> getCCRGOneSummary(
            @PathVariable String issueNumber,
            @PathVariable String region) {
        CCRGOneSummaryResponse response = forumService.getCCRGOneSummary(issueNumber, region);
        if (response != null) {
            return ResponseEntity.ok(response);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @Operation(summary = "Save Forum Status", description = "Accepts a ForumStatusRequest object, saves it in the database, and returns the created ForumStatusResponse.")
    @PostMapping("/saveForumStatus")
    public ResponseEntity<ForumStatusResponse> saveForumStatus(@RequestBody ForumStatusRequest forumStatusRequest) throws GridException {
        return new ResponseEntity<>(forumStatusService.saveForumStatus(forumStatusRequest), HttpStatus.OK);
    }


    @GetMapping({"/getForumStatus/{issueNumber}/{forumType}",
            "/getForumStatus/{issueNumber}/{forumType}/{agency}"})
    @Operation(summary = "Get Forum Status", description = "GET API to retrieve Forum Status data by issue number and forum type")
    @SystemWideResponses
    public ResponseEntity<ForumStatusResponse> getForumStatus(
            @PathVariable String issueNumber,
            @PathVariable String forumType, @PathVariable(required = false) String agency) throws GridException {
        return new ResponseEntity<>(forumStatusService.getForumStatusResponse(issueNumber, forumType, agency), HttpStatus.OK);
    }

    @GetMapping("/getForumStatus/{issueNumber}")
    @Operation(summary = "Get All Forum Status", description = "GET API to retrieve All Forum Status data by issue number")
    @SystemWideResponses
    public ResponseEntity<List<ForumTypeStatus>> getAllForumStatus(
            @PathVariable String issueNumber) throws GridException {
        return new ResponseEntity<>(forumStatusService.getIssueForumStatus(issueNumber), HttpStatus.OK);
    }

    @GetMapping({"/getForumStatusAudit/{issueNumber}/{forumType}",
            "/getForumStatusAudit/{issueNumber}/{forumType}/{agency}"})
    @Operation(summary = "Get Forum Status Audit log for active version", description = "GET API to retrieve Forum Status audit data by issue number and forum type")
    @SystemWideResponses
    public ResponseEntity<List<ForumAuditResponse>> getForumStatusAuditLog(
            @PathVariable String issueNumber,
            @PathVariable String forumType, @PathVariable(required = false) String agency) throws GridException {
        return new ResponseEntity<>(forumStatusService.getForumStatusAuditLogs(issueNumber, forumType, agency), HttpStatus.OK);
    }

    @GetMapping("/getIssuePreviewStatus/{issueNumber}")
    @Operation(summary = "Get Combined Forum, FD, TRG and EMM Status", description = "GET API to retrieve Forum Status, FD Status, Issue TRG Schedule and EMM Schedule data by issue number in a single call")
    @SystemWideResponses
    public ResponseEntity<IssuePreviewStatusResponse> getIssuePreviewStatus(
            @PathVariable String issueNumber) {
        List<ForumTypeStatus> forumStatuses;
        try {
            forumStatuses = forumStatusService.getIssueForumStatus(issueNumber);
        } catch (GridException e) {
            logger.warn("No forum status data found for issueNumber: {}. Returning empty list. Reason: {}", issueNumber, e.getMessage());
            forumStatuses = Collections.emptyList();
        }
        FdStatusResponse fdStatus;
        try {
            fdStatus = fdQuestionnaireService.getFdStatusResponse(issueNumber);
        } catch (GridException e) {
            logger.warn("No FD status data found for issueNumber: {}. Returning empty response. Reason: {}", issueNumber, e.getMessage());
            fdStatus = new FdStatusResponse();
        }
        IssueTrgScheduleResponse issueTrgSchedule;
        try {
            issueTrgSchedule = trgService.getIssueTrgSchedule(issueNumber);
        } catch (Exception e) {
            logger.warn("No TRG schedule data found for issueNumber: {}. Returning empty response. Reason: {}", issueNumber, e.getMessage());
            issueTrgSchedule = new IssueTrgScheduleResponse();
        }
        EmmScheduleResponse emmSchedule;
        try {
            emmSchedule = trgService.getEmmScheduleByKeys(issueNumber);
        } catch (Exception e) {
            logger.warn("No EMM schedule data found for issueNumber: {}. Returning empty response. Reason: {}", issueNumber, e.getMessage());
            emmSchedule = new EmmScheduleResponse();
        }
        return new ResponseEntity<>(new IssuePreviewStatusResponse(forumStatuses, fdStatus, issueTrgSchedule, emmSchedule), HttpStatus.OK);
    }
}

