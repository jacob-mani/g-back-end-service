package com.ford.grid.controller;

import com.ford.grid.model.dto.request.ForumMinutesRequest;
import com.ford.grid.model.dto.response.ForumMinsEprcResponse;
import com.ford.grid.service.ForumMinutesService;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v2/forum-minutes")
public class ForumMinutesController {
    private static final Logger LOGGER = LoggerFactory.getLogger(ForumMinutesController.class);
    private final ForumMinutesService forumMinutesService;

    /**
     * Saves forum minutes based on the provided request.
     *
     * @param request the ForumMinsEprcRequest containing forum minutes details
     * @return ResponseEntity containing the ForumMinsEprcResponse and HTTP status CREATED
     */
    @PostMapping
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MeetingNotes','update')")
    public ResponseEntity<ForumMinsEprcResponse> save(@RequestBody ForumMinutesRequest request) {
        LOGGER.info("Saving forum minutes for issue number: {} and regulation: {}", request.getIssueNumber(), request.getRegulation());
        return new ResponseEntity<>(forumMinutesService.saveByIssueNumberAndReg(request), HttpStatus.CREATED);
    }

    /**
     * Retrieves forum minutes for a given issue number and regulation.
     *
     * @param issueNumber the issue number
     * @param regulation  the regulation
     * @return ResponseEntity containing the ForumMinsEprcResponse and HTTP status OK
     */
    @GetMapping(value = "{issueNumber}/{regulation}")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MeetingNotes','read')")
    public ResponseEntity<ForumMinsEprcResponse> getByIssueNumber(@PathVariable String issueNumber, @PathVariable String regulation) {
        LOGGER.info("Start of getByIssueNumber method in ForumMinutesController");
        LOGGER.info("Issue number: {} and regulation: {}", issueNumber, regulation);

        return new ResponseEntity<>(forumMinutesService.findByIssueNumberAndReg(issueNumber, regulation), HttpStatus.OK);
    }

    /**
     * Deletes forum minutes for a given issue number and regulation.
     *
     * @param issueNumber the issue number
     * @param regulation  the regulation
     * @return ResponseEntity with HTTP status NO_CONTENT if deleted, NOT_FOUND if not found
     */
    @DeleteMapping("/{issueNumber}/{regulation}")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MeetingNotes','update')")
    public ResponseEntity<?> deleteForumMinutes(@PathVariable String issueNumber, @PathVariable String regulation) {
        LOGGER.info("Start of deleteForumMinutes method in ForumMinutesController for issue number: {} and regulation: {}", issueNumber, regulation);

        boolean isForumMinutesDeleted = forumMinutesService.deleteForumMinutes(issueNumber, regulation);
        LOGGER.info("isForumMinutesDeleted: {}", isForumMinutesDeleted);

        if (isForumMinutesDeleted) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Forum minutes not found for " + issueNumber + " and regulation " + regulation);
        }
    }
}