package com.ford.grid.controller.GDIAExport;

import com.ford.grid.common.SystemWideResponses;
import com.ford.grid.exception.GridException;
import com.ford.grid.model.dto.request.EdpFileTransferRequest;
import com.ford.grid.model.dto.response.FilesListResponse;
import com.ford.grid.model.dto.response.JsonUploadResponse;
import com.ford.grid.model.entity.Attachment;
import com.ford.grid.model.entity.FDKickoff;
import com.ford.grid.model.entity.GdiaExportTracker;
import com.ford.grid.model.entity.IssueImplementation;
import com.ford.grid.repository.FDKickoffRepository;
import com.ford.grid.repository.IssueImplementationRepository;
import com.ford.grid.schedule.GDIAJsonExportScheduler;
import com.ford.grid.service.GDIAJsonService;
import io.swagger.v3.oas.annotations.Operation;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@RestController
@AllArgsConstructor
@Slf4j
@RequestMapping("/api/v2/export/edp")
public class GDIAJsonController {

    private final GDIAJsonService gdiaJsonService;
    private final GDIAJsonExportScheduler gdiaJsonExportScheduler;

    // ── LOCAL FILE GENERATION (streaming — no OOM) ──────────────────────────
    // Generates full JSON file locally using MongoDB cursor streaming.
    // No GCS upload, no SharePoint. Safe for large collections.
    //
    // Valid viewName values:
    //   launch, population, repairprofile, fsa, documents, hwparts, forum, swparts, issue
    // ─────────────────────────────────────────────────────────────────────────

    @GetMapping("/local/{viewName}-json")
    @Operation(summary = "[Local] Generate mat view JSON file",
            description = "Streams the specified mat view collection to a local JSON file. "
                    + "No GCS upload. Returns file path and metadata. "
                    + "Valid viewName: launch, population, repairprofile, fsa, documents, hwparts, forum, swparts, issue, issuecontacts")
    public ResponseEntity<Map<String, String>> generateLocalJson(@PathVariable String viewName) {
        try {
            Map<String, String> result = gdiaJsonService.generateLocalJsonFile(viewName);
            if ("FAILED".equals(result.get("status"))) {
                return ResponseEntity.badRequest().body(result);
            }
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("status", "FAILED", "error", e.getMessage()));
        }
    }

    // ── PRODUCTION ENDPOINTS ──────────────────────────────────────────────────

    @PostMapping("/all-part-json")
    @Operation(summary = "Upload Parts Json", description = "testing all parts json")
    @SystemWideResponses
    public void uploadAllPartsJson() throws GridException {
        gdiaJsonService.uploadAllPartsJson();
    }

    @PostMapping("/all-issue-contacts-json")
    @Operation(summary = "Upload View By Issue Contacts Json", description = "Exports view_by_issue_contacts_mat data to GCS and SharePoint")
    @SystemWideResponses
    public ResponseEntity<JsonUploadResponse> uploadViewByIssueContactsJson() throws GridException {
        JsonUploadResponse response = gdiaJsonService.uploadViewByIssueContactsJson();
        HttpStatus status = "SUCCESS".equals(response.getStatus()) ? HttpStatus.OK : HttpStatus.INTERNAL_SERVER_ERROR;
        return ResponseEntity.status(status).body(response);
    }

    @PostMapping("/view-by-population-json")
    @Operation(summary = "Upload View By Population Json", description = "Exports view_by_population data to GCS")
    @SystemWideResponses
    public ResponseEntity<JsonUploadResponse> uploadViewByPopulationJson() {
        JsonUploadResponse response = gdiaJsonService.uploadViewByPopulationJson();
        HttpStatus status = "SUCCESS".equals(response.getStatus()) ? HttpStatus.OK : HttpStatus.INTERNAL_SERVER_ERROR;
        return ResponseEntity.status(status).body(response);
    }

    @PostMapping("/view-by-launch-json")
    @Operation(summary = "Upload View By Launch Json", description = "Exports view_by_launch data to GCS")
    @SystemWideResponses
    public ResponseEntity<JsonUploadResponse> uploadViewByLaunchJson() {
        JsonUploadResponse response = gdiaJsonService.uploadViewByLaunchJson();
        HttpStatus status = "SUCCESS".equals(response.getStatus()) ? HttpStatus.OK : HttpStatus.INTERNAL_SERVER_ERROR;
        return ResponseEntity.status(status).body(response);
    }

    @PostMapping("/view-by-repair-profile-json")
    @Operation(summary = "Upload View By Repair Profile Json", description = "Exports view_by_repairProfile data to GCS")
    @SystemWideResponses
    public ResponseEntity<JsonUploadResponse> uploadViewByRepairProfileJson() {
        JsonUploadResponse response = gdiaJsonService.uploadViewByRepairProfileJson();
        HttpStatus status = "SUCCESS".equals(response.getStatus()) ? HttpStatus.OK : HttpStatus.INTERNAL_SERVER_ERROR;
        return ResponseEntity.status(status).body(response);
    }

    @PostMapping("/view-by-fsa-json")
    @Operation(summary = "Upload View By FSA Json", description = "Exports view_by_fsa data to GCS")
    @SystemWideResponses
    public ResponseEntity<JsonUploadResponse> uploadViewByFsaJson() {
        JsonUploadResponse response = gdiaJsonService.uploadViewByFsaJson();
        HttpStatus status = "SUCCESS".equals(response.getStatus()) ? HttpStatus.OK : HttpStatus.INTERNAL_SERVER_ERROR;
        return ResponseEntity.status(status).body(response);
    }

    @PostMapping("/view-by-documents-json")
    @Operation(summary = "Upload View By Documents Json", description = "Exports view_by_documents data to GCS")
    @SystemWideResponses
    public ResponseEntity<JsonUploadResponse> uploadViewByDocumentsJson() {
        JsonUploadResponse response = gdiaJsonService.uploadViewByDocumentsJson();
        HttpStatus status = "SUCCESS".equals(response.getStatus()) ? HttpStatus.OK : HttpStatus.INTERNAL_SERVER_ERROR;
        return ResponseEntity.status(status).body(response);
    }

    @PostMapping("/view-by-hwparts-json")
    @Operation(summary = "Upload View By HW Parts Json", description = "Exports view_by_hwParts data to GCS")
    @SystemWideResponses
    public ResponseEntity<JsonUploadResponse> uploadViewByHwPartsJson() {
        JsonUploadResponse response = gdiaJsonService.uploadViewByHwPartsJson();
        HttpStatus status = "SUCCESS".equals(response.getStatus()) ? HttpStatus.OK : HttpStatus.INTERNAL_SERVER_ERROR;
        return ResponseEntity.status(status).body(response);
    }

    @PostMapping("/view-by-forum-json")
    @Operation(summary = "Upload View By Forum Json", description = "Exports view_by_forum data to GCS")
    @SystemWideResponses
    public ResponseEntity<JsonUploadResponse> uploadViewByForumJson() {
        JsonUploadResponse response = gdiaJsonService.uploadViewByForumJson();
        HttpStatus status = "SUCCESS".equals(response.getStatus()) ? HttpStatus.OK : HttpStatus.INTERNAL_SERVER_ERROR;
        return ResponseEntity.status(status).body(response);
    }

    @PostMapping("/view-by-swparts-json")
    @Operation(summary = "Upload View By SW Parts Json", description = "Exports view_by_swParts data to GCS")
    @SystemWideResponses
    public ResponseEntity<JsonUploadResponse> uploadViewBySwPartsJson() {
        JsonUploadResponse response = gdiaJsonService.uploadViewBySwPartsJson();
        HttpStatus status = "SUCCESS".equals(response.getStatus()) ? HttpStatus.OK : HttpStatus.INTERNAL_SERVER_ERROR;
        return ResponseEntity.status(status).body(response);
    }

    @PostMapping("/view-by-issue-json")
    @Operation(summary = "Upload View By Issue Json", description = "Exports view_by_issue data to GCS")
    @SystemWideResponses
    public ResponseEntity<JsonUploadResponse> uploadViewByIssueJson() {
        JsonUploadResponse response = gdiaJsonService.uploadViewByIssueJson();
        HttpStatus status = "SUCCESS".equals(response.getStatus()) ? HttpStatus.OK : HttpStatus.INTERNAL_SERVER_ERROR;
        return ResponseEntity.status(status).body(response);
    }

    /**
     * This API will list all  JSON file in the GCS Bucket where we used to upload our json file
     *
     * @return
     */
    @GetMapping("/bucket/files")
    @Operation(summary = "List files in bucket", description = "testing files in edp bucket")
    @SystemWideResponses
    public ResponseEntity<FilesListResponse> listFiles() {
        return new ResponseEntity<>(gdiaJsonService.listOfFiles(), HttpStatus.OK);
    }

    // ── EXPORT STATUS & MANUAL TRIGGER ────────────────────────────────────────

    @GetMapping("/export-status")
    @Operation(summary = "Get GDIA export status for all views",
            description = "Returns the gdia_export_tracker collection showing status, duration, "
                    + "record count, GCS path, and next scheduled time for each view.")
    public ResponseEntity<List<GdiaExportTracker>> getExportStatus() {
        return ResponseEntity.ok(gdiaJsonExportScheduler.getAllExportStatus());
    }

    @PostMapping("/trigger-all-exports")
    @Operation(summary = "Manually trigger all GDIA exports",
            description = "Runs all 10 GDIA view exports sequentially (same as scheduler). "
                    + "Status is tracked in gdia_export_tracker collection. "
                    + "Use GET /export-status to monitor progress.")
    public ResponseEntity<Map<String, String>> triggerAllExports() {
        try {
            // Run in a separate thread so the API returns immediately
            new Thread(() -> gdiaJsonExportScheduler.runAllExports("MANUAL"), "gdia-manual-export").start();
            return ResponseEntity.ok(Map.of(
                    "status", "TRIGGERED",
                    "message", "All GDIA exports triggered. Use GET /api/v2/export/edp/export-status to monitor progress."
            ));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("status", "FAILED", "error", e.getMessage()));
        }
    }

    // ── FILE TRANSFER: GRID BUCKET → EDP BUCKET ───────────────────────────────

    @PostMapping("/factsheet-to-edp")
    @Operation(summary = "Transfer files from GRID bucket to EDP bucket",
            description = "Accepts a list of file transfer requests with documentName and nameInGCP, "
                    + "downloads each from the GRID GCS bucket using nameInGCP, "
                    + "and uploads them to the EDP (GDIA) bucket. Returns per-document status.")
    @SystemWideResponses
    public ResponseEntity<Map<String, String>> transferFilesToEdp(@RequestBody List<EdpFileTransferRequest> fileTransferRequests) {
        if (fileTransferRequests == null || fileTransferRequests.isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("error", "File transfer request list cannot be empty"));
        }
        Map<String, String> results = gdiaJsonService.transferFactsheetPdfToEdp(fileTransferRequests);
        return ResponseEntity.ok(results);
    }

    @PostMapping("/delete-from-edp")
    @Operation(summary = "Transfer files from GRID bucket to EDP bucket",
            description = "Accepts a list of file names, downloads each from the GRID GCS bucket, "
                    + "and uploads them to the EDP (GDIA) bucket. Returns per-file status.")
    @SystemWideResponses
    public ResponseEntity<String> deleteFilesFromEdp() {

        gdiaJsonService.deleteFromEdp();
        return ResponseEntity.ok("success");
    }

    @GetMapping("/fd-schedule/14d-pdf-names")
    @Operation(summary = "Get 14D PDF attachment names from fd_schedule",
            description = "Fetches all fd_schedule documents, checks if the linked issue_implementation "
                    + "has an fsaNumber, and returns matching 14D Document PDF attachment names.")
    public ResponseEntity<String> get14dPdfAttachmentNames() {

        gdiaJsonService.upload14DToEdp();
        return ResponseEntity.ok("success");
    }
}

