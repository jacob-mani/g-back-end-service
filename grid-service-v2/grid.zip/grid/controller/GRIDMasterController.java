package com.ford.grid.controller;

import com.ford.grid.common.SystemWideResponses;
import com.ford.grid.model.dto.request.meetingnotes.WorkLoadRequest;
import com.ford.grid.model.dto.response.*;
import com.ford.grid.model.dto.response.meetingnotes.RegionResponse;
import com.ford.grid.model.entity.*;
import com.ford.grid.service.GRIDMasterService;
import io.swagger.v3.oas.annotations.Operation;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

/**
 * Controller for master data APIs used in the GRID application.
 * Provides endpoints to retrieve issue types, vehicle plant mappings, filter groups, regions, forum types,
 * vehicle years, casual types, vehicle types, lead regions, banner details, and segments.
 */
@RestController
@AllArgsConstructor
@RequestMapping("/api/v2/master")
public class GRIDMasterController {
    private static final Logger LOGGER = LoggerFactory.getLogger(GRIDMasterController.class);

    private GRIDMasterService gridMasterService;

    /**
     * Retrieves all issue types.
     *
     * @return ResponseEntity containing a list of IssueTypeMasterResponse objects.
     */
    @GetMapping("issueTypes")
    @Operation(summary = "Issue-type", description = "Issue type get API")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<List<IssueTypeMasterResponse>> getIssueTypeMaster() {
        return ResponseEntity.ok(gridMasterService.getIssueTypeMaster());
    }

    /**
     * Retrieves vehicle plant mappings.
     *
     * @return ResponseEntity containing a list of VehiclePlantMappingResponse objects.
     */
    @GetMapping("vehiclePlantMapping")
    @Operation(summary = "vehiclePlantMapping", description = "Vehicle Plant Mapping get API")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<List<VehiclePlantMappingResponse>> getVehiclePlantMapping() {
        return ResponseEntity.ok(gridMasterService.getVehiclePlantMapping());
    }

    /**
     * Retrieves non-WERS filter groups.
     *
     * @return ResponseEntity containing a list of NonWERSFilterGroupsResponse objects.
     */
    @GetMapping("nonWersFilterGroups")
    @Operation(summary = "nonWERSFilterGroups", description = "nonWERSFilterGroups get API")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<List<NonWERSFilterGroupsResponse>> getNonWERSFilterGroups() {
        return ResponseEntity.ok(gridMasterService.getNonWERSFilterGroups());
    }

    /**
     * Retrieves region-country mappings.
     *
     * @return ResponseEntity containing a list of MarketRegionModel objects.
     */
    @GetMapping("regionCountryMapping")
    @Operation(summary = "regionCountryMapping", description = "regionCountryMapping get API")
    @Cacheable("regionCountryMapping")
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<List<MarketRegionModel>> getRegionCountryMapping() {
        return ResponseEntity.ok(gridMasterService.getRegionCountryMapping());
    }

    /**
     * Retrieves forum types.
     *
     * @return ResponseEntity containing a list of ForumTypeResponse objects.
     */
    @GetMapping(value = "forumTypes", produces = MediaType.APPLICATION_JSON_VALUE)
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<List<ForumTypeResponse>> getForumTypes() {
        LOGGER.debug("Start of getForumTypes in GRIDMasterController");
        return ResponseEntity.ok(gridMasterService.getForumType());
    }
    //test

    /**
     * Retrieves Agenda types.
     *
     * @return ResponseEntity containing a list of AgendaTypeResponse objects.
     */
    @GetMapping(value = "agendaTypes", produces = MediaType.APPLICATION_JSON_VALUE)
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<List<AgendaTypeResponse>> getAgendaTypes() {
        LOGGER.debug("Start of getAgendaTypes in GRIDMasterController");
        return ResponseEntity.ok(gridMasterService.getAgendaType());
    }

    /**
     * Retrieves vehicle model years.
     *
     * @return ResponseEntity containing a list of VehicleModelYearResponse objects.
     */
    @GetMapping(value = "vehicleYear", produces = MediaType.APPLICATION_JSON_VALUE)
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<List<VehicleModelYearResponse>> getVehicleYears() {
        LOGGER.debug("Start of getVehicleYears in GRIDMasterController");
        return ResponseEntity.ok(gridMasterService.getVehicleModelYears());
    }

    /**
     * Retrieves casual types.
     *
     * @return ResponseEntity containing a list of CasualTypeResponse objects.
     */
    @GetMapping(value = "casualTypes", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<CasualTypeResponse>> getCasualTypes() {
        LOGGER.debug("Start of getCasualTypes in GRIDMasterController");
        return ResponseEntity.ok(gridMasterService.getCasualType());
    }

    /**
     * Retrieves vehicle types.
     *
     * @return ResponseEntity containing a list of VehicleTypesResponse objects.
     */
    @GetMapping(value = "vehicleTypes", produces = MediaType.APPLICATION_JSON_VALUE)
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<List<VehicleTypesResponse>> getVehicleTypes() {
        LOGGER.debug("Start of getVehicleTypes in GRIDMasterController");
        return ResponseEntity.ok(gridMasterService.getVehicleTypes());
    }

    /**
     * Retrieves lead regions.
     *
     * @return ResponseEntity containing a list of LeadRegionsResponse objects.
     */
    @GetMapping(value = "leadRegions", produces = MediaType.APPLICATION_JSON_VALUE)
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<List<LeadRegionsResponse>> getLeadRegions() {
        LOGGER.debug("Start of getLeadRegions in GRIDMasterController");
        return ResponseEntity.ok(gridMasterService.getLeadRegions());
    }

    /**
     * Retrieves banner details.
     *
     * @return ResponseEntity containing BannerDetailsResponse if found, otherwise throws RuntimeException.
     */
    @GetMapping(value = "banner", produces = MediaType.APPLICATION_JSON_VALUE)
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<?> getBannerDetails() {
        LOGGER.debug("Start of getBannerDetails in GRIDMasterController");

        Optional<BannerDetailsResponse> bannerDetails = gridMasterService.getBannerDetails().stream().findFirst();
        BannerDetailsResponse bannerDetailsResponse = bannerDetails.orElseThrow(() -> new RuntimeException("Banner details not found"));
        LOGGER.debug("Banner Details : {}", bannerDetailsResponse);

        return ResponseEntity.ok(bannerDetailsResponse);
    }

    /**
     * Retrieves segments by lead region key.
     *
     * @param leadRegionKey the key of the lead region
     * @return ResponseEntity containing a list of segments for the specified lead region.
     */
    @GetMapping(value = "segments/{leadRegionKey}", produces = MediaType.APPLICATION_JSON_VALUE)
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<?> getSegmentsByLeadRegionKey(@PathVariable final String leadRegionKey) {
        LOGGER.debug("Start of getSegmentsByLeadRegionKey in GRIDMasterController");
        return ResponseEntity.ok(gridMasterService.getApplicationVehicleSegmentsByRegion(leadRegionKey));
    }

    /**
     * Retrieves all segments.
     *
     * @return ResponseEntity containing a list of SegmentsResponse objects.
     */
    @GetMapping(value = "segments", produces = MediaType.APPLICATION_JSON_VALUE)
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<List<SegmentsResponse>> getAllSegments() {
        LOGGER.debug("Start of getAllSegments in GRIDMasterController");
        return ResponseEntity.ok(gridMasterService.getAllSegments());
    }

    /**
     * Retrieves vehicle feature mappings.
     *
     * @return ResponseEntity containing a list of VehicleFeatureMappingResponse objects.
     */
    @GetMapping(value = "vehicleFeatureMapping", produces = MediaType.APPLICATION_JSON_VALUE)
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<List<VehicleFeatureMappingResponse>> getVehicleFeatureMapping(@RequestParam final String vehicleIds, @RequestParam final String filterGroupCode) {
        LOGGER.info("Start of getVehicleFeatureMapping in GRIDMasterController");
        return ResponseEntity.ok(gridMasterService.getVehicleFeaturesByGroupCode(vehicleIds, filterGroupCode));
    }

    /**
     * Retrieves filters by group code.
     *
     * @param filterGroupCode the filter group code
     * @return ResponseEntity containing a list of FilterResponse objects.
     */
    @GetMapping(value = "vehicleAttributeFilterCode", produces = MediaType.APPLICATION_JSON_VALUE)
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<List<FilterResponse>> getFilterByGroupsCode(@RequestParam final String filterGroupCode) {
        LOGGER.info("Start of getFilterByGroupsCode in GRIDMasterController");
        return ResponseEntity.ok(gridMasterService.getFiltersByGroupCode(filterGroupCode));
    }

    /**
     * REST endpoint to fetch all vehicle codes.
     *
     * @return List of VehicleCodes objects stored in the database
     */
    @Operation(summary = "REST endpoint to fetch all vehicle codes.", description = "Returns a list of VehicleCodes objects stored in the database.")
    @GetMapping("/vehicleCodes")
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<List<VehicleCodes>> getAllVehicleCodes() {
        return ResponseEntity.ok(gridMasterService.getAllVehicleCodes());
    }

    /**
     * REST endpoint to fetch all state provinces.
     *
     * @return List of state provinces stored in the database
     */
    @Operation(summary = "Fetch all state provinces", description = "Returns a list of state provinces stored in the database.")
    @GetMapping("/stateProvinces")
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<List<StateProvince>> getAllStateProvinces() {
        return ResponseEntity.ok(gridMasterService.getAllStateProvinces());
    }

    /**
     * REST endpoint to fetch all issueStagestatuses.
     *
     * @return List of issueStagestatuses stored in the database
     */
    @Operation(summary = "Fetch all issue stage statuses", description = "Returns a list of issue stage statuses stored in the database.")
    @GetMapping("/issueStageStatus")
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<List<IssueStageStatus>> getAllIssueStageStatus() {
        return ResponseEntity.ok(gridMasterService.getAllIssueStageStatus());
    }

    /**
     * REST endpoint to fetch all issueSourceTypes.
     *
     * @return List of issueSourceTypes stored in the database
     */
    @Operation(summary = "Fetch all issueSourceTypes", description = "Returns a list of issueSourceTypes stored in the database.")
    @GetMapping("/issueSourceTypes")
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<List<IssueSourceType>> getAllIssueSourceTypes() {
        return ResponseEntity.ok(gridMasterService.getAllIssueSourceTypes());
    }

    /**
     * REST endpoint to fetch all issueFunctions.
     *
     * @return List of issueFunctions stored in the database
     */
    @Operation(summary = "Fetch all issueFunctions", description = "Returns a list of issueFunctions stored in the database.")
    @GetMapping("/issueFunctions")
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<List<IssueFunction>> getAllIssueFunctions() {
        return ResponseEntity.ok(gridMasterService.getAllIssueFunctions());
    }

    /**
     * REST endpoint to fetch all potentialTypes.
     *
     * @return List of potentialTypes stored in the database
     */
    @Operation(summary = "Fetch all potentialTypes", description = "Returns a list of potentialTypes stored in the database.")
    @GetMapping("/potentialTypes")
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<List<PotentialType>> getAllPotentialTypes() {
        return ResponseEntity.ok(gridMasterService.getAllPotentialTypes());
    }

    /**
     * REST endpoint to fetch all statuses.
     *
     * @return List of statuses stored in the database
     */
    @Operation(summary = "Fetch all statuses", description = "Returns a list of statuses stored in the database.")
    @GetMapping("/issue_status")
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<List<Status>> getAllStatus() {
        return ResponseEntity.ok(gridMasterService.getAllStatus());
    }

    @GetMapping("/getAllCommodities")
    @Operation(summary = "Get All commodity", description = "commodities Get API")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<List<Commodities>> getAllCommodities() {
        return ResponseEntity.ok(gridMasterService.getAllCommodities());
    }


    @GetMapping("/getTrgPurposeType")
    @Operation(summary = "Get All TRG Purpose Type", description = "TRG Purpose Type Get API")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<List<TrgPurposeType>> getTRGPurposeType() {
        return ResponseEntity.ok(gridMasterService.getTRGPurposeType());
    }

    @GetMapping("/getTrgType")
    @Operation(summary = "Get All TRG Options", description = "TRG Options Get API")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<List<TrgOptions>> getTRGOptions() {
        return ResponseEntity.ok(gridMasterService.getTRGOptions());
    }

    @GetMapping("/getTrgDuration")
    @Operation(summary = "Get All TRG Duration", description = "TRG Duration Get API")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<List<TrgDuration>> getTRGDuration() {
        return ResponseEntity.ok(gridMasterService.getTRGDuration());
    }

    @GetMapping("/getStatusOption")
    @Operation(summary = "Get All Status Options", description = "Status Options Get API")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<List<StatusOption>> getStatusOption() {
        return ResponseEntity.ok(gridMasterService.getAllStatusOptions());
    }

    @GetMapping("/getDefectCategory")
    @Operation(summary = "Get All Defect Category", description = "Defect Category Get API")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<List<DefectCategory>> getDefectCategory() {
        return ResponseEntity.ok(gridMasterService.getAllDefectCategory());
    }

    @GetMapping("/getRegulations")
    @Operation(summary = "Get All Regulations", description = "Regulations Get API")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<List<Regulations>> getRegulations() {
        return ResponseEntity.ok(gridMasterService.getAllRegulations());
    }

    @GetMapping("/getTrgStatus")
    @Operation(summary = "Get All TRG Status", description = "TRG Status Get API")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<List<TrgStatus>> getTrgStatus() {
        return ResponseEntity.ok(gridMasterService.getAllTrgStatus());
    }

    @GetMapping("/getTrgImgTimeZone")
    @Operation(summary = "Get TRG Image Time Zone", description = "TRG Image Time Zone Get API")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<List<TrgTimeZone>> getTrgImgTimeZone() {
        return ResponseEntity.ok(gridMasterService.getAllTrgImgTimeZone());
    }

    @GetMapping("/getRegionalParticipation")
    @Operation(summary = "Get Regional Participation", description = "Regional Participation Get API")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<List<RegionalParticipation>> getRegionalParticipation() {
        return ResponseEntity.ok(gridMasterService.getAllRegionalParticipation());
    }

    @GetMapping("/getCcrgTeam")
    @Operation(summary = "Get CCRG Team", description = "CCRG Team Get API")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<List<CcrgTeam>> getCcrgTeam() {
        return ResponseEntity.ok(gridMasterService.getAllCcrgTeam());
    }

    @GetMapping("/getAllPlants")
    @Operation(summary = "Get Plants", description = "Plants Get API")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<List<AddressOfPlants>> getPlants() {
        return ResponseEntity.ok(gridMasterService.getAllPlants());
    }

    @GetMapping("/getDefects")
    @Operation(summary = "Get Defects", description = "Defects Get API")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<List<Defects>> getDefects() {
        return ResponseEntity.ok(gridMasterService.getAllDefects());
    }

    @GetMapping("/getSalesAreas")
    @Operation(summary = "Get Sales Areas", description = "Sales Areas Get API")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<List<SalesArea>> getSalesAreas() {
        return ResponseEntity.ok(gridMasterService.getAllSalesAreas());
    }

    /**
     * Retrieves Dealer Bulletin Notification Types with dynamic Editorial Supplements.
     * Pass currentSupplementCount to get the next available supplement option.
     *
     * @param currentSupplementCount current count of selected editorial supplements (default 0)
     * @return ResponseEntity containing a list of LaunchNotificationTypeResponse objects
     */
    @GetMapping("/getDealerBulletinNotificationTypes")
    @Operation(summary = "Get Dealer Bulletin Notification Types",
            description = "Get Dealer Bulletin Notification Types with dynamic Editorial Supplement options. Pass currentSupplementCount to show next available supplement.")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<List<LaunchNotificationTypeResponse>> getDealerBulletinNotificationTypes(
            @RequestParam(defaultValue = "0") Integer currentSupplementCount) {
        LOGGER.info("GET /api/v2/master/getDealerBulletinNotificationTypes with currentSupplementCount: {}", currentSupplementCount);
        return ResponseEntity.ok(gridMasterService.getDealerBulletinNotificationTypes(currentSupplementCount));
    }

    /**
     * Retrieves Owner Notification Types with dynamic Editorial Supplements.
     * Pass currentSupplementCount to get the next available supplement option.
     *
     * @param currentSupplementCount current count of selected editorial supplements (default 0)
     * @return ResponseEntity containing a list of NotificationTypeResponse objects
     */
    @GetMapping("/getOwnerNotificationTypes")
    @Operation(summary = "Get Owner Notification Types",
            description = "Get Owner Notification Types with dynamic Editorial Supplement options. Pass currentSupplementCount to show next available supplement.")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<List<LaunchNotificationTypeResponse>> getOwnerNotificationTypes(
            @RequestParam(defaultValue = "0") Integer currentSupplementCount) {
        LOGGER.info("GET /api/v2/master/getOwnerNotificationTypes with currentSupplementCount: {}", currentSupplementCount);
        return ResponseEntity.ok(gridMasterService.getOwnerNotificationTypes(currentSupplementCount));
    }

    /**
     * Retrieves Reason For Delay options.
     *
     * @return ResponseEntity containing a list of MasterOptionResponse objects
     */
    @GetMapping("/getReasonForDelay")
    @Operation(summary = "Get Reason For Delay", description = "Get Reason For Delay options")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<List<MasterOptionResponse>> getReasonForDelay() {
        LOGGER.info("GET /api/v2/master/getReasonForDelay");
        return ResponseEntity.ok(gridMasterService.getReasonForDelay());
    }

    /**
     * Retrieves Reason For Supplement options.
     *
     * @return ResponseEntity containing a list of MasterOptionResponse objects
     */
    @GetMapping("/getReasonForSupplement")
    @Operation(summary = "Get Reason For Supplement", description = "Get Reason For Supplement options")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<List<MasterOptionResponse>> getReasonForSupplement() {
        LOGGER.info("GET /api/v2/master/getReasonForSupplement");
        return ResponseEntity.ok(gridMasterService.getReasonForSupplement());
    }

    /**
     * Retrieves Repair Details options.
     *
     * @return ResponseEntity containing a list of MasterOptionResponse objects
     */
    @GetMapping("/getRepairDetails")
    @Operation(summary = "Get Repair Details", description = "Get Repair Details options")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<List<MasterOptionResponse>> getRepairDetails() {
        LOGGER.info("GET /api/v2/master/getRepairDetails");
        return ResponseEntity.ok(gridMasterService.getRepairDetails());
    }

    /**
     * Retrieves Mail Tracking Status options.
     *
     * @return ResponseEntity containing a list of MasterOptionResponse objects
     */
    @GetMapping("/getMailTrackingStatus")
    @Operation(summary = "Get Mail Tracking Status", description = "Get Mail Tracking Status options")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<List<MasterOptionResponse>> getMailTrackingStatus() {
        LOGGER.info("GET /api/v2/master/getMailTrackingStatus");
        return ResponseEntity.ok(gridMasterService.getMailTrackingStatus());
    }

    /**
     * Retrieves FSA numbers by issue number.
     *
     * @param issueNumber the issue number
     * @return ResponseEntity containing a list of FsaNumberResponse objects.
     */
    @GetMapping("/fsaNumbers/{issueNumber}")
    @Operation(summary = "Get FSA Numbers by Issue Number", description = "Get FSA Numbers by Issue Number")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<FsaNumberResponse> getFsaNumbersByIssueNumber(@PathVariable String issueNumber) {
        return ResponseEntity.ok(gridMasterService.getFsaNumbersByIssueNumber(issueNumber));
    }

    /**
     * Retrieves regions by issue number.
     *
     * @param issueNumber the issue number
     * @return ResponseEntity containing a list of RegionResponse objects.
     */
    @GetMapping("/regions/{issueNumber}")
    @Operation(summary = "Get Regions by Issue Number", description = "Get Regions by Issue Number")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<List<RegionResponse>> getRegionsByIssue(@PathVariable String issueNumber) {
        return ResponseEntity.ok(gridMasterService.getRegionsByIssue(issueNumber));
    }

    /**
     * Fetches all roles.
     *
     * @return List of RoleResponse objects stored in the database
     */

    @GetMapping("/roles")
    @Operation(summary = "Get all Roles", description = "Get all Roles")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<List<RoleResponse>> getAllRoles() {
        return ResponseEntity.ok(gridMasterService.getAllRoles());
    }

    @GetMapping("/getAllWorkLoads")
    @Operation(summary = "Get all WorkLoad", description = "Get all WorkLoad")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<List<WorkLoadResponse>> getAllWorkLoads() {
        return ResponseEntity.ok(gridMasterService.getAllWorkLoads());
    }

    @PostMapping("/saveWorkLoad")
    @Operation(summary = "Create WorkLoad", description = "Create a new WorkLoad entry")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'write','GRID:AllIssues':'write','GRID:IssueList':'write'})")
    public ResponseEntity<WorkLoadResponse> createWorkLoad(@RequestBody WorkLoadRequest workLoadRequest) {
        if (workLoadRequest == null
                || workLoadRequest.getKey() == null || workLoadRequest.getKey().isBlank()
                || workLoadRequest.getValue() == null || workLoadRequest.getValue().isBlank()) {
            LOGGER.warn("Invalid createWorkLoad request received in GRIDMasterController");
            return ResponseEntity.badRequest().build();
        }
        LOGGER.info("Start of createWorkLoad method in GRIDMasterController with key: {}", workLoadRequest.getKey());
        WorkLoadResponse response = gridMasterService.saveWorkLoad(workLoadRequest);
        LOGGER.info("End of createWorkLoad method in GRIDMasterController");
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }


    /**
     * Retrieves all EMM TR Types from the master data collection.
     *
     * <p>EMM TR Types define the category of an EMM Agenda item.
     * Example values: "Safety EMM", "Customer Satisfaction EMM",
     * "EPRC EMM", "TR/Other".</p>
     *
     * @return {@code 200 OK} with a list of {@link EmmTrTypeResponse} objects
     * containing the {@code key} and {@code value} for each EMM TR Type
     */
    @GetMapping("/emmTrType")
    @Operation(summary = "Get all EMM TR Types", description = "Get all EMM TR Types")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:IssueList','read')")
    public ResponseEntity<List<EmmTrTypeResponse>> getAllEmmTrTypes() {
        LOGGER.info("Start of getAllEmmTrTypes in GRIDMasterController");
        List<EmmTrTypeResponse> response = gridMasterService.getAllEmmTrTypes();
        LOGGER.info("End of getAllEmmTrTypes in GRIDMasterController - returning {} record(s)", response.size());
        return ResponseEntity.ok(response);
    }

    /**
     * Retrieves all EMM Types from the master data collection.
     *
     * <p>EMM Types define the agenda classification of an EMM meeting item.
     * Example values: "Investigation Awareness", "Investigation Support Required",
     * "FSA Implementation", "Emerging Concern".</p>
     *
     * @return {@code 200 OK} with a list of {@link EmmTypeResponse} objects
     * containing the {@code key} and {@code value} for each EMM Type
     */
    @GetMapping("/emmType")
    @Operation(summary = "Get all EMM Types", description = "Get all EMM Types")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:IssueList','read')")
    public ResponseEntity<List<EmmTypeResponse>> getAllEmmTypes() {
        LOGGER.info("Start of getAllEmmTypes in GRIDMasterController");
        List<EmmTypeResponse> response = gridMasterService.getAllEmmTypes();
        LOGGER.info("End of getAllEmmTypes in GRIDMasterController - returning {} record(s)", response.size());
        return ResponseEntity.ok(response);
    }

    /**
     * Fetches all part allocation options.
     *
     * @return List of PartAllocation objects stored in the database
     */
    @GetMapping("/partAllocations")
    @Operation(summary = "Get all Part Allocation options", description = "Part Allocation master data get API")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<List<PartAllocation>> getAllPartAllocations() {
        return ResponseEntity.ok(gridMasterService.getAllPartAllocations());
    }

    /**
     * Fetches all purchasing support request options.
     *
     * @return List of PurchasingSupportReq objects stored in the database
     */
    @GetMapping("/purchasingSupportReqs")
    @Operation(summary = "Get all Purchasing Support Request options", description = "Purchasing Support Request master data get API")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<List<PurchasingSupportReq>> getAllPurchasingSupportReqs() {
        return ResponseEntity.ok(gridMasterService.getAllPurchasingSupportReqs());
    }

    /**
     * Fetches all freight method options.
     *
     * @return List of FreightMethod objects stored in the database
     */
    @GetMapping("/freightMethods")
    @Operation(summary = "Get all Freight Method options", description = "Freight Method master data get API")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<List<FreightMethod>> getAllFreightMethods() {
        return ResponseEntity.ok(gridMasterService.getAllFreightMethods());
    }

    /**
     * Fetches all SCM rating options.
     *
     * @return List of ScmRating objects stored in the database
     */
    @GetMapping("/scmRatings")
    @Operation(summary = "Get all SCM Rating options", description = "SCM Rating master data get API")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<List<ScmRating>> getAllScmRatings() {
        return ResponseEntity.ok(gridMasterService.getAllScmRatings());
    }

    /**
     * Fetches all escalation leadership options.
     *
     * @return List of EscalationLeadership objects stored in the database
     */
    @GetMapping("/escalationLeaderships")
    @Operation(summary = "Get all Escalation Leadership options", description = "Escalation Leadership master data get API")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<List<EscalationLeadership>> getAllEscalationLeaderships() {
        return ResponseEntity.ok(gridMasterService.getAllEscalationLeaderships());
    }

    /**
     * Retrieves all Issue Phase types from the master data collection.
     *
     * <p>Issue Phase types represent the different phases an issue can go through
     * (e.g. "Investigation", "14D", "TRG", "FRC", "Launch").</p>
     *
     * @return {@code 200 OK} with a list of {@link IssuePhaseResponse} objects
     * containing the {@code key} and {@code value} for each Issue Phase
     */
    @GetMapping("/issuePhases")
    @Operation(summary = "Get all Issue Phases", description = "Issue Phase master data get API")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:IssueList','read')")
    public ResponseEntity<List<IssuePhaseResponse>> getAllIssuePhases() {
        LOGGER.info("Start of getAllIssuePhases in GRIDMasterController");
        List<IssuePhaseResponse> response = gridMasterService.getAllIssuePhases();
        LOGGER.info("End of getAllIssuePhases in GRIDMasterController - returning {} record(s)", response.size());
        return ResponseEntity.ok(response);
    }

    /**
     * Fetches all meeting export types.
     *
     * @return List of MeetingExportTypeResponse objects stored in the database
     */
    @GetMapping("/meetingExportTypes")
    @Operation(summary = "Get all Meeting Export Types", description = "Meeting Export Types master data get API")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:IssueList','read')")
    public ResponseEntity<List<MeetingExportTypeResponse>> getAllMeetingExportTypes() {
        LOGGER.info("Start of getAllMeetingExportTypes in GRIDMasterController");
        List<MeetingExportTypeResponse> response = gridMasterService.getAllMeetingExportTypes();
        LOGGER.info("End of getAllMeetingExportTypes in GRIDMasterController - returning {} record(s)", response.size());
        return ResponseEntity.ok(response);
    }

    /**
     * Fetches all meeting export interval options.
     *
     * @return List of MeetingExportIntervalResponse objects stored in the database
     */
    @GetMapping("/meetingExportIntervals")
    @Operation(summary = "Get all Meeting Export Intervals", description = "Meeting Export Intervals master data get API")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:IssueList','read')")
    public ResponseEntity<List<MeetingExportIntervalResponse>> getAllMeetingExportIntervals() {
        LOGGER.info("Start of getAllMeetingExportIntervals in GRIDMasterController");
        List<MeetingExportIntervalResponse> response = gridMasterService.getAllMeetingExportIntervals();
        LOGGER.info("End of getAllMeetingExportIntervals in GRIDMasterController - returning {} record(s)", response.size());
        return ResponseEntity.ok(response);
    }

    /**
     * Fetches all hide issues options.
     *
     * @return List of HideIssuesOptionResponse objects stored in the database
     */
    @GetMapping("/hideIssuesOptions")
    @Operation(summary = "Get all Hide Issues Options", description = "Hide Issues Options master data get API")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:IssueList','read')")
    public ResponseEntity<List<HideIssuesOptionResponse>> getAllHideIssuesOptions() {
        LOGGER.info("Start of getAllHideIssuesOptions in GRIDMasterController");
        List<HideIssuesOptionResponse> response = gridMasterService.getAllHideIssuesOptions();
        LOGGER.info("End of getAllHideIssuesOptions in GRIDMasterController - returning {} record(s)", response.size());
        return ResponseEntity.ok(response);
    }

    @GetMapping(value = "wersSearch", produces = MediaType.APPLICATION_JSON_VALUE)
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<List<VehicleFeatureMappingResponse>> getWERSSearch(@RequestParam final String vehicleIds, @RequestParam final String filterGroupCode, @RequestParam final String searchString) {
        LOGGER.info("Start of getWERSSearch in GRIDMasterController");

        List<VehicleFeatureMappingResponse> vehicleFeaturesByGroupCode = gridMasterService.getVehicleFeaturesByGroupCode(vehicleIds, filterGroupCode);
        return ResponseEntity.ok(gridMasterService.getWERSCode(vehicleFeaturesByGroupCode, searchString));
    }
}