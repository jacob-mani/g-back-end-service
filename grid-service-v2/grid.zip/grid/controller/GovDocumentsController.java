package com.ford.grid.controller;


import com.ford.grid.common.SystemWideResponses;
import com.ford.grid.exception.GridException;
import com.ford.grid.model.dto.request.GovDocDownloadRequest;
import com.ford.grid.model.dto.request.Part573AIRequest;
import com.ford.grid.model.dto.request.Part573AIUpdateRequest;
import com.ford.grid.model.dto.request.Part573ApprovalRequest;
import com.ford.grid.model.dto.request.Part573Request;
import com.ford.grid.model.dto.response.*;
import com.ford.grid.service.GovDocumentsService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import java.io.IOException;


@RestController
@RequestMapping("/api/v2/govDocuments")
@Validated
public class GovDocumentsController {
    private static final Logger LOGGER = LoggerFactory.getLogger(GovDocumentsController.class);

    @Autowired
    GovDocumentsService govDocumentsService;

    @PostMapping("/createPart573Doc")
    @Operation(summary = "Part573 Document", description = "Create Part573 Document")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<Part573Response> createPart573Doc(@Valid @RequestBody Part573Request req) throws GridException {
        Part573Response response = govDocumentsService.createPart573Doc(req);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("getPart573Doc/{issueNumber}/{implId}/{popId}")
    @Operation(summary = "Part573Doc", description = "Get Part 573 Document by issue number")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<Part573Response> getPart573Doc(@PathVariable String issueNumber, @PathVariable String implId, @PathVariable String popId) {
        return ResponseEntity.ok(govDocumentsService.getPart573Doc(issueNumber, implId, popId));

    }

    @GetMapping("/downloadPart573File")
    @Operation(summary = "part573 Document", description = "Download part573 Document")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<StreamingResponseBody> downloadPart573File(
            @RequestParam String issueNumber,
            @RequestParam String implId,
            @RequestParam String populationId,
            @RequestParam(defaultValue = "false") Boolean draft) throws IOException, GridException {

        GovDocDownloadRequest request = new GovDocDownloadRequest();
        request.setIssueNumber(issueNumber);
        request.setImplId(implId);
        request.setPopulationId(populationId);
        request.setDraft(draft);

        return govDocumentsService.downloadPart573File(request);
    }

    @PostMapping("/createTcDefectDoc")
    @Operation(summary = "TC Defect Document", description = "Create TC Defect Document")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<TcDocResponse> createTcDefectDoc(@Valid @RequestBody Part573Request req) throws GridException {
        TcDocResponse response = govDocumentsService.createTcDefectDoc(req);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("getTcDoc/{issueNumber}/{implId}/{popId}")
    @Operation(summary = "Tc Document", description = "Get Tc Document by issue number")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<TcDocResponse> getTcDoc(@PathVariable String issueNumber, @PathVariable String implId, @PathVariable String popId) {
        return ResponseEntity.ok(govDocumentsService.getTcDoc(issueNumber, implId, popId));
    }

    @GetMapping("/downloadTcFile")
    @Operation(summary = "TC Document", description = "Download TC Document")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<StreamingResponseBody> downloadTcFile(
            @RequestParam String issueNumber,
            @RequestParam String implId,
            @RequestParam String populationId,
            @RequestParam(defaultValue = "false") Boolean draft) throws IOException, GridException {

        GovDocDownloadRequest request = new GovDocDownloadRequest();
        request.setIssueNumber(issueNumber);
        request.setImplId(implId);
        request.setPopulationId(populationId);
        request.setDraft(draft);

        return govDocumentsService.downloadTcFile(request);
    }


    @PutMapping("/part573DocApproval")
    @Operation(summary = "Approve Part573 Document", description = "Handle Part573 Document approval/rejection workflow")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<Part573Response> part573DocApproval(@Valid @RequestBody Part573ApprovalRequest request) throws GridException {
        Part573Response response = govDocumentsService.part573DocApproval(request);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PutMapping("/tcDocApproval")
    @Operation(summary = "Approve TC Document", description = "Handle TC Document approval/rejection workflow")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<TcDocResponse> tcDocApproval(@Valid @RequestBody Part573ApprovalRequest request) throws GridException {
        TcDocResponse response = govDocumentsService.tcDocApproval(request);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/get-envelope-status/{envelopeId}")
    @Operation(summary = "Get DocuSign Envelope Status (Part573)",
            description = "Get DocuSign envelope status for a Part573 document")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<DocuSignEnvelope> getEnvelopeStatus(@PathVariable String envelopeId) throws GridException {
        LOGGER.info("Get Part573 envelope status - envelopeId: {}", envelopeId);
        DocuSignEnvelope result = govDocumentsService.getDocusignedEnvelopeStatus(envelopeId);
        if (result == null) {
            LOGGER.error("getDocusignedEnvelopeStatus returned null for envelopeId: {}", envelopeId);
            throw new GridException(HttpStatus.BAD_GATEWAY, "DocuSign Error",
                    "Failed to retrieve envelope status from DocuSign for envelopeId: " + envelopeId
                            + ". Check server logs for details (PEM key path, access token, or DocuSign API error).");
        }
        return ResponseEntity.ok(result);
    }

    @GetMapping("/get-tc-envelope-status/{envelopeId}")
    @Operation(summary = "Get DocuSign Envelope Status (TC)",
            description = "Get DocuSign envelope status for a Transport Canada document")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<DocuSignEnvelope> getTcEnvelopeStatus(@PathVariable String envelopeId) throws GridException {
        LOGGER.info("Get TC envelope status - envelopeId: {}", envelopeId);
        DocuSignEnvelope result = govDocumentsService.getTcDocusignedEnvelopeStatus(envelopeId);
        if (result == null) {
            LOGGER.error("getTcDocusignedEnvelopeStatus returned null for envelopeId: {}", envelopeId);
            throw new GridException(HttpStatus.BAD_GATEWAY, "DocuSign Error",
                    "Failed to retrieve TC envelope status from DocuSign for envelopeId: " + envelopeId
                            + ". Check server logs for details (PEM key path, access token, or DocuSign API error).");
        }
        return ResponseEntity.ok(result);
    }

    @PutMapping("/changePermissions")
    @Operation(summary = "Change Permission for GovDoc", description = "Change permission type for a user on government document")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<DocResponse> changePermissions(
            @RequestParam String fileName,
            @RequestParam String cdsId,
            @RequestParam String oldType,
            @RequestParam String newType) throws GridException {
        DocResponse response = govDocumentsService.changePermission(fileName, cdsId, oldType, newType);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PostMapping("/addPermission")
    @Operation(summary = "Add Single Permission for GovDoc", description = "Add permission for a single user on government document")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<DocResponse> addSinglePermission(
            @RequestParam String fileName,
            @RequestParam String cdsId,
            @RequestParam String permissionType) throws GridException {
        DocResponse response = govDocumentsService.addPermission(fileName, cdsId, permissionType, false);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @DeleteMapping("/removePermission")
    @Operation(summary = "Remove Single Permission for GovDoc", description = "Remove permission for a single user on government document")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<DocResponse> removeSinglePermission(
            @RequestParam String fileName,
            @RequestParam String cdsId,
            @RequestParam String permissionType) throws GridException {
        DocResponse response = govDocumentsService.removePermission(fileName, cdsId, permissionType, false);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PostMapping("/getPart573AIResponse")
    @Operation(summary = "Get Part573 AI Response", description = "Get AI-generated response for Part573 document")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<Part573AIResponse> getPart573AIResponse(@Valid @RequestBody Part573AIRequest pdfRequest, HttpServletRequest request) throws GridException {
        Part573AIResponse response = govDocumentsService.getPart573AIResponse(pdfRequest, request);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PostMapping("/updatePart573AIResponse")
    @Operation(summary = "Update Part573 AI Response", description = "Update AI-generated response for Part573 document")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<Part573AIResponse> updatePart573AIResponse(@Valid @RequestBody Part573AIUpdateRequest request) {
        Part573AIResponse response = govDocumentsService.updatePart573AIResponse(request);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

}