package com.ford.grid.controller;

import com.ford.grid.common.SystemWideResponses;
import com.ford.grid.constants.AzureAuthConstants;
import com.ford.grid.model.entity.UserDetails;
import com.ford.grid.service.GridUserService;
import com.ford.grid.util.SharePointUtil;
import io.swagger.v3.oas.annotations.Operation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v2/grid-user")
public class GridUserController {
    private static final Logger LOGGER = LoggerFactory.getLogger(GridUserController.class);

    @Value("${aps.roles.api}")
    String baseRolesAPIUrl;

    @Autowired
    GridUserService gridUserService;


    @GetMapping("/{query}")
    @Operation(summary = "Get employees with cdsid", description = "Get employees with cdsid")
    @SystemWideResponses
    public ResponseEntity<List<UserDetails>> searchEmployee(@PathVariable String query) {
        return new ResponseEntity<>(gridUserService.lookupEmployee(query), HttpStatus.OK);

    }

    @GetMapping("roles/{cdsid}")
    @Operation(summary = "Get roles of user", description = "Get user roles in GRID")
    @SystemWideResponses
    //@PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:IssueList','read')")
    public ResponseEntity<Object> getGridRoles( @PathVariable String cdsid) {
        String query = "?userName=" + cdsid + "&entityNames=grid";
        RestTemplate restTemplate = new RestTemplate();
        return restTemplate.getForEntity(baseRolesAPIUrl + query, Object.class);
    }

}
