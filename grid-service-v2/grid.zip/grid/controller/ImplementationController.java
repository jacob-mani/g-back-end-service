package com.ford.grid.controller;

import com.ford.grid.common.SystemWideResponses;
import com.ford.grid.exception.GridException;
import com.ford.grid.model.dto.request.CreateImplementationRequest;
import com.ford.grid.model.dto.request.ForumNoteApprovers;
import com.ford.grid.model.dto.request.PopulationAndImplementationDetail;
import com.ford.grid.model.dto.request.vern.GcampVernRequest;
import com.ford.grid.model.dto.request.vern.VernReviewRequest;
import com.ford.grid.model.dto.response.ImplementationResponse;
import com.ford.grid.model.dto.response.PopulationListItem;
import com.ford.grid.model.dto.response.VernReviewDTO;
import com.ford.grid.model.dto.response.vern.GcampVernResponse;
import com.ford.grid.model.dto.response.vern.VernNumbersResponse;
import com.ford.grid.model.entity.KeyValueModel;
import com.ford.grid.service.ImplementationService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v2/impl")
@RequiredArgsConstructor
@Slf4j
public class ImplementationController {

    private final ImplementationService implementationService;

    @PostMapping("/create")
    @Operation(summary = "Create Implementation", description = "New Population creation for issue")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<ImplementationResponse> createImplementation(@Valid @RequestBody CreateImplementationRequest implRequest) throws GridException {
        log.debug("Create Implementation Started for issue- {}", implRequest.getIssueNumber());
        ImplementationResponse response = implementationService.createImplementation(implRequest);
        log.debug("Create Implementation Ended for issue- {}", response.getIssueNumber());
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @GetMapping("/getByIssue/{issueNumber}")
    @Operation(summary = "Get Implementation", description = "Get Implementation details by issue number")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<List<ImplementationResponse>> getImplementationByIssueNumber(@PathVariable String issueNumber) {
        log.debug("Get Implementation Started for issue- {}", issueNumber);
        List<ImplementationResponse> response = implementationService.getImplementationsByIssueNumber(issueNumber);
        log.debug("Get Implementation Ended for issue- {}", issueNumber);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/getByPopulationId/{populationId}")
    @Operation(summary = "Get Implementation", description = "Get Implementation details by population id")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<ImplementationResponse> getImplementationByPopulationId(@PathVariable String populationId) throws GridException {
        log.debug("Get Implementation Started for populationId- {}", populationId);
        ImplementationResponse response = implementationService.getImplementationByPopulationId(populationId);
        log.debug("Get Implementation Ended for populationId- {}", populationId);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PutMapping("/updatePopulation")
    @Operation(summary = "Update Population", description = "Update Population details")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<ImplementationResponse> updatePopulation(@Valid @RequestBody PopulationAndImplementationDetail populationAndImplementationDetail) throws GridException {
        log.debug("Update Population Started for populationId- {}", populationAndImplementationDetail.getPopulationId());
        ImplementationResponse response = implementationService.updatePopulation(populationAndImplementationDetail);
        log.debug("Update Population Ended for populationId- {}", populationAndImplementationDetail.getPopulationId());
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PostMapping("/saveGcampRequest")
    @Operation(summary = "Save GCAMP Implementation Request", description = "Save GCAMP Implementation Request details")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<GcampVernResponse> saveGcampImplementationRequest(@Valid @RequestBody GcampVernRequest GcampVernRequest) throws GridException {
        log.debug("Save GCAMP Implementation Request Started for populationId- {} and vernNumber - {}", GcampVernRequest.getPopulationId(), GcampVernRequest.getVernNumber());
        GcampVernResponse response = implementationService.saveGridGcampRequest(GcampVernRequest);
        log.debug("Save GCAMP Implementation Request Ended for populationId- {} and vernNumber - {}", GcampVernRequest.getPopulationId(), GcampVernRequest.getVernNumber());
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/getGcampVernRequest/{issueNumber}/{populationId}/{vernNumber}")
    @Operation(summary = "Get Gcamp Vern Request", description = "Get Gcamp Vern Request by Vern Number")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public GcampVernResponse getGcampVernRequest(@PathVariable String issueNumber, @PathVariable String populationId, @PathVariable String vernNumber) throws GridException {
        log.debug("Get Gcamp Vern request started for vernNumber- {}", vernNumber);
        GcampVernResponse request = implementationService.getGcampVernRequest(issueNumber, populationId,vernNumber);
        log.debug("Get Gcamp Vern request ended for vernNumber- {}", vernNumber);
        return request;
    }

    @PostMapping("/submitFCSDApproval")
    @Operation(summary = "Submit FCSDApproval Request", description = "Submit a FCSDApproval request for processing")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public VernReviewRequest submitFCSDApprovalRequest(@RequestBody VernReviewRequest vernRequest) throws GridException {
        log.debug("FCSDApproval request submission started for vernNumber- {}", vernRequest.getVernNumber());
        VernReviewRequest request = implementationService.submitFCSDApprovalRequest(vernRequest);
        log.debug("FCSDApproval request submission ended for vernNumber- {}", vernRequest.getVernNumber());
        return request;
    }

    @GetMapping("/getFCSDApproval/{vernNumber}")
    @Operation(summary = "Get FCSD Approval Request", description = "Get a FCSD Approval request by Vern Number")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public VernReviewRequest getFCSDApprovalRequest(@PathVariable String vernNumber) throws GridException {
        log.debug("Get FCSD Approval request started for vernNumber- {}", vernNumber);
        VernReviewRequest request = implementationService.getVernReviewDetails(vernNumber);
        log.debug("Get FCSD Approval request ended for vernNumber- {}", vernNumber);
        return request;
    }

    @DeleteMapping("/deleteVern/{vernNumber}")
    @Operation(summary = "Delete Vern Details", description = "Delete Vern Details by Vern Number")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public String deleteVernDetails(@PathVariable String vernNumber) throws GridException {
        log.debug("Delete Vern Details started for vernNumber- {}", vernNumber);
        String response = implementationService.deleteVernDetails(vernNumber);
        log.debug("Delete Vern Details ended for vernNumber- {}", vernNumber);
        return response;
    }

    @GetMapping("/getAllVernNumbers/{populationId}")
    @Operation(summary = "Get All Vern Numbers", description = "Get All Vern Numbers by Population Id for compare")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public List<VernNumbersResponse> getAllVernNumbers(@PathVariable String populationId) throws GridException {
        log.debug("Get All Vern Numbers started for populationId- {}", populationId);
        List<VernNumbersResponse> response = implementationService.getAllVernNumbers(populationId);
        log.debug("Get All Vern Numbers ended for populationId- {}", populationId);
        return response;
    }

    @PutMapping("/updateVernExtractApprovers")
    @Operation(summary = "Update Vern Extract Approvers", description = "Update Vern Extract Approvers with VernReviewDTO")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<String> updateVernExtractApprovers(@Valid @RequestBody VernReviewDTO vernReviewDTO) throws GridException {
        log.debug("Update Vern Extract Approvers started for vernNumber- {}", vernReviewDTO.getVernNumber());
        String response = implementationService.updateVernExtractApprovers(vernReviewDTO);
        log.debug("Update Vern Extract Approvers ended for vernNumber- {}", vernReviewDTO.getVernNumber());
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/getVernExtractReviewer/{vernNumber}")
    @Operation(summary = "Get Vern Extract Reviewer", description = "Get Vern Extract Reviewer by Vern Number")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<VernReviewDTO> getVernExtractReviewer(@PathVariable String vernNumber) throws GridException {
        log.debug("Get Vern Extract Reviewer started for vernNumber- {}", vernNumber);
        VernReviewDTO response = implementationService.getVernExtractReviewer(vernNumber);
        log.debug("Get Vern Extract Reviewer ended for vernNumber- {}", vernNumber);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/getRegionsForPopulation/{populationId}")
    @Operation(summary = "Get Regions for Population", description = "Get list of region codes for the latest VERN extract by Population Id")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<List<KeyValueModel>> getRegionsForPopulation(@PathVariable String populationId) throws GridException {
        log.debug("Get Regions for Population started for populationId- {}", populationId);
        List<KeyValueModel> response = implementationService.getRegionsForPopulation(populationId);
        log.debug("Get Regions for Population ended for populationId- {}", populationId);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/getCountriesForRegion/{populationId}/{region}")
    @Operation(summary = "Get Country Details for Region", description = "Get list of country codes for a region in the latest VERN extract by Population Id and Region")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<List<String>> getCountryDetailsForRegion(@PathVariable String populationId, @PathVariable String region) throws GridException {
        log.debug("Get Country Details for Region started for populationId- {} and region- {}", populationId, region);
        List<String> response = implementationService.getCountryDetailsForRegion(populationId, region);
        log.debug("Get Country Details for Region ended for populationId- {} and region- {}", populationId, region);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/getFsaNumbers/{issueNumber}")
    @Operation(summary = "Get FSA Numbers", description = "Get all FSA numbers associated with an issue number")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<List<String>> getFsaNumbersByIssueNumber(@PathVariable String issueNumber) {
        log.debug("Get FSA Numbers started for issue- {}", issueNumber);
        List<String> response = implementationService.getFsaNumbersByIssueNumber(issueNumber);
        log.debug("Get FSA Numbers ended for issue- {}", issueNumber);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/getLatestVinAttachment/{populationId}")
    @Operation(summary = "Get Latest VIN Attachment", description = "Get VIN attachment from the latest saved VERN for a population (used to pre-populate New Vern form)")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public GcampVernResponse getLatestVinAttachment(@PathVariable String populationId) throws GridException {
        log.debug("Get Latest VIN Attachment started for populationId- {}", populationId);
        GcampVernResponse response = implementationService.getLatestVinAttachment(populationId);
        log.debug("Get Latest VIN Attachment ended for populationId- {}", populationId);
        return response;
    }

    @GetMapping("/getPopulations/{issueNumber}")
    @Operation(summary = "Get All Populations", description = "Get all populations (populationId and potentialName) for an issue number from issue_implementation")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<List<PopulationListItem>> getPopulationsByIssueNumber(@PathVariable String issueNumber) {
        log.debug("Get Populations started for issue- {}", issueNumber);
        List<PopulationListItem> response = implementationService.getPopulationsByIssueNumber(issueNumber);
        log.debug("Get Populations ended for issue- {}", issueNumber);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
