package com.ford.grid.controller;

import com.ford.grid.common.SystemWideResponses;
import com.ford.grid.model.dto.request.InvestigationAnalysisRequest;
import com.ford.grid.model.dto.response.InvestigationAnalysisResponse;
import com.ford.grid.service.InvestigationAnalysisService;
import io.swagger.v3.oas.annotations.Operation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/api/v2")
public class InvestigationAnalysisController {

    private static final Logger LOGGER = LoggerFactory.getLogger(InvestigationAnalysisController.class);

    @Autowired
    InvestigationAnalysisService investigationAnalysisService;

    @PostMapping("/investigationAnalysis")
    @Operation(summary = "Create Investigation Analysis", description = "Investigation Analysis Create API")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<InvestigationAnalysisResponse> createAndUpdateInvestigationAnalysis(@RequestBody InvestigationAnalysisRequest request) {
        LOGGER.info("Create InvestigationAnalysis Issue Number- {}", request);
        InvestigationAnalysisResponse investigationAnalysisResponse = investigationAnalysisService.createAndUpdateInvestigationAnalysis(request);
        return new ResponseEntity<>(investigationAnalysisResponse, HttpStatus.CREATED);
    }

    @GetMapping({"/getInvestigationAnalysis/{issueNumber}/{forumType}",
            "/getInvestigationAnalysis/{issueNumber}/{forumType}/{agency}"})
    @Operation(summary = "Get InvestigationAnalysis", description = "InvestigationAnalysis Get API with IssueNumber")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<InvestigationAnalysisResponse> getInvestigationAnalysis(@PathVariable String issueNumber, @PathVariable String forumType, @PathVariable(required = false) String agency) {
        LOGGER.info("get InvestigationAnalysis Issue Number- {}", issueNumber);

        return ResponseEntity.ok(investigationAnalysisService.getByIssueNumberAndForumTypeAndAgency(issueNumber, forumType, agency));
    }


}
