package com.ford.grid.controller;

import com.ford.grid.model.dto.response.EmmScheduleResponse;
import com.ford.grid.model.dto.response.InvestigationViewResponse;
import com.ford.grid.service.InvestigationViewService;
import com.ford.grid.service.TrgService;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v2/investigationview")
@AllArgsConstructor
public class InvestigationViewController {

    private final InvestigationViewService investigationViewService;
    private static final Logger LOGGER = LoggerFactory.getLogger(InvestigationViewController.class);

    @GetMapping("/getInvestigationView/{issueNumber}")

    public ResponseEntity<InvestigationViewResponse> getInvestigationView(
            @PathVariable String issueNumber) {
        LOGGER.info("Start of View method in InvestigationViewController , Issue Number: {}", issueNumber);
        return ResponseEntity.ok(
                investigationViewService.getInvestigationView(issueNumber)
        );
    }
}
