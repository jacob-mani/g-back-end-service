package com.ford.grid.controller;

import com.ford.grid.common.SystemWideResponses;
import com.ford.grid.exception.GridException;
import com.ford.grid.model.dto.request.IssueContactsRequest;
import com.ford.grid.model.dto.request.IssueKeyStakeholdersRequest;
import com.ford.grid.model.dto.response.IssueContactsResponse;
import com.ford.grid.model.dto.response.IssueKeyStakeholdersResponse;
import com.ford.grid.service.IssueContactsService;
import io.swagger.v3.oas.annotations.Operation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v2/Contacts")
public class IssueContactsController {

    private static final Logger LOGGER = LoggerFactory.getLogger(IssueContactsController.class);

    @Autowired
    IssueContactsService issueContactsService;


    @PostMapping("saveIssueContacts")
    @Operation(summary = "Contacts", description = "Save IssueContacts by Region,Segment,Forum and Issue Number")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Contacts','update')")
    public ResponseEntity<List<IssueContactsResponse>> saveIssueContactDetails(@RequestBody List<IssueContactsRequest> contacts) throws GridException {
        List<IssueContactsResponse> response = issueContactsService.saveIssueContacts(contacts);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("getIssueContactsByIssueNoRegion/{issueNum}/{region}")
    @Operation(summary = "IssueContacts", description = "Get IssueContacts by IssueNum,Region ")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MyIssuesList','read')")
    public ResponseEntity<List<IssueContactsResponse>> getIssueContactsByIssueNoRegion(@PathVariable String issueNum,
                                                                                            @PathVariable String region) {
        return ResponseEntity.ok(issueContactsService.getIssueContactsByIssueNoRegion(issueNum,region));

    }

    @GetMapping("getIssueContactsByIssueNumber/{issueNum}")
    @Operation(summary = "IssueContacts", description = "Get all IssueContacts by IssueNumber across all regions")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MyIssuesList','read')")
    public ResponseEntity<List<IssueContactsResponse>> getIssueContactsByIssueNumber(@PathVariable String issueNum) {
        return ResponseEntity.ok(issueContactsService.getIssueContactsByIssueNumber(issueNum));
    }

    @DeleteMapping("/deleteContact/{issueNumber}/{title}/{region}")
    @Operation(summary = "Delete contact Details", description = "Delete contact Details by Issue Number and Title, and Region")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Contacts','update')")
    public ResponseEntity<String> deleteContactDetails(@PathVariable String issueNumber, @PathVariable String title, @PathVariable String region) throws GridException {
        LOGGER.debug("Delete Issue Contact started for issueNumber- {}", issueNumber);
        String response = issueContactsService.deleteContactDetails(issueNumber, title, region);
        LOGGER.debug("Delete Issue Contact ended for issueNumber- {}", issueNumber);
        if (response != null) {
            return ResponseEntity.status(HttpStatus.OK).body(response);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Contact not found or could not be deleted");
        }
    }
    @PostMapping("keyStakeholders")
    @Operation(
            summary = "Key stakeholders by issue number",
            description = "Fetch dynamic stakeholder details by issue number"
    )
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MyIssuesList','read')")
    public ResponseEntity<IssueKeyStakeholdersResponse>
    getKeyStakeholdersByIssueNumber(
            @RequestBody IssueKeyStakeholdersRequest request)
            throws GridException {

        return ResponseEntity.ok(
                issueContactsService.getKeyStakeholdersByIssueNumber(
                        request.getIssueNumber(),
                        request.getRegion(),
                        request.getFsaNumber(),
                        request.getCollabId()
                )
        );
    }
}
