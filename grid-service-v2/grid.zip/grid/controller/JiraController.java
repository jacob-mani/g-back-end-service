package com.ford.grid.controller;

import com.ford.grid.common.SystemWideResponses;
import com.ford.grid.config.JiraProperties;
import com.ford.grid.exception.GridException;
import com.ford.grid.model.dto.response.JiraPartsBomResponse;
import com.ford.grid.service.JiraRestClientService;
import io.swagger.v3.oas.annotations.Operation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/v2/jira")
public class JiraController {

    private static final Logger logger = LoggerFactory.getLogger(JiraController.class);

    private final JiraRestClientService client;

    private final JiraProperties props;

    /**
     * Constructs a new {@code JiraController} with the given {@link JiraRestClientService}.
     *
     * @param client the Jira REST client service used to interact with Jira APIs
     */
    public JiraController(JiraRestClientService client, JiraProperties props) {this.client = client; this.props = props;}

    /**
     * Retrieves a paginated list of hardware parts (BOM) associated with the given
     * issue number, implementation ID, and population ID.
     *
     * @param issueNumber  the recall issue number
     * @param implId       the implementation ID
     * @param populationId the population ID
     * @param page         the zero-based page index (default: {@code 0})
     * @param size         the number of records per page (default: {@code 10})
     * @param sortBy       the field to sort by (default: {@code issueNumber})
     * @param direction    the sort direction, {@code ASC} or {@code DESC} (default: {@code DESC})
     * @param searchKey    an optional search keyword to filter results
     * @return a {@link ResponseEntity} containing a {@link Page} of {@link JiraPartsBomResponse}
     */
    @GetMapping("/getHardWareParts/{issueNumber}/{implId}/{populationId}")
    @Operation(summary = "Get HardWare Parts", description = "Get HardWare Parts for a given issue number and implementation ID and Population ID")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MyIssuesList','read')")
    public ResponseEntity<Page<JiraPartsBomResponse>> getHardWareParts(
            @PathVariable String issueNumber,
            @PathVariable String implId,
            @PathVariable String populationId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "issueNumber") String sortBy,
            @RequestParam(defaultValue = "DESC") String direction,
            @RequestParam(required = false) String searchKey) {

        logger.info("Fetching Hardware Parts for issueNumber: {}, implId: {}, populationId: {}, page: {}, size: {}, sortBy: {}, direction: {}, searchKey: {}",
                issueNumber, implId, populationId, page, size, sortBy, direction, searchKey);

        Sort sort = Sort.by(Sort.Direction.fromString(direction), sortBy);
        Pageable pageable = PageRequest.of(page, size, sort);
        Page<JiraPartsBomResponse> response = client.getHardWareParts(issueNumber, implId, populationId, pageable, searchKey);

        logger.info("Successfully fetched {} hardware parts for issueNumber: {}, implId: {}, populationId: {}",
                response.getTotalElements(), issueNumber, implId, populationId);

        return ResponseEntity.ok(response);
    }

    /**
     * Updates an existing Jira Epic linked to the specified issue number,
     * implementation ID, and population ID.
     *
     * @param issueNumber  the recall issue number
     * @param implId       the implementation ID
     * @param populationId the population ID
     * @param requestBody  an optional request body (currently unused)
     * @return a {@link ResponseEntity} containing a map with the updated {@code epicKey}
     */
    @PostMapping("/updateEpic")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MyIssuesList','read')")
    public ResponseEntity<Map<String, String>> updateJiraEpic(
            @RequestParam String issueNumber,
            @RequestParam String implId,
            @RequestParam String populationId,
            @RequestBody(required = false) Object requestBody) {

        logger.info("Updating Jira Epic for issueNumber: {}, implId: {}, populationId: {}", issueNumber, implId, populationId);

        String epicKey = client.updateJiraEpic(issueNumber, implId, populationId);

        logger.info("Successfully updated Jira Epic. epicKey: {} for issueNumber: {}, implId: {}, populationId: {}",
                epicKey, issueNumber, implId, populationId);

        return ResponseEntity.ok(Map.of("epicKey", epicKey));
    }

    /**
     * Retrieves the software parts (preview BOM) for the given issue number and
     * implementation ID without requiring a population ID.
     *
     * @param issueNumber the recall issue number
     * @param implId      the implementation ID
     * @param page        the zero-based page index (default: {@code 0})
     * @param size        the number of records per page (default: {@code 10})
     * @param sortBy      the field to sort by (default: {@code partNo})
     * @param direction   the sort direction, {@code ASC} or {@code DESC} (default: {@code DESC})
     * @param searchKey   an optional search keyword to filter results by issueNumber, implId, partNo, partName, fsa, or noticeNo
     * @return a {@link ResponseEntity} containing a {@link JiraPartsBomResponse}
     */
    @GetMapping("/getSoftwareParts/{issueNumber}/{implId}/{populationId}")
    @Operation(summary = "Get Preview BOM without populationId", description = "Get Preview BOM for a given issue number and implementation ID without populationId")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MyIssuesList','read')")
    public ResponseEntity<JiraPartsBomResponse> getSoftwareParts(
            @PathVariable String issueNumber,
            @PathVariable String implId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @PathVariable String populationId,
            @RequestParam(defaultValue = "partNo") String sortBy,
            @RequestParam(defaultValue = "DESC") String direction,
            @RequestParam(required = false) String searchKey) {

        logger.info("Fetching Software Parts for issueNumber: {}, implId: {}, page: {}, size: {}, sortBy: {}, direction: {}, searchKey: {}",
                issueNumber, implId, page, size, sortBy, direction, searchKey);

        Sort sort = Sort.by(Sort.Direction.fromString(direction), sortBy);
        Pageable pageable = PageRequest.of(page, size, sort);
        JiraPartsBomResponse response = client.getSoftwareParts(issueNumber, implId, populationId, pageable, searchKey);

        logger.info("Successfully fetched {} software parts for issueNumber: {}, implId: {}",
                response.getSoftware() != null ? response.getSoftware().size() : 0, issueNumber, implId);

        return ResponseEntity.ok(response);
    }

    /**
     * Creates a new Jira Epic for the given issue number, implementation ID,
     * and population ID.
     *
     * @param epicName     an optional name for the Jira Epic; if not provided, a default name may be used
     * @param issueNumber  the recall issue number
     * @param implId       the implementation ID
     * @param populationId the population ID
     * @param description  an optional description for the Jira Epic
     * @param requestBody  an optional request body (currently unused)
     * @return a {@link ResponseEntity} containing a map with the newly created {@code epicKey}
     * @throws GridException if an error occurs during Epic creation
     */
    @PostMapping("/epics")
    @Operation(summary = "Create Jira Epic", description = "Creates a Jira Epic based on the provided parameters.")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read'})")
    public ResponseEntity<?> createEpicApi(@RequestParam(required = false) String epicName,
                                           @RequestParam String issueNumber,
                                           @RequestParam String implId,
                                           @RequestParam String populationId,
                                           @RequestParam(required = false) String description,
                                           @RequestBody(required = false) Object requestBody) throws GridException {

        logger.info("Creating Jira Epic for issueNumber: {}, implId: {}, populationId: {}, epicName: {}",
                issueNumber, implId, populationId, epicName);

        String key = client.createJiraEpic(epicName, issueNumber, implId, populationId, description);
        Map<String, Object> response = new HashMap<>();
        response.put("epicKey", key);
        if (key != null && !key.contains("BLOCKED")) {
            String baseUrl = props.getBaseUrl().replaceAll("/+$", "");
            response.put("epicUrl", baseUrl + "/browse/" + key);
        }
        logger.info("Successfully created Jira Epic. epicKey: {} for issueNumber: {}, implId: {}, populationId: {}",
                key, issueNumber, implId, populationId);

        return ResponseEntity.ok(Map.of("epicKey", key));
    }
}