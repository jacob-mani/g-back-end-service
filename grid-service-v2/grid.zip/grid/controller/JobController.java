package com.ford.grid.controller;

import com.ford.grid.constants.CommonConstants;
import com.ford.grid.model.dto.request.scheduler.MonitorComebackJobRequest;
import com.ford.grid.model.dto.response.scheduler.MonitorComebackJobSummary;
import com.ford.grid.schedule.GCAMPCollectionScheduleTask;
import com.ford.grid.service.ForumStatusService;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/v2/job")
@RequiredArgsConstructor
public class JobController {
    private static final Logger LOGGER = LoggerFactory.getLogger(JobController.class);
    private final GCAMPCollectionScheduleTask gcampCollectionScheduleTask;
    private final ForumStatusService forumStatusService;

    @Value("${monitor.comeback.job.allow-manual:true}")
    private boolean monitorComebackJobManualAllowed;

    @GetMapping
    public void refreshGRIDIssueCollections() {
        LOGGER.info("Start of refreshGRIDIssueCollections in GCAMPCollectionScheduleTask");
        gcampCollectionScheduleTask.reloadGRIDIssueCollections();
        LOGGER.info("End of refreshGRIDIssueCollections in GCAMPCollectionScheduleTask");
    }

    @GetMapping("/monitor-comeback")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:IssueList','update')")
    @Deprecated(forRemoval = false)
    public ResponseEntity<MonitorComebackJobSummary> runMonitorComebackJob() throws Exception {
        LOGGER.warn("Monitor comeback endpoint start - triggerSource=manual, method=GET, issueNumber=null, forumType=null, dryRun=false, force=false, manualAllowed={}, message=Prefer POST for this mutating operation",
                monitorComebackJobManualAllowed);
        return runMonitorComebackJob(MonitorComebackJobRequest.builder().build());
    }

    @PostMapping("/monitor-comeback")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:IssueList','update')")
    public ResponseEntity<MonitorComebackJobSummary> runMonitorComebackJob(@RequestBody(required = false) MonitorComebackJobRequest request) throws Exception {
        MonitorComebackJobRequest effectiveRequest = request != null ? request : MonitorComebackJobRequest.builder().build();
        LOGGER.info("Monitor comeback endpoint start - triggerSource=manual, method=POST, issueNumber={}, forumType={}, dryRun={}, force={}, manualAllowed={}",
                effectiveRequest.issueNumber(),
                effectiveRequest.forumType(),
                Boolean.TRUE.equals(effectiveRequest.dryRun()),
                Boolean.TRUE.equals(effectiveRequest.force()),
                monitorComebackJobManualAllowed);
        if (!monitorComebackJobManualAllowed) {
            LOGGER.info("Monitor comeback job manual execution skipped - allowManual=false");
            MonitorComebackJobSummary summary = buildManualDisabledSummary(effectiveRequest);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(summary);
        }

        LOGGER.info("Monitor comeback job triggered manually - issueNumber={}, forumType={}, dryRun={}, force={}",
                effectiveRequest.issueNumber(),
                effectiveRequest.forumType(),
                effectiveRequest.dryRun(),
                effectiveRequest.force());
        return ResponseEntity.ok(forumStatusService.runMonitorComebackJob("manual", effectiveRequest));
    }

    private MonitorComebackJobSummary buildManualDisabledSummary(MonitorComebackJobRequest request) {
        LocalDateTime startedAt = LocalDateTime.now();
        LocalDateTime completedAt = LocalDateTime.now();
        return MonitorComebackJobSummary.builder()
                .jobName(CommonConstants.MONITOR_COMEBACK_JOB_NAME)
                .triggerSource("manual")
                .processingDate(LocalDate.now())
                .requestedIssueNumber(request.issueNumber())
                .requestedForumType(request.forumType())
                .dryRun(Boolean.TRUE.equals(request.dryRun()))
                .force(Boolean.TRUE.equals(request.force()))
                .startedAt(startedAt)
                .completedAt(completedAt)
                .durationMs(0)
                .issuesScanned(0)
                .eligibleStatusesFound(0)
                .issuesUpdated(0)
                .skippedCount(0)
                .ccrgUpdated(0)
                .csfUpdated(0)
                .eprcUpdated(0)
                .govtUpdated(0)
                .notificationsQueued(0)
                .emailsAttempted(0)
                .failureCount(0)
                .failedItems(List.of())
                .skippedItems(List.of())
                .errorSummary("Manual monitor comeback execution is disabled")
                .status("SKIPPED_DISABLED")
                .build();
    }
}