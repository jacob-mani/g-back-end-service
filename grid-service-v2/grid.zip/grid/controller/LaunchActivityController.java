package com.ford.grid.controller;

import com.ford.grid.exception.GridException;
import com.ford.grid.model.dto.request.LaunchActivityUnifiedUpdateRequest;
import com.ford.grid.model.dto.response.LaunchActivityStatusResponse;
import com.ford.grid.service.LaunchActivityService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v2/launch-activity")
@Tag(name = "Launch Activity", description = "APIs for managing launch activity status across all collections")
public class LaunchActivityController {

    private static final Logger LOGGER = LoggerFactory.getLogger(LaunchActivityController.class);

    // Service for managing launch activity operations across all three collections
    private final LaunchActivityService launchActivityService;

    @GetMapping("/status/{populationId}")
    @Operation(summary = "Get Launch Activity Status", description = "Get launch activity status for all regions of a population across all three collections")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<List<LaunchActivityStatusResponse>> getLaunchActivityStatus(
            @Parameter(description = "Population ID") @PathVariable String populationId) {

        LOGGER.info("Get launch activity status for populationId: {}", populationId);
        List<LaunchActivityStatusResponse> response = launchActivityService.getLaunchActivityStatus(populationId);
        return ResponseEntity.ok(response);
    }

    @PutMapping("/update-status")
    @Operation(summary = "Unified Status Update", description = "Update both region-level status and editorial supplement statuses for multiple regions in one call")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<Void> updateLaunchActivityStatus(
            @RequestBody List<LaunchActivityUnifiedUpdateRequest> requests) throws GridException {

        LOGGER.info("Unified status update for {} regions", requests.size());
        launchActivityService.updateLaunchActivityStatus(requests);
        return ResponseEntity.ok().build();
    }
}
