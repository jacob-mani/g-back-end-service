package com.ford.grid.controller;

import com.ford.grid.common.SystemWideResponses;
import com.ford.grid.exception.GridException;
import com.ford.grid.model.dto.request.*;
import com.ford.grid.model.dto.response.FDKickoffResponse;
import com.ford.grid.model.dto.response.LaunchCardResponse;
import com.ford.grid.model.dto.response.LaunchRegionCommunicationResponse;
import com.ford.grid.model.entity.LaunchCard;
import com.ford.grid.service.LaunchCardService;
import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.Objects;

@RestController
@RequestMapping("/api/v2/launch")
@RequiredArgsConstructor
public class LaunchCardController {
    private static final Logger logger = LoggerFactory.getLogger(LaunchCardController.class);

    private final LaunchCardService launchCardService;

    @PostMapping("/launchCard")
    @Operation(summary = "Launch Card API", description = "API endpoint to save launch card details")
    @SystemWideResponses
    public ResponseEntity<LaunchCard> launchCard(@RequestBody LaunchCardRequest launchCardRequest) throws GridException {
        logger.info("Received request: {}", launchCardRequest);
        if (Objects.isNull(launchCardRequest))
            return ResponseEntity.badRequest().build();

        return new ResponseEntity<>(launchCardService.saveLaunchCard(launchCardRequest), HttpStatus.CREATED);
    }

    @GetMapping("/{issueNumber}/{implId}/{populationId}")
    @Operation(summary = "Get Launch Card API", description = "Fetches Launch Card API by issue number,impl id and population id")
    @SystemWideResponses
    public ResponseEntity<LaunchCardResponse> getLaunchCard (
            @PathVariable String issueNumber, @PathVariable String implId, @PathVariable String populationId) {
        logger.info("Fetching Launch Card API for issue number: {}, implementation id: {}, population id: {}", issueNumber, implId, populationId);
        LaunchCardResponse response = launchCardService.getLaunchCardUI(issueNumber, implId, populationId) ;
        return ResponseEntity.ok(response);
    }
}