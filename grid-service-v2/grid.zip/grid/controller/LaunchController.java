package com.ford.grid.controller;

import com.ford.grid.common.SystemWideResponses;
import com.ford.grid.exception.GridException;
import com.ford.grid.model.dto.request.LaunchGovernmentSubmissionRequest;
import com.ford.grid.model.dto.response.LaunchGovernmentSubmissionResponse;
import com.ford.grid.service.LaunchGovernmentSubmissionService;
import io.swagger.v3.oas.annotations.Operation;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v2/launch")
@AllArgsConstructor
public class LaunchController {

    private static final Logger LOGGER = LoggerFactory.getLogger(LaunchController.class);
    private final LaunchGovernmentSubmissionService launchService;

    /**
     * Retrieves a Government Submission by Population ID and Region ID.
     *
     * @param populationId the unique identifier for the population (must not be null or empty)
     * @param regionId the unique identifier for the region (must not be null or empty)
     * @return ResponseEntity containing the LaunchGovernmentSubmissionResponse
     * @throws IllegalArgumentException if populationId or regionId is null or empty
     */
    @GetMapping("/governmentSubmission/{populationId}/{regionId}")
    @Operation(summary = "Get Government Submission by Population and Region", description = "Retrieves a Government Submission for the specified population and region")
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:Checklist':'read'})")
    @SystemWideResponses
    public ResponseEntity<LaunchGovernmentSubmissionResponse> getGovernmentSubmissionByPopulationIdAndRegionId(
            @PathVariable String populationId,
            @PathVariable String regionId){
        LOGGER.info("Retrieving Government Submission for populationId: {}, regionId: {}", populationId, regionId);

        if (populationId == null || populationId.trim().isEmpty()) {
            LOGGER.error("Invalid request: populationId is null or empty");
            throw new IllegalArgumentException("Population ID must not be null or empty");
        }

        if (regionId == null || regionId.trim().isEmpty()) {
            LOGGER.error("Invalid request: regionId is null or empty");
            throw new IllegalArgumentException("Region ID must not be null or empty");
        }

        LaunchGovernmentSubmissionResponse response = launchService.getGovernmentSubmissionByPopulationIdAndRegionId(populationId, regionId);

        LOGGER.info("Successfully retrieved Government Submission for populationId: {}, regionId: {}", populationId, regionId);
        return ResponseEntity.ok(response);
    }

    /**
     * Creates or updates a Government Submission.
     *
     * @param request the LaunchGovernmentSubmissionRequest containing submission details (must not be null)
     * @return ResponseEntity containing the created or updated LaunchGovernmentSubmissionResponse with HTTP 201 status
     * @throws GridException if an error occurs during save/update operation
     * @throws IllegalArgumentException if request is null or contains invalid data
     */
    @PostMapping("/governmentSubmission/saveOrUpdate")
    @Operation(summary = "Save or Update Government Submission", description = "Creates or updates a Government Submission")
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:Checklist':'update'})")
    @SystemWideResponses
    public ResponseEntity<LaunchGovernmentSubmissionResponse> saveOrUpdateLaunchRegionCommunication(@RequestBody LaunchGovernmentSubmissionRequest request) throws GridException {
        if (request == null) {
            LOGGER.error("Invalid request: request body is null");
            throw new IllegalArgumentException("Request body must not be null");
        }

        if (request.getIssueNumber() == null || request.getIssueNumber().trim().isEmpty()) {
            LOGGER.error("Invalid request: issue number is null or empty");
            throw new IllegalArgumentException("Issue number must not be null or empty");
        }

        if (request.getPopulationId() == null || request.getPopulationId().trim().isEmpty()) {
            LOGGER.error("Invalid request: population ID is null or empty for issue: {}", request.getIssueNumber());
            throw new IllegalArgumentException("Population ID must not be null or empty");
        }

        if (request.getRegionId() == null || request.getRegionId().trim().isEmpty()) {
            LOGGER.error("Invalid request: region ID is null or empty for issue: {}", request.getIssueNumber());
            throw new IllegalArgumentException("Region ID must not be null or empty");
        }

        LOGGER.info("Saving Launch Government Submission for issue: {}, populationId: {}, regionId: {}",
                request.getIssueNumber(), request.getPopulationId(), request.getRegionId());

        LaunchGovernmentSubmissionResponse response = launchService.createAndUpdateGovernmentSubmission(request);

        LOGGER.info("Successfully saved/updated Government Submission for issue: {}", request.getIssueNumber());
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    /**
     * Permanently deletes a Government Submission Notification by its notification type ID.
     * This removes the notification from the submission's notification list and cannot be undone.
     *
     * @param populationId the unique identifier for the population (must not be null or empty)
     * @param regionId the unique identifier for the region (must not be null or empty)
     * @param notificationTypeId the unique identifier for the notification type (must not be null or empty)
     * @return ResponseEntity with HTTP 200 status on successful deletion
     * @throws IllegalArgumentException if any parameter is null or empty
     */
    @DeleteMapping("/governmentSubmission/{populationId}/{regionId}/notification/{notificationTypeId}")
    @Operation(summary = "Delete Government Submission Notification", description = "Permanently deletes a Government Submission Notification by ID")
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:Checklist':'update'})")
    @SystemWideResponses
    public ResponseEntity<Void> deleteGovernmentSubmissionNotification(
            @PathVariable String populationId,
            @PathVariable String regionId,
            @PathVariable String notificationTypeId) {
        LOGGER.info("Request to delete Government Submission Notification for populationId: {}, regionId: {}, notificationTypeId: {}",
                populationId, regionId, notificationTypeId);

        if (populationId == null || populationId.trim().isEmpty()) {
            LOGGER.error("Invalid request: in Delete api populationId is null or empty");
            throw new IllegalArgumentException("Population ID must not be null or empty");
        }

        if (regionId == null || regionId.trim().isEmpty()) {
            LOGGER.error("Invalid request: in Delete api regionId is null or empty");
            throw new IllegalArgumentException("Region ID must not be null or empty");
        }

        if (notificationTypeId == null || notificationTypeId.trim().isEmpty()) {
            LOGGER.error("Invalid request: notificationTypeId is null or empty");
            throw new IllegalArgumentException("Notification Type ID must not be null or empty");
        }

        launchService.deleteNotification(populationId, regionId, notificationTypeId);

        LOGGER.info("Successfully deleted Government Submission Notification for populationId: {}, regionId: {}, notificationTypeId: {}",
                populationId, regionId, notificationTypeId);
        return ResponseEntity.ok().build();
    }
}
