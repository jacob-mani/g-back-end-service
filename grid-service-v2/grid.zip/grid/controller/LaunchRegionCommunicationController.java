package com.ford.grid.controller;

import com.ford.grid.common.SystemWideResponses;
import com.ford.grid.exception.GridException;
import com.ford.grid.model.dto.request.LaunchRegionCommunicationRequest;
import com.ford.grid.model.dto.response.LaunchRegionCommunicationResponse;
import com.ford.grid.service.LaunchRegionCommunicationService;
import io.swagger.v3.oas.annotations.Operation;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v2/communications")
@AllArgsConstructor
public class LaunchRegionCommunicationController {

    private static final Logger LOGGER = LoggerFactory.getLogger(LaunchRegionCommunicationController.class);
    private final LaunchRegionCommunicationService launchRegionCommunicationService;

    @PostMapping("/saveCommunications")
    @Operation(summary = "Save communications", description = "save communications if record exists")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<LaunchRegionCommunicationResponse> saveCommunications(@RequestBody LaunchRegionCommunicationRequest request) throws GridException {
        LOGGER.info("Start of saveCommunications : {}", request);
        LaunchRegionCommunicationResponse response = launchRegionCommunicationService.saveCommunications(request);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/getCommunications/{issueNumber}/{implId}/{populationId}")
    @Operation(summary = "Get Communications", description = "Get Communications by issueNumber and implId and populationId")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<LaunchRegionCommunicationResponse> getCommunications(
            @PathVariable String issueNumber,
            @PathVariable String implId,
            @PathVariable String populationId) throws GridException {
        LOGGER.info("Get Communications for issueNumber: {}, implId: {}",
                issueNumber, implId);
        LaunchRegionCommunicationResponse response = launchRegionCommunicationService.getCommunications(issueNumber, implId, populationId);
        return ResponseEntity.ok(response);
    }
}
