package com.ford.grid.controller;

import com.ford.grid.common.SystemWideResponses;
import com.ford.grid.exception.GridException;
import com.ford.grid.model.dto.request.LaunchRegionDealerBulletinRequest;
import com.ford.grid.model.dto.response.LaunchRegionDealerBulletinResponse;
import com.ford.grid.service.LaunchRegionDealerBulletinService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v2/launch-dealer-bulletin")
@Tag(name = "Launch Region Dealer Bulletin", description = "APIs for managing Launch Region Dealer Bulletin")
public class LaunchRegionDealerBulletinController {

    private static final Logger logger = LoggerFactory.getLogger(LaunchRegionDealerBulletinController.class);

    private final LaunchRegionDealerBulletinService service;

    @GetMapping("/{populationId}/{regionId}")
    @Operation(summary = "Get by Population and Region", description = "Get Launch Region Dealer Bulletin by issue number, impl ID, population ID and region ID")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<LaunchRegionDealerBulletinResponse> getByPopulationIdAndRegionId(
            @PathVariable String populationId,
            @PathVariable String regionId) {
        logger.info("GET /api/v2/launch-dealer-bulletin/{}/{}", populationId, regionId);
        return ResponseEntity.ok(service.getByPopulationIdAndRegionId(populationId, regionId));
    }

    @PostMapping
    @Operation(summary = "Save", description = "Save a new Launch Region Dealer Bulletin")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<LaunchRegionDealerBulletinResponse> save(@Valid @RequestBody LaunchRegionDealerBulletinRequest request) throws GridException {
        logger.info("POST /api/v2/launch-dealer-bulletin");
        return ResponseEntity.status(HttpStatus.CREATED).body(service.save(request));
    }

    @DeleteMapping("/{populationId}/{regionId}/notification/{notificationTypeId}")
    @Operation(summary = "Delete", description = "Soft delete a Launch Region Dealer Bulletin Notification by ID")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<Void> deleteNotification(
            @PathVariable String populationId,
            @PathVariable String regionId,
            @PathVariable String notificationTypeId) {
        service.deleteNotification(populationId, regionId, notificationTypeId);
        return ResponseEntity.ok().build();
    }
}