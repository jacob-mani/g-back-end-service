package com.ford.grid.controller;

import com.ford.grid.exception.GridException;
import com.ford.grid.model.dto.request.LaunchRegionOwnerNotificationRequest;
import com.ford.grid.model.dto.response.LaunchRegionOwnerNotificationResponse;
import com.ford.grid.service.LaunchRegionOwnerNotificationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v2/launch/owner-notification")
@Tag(name = "Launch Region Owner Notification", description = "APIs for managing launch region owner notifications")
public class LaunchRegionOwnerNotificationController {

    private static final Logger LOGGER = LoggerFactory.getLogger(LaunchRegionOwnerNotificationController.class);

    private final LaunchRegionOwnerNotificationService ownerNotificationService;

    @GetMapping("/{populationId}/{regionId}")
    @Operation(summary = "Get Owner Notification", description = "Get owner notification by population ID and region ID")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<LaunchRegionOwnerNotificationResponse> getOwnerNotification(
            @PathVariable String populationId,
            @PathVariable String regionId) {

        LOGGER.info("Get owner notification for populationId: {}, regionId: {}", populationId, regionId);
        LaunchRegionOwnerNotificationResponse response = ownerNotificationService.getByPopulationIdAndRegionId(populationId, regionId);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/save")
    @Operation(summary = "Save Owner Notification", description = "Save or update owner notification")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<LaunchRegionOwnerNotificationResponse> saveOwnerNotification(
            @RequestBody LaunchRegionOwnerNotificationRequest request) throws GridException {

        LOGGER.info("Save owner notification for populationId: {}, regionId: {}",
                request.getPopulationId(), request.getRegionId());
        LaunchRegionOwnerNotificationResponse response = ownerNotificationService.save(request);
        return ResponseEntity.ok(response);
    }

    @DeleteMapping("/{populationId}/{regionId}/notification/{notificationTypeId}")
    @Operation(summary = "Delete Owner Notification", description = "Delete a specific owner notification by notification type ID")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<Void> deleteOwnerNotification(
            @PathVariable String populationId,
            @PathVariable String regionId,
            @PathVariable String notificationTypeId) {

        LOGGER.info("Delete owner notification with notificationTypeId: {} for populationId: {}, regionId: {}",
                notificationTypeId, populationId, regionId);
        ownerNotificationService.deleteNotification(populationId, regionId, notificationTypeId);
        return ResponseEntity.ok().build();
    }
}
