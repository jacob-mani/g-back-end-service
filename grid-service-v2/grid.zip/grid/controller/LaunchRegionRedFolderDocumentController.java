package com.ford.grid.controller;

import com.ford.grid.common.SystemWideResponses;
import com.ford.grid.exception.GridException;
import com.ford.grid.model.dto.request.LaunchRegionRedFolderDocumentRequest;
import com.ford.grid.model.dto.response.LaunchRegionRedFolderDocumentResponse;
import com.ford.grid.service.LaunchRegionRedFolderDocumentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v2/redFolderDocument")
@Tag(name = "Launch Region Red Folder Document APIs", description = "APIs for managing launch region red folder documents")
@AllArgsConstructor
public class LaunchRegionRedFolderDocumentController {

    private static final Logger LOGGER = LoggerFactory.getLogger(LaunchRegionRedFolderDocumentController.class);

    private final LaunchRegionRedFolderDocumentService launchRegionRedFolderDocumentService;

    @GetMapping("/getRedFolderDocument/{issueNumber}/{implId}/{populationId}")
    @Operation(summary = "Get FRC Pac", description = "Get Red Folder Document by issueNumber and implId and populationId")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<LaunchRegionRedFolderDocumentResponse> getRedFolderDocument(
            @PathVariable String issueNumber,
            @PathVariable String implId,
            @PathVariable String populationId) throws GridException {
        LOGGER.info("Get FRC Pac for issueNumber: {}, implId: {}",
                issueNumber, implId);
        LaunchRegionRedFolderDocumentResponse response = launchRegionRedFolderDocumentService.getLaunchRegionRedFolderDocument(issueNumber, implId, populationId);
        return ResponseEntity.ok(response);
    }

    /**
     * Create or update a LaunchRegionRedFolderDocument.
     *
     * @param request LaunchRegionRedFolderDocumentRequest containing document data
     * @return created/updated LaunchRegionRedFolderDocumentResponse
     */
    @PostMapping("/saveRedFolderDocument")
    @Operation(summary = "Save or Update LaunchRegionRedFolder Document", description = "Creates or updates a LaunchRegionRedFolderDocument")
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:Checklist':'update'})")
    @SystemWideResponses
    public ResponseEntity<LaunchRegionRedFolderDocumentResponse> saveOrUpdateLaunchRegionRedFolderDocument(@RequestBody LaunchRegionRedFolderDocumentRequest request) throws GridException {
        LOGGER.info("Saving Launch Region Red Folder Document for issue number: {}", request.getIssueNumber());
        LaunchRegionRedFolderDocumentResponse response =
                launchRegionRedFolderDocumentService.createAndUpdateLaunchRegionRedFolderDocument(request);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

}
