package com.ford.grid.controller;

import com.ford.grid.model.dto.MailRequest;
import com.ford.grid.service.impl.MailService;
import jakarta.mail.MessagingException;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.InputStreamSource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.thymeleaf.context.Context;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

@RestController
@AllArgsConstructor
@RequestMapping("/api/v2/mail")
public class MailController {
    private static final Logger LOGGER = LoggerFactory.getLogger(MailController.class);
    private final MailService mailService;

    /**
     * Endpoint to send a test email using a predefined template and attachment.
     *
     * @return ResponseEntity with a success message
     * @throws MessagingException if there is an error in sending the email
     */
    //@GetMapping("sendEmail")
    public ResponseEntity<String> sendEmail() throws MessagingException {
        LOGGER.info("Start of sendEmail in MailController");

        Context mailContext = new Context();
        mailContext.setVariable("fileURL", "https://grid-ui-v2-781313647403.us-central1.run.app/dashboard");
        mailContext.setVariable("investigationReportType", "EPRC Approval report");
        mailContext.setVariable("issueNumber", "11-001");

        final String fileContent = "This is a test file for attachment in email.";

        Map<String, InputStreamSource> fileAttachment = Map.of(
                "Test_File1.txt", new ByteArrayResource(fileContent.getBytes(StandardCharsets.UTF_8)),
                "Test_File2.txt", new ByteArrayResource(fileContent.getBytes(StandardCharsets.UTF_8))
        );

        MailRequest build = MailRequest.builder().sender("griddev").
                recipients(List.of("VGUNAS14")).
                subject("EPRC Report Approval").
                context(mailContext).
                notificationType("Action - user").
                notificationName("Confirm Cost Estimate").
                mailTemplateName("Template_EPRC_Report_Approval").
                attachments(fileAttachment).
                build();

        String mailResponse = mailService.sendEmail(build, Boolean.TRUE);
        LOGGER.info("End of sendEmail in MailController");

        return ResponseEntity.ok(mailResponse + " using the Mail template : " + build.getMailTemplateName());
    }
}