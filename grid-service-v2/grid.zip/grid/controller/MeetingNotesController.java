package com.ford.grid.controller;

import com.ford.grid.exception.GridException;
import com.ford.grid.model.dto.request.meetingnotes.*;
import com.ford.grid.model.dto.response.meetingnotes.MeetingNotesPageLoadResponse;
import com.ford.grid.model.dto.response.meetingnotes.MeetingNotesPopulationLoadResponse;
import com.ford.grid.model.dto.response.meetingnotes.MeetingNotesWithPopulationResponse;
import com.ford.grid.model.dto.response.meetingnotes.MeetingNotesTRGResponse;
import com.ford.grid.model.dto.response.meetingnotes.TransientFSARoles;
import com.ford.grid.model.entity.ForumMinutes;
import com.ford.grid.model.entity.meetingnotes.MeetingNotes;
import com.ford.grid.model.entity.meetingnotes.MeetingNotesWithPopulation;
import com.ford.grid.repository.ForumMinutesRepository;
import com.ford.grid.service.MeetingNotesService;
import com.mongodb.client.result.UpdateResult;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import static com.ford.grid.constants.CommonConstants.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v2/meeting-notes")
public class MeetingNotesController {
    private static final Logger LOGGER = LoggerFactory.getLogger(MeetingNotesController.class);
    private final MeetingNotesService meetingNotesService;
    private final ForumMinutesRepository forumMinutesRepository;

    /**
     * Retrieves meeting card details by issue number.
     *
     * @param issueNumber the issue number to search for
     * @return the MeetingNotesResponse containing meeting card details
     * @throws GridException if an error occurs while retrieving the details
     */
    @GetMapping("/{issueNumber}")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MeetingNotes','read')")
    public ResponseEntity<MeetingNotesPageLoadResponse> getMeetingCardDetails(@PathVariable String issueNumber) throws GridException {
        LOGGER.info("Start of getMeetingCardDetails method in MeetingNotesController, Issue Number: {}", issueNumber);
        return ResponseEntity.ok(meetingNotesService.getMeetingCardDetails(issueNumber));
    }

    /**
     * Retrieves TRG and FRC meeting notes for all populations under the given issue number.
     *
     * @param issueNumber the issue number
     * @return MeetingNotesPopulationLoadResponse containing all meeting notes organized by population
     */
    @GetMapping("/{issueNumber}/trg-frc")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MeetingNotes','read')")
    public ResponseEntity<MeetingNotesPopulationLoadResponse> getPopulationMeetingCardDetails(@PathVariable String issueNumber) {
        LOGGER.info("Start of getTrgFrcMeetingNotes method in MeetingNotesController for issueNumber: {}", issueNumber);

        MeetingNotesPopulationLoadResponse response = meetingNotesService.getPopulationMeetingCardDetails(issueNumber);
        return ResponseEntity.ok(response);
    }

    /**
     * Retrieves MeetingNotes by issue number and category.
     *
     * @param issueNumber the issue number to search for
     * @param category    the category of meeting notes (e.g., "ccrg", "csf", "eprc", "govt")
     * @return the MeetingNotes document if found
     */
    @GetMapping("/{issueNumber}/{category}")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MeetingNotes','read')")
    public ResponseEntity<?> getMeetingNotesByIssueNumberAndCategory(@PathVariable String issueNumber, @PathVariable String category) {
        LOGGER.info("Start of getMeetingNotesByIssueNumberAndCategory method in MeetingNotesController");
        LOGGER.info("Issue Number: {}, Category: {}", issueNumber, category);

        try {
            MeetingNotes meetingNotes = meetingNotesService.getMeetingNotesByIssueNumber(issueNumber, StringUtils.lowerCase(category));
            if (StringUtils.equalsAnyIgnoreCase(category, FORUM_EPRC) && Objects.isNull(meetingNotes.getEprc())) {
                //Check the Forum minutes collection for EPRC notes if not found in Meeting Notes collection
                ForumMinutes forumMinutes = forumMinutesRepository.findByIssueNumber(issueNumber).orElse(null);
                if (Objects.nonNull(forumMinutes))
                    return ResponseEntity.ok(List.of(forumMinutes));
            }
            return ResponseEntity.ok(meetingNotes);
        } catch (GridException gridException) {
            LOGGER.error("Error while fetching meeting notes: {}", gridException.getMessage());
            return ResponseEntity.status(gridException.getStatus()).body(gridException.getDescription());
        }
    }

    @GetMapping("/meetingNotesCount/{issueNumber}")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MeetingNotes','read')")
    public ResponseEntity<Map<String, Integer>> getMeetingNotesCount(@PathVariable String issueNumber) {
        LOGGER.info("Start of getMeetingNotesCount in MeetingNotesController");

        Map<String, Integer> meetingNotesCount = meetingNotesService.getMeetingNotesCount(issueNumber);
        LOGGER.info("EPRC meeting notes count:{}", meetingNotesCount);
        LOGGER.info("End of getMeetingNotesCountForEPRC in MeetingNotesController");
        return ResponseEntity.ok(meetingNotesCount);
    }

    /**
     * Deletes a meeting note by its ID within a specific issue number and category.
     *
     * @param issueNumber the issue number to search for
     * @param category    the category of meeting notes (e.g., "ccrg", "csf", "eprc", "govt")
     * @param id          the ID of the meeting note to delete
     */
    @DeleteMapping("/{issueNumber}/{category}/{id}")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MeetingNotes','update')")
    public ResponseEntity<String> deleteMeetingNotesById(@PathVariable String issueNumber, @PathVariable String category, @PathVariable int id) {
        LOGGER.info("Start of deleteMeetingNotesById method in MeetingNotesController");
        LOGGER.info("Issue Number: {}, Category: {}, ID: {}", issueNumber, category, id);

        UpdateResult updateResult = meetingNotesService.deleteMeetingNotesById(issueNumber, StringUtils.lowerCase(category), id);
        final long modifiedCount = updateResult.getModifiedCount();
        LOGGER.info("End of deleteMeetingNotesById method in MeetingNotesController : {}", modifiedCount);

        return ResponseEntity.status(modifiedCount > 0 ? HttpStatus.NO_CONTENT : HttpStatus.NOT_FOUND).build();
    }

    /**
     * Adds a new meeting note to a specific issue number and category.
     *
     * @param issueNumber  the issue number to which the meeting note will be added
     * @param category     the category of meeting notes (e.g., "ccrg", "csf", "eprc", "govt")
     * @param meetingNotes the details of the meeting note to add
     */
    @PostMapping("/{issueNumber}/{category}")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MeetingNotes','update')")
    public ResponseEntity<?> addMeetingNotes(@PathVariable String issueNumber, @PathVariable String category, @RequestBody MeetingNotesDetails meetingNotes) {
        LOGGER.info("Start of addMeetingNotes method in MeetingNotesController");
        LOGGER.info("Issue Number: {}, Category: {}, MeetingNotesDetails: {}", issueNumber, category, meetingNotes);

        try {
            //No meeting notes available for the issue number, create new document
            if (!meetingNotesService.existsByIssueNumber(issueNumber)) {
                meetingNotes.setSequenceId(1);
                MeetingNotes savedMeetingNotes = meetingNotesService.addNewMeetingNotesAndCreateIssueNumber(issueNumber, StringUtils.lowerCase(category), meetingNotes);
                LOGGER.info("MeetingNotes saved successfully : {}", savedMeetingNotes);

                return ResponseEntity.status(HttpStatus.CREATED).body(meetingNotes);
            } else {
                //Meeting notes available for the issue number, update existing document for the new category
                UpdateResult updateResult = meetingNotesService.addNewMeetingToExistingIssueNumber(issueNumber, StringUtils.lowerCase(category), meetingNotes);
                LOGGER.info("MeetingNotes updated successfully : {}", updateResult.getModifiedCount());

                return ResponseEntity.status(HttpStatus.OK).body(meetingNotes);
            }
        } catch (GridException gridException) {
            LOGGER.error("Error while adding meeting notes: {}", gridException.getMessage());
            return ResponseEntity.status(gridException.getStatus()).body(gridException.getDescription());
        }
    }

    /**
     * Updates an existing meeting note by its ID within a specific issue number and category.
     *
     * @param issueNumber         the issue number to search for
     * @param category            the category of meeting notes (e.g., "ccrg", "csf", "eprc", "govt")
     * @param id                  the ID of the meeting note to update
     * @param meetingNotesDetails the updated details of the meeting note
     */
    @PutMapping("/{issueNumber}/{category}/{id}")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MeetingNotes','update')")
     public ResponseEntity<MeetingNotesDetails> updateMeetingNotes(@PathVariable String issueNumber, @PathVariable String category, @PathVariable int id, @RequestBody MeetingNotesDetails meetingNotesDetails) throws GridException {
        LOGGER.info("Start of updateMeetingNotes method in MeetingNotesController");
        LOGGER.info("Issue Number: {}, Category: {}, ID: {}, MeetingNotesDetails: {}", issueNumber, category, id, meetingNotesDetails);

        MeetingNotesDetails updatedMeetingNotes = meetingNotesService.updateMeetingNotes(issueNumber, StringUtils.lowerCase(category), id, meetingNotesDetails);

        return ResponseEntity.ok(updatedMeetingNotes);
    }

    /**
     * Adds government meeting notes to a specific issue number.
     *
     * @param issueNumber           the issue number to which the government meeting notes will be added
     * @param transientMeetingNotes the details of the government meeting notes to add
     */
    @PostMapping("/transient/{issueNumber}")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MeetingNotes','update')")
    public ResponseEntity<TransientMeetingNotes> addTransientMeetingNotes(@PathVariable String issueNumber, @RequestBody TransientMeetingNotes transientMeetingNotes) throws GridException {
        LOGGER.info("Start of addTransientMeetingNotes method in MeetingNotesController");
        LOGGER.info("Issue Number: {}, TransientMeetingNotes: {}", issueNumber, transientMeetingNotes);

        meetingNotesService.addTransientMeetingNotes(issueNumber, transientMeetingNotes);

        return ResponseEntity.status(HttpStatus.CREATED).body(transientMeetingNotes);
    }


    /**
     * Updates government meeting notes for a specific issue number and role.
     *
     * @param issueNumber           the issue number to which the government meeting notes belong
     * @param transientMeetingNotes the updated details of the government meeting notes
     */
    @PutMapping("/transient/{issueNumber}")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MeetingNotes','update')")
    public ResponseEntity<TransientMeetingNotes> updateTransientMeetingNotes(@PathVariable String issueNumber, @RequestBody TransientMeetingNotes transientMeetingNotes) {
        LOGGER.info("Start of updateTransientMeetingNotes method in MeetingNotesController");
        LOGGER.info("Issue Number: {}, Request: {}", issueNumber, transientMeetingNotes);

        TransientMeetingNotes updatedNotes = meetingNotesService.updateTransientMeetingNotes(issueNumber, transientMeetingNotes);
        LOGGER.info("Successfully updated transient meeting notes");

        return ResponseEntity.ok(updatedNotes);
    }


    /**
     * Deletes government meeting notes by issue number, category, and notes key.
     *
     * @param issueNumber the issue number to which the government meeting notes belong
     * @param category    the category of meeting notes (e.g., "general", "regionAndFSA")
     * @param notesKey    the unique key of the meeting notes to delete
     */
    @DeleteMapping("/transient/{issueNumber}/{category}/{notesKey}")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MeetingNotes','update')")
    public ResponseEntity<String> deleteTransientMeetingNotes(@PathVariable String issueNumber, @PathVariable String category, @PathVariable String notesKey) {
        LOGGER.info("Start of deleteTransientMeetingNotes method in MeetingNotesController");
        LOGGER.info("Issue Number: {}, Category: {}, Notes Key: {}", issueNumber, category, notesKey);

        long modifiedCount = meetingNotesService.deleteTransientMeetingNotes(issueNumber, StringUtils.lowerCase(category), StringUtils.lowerCase(notesKey));
        return ResponseEntity.status(modifiedCount > 0 ? HttpStatus.NO_CONTENT : HttpStatus.NOT_FOUND).build();
    }


    /**
     * Retrieves all TRG meeting notes for a specific issue number (issue-level, stored in meeting_notes).
     *
     * @param issueNumber the issue number to search for
     * @return TRGIssueMeetingNotesResponse containing issueNumber and the trg list
     */
    @GetMapping("/trg-issue/{issueNumber}")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MeetingNotes','read')")
    public ResponseEntity<MeetingNotesTRGResponse> getTRGIssueMeetingNotes(@PathVariable String issueNumber) {
        LOGGER.info("Start of getTRGIssueMeetingNotes in MeetingNotesController, issueNumber: {}", issueNumber);
        MeetingNotesTRGResponse response = meetingNotesService.getTRGIssueMeetingNotes(issueNumber);
        return ResponseEntity.ok(response);
    }

    /**
     * Adds TRG meeting notes to a specific issue number (issue-level, stored in meeting_notes).
     *
     * @param issueNumber     the issue number to which the TRG meeting notes will be added
     * @param trgMeetingNotes the details of the TRG meeting notes to add
     * @return TRGIssueMeetingNotesResponse containing issueNumber and the updated trg list
     */
    @PostMapping("/trg-issue/{issueNumber}")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MeetingNotes','update')")
    public ResponseEntity<MeetingNotesTRGResponse> addTRGIssueMeetingNotes(@PathVariable String issueNumber, @RequestBody TRGMeetingNotes trgMeetingNotes) {
        LOGGER.info("Start of addTRGIssueMeetingNotes in MeetingNotesController, issueNumber: {}", issueNumber);
        LOGGER.info("Create meeting notes TRG MeetingNotes: {}", trgMeetingNotes);

        MeetingNotesTRGResponse response = meetingNotesService.addTRGIssueMeetingNotes(issueNumber, trgMeetingNotes);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    /**
     * Updates TRG meeting notes for a specific issue number (issue-level, stored in meeting_notes).
     *
     * @param issueNumber     the issue number to which the TRG meeting notes belong
     * @param sequenceId      the sequence ID of the TRG meeting note to update (path variable)
     * @param trgMeetingNotes the updated details of the TRG meeting notes
     * @return the updated TRGMeetingNotes or error status
     */
    @PutMapping("/trg-issue/{issueNumber}/{sequenceId}")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MeetingNotes','update')")
    public ResponseEntity<TRGMeetingNotes> updateTRGIssueMeetingNotes(@PathVariable String issueNumber, @PathVariable int sequenceId, @RequestBody TRGMeetingNotes trgMeetingNotes) {
        LOGGER.info("Start of updateTRGIssueMeetingNotes in MeetingNotesController, issueNumber: {}, sequenceId: {}", issueNumber, sequenceId);
        LOGGER.info("Update meeting notes for TRG: {}", trgMeetingNotes);

        trgMeetingNotes.setSequenceId(sequenceId);
        long updateCount = meetingNotesService.updateTRGIssueMeetingNotes(issueNumber, trgMeetingNotes);
        return ResponseEntity.status(updateCount > 0 ? HttpStatus.OK : HttpStatus.NOT_FOUND).body(trgMeetingNotes);
    }

    /**
     * Deletes TRG meeting notes by issue number and sequence ID (issue-level, stored in meeting_notes).
     *
     * @param issueNumber the issue number to which the TRG meeting notes belong
     * @param sequenceId  the sequence ID of the note to delete
     */
    @DeleteMapping("/trg-issue/{issueNumber}/{sequenceId}")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MeetingNotes','update')")
    public ResponseEntity<String> deleteTRGIssueMeetingNotes(@PathVariable String issueNumber, @PathVariable int sequenceId) {
        LOGGER.info("Start of deleteTRGIssueMeetingNotes in MeetingNotesController, issueNumber: {}, sequenceId: {}", issueNumber, sequenceId);

        long modifiedCount = meetingNotesService.deleteTRGIssueMeetingNotes(issueNumber, sequenceId);
        return ResponseEntity.status(modifiedCount > 0 ? HttpStatus.NO_CONTENT : HttpStatus.NOT_FOUND).build();
    }

    /**
     * Retrieves a specific TRG issue-level meeting note by its sequence ID.
     *
     * @param issueNumber the issue number associated with the meeting note
     * @param sequenceId  the sequence ID of the TRG meeting note to retrieve
     * @return ResponseEntity containing the TRGMeetingNotes or NOT_FOUND
     */
    @GetMapping("/trg-issue/{issueNumber}/{sequenceId}")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MeetingNotes','read')")
    public ResponseEntity<TRGMeetingNotes> getTRGIssueMeetingNoteBySequenceId(@PathVariable String issueNumber, @PathVariable int sequenceId) {
        LOGGER.info("Start of getTRGIssueMeetingNoteBySequenceId in MeetingNotesController, issueNumber: {}, sequenceId: {}", issueNumber, sequenceId);

        TRGMeetingNotes meetingNote = meetingNotesService.getTRGIssueMeetingNoteBySequenceId(issueNumber, sequenceId);
        if (Objects.isNull(meetingNote)) {
            LOGGER.info("No TRG issue meeting note found for issueNumber: {}, sequenceId: {}", issueNumber, sequenceId);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        return ResponseEntity.ok(meetingNote);
    }

    /**
     * Deletes only the recovery plan from a specific TRG issue-level meeting note.
     * The meeting notes will be retained.
     *
     * @param issueNumber the issue number
     * @param sequenceId  the sequence ID of the TRG meeting note
     * @return success or error message
     */
    @DeleteMapping("/trg-issue/{issueNumber}/{sequenceId}/recoveryplan")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MeetingNotes','update')")
    public ResponseEntity<String> deleteTRGIssueRecoveryPlan(@PathVariable String issueNumber, @PathVariable int sequenceId) {
        LOGGER.info("Start of deleteTRGIssueRecoveryPlan in MeetingNotesController, issueNumber: {}, sequenceId: {}", issueNumber, sequenceId);

        final long deleteCount = meetingNotesService.deleteTRGIssueRecoveryPlan(issueNumber, sequenceId);
        if (deleteCount > 0)
            return ResponseEntity.ok("Recovery plan deleted successfully");
        else
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Recovery plan not found for the given parameters");
    }

    /**
     * Adds TRG meeting notes to a specific issue number.
     *
     * @param issueNumber        the issue number to which the TRG meeting notes will be added
     * @param trgMeetingNotesDTO the details of the TRG meeting notes including implId and populationId
     * @return the updated MeetingNotes document
     */
    @PostMapping("/trg/{issueNumber}")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MeetingNotes','update')")
    public ResponseEntity<MeetingNotesWithPopulationResponse> addTRGMeetingNotes(@PathVariable String issueNumber, @Valid @RequestBody TRGMeetingNotesDTO trgMeetingNotesDTO) {
        LOGGER.info("Start of addTRGMeetingNotes method in MeetingNotesController");
        LOGGER.info("Issue Number: {}, TRG Meeting Notes DTO: {}", issueNumber, trgMeetingNotesDTO);

        MeetingNotesWithPopulationResponse savedMeetingNotes = meetingNotesService.addTRGMeetingNotes(issueNumber, trgMeetingNotesDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedMeetingNotes);
    }

    /**
     * Retrieves a specific TRG meeting note entry by its sequence ID.
     *
     * @param issueNumber  the issue number associated with the meeting note
     * @param populationId the population ID for the meeting note
     * @param id           the sequence ID of the TRG meeting note to retrieve
     * @return ResponseEntity containing the TRGMeetingNotes object or an appropriate error response
     */
    @GetMapping("/trg/{issueNumber}/{populationId}/{id}")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MeetingNotes','read')")
    public ResponseEntity<TRGMeetingNotes> getTRGMeetingNoteBySequenceId(@PathVariable String issueNumber, @PathVariable String populationId, @PathVariable int id) {
        LOGGER.info("Start of getTRGMeetingNoteBySequenceId method in MeetingNotesController");

        if (!isValidPopulationId(populationId))
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();

        final String implementationId = populationId.substring(0, populationId.lastIndexOf("-"));
        TRGMeetingNotes meetingNote = meetingNotesService.getTRGMeetingNoteBySequenceId(issueNumber, implementationId, populationId, id);
        if (Objects.isNull(meetingNote)) {
            LOGGER.info("No TRG meeting note found for the given parameters");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }

        return ResponseEntity.ok(meetingNote);
    }

    /**
     * Retrieves TRG meeting notes for a specific issue number, implementation ID, and population ID.
     *
     * @param issueNumber  the issue number to search for
     * @param populationId the population ID associated with the meeting notes
     * @return a ResponseEntity containing the TRG meeting notes if found, or a NOT_FOUND status if not found
     */
    @GetMapping("/trg/{issueNumber}/{populationId}")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MeetingNotes','update')")
    public ResponseEntity<?> getTRGMeetingNotes(@PathVariable String issueNumber, @PathVariable String populationId) {
        LOGGER.info("Start of getTRGMeetingNotes method in MeetingNotesController");

        if (!isValidPopulationId(populationId))
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();

        final String implId = populationId.substring(0, populationId.lastIndexOf("-"));
        MeetingNotesWithPopulation meetingNotesWithPopulation = meetingNotesService.getTRGMeetingNotes(issueNumber, implId, populationId);
        if (Objects.isNull(meetingNotesWithPopulation)) {
            LOGGER.info("No TRG meeting notes found for the given issue number, implId, and populationId");
            return ResponseEntity.ok(Collections.emptyList());
        }

        return ResponseEntity.ok(meetingNotesWithPopulation);
    }

    /**
     * Updates TRG meeting notes for a specific issue number and sequence ID.
     *
     * @param issueNumber        the issue number to which the TRG meeting notes belong
     * @param id                 the sequence ID of the TRG meeting notes to update
     * @param trgMeetingNotesDTO the updated details including implId and populationId
     * @return the updated TRGMeetingNotesDTO
     */
    @PutMapping("/trg/{issueNumber}/{id}")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MeetingNotes','update')")
    public ResponseEntity<TRGMeetingNotesDTO> updateTRGMeetingNotes(@PathVariable String issueNumber, @PathVariable int id, @Valid @RequestBody TRGMeetingNotesDTO trgMeetingNotesDTO) {
        LOGGER.info("Start of updateTRGMeetingNotes method in MeetingNotesController");
        LOGGER.info("Issue Number: {}, Sequence ID: {}, DTO: {}", issueNumber, id, trgMeetingNotesDTO);

        trgMeetingNotesDTO.setSequenceId(id);
        final long updateCount = meetingNotesService.updateTRGMeetingNotes(issueNumber, trgMeetingNotesDTO);
        return ResponseEntity.status(updateCount > 0 ? HttpStatus.OK : HttpStatus.NOT_FOUND).body(trgMeetingNotesDTO);
    }

    /**
     * Deletes TRG meeting notes by issue number, implId, populationId, and sequence ID
     *
     * @param issueNumber  the issue number to which the TRG meeting notes belong
     * @param populationId the population id
     * @param sequenceId   the sequence ID of the meeting notes to delete
     */
    @DeleteMapping("/trg/{issueNumber}/{populationId}/{sequenceId}")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MeetingNotes','update')")
    public ResponseEntity<String> deleteTRGMeetingNotes(@PathVariable String issueNumber, @PathVariable String populationId, @PathVariable int sequenceId) {
        LOGGER.info("Start of deleteTRGMeetingNotes method in MeetingNotesController");

        if (!isValidPopulationId(populationId))
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();

        final String implementationId = populationId.substring(0, populationId.lastIndexOf("-"));
        long modifiedCount = meetingNotesService.deleteTRGMeetingNotes(issueNumber, implementationId, populationId, sequenceId);
        return ResponseEntity.status(modifiedCount > 0 ? HttpStatus.NO_CONTENT : HttpStatus.NOT_FOUND).build();
    }

    /**
     * Deletes only the recovery plan from a specific TRG meeting note.
     * The meeting notes will be retained.
     *
     * @param issueNumber  the issue number
     * @param populationId the population id
     * @param id           the sequence ID of the TRG meeting note
     * @return success or error message
     */
    @DeleteMapping("/trg/{issueNumber}/{populationId}/{id}/recoveryplan")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MeetingNotes','update')")
    public ResponseEntity<String> deleteTRGRecoveryPlan(@PathVariable String issueNumber, @PathVariable String populationId, @PathVariable int id) {
        LOGGER.info("Start of deleteTRGRecoveryPlan method in MeetingNotesController");

        if (!isValidPopulationId(populationId))
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();

        final String implId = populationId.substring(0, populationId.lastIndexOf("-"));
        final long deleteCount = meetingNotesService.deleteTRGRecoveryPlan(issueNumber, implId, populationId, id);
        if (deleteCount > 0)
            return ResponseEntity.ok("Recovery plan deleted successfully");
        else
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Recovery plan not found for the given parameters");
    }

    /**
     * Adds FRC meeting notes for a specific issue number.
     *
     * @param issueNumber        the issue number
     * @param frcMeetingNotesDTO the DTO containing implId, populationId, and FRC meeting notes
     * @return ResponseEntity with the created MeetingNotesWithPopulation
     */
    @PostMapping("/frc/{issueNumber}")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MeetingNotes','update')")
    public ResponseEntity<MeetingNotesWithPopulationResponse> addFRCMeetingNotes(@PathVariable String issueNumber, @RequestBody @Valid FRCMeetingNotesDTO frcMeetingNotesDTO) {
        LOGGER.info("Start of addFRCMeetingNotes method in MeetingNotesController for issueNumber: {}", issueNumber);

        MeetingNotesWithPopulationResponse result = meetingNotesService.addFRCMeetingNotes(issueNumber, frcMeetingNotesDTO);

        LOGGER.info("End of addFRCMeetingNotes method in MeetingNotesController");
        return new ResponseEntity<>(result, HttpStatus.CREATED);
    }

    /**
     * Retrieves FRC meeting notes for a specific issue number, implementation ID, and population ID.
     *
     * @param issueNumber  the issue number to search for
     * @param populationId the population ID associated with the meeting notes
     * @return a ResponseEntity containing the FRC meeting notes if found, or a NOT_FOUND status if not found
     */
    @GetMapping("/frc/{issueNumber}/{populationId}")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MeetingNotes','update')")
    public ResponseEntity<?> getFRCMeetingNotes(@PathVariable String issueNumber, @PathVariable String populationId) {
        LOGGER.info("Start of getFRCMeetingNotes method in MeetingNotesController");

        if (!isValidPopulationId(populationId))
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();

        final String implementationId = populationId.substring(0, populationId.lastIndexOf("-"));
        LOGGER.info("Issue Number: {}, ImplId: {}, PopulationId: {}", issueNumber, implementationId, populationId);

        MeetingNotesWithPopulation meetingNotesWithPopulation = meetingNotesService.getFrcMeetingNotes(issueNumber, implementationId, populationId);
        if (Objects.isNull(meetingNotesWithPopulation)) {
            LOGGER.info("No FRC meeting notes found for the given issue number, implementationId, and populationId");
            return ResponseEntity.ok(Collections.emptyList());
        }
        return ResponseEntity.ok(meetingNotesWithPopulation);
    }

    /**
     * API endpoint to retrieve a specific FRC meeting note entry by its sequence ID.
     *
     * @param issueNumber  the issue number associated with the meeting note
     * @param populationId the population ID for the meeting note
     * @param sequenceId   the sequence ID of the FRC meeting note to retrieve
     * @return ResponseEntity containing the FRCMeetingNotes object or an appropriate error response
     */
    @GetMapping("/frc/{issueNumber}/{populationId}/{sequenceId}")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MeetingNotes','read')")
    public ResponseEntity<FRCMeetingNotes> getFRCMeetingNoteBySequenceId(@PathVariable String issueNumber, @PathVariable String populationId, @PathVariable int sequenceId) {
        LOGGER.info("Start of getFRCMeetingNoteBySequenceId method in MeetingNotesController");
        LOGGER.info("Issue Number: {}, PopulationId: {}, Sequence ID: {}", issueNumber, populationId, sequenceId);

        if (!isValidPopulationId(populationId))
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();

        final String implId = populationId.substring(0, populationId.lastIndexOf("-"));
        FRCMeetingNotes meetingNote = meetingNotesService.getFRCMeetingNoteBySequenceId(issueNumber, implId, populationId, sequenceId);

        if (Objects.isNull(meetingNote)) {
            LOGGER.info("No FRC meeting note found for the given parameters");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        return ResponseEntity.ok(meetingNote);
    }

    /**
     * Deletes FRC meeting notes by issue number, implementation ID, population ID, and sequence ID.
     *
     * @param issueNumber  the issue number to which the FRC meeting notes belong
     * @param populationId the population ID associated with the meeting notes
     * @param sequenceId   the sequence ID of the meeting notes to delete
     */
    @DeleteMapping("/frc/{issueNumber}/{populationId}/{sequenceId}")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MeetingNotes','update')")
    public ResponseEntity<String> deleteFRCMeetingNotes(@PathVariable String issueNumber, @PathVariable String populationId, @PathVariable int sequenceId) {
        LOGGER.info("Start of deleteFRCMeetingNotes method in MeetingNotesController");

        if (!isValidPopulationId(populationId))
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();

        final String implementationId = populationId.substring(0, populationId.lastIndexOf("-"));
        long modifiedCount = meetingNotesService.deleteFRCMeetingNotes(issueNumber, implementationId, populationId, sequenceId);
        if (modifiedCount > 0) {
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body("FRC meeting note deleted successfully for sequenceId: " + sequenceId);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No FRC meeting note found for the given parameters");
        }
    }

    /**
     * Updates FRC meeting notes for a specific issue number and sequence ID.
     *
     * @param issueNumber        the issue number to which the FRC meeting notes belong
     * @param sequenceId         the sequence ID of the FRC meeting notes to update
     * @param frcMeetingNotesDTO the updated FRC meeting notes data transfer object
     * @return a ResponseEntity containing the updated FRCMeetingNotesDTO and appropriate HTTP status
     */
    @PutMapping("/frc/{issueNumber}/{sequenceId}")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MeetingNotes','update')")
    public ResponseEntity<FRCMeetingNotesDTO> updateFRCMeetingNotes(@PathVariable String issueNumber, @PathVariable int sequenceId, @Valid @RequestBody FRCMeetingNotesDTO frcMeetingNotesDTO) {

        LOGGER.info("Start of updateFRCMeetingNotes method in MeetingNotesController");
        LOGGER.info("Issue Number: {}, Sequence ID: {}, FRC Meeting Notes DTO: {}", issueNumber, sequenceId, frcMeetingNotesDTO);

        frcMeetingNotesDTO.getMeetingnotes().setSequenceId(sequenceId);
        long updateCount = meetingNotesService.updateFRCMeetingNotes(issueNumber, frcMeetingNotesDTO);
        return ResponseEntity.status(updateCount > 0 ? HttpStatus.OK : HttpStatus.NOT_FOUND).body(frcMeetingNotesDTO);
    }

    /**
     * Sets the edit status of a meeting note card.
     *
     * @param meetingNotesEdit the details of the meeting note edit status to set
     */
    @PutMapping("/edit-status")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MeetingNotes','update')")
    public ResponseEntity<String> setCardEditStatus(@Valid @RequestBody MeetingNotesEdit meetingNotesEdit) {
        LOGGER.info("Start of setCardEditStatus method in MeetingNotesController");
        LOGGER.info("MeetingNotesEdit: {}", meetingNotesEdit);

        long updateResult;
        try {
            updateResult = meetingNotesService.setCardEditStatus(meetingNotesEdit);
            LOGGER.info("End of setCardEditStatus method in MeetingNotesController : {}", updateResult);
            if (meetingNotesEdit.category().equalsIgnoreCase("trg") || meetingNotesEdit.category().equalsIgnoreCase("frc")) {
                return ResponseEntity.ok("Edit status set for issue number: " + meetingNotesEdit.issueNumber() + ", category: " + meetingNotesEdit.category() + ", populationId: " + meetingNotesEdit.populationId());
            }
            return ResponseEntity.ok("Edit status set for issue number: " + meetingNotesEdit.issueNumber() + ", category: " + meetingNotesEdit.category());
        } catch (GridException e) {
            LOGGER.error("Error while setting card edit status: {}", e.getMessage());
            return ResponseEntity.status(e.getStatus()).body(e.getDescription());
        }
    }


    /**
     * Sets the edit status of a transient meeting note card.
     *
     * @param transientMeetingNotesEdit the details of the transient meeting note edit status to set
     */
    @PutMapping("/transient-edit-status")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MeetingNotes','update')")
    public ResponseEntity<String> setTransientCardEditStatus(@Valid @RequestBody TransientMeetingNotesEdit transientMeetingNotesEdit) {
        LOGGER.info("Start of setTransientCardEditStatus method in MeetingNotesController");
        LOGGER.info("TransientMeetingNotesEdit: {}", transientMeetingNotesEdit);

        long updateResult;
        try {
            updateResult = meetingNotesService.setTransientCardEditStatus(transientMeetingNotesEdit);
            LOGGER.info("End of setTransientCardEditStatus method in MeetingNotesController : {}", updateResult);
            return ResponseEntity.ok("Edit status set for issue number: " + transientMeetingNotesEdit.issueNumber() + ", category: " + transientMeetingNotesEdit.category() + ", key: " + transientMeetingNotesEdit.key());
        } catch (GridException e) {
            LOGGER.error("Error while setting transient card edit status: {}", e.getMessage());
            return ResponseEntity.status(e.getStatus()).body(e.getDescription());
        }
    }

    /**
     * Clears the edit status of a meeting note card.
     *
     * @param meetingNotesEdit the details of the meeting note edit status to clear
     */
    @PutMapping("/reset-edit-status")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MeetingNotes','update')")
    public ResponseEntity<?> resetEditStatus(@Valid @RequestBody MeetingNotesEdit meetingNotesEdit) {
        LOGGER.info("Start of resetEditStatus method in MeetingNotesController : {}", meetingNotesEdit);

        UpdateResult updateResult;
        try {
            updateResult = meetingNotesService.resetEdit(meetingNotesEdit);
            final long modifiedCount = updateResult.getModifiedCount();
            if (meetingNotesEdit.category().equalsIgnoreCase(CATEGORY_TRG) || meetingNotesEdit.category().equalsIgnoreCase(CATEGORY_FRC)) {
                return ResponseEntity.ok("Edit status reset for issue number: " + meetingNotesEdit.issueNumber() + ", category: " + meetingNotesEdit.category() + ", populationId: " + meetingNotesEdit.populationId());
            }
            return ResponseEntity.status(modifiedCount > 0 ? HttpStatus.OK : HttpStatus.NOT_FOUND)
                    .body("Edit status reset for issue number: " + meetingNotesEdit.issueNumber() + ", category: " + meetingNotesEdit.category());
        } catch (GridException gridException) {
            return ResponseEntity.status(gridException.getStatus()).body(gridException.getDescription());
        }
    }

    /**
     * Clears the edit status of a transient meeting note card.
     *
     * @param transientMeetingNotesEdit the details of the transient meeting note edit status to clear
     */
    @PutMapping("/transient-reset-edit-status")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MeetingNotes','update')")
    public ResponseEntity<?> resetTransientEditStatus(@Valid @RequestBody TransientMeetingNotesEdit transientMeetingNotesEdit) {
        LOGGER.info("Start of resetTransientEditStatus method in MeetingNotesController : {}", transientMeetingNotesEdit);

        UpdateResult updateResult;
        try {
            updateResult = meetingNotesService.resetTransientEdit(transientMeetingNotesEdit);
            final long modifiedCount = updateResult.getModifiedCount();
            return ResponseEntity.status(modifiedCount > 0 ? HttpStatus.OK : HttpStatus.NOT_FOUND)
                    .body("Edit status reset for issue number: " + transientMeetingNotesEdit.issueNumber() + ", category: " + transientMeetingNotesEdit.category() + ", key: " + transientMeetingNotesEdit.key());
        } catch (GridException gridException) {
            return ResponseEntity.status(gridException.getStatus()).body(gridException.getDescription());
        }
    }

    /**
     * Retrieves the status for a specific meeting note card.
     *
     * @param issueNumber       the issue number to search for
     * @param forumTypeCategory the category of meeting notes (e.g., "ccrg", "csf", "eprc", "govt")
     * @param sequenceId        the sequence ID of the meeting note card
     * @return the MeetingNotes document containing the status of the specified meeting note card
     */
    @GetMapping("{issueNumber}/{forumTypeCategory}/{sequenceId}")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MeetingNotes','read')")
    public ResponseEntity<MeetingNotes> getEditStatus(@PathVariable String issueNumber, @PathVariable String forumTypeCategory, @PathVariable int sequenceId) {
        LOGGER.info("Start of getEditStatus method in MeetingNotesController, Issue Number: {}, ForumTypeCategory: {}, Sequence ID: {}", issueNumber, forumTypeCategory, sequenceId);
        return ResponseEntity.ok(meetingNotesService.getStatusForMeetingNoteCard(issueNumber, StringUtils.lowerCase(forumTypeCategory), sequenceId));
    }

    /**
     * Retrieves transient FSA roles for a specific issue number.
     *
     * @param issueNumber the issue number to search for
     * @return the TransientFSARoles containing the transient roles for the specified issue number
     */
    @GetMapping("/transient-role/{issueNumber}")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MeetingNotes','read')")
    public ResponseEntity<TransientFSARoles> getTransientMeetingNotesRole(@PathVariable String issueNumber) {
        LOGGER.info("Start of getTransientMeetingNotesRole method in MeetingNotesController for issueNumber: {}", issueNumber);
        TransientFSARoles response = meetingNotesService.getTransientMeetingNotesRole(issueNumber);
        return ResponseEntity.ok(response);
    }

    /**
     * Validates the population ID format.
     * The population ID should contain a hyphen and should not end with a hyphen.
     *
     * @param populationId the population ID to validate
     * @return true if the population ID is valid, false otherwise
     */
    private boolean isValidPopulationId(final String populationId) {
        return populationId != null && populationId.contains("-") && !populationId.endsWith("-");
    }

    /**
     * Retrieves transient meeting notes history for a specific issue number, category, role, and isNoteActive status.
     *
     * @param issueNumber  the issue number to search for
     * @param category     the category (general or regionandfsa)
     * @param key          the role for which to retrieve "general" or title of the notes for "regionandfsa"
     * @param isNoteActive the active status of the notes to retrieve
     * @return TransientMeetingNotes containing the filtered notes
     */
    @GetMapping("/transient-history/{issueNumber}/{category}/{key}")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MeetingNotes','read')")
    public ResponseEntity<?> getTransientMeetingNotesHistory(
            @PathVariable String issueNumber,
            @PathVariable String category,
            @PathVariable String key,
            @RequestParam boolean isNoteActive) throws GridException {
        TransientMeetingNotes notes = meetingNotesService.getTransientMeetingNotesHistory(issueNumber, category, key, isNoteActive);
        if (CATEGORY_GENERAL.equalsIgnoreCase(category)) {
            return ResponseEntity.ok(notes.getGeneralList());
        } else if (CATEGORY_REGION_FSA.equalsIgnoreCase(category)) {
            return ResponseEntity.ok(notes.getRegionandfsaList());
        }
        return ResponseEntity.ok(List.of());
    }

    /**
     * Valid meeting notes types include: EPRC, CSF, CCRG, GOVERNMENT, TRG, FRC, 14D, CARB, TC, EMM.
     * </p>
     *
     * @param request the export request containing the issue number, cdsid, and meeting notes types to include
     */
    @PostMapping("/export")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MeetingNotes','read')")
    public ResponseEntity<StreamingResponseBody> exportMeetingNotesDocument(
            @Valid @RequestBody ExportMeetingNotesDocumentRequest request) throws GridException {
        LOGGER.info("Start of exportMeetingNotesDocument method in MeetingNotesController");
        LOGGER.info("Request: issueNumber={}, levelOfMeetingNotes={}, cdsid={}, meetingNotesTypes={}",
                request.getIssueNumber(), request.getLevelOfMeetingNotes(),
                request.getCdsid(), request.getMeetingNotesTypes());

        // Delegate to service layer for business logic and document generation
        ResponseEntity<StreamingResponseBody> response = meetingNotesService.exportMeetingNotesDocument(request);

        LOGGER.info("End of exportMeetingNotesDocument method in MeetingNotesController");
        return response;
    }
}
