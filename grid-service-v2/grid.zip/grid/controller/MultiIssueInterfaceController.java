package com.ford.grid.controller;

import com.ford.grid.common.SystemWideResponses;
import com.ford.grid.model.dto.response.PagedResponse;
import com.ford.grid.model.entity.ForumAgenda;
import com.ford.grid.model.entity.MultiIssueInterfaceRequest;
import com.ford.grid.model.entity.MultiIssueResponse;
import com.ford.grid.model.entity.ScheduleNextReviewRequest;
import com.ford.grid.service.MultiIssueInterfaceService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v2/summary")
@RequiredArgsConstructor
public class MultiIssueInterfaceController {

    private static final Logger LOGGER = LoggerFactory.getLogger(MultiIssueInterfaceController.class);
    private static final int MAX_PAGE_SIZE = 100;

    // Allowed issuePhase values — DB stores e.g. "Investigation (CCRG)" but API accepts the prefix
    private static final java.util.Set<String> ALLOWED_ISSUE_PHASES = java.util.Set.of(
            "Investigation", "14D", "TRG", "FRC", "Launch"
    );

    // Allowed hideIssues values — these are hide_issues_options.value (UI display labels).
    // Semantics mirror ExportNotesViewQueryService.applyHideIssuesFilter():
    //   "Concluded Issues" → excludes issuePhase matching Concluded(<forumLabel>) for the REQUESTED forum only
    //   "Approved Issues"  → excludes issuePhase matching Approved(<forumLabel>)  for the REQUESTED forum only
    //   "Monitor Issues"   → excludes issuePhase starting with "Monitor" (not forum-qualified in DB)
    // Applied as MongoDB $nor regex in MultiIssueInterfaceServiceImpl — no in-memory filtering.
    private static final java.util.Set<String> ALLOWED_HIDE_ISSUES = java.util.Set.of(
            "Concluded Issues", "Approved Issues", "Monitor Issues"
    );

    private final MultiIssueInterfaceService multiIssueInterfaceService;

    @PostMapping("/multiIssues")
    @Operation(summary = "Get Multi Issue Interface",
            description = "Returns recall_issue records filtered by leadRegion, segment, forumType, issuePhase. " +
                    "issuePhase allowed values: Investigation, 14D, TRG, FRC, Launch. " +
                    "Optional: hideIssues (exclude phases), agency (Government only, multi-select). " +
                    "Responds with issueNumber, issueTitle, openedDate wrapped in a PagedResponse.")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<PagedResponse<MultiIssueResponse>> getMultiIssueReport(
            @Valid @RequestBody MultiIssueInterfaceRequest request) {

        LOGGER.info("Start of getMultiIssueReport - leadRegion: {}, segment: {}, forumType: {}, issuePhase: {}, hideIssues: {}, agency: {}, page: {}, size: {}, sortBy: {}, direction: {}",
                request.getLeadRegion(), request.getSegment(), request.getForumType(), request.getIssuePhase(),
                request.getHideIssues(), request.getAgency(),
                request.getPage(), request.getSize(), request.getSortBy(), request.getDirection());

        // ── Validate leadRegion — mandatory, must not be null or blank ───────────
        if (!org.springframework.util.StringUtils.hasText(request.getLeadRegion())) {
            LOGGER.error("leadRegion is required and must not be blank.");
            return ResponseEntity.badRequest().build();
        }

        // ── Validate segment — mandatory, must not be null or empty
        List<String> segments = request.getSegment();
        if (segments == null || segments.isEmpty() || segments.stream().anyMatch(segment -> segment == null || segment.isBlank())) {
            LOGGER.error("segment is required and must not be blank.");
            return ResponseEntity.badRequest().build();
        }

        // ── Validate forumType — mandatory, must not be null or blank ──────────
        if (!org.springframework.util.StringUtils.hasText(request.getForumType())) {
            LOGGER.error("forumType is required and must not be blank.");
            return ResponseEntity.badRequest().build();
        }

        // ── Validate issuePhase — must not be empty, all values must be allowed ─
        List<String> issuePhaseList = request.getIssuePhase();
        if (issuePhaseList == null || issuePhaseList.isEmpty()) {
            LOGGER.error("issuePhase must not be empty. Allowed values: {}.", ALLOWED_ISSUE_PHASES);
            return ResponseEntity.badRequest().build();
        }
        List<String> invalidPhases = issuePhaseList.stream()
                .filter(p -> p == null || p.isBlank() || !ALLOWED_ISSUE_PHASES.contains(p))
                .toList();
        if (!invalidPhases.isEmpty()) {
            LOGGER.error("Invalid issuePhase value(s): {}. Allowed values: {}.", invalidPhases, ALLOWED_ISSUE_PHASES);
            return ResponseEntity.badRequest().build();
        }

        // ── Validate hideIssues — optional, but any provided value must be allowed ─
        List<String> hideIssuesList = request.getHideIssues();
        if (hideIssuesList != null && !hideIssuesList.isEmpty()) {
            List<String> invalidHide = hideIssuesList.stream()
                    .filter(h -> h == null || h.isBlank() || !ALLOWED_HIDE_ISSUES.contains(h))
                    .toList();
            if (!invalidHide.isEmpty()) {
                LOGGER.error("Invalid hideIssues value(s): {}. Allowed values: {}.", invalidHide, ALLOWED_HIDE_ISSUES);
                return ResponseEntity.badRequest().build();
            }
        }

        // ── Validate direction — must be ASC or DESC ──────────────────────────
        String directionStr = request.getDirection();
        if (directionStr == null || directionStr.isBlank()
                || (!directionStr.equalsIgnoreCase("ASC") && !directionStr.equalsIgnoreCase("DESC"))) {
            LOGGER.error("Invalid direction value: '{}'. Must be ASC or DESC.", directionStr);
            return ResponseEntity.badRequest().build();
        }

        // ── Validate page — must be >= 0 (default 0 if not provided) ──────────
        int page = request.getPage() != null ? request.getPage() : 0;
        if (page < 0) {
            LOGGER.error("Invalid page value: {}. Must be >= 0.", page);
            return ResponseEntity.badRequest().build();
        }

        // ── Validate size — must be between 1 and MAX_PAGE_SIZE (100) ─────────
        int size = request.getSize() != null ? request.getSize() : 10;
        if (size < 1 || size > MAX_PAGE_SIZE) {
            LOGGER.error("Invalid size value: {}. Must be between 1 and {}.", size, MAX_PAGE_SIZE);
            return ResponseEntity.badRequest().build();
        }

        Sort sort = Sort.by(Sort.Direction.fromString(directionStr), request.getSortBy());
        Pageable pageable = PageRequest.of(page, size, sort);

        PagedResponse<MultiIssueResponse> response = multiIssueInterfaceService.getMultiIssueReport(request, pageable);

        LOGGER.info("End of getMultiIssueReport - returned {} items", response.getTotalElements());
        return ResponseEntity.ok(response);
    }


    /**
     * Appends a new meeting date to the forum agenda for the given issue.
     * For Government forums (forumType="4"), agency is also used to find the record.
     *
     * @param request contains issueNumber, forumType, optional agency, and meetingDate
     * @return 201 Created with the updated ForumAgenda
     */
    @PostMapping("/scheduleNextReview")
    @Operation(summary = "Schedule Next Review",
            description = "Appends a new meeting date to the forum_schedule_agenda record for a given " +
                    "issueNumber + forumType (+ agency for Government forumType=\"4\").")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<ForumAgenda> scheduleNextReview(
            @Valid @RequestBody ScheduleNextReviewRequest request) {

        LOGGER.info("scheduleNextReview - issueNumber: {}, forumType: {}, agency: {}, meetingDate: {}",
                request.getIssueNumber(), request.getForumType(),
                request.getAgency(), request.getMeetingDate());

        ForumAgenda saved = multiIssueInterfaceService.saveScheduleNextReview(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(saved);
    }
}