package com.ford.grid.controller;

import com.ford.grid.exception.GridException;
import com.ford.grid.model.dto.request.ClearNotificationsByDateRequest;
import com.ford.grid.model.dto.request.Notification;
import com.ford.grid.model.dto.request.NotificationPreferencesRequest;
import com.ford.grid.model.dto.request.UserAccessRequestNotificationRequest;
import com.ford.grid.model.dto.request.UserNotifications;
import com.ford.grid.model.dto.response.ClearNotificationsByDateResponse;
import jakarta.validation.Valid;
import com.ford.grid.model.entity.notification.NotificationContacts;
import com.ford.grid.model.entity.notification.NotificationPreferences;
import com.ford.grid.model.entity.notification.NotificationTypes;
import com.ford.grid.security.UserDetailProvider;
import com.ford.grid.service.NotificationService;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v2/notifications")
public class NotificationController {
    private static final Logger LOGGER = LoggerFactory.getLogger(NotificationController.class);

    private final NotificationService notificationService;
    private final UserDetailProvider userDetailProvider;

    /**
     * Retrieves a paginated list of all notification contacts.
     *
     * @param pageable The pagination information.
     * @return A ResponseEntity containing a Page of NotificationContacts.
     */
    @GetMapping("/contacts")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MyIssuesList','read')")
    public ResponseEntity<Page<NotificationContacts>> getAllContacts(Pageable pageable) {
        LOGGER.info("Start of getAllContacts in NotificationController for page: {}", pageable);
        Page<NotificationContacts> contacts = notificationService.getAllContacts(pageable);
        return ResponseEntity.ok(contacts);
    }

    /**
     * Retrieves a paginated list of all notification types.
     *
     * @param pageable The pagination information.
     * @return A ResponseEntity containing a Page of notification types.
     */
    @GetMapping("/types")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MyIssuesList','read')")
    public ResponseEntity<Page<NotificationTypes>> getAllNotificationTypes(Pageable pageable) {
        LOGGER.info("Start of getAllNotificationTypes in NotificationController for page: {}", pageable);
        Page<NotificationTypes> types = notificationService.getAllNotificationTypes(pageable);
        return ResponseEntity.ok(types);
    }

    /**
     * Retrieves the notification preferences for a specific user identified by their cdsId.
     *
     * @param cdsId The unique identifier for the user.
     * @return A ResponseEntity containing the user's NotificationPreferences.
     */
    @GetMapping("/preferences/{cdsId}")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MyIssuesList','read')")
    public ResponseEntity<NotificationPreferences> getNotificationPreferenceForUser(@PathVariable String cdsId) {
        LOGGER.info("Start of getNotificationPreferenceForUser in NotificationController for cdsId: {}", cdsId);
        return ResponseEntity.ok(notificationService.getNotificationPreferenceForUser(cdsId));
    }

    /**
     * Retrieves notifications for a specific user based on their cdsId, type, and name.
     *
     * @param cdsId            The unique identifier for the user.
     * @param notificationType The type of notification.
     * @param notificationName The name associated with the notification.
     * @return A ResponseEntity containing a Notification matching the criteria.
     */
    @GetMapping("/user/{cdsId}/{notificationType}/{notificationName}")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MyIssuesList','read')")
    public ResponseEntity<Notification> getUserNotification(@PathVariable String cdsId, @PathVariable String notificationType, @PathVariable String notificationName) {
        LOGGER.info("Start of getUserNotification in NotificationController for cdsId: {}, notificationType: {}, notificationName: {}",
                cdsId, notificationType, notificationName);

        if (cdsId == null || cdsId.isBlank() || notificationType == null || notificationType.isBlank()
                || notificationName == null || notificationName.isBlank()) {
            return ResponseEntity.badRequest().build();
        }

        Map<String, Notification> userNotification = notificationService.getUserNotification(List.of(cdsId), notificationType, notificationName);
        Notification notification = userNotification != null ? userNotification.get(cdsId) : null;
        if (notification == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(notification);
    }

    /**
     * Retrieves a specific notification preference item using a dedicated preference lookup route.
     * This endpoint mirrors the existing /user/{cdsId}/{notificationType}/{notificationName} behavior
     * without altering existing consumers on older routes.
     */
    @GetMapping("/preferences/lookup/{cdsId}/{notificationType}/{notificationName}")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MyIssuesList','read')")
    public ResponseEntity<Notification> getNotificationPreferenceItem(@PathVariable String cdsId,
                                                                      @PathVariable String notificationType,
                                                                      @PathVariable String notificationName) {
        LOGGER.info("Start of getNotificationPreferenceItem in NotificationController for cdsId: {}, notificationType: {}, notificationName: {}",
                cdsId, notificationType, notificationName);

        if (cdsId == null || cdsId.isBlank() || notificationType == null || notificationType.isBlank()
                || notificationName == null || notificationName.isBlank()) {
            return ResponseEntity.badRequest().build();
        }

        Map<String, Notification> userNotification = notificationService.getUserNotification(List.of(cdsId), notificationType, notificationName);
        Notification notification = userNotification != null ? userNotification.get(cdsId) : null;
        if (notification == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(notification);
    }

    /**
     * Saves the notification preferences for a specific user identified by their cdsId.
     *
     * @param notificationPreferencesRequest The NotificationPreferencesRequest object containing the user's settings to be saved.
     * @return A ResponseEntity indicating the success of the operation.
     */
    @PostMapping()
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:AllIssues','update')")
    public ResponseEntity<String> saveNotificationPreferences(@RequestBody NotificationPreferencesRequest notificationPreferencesRequest) {
        LOGGER.info("Start of saveNotificationPreferences in NotificationController");

        notificationService.saveNotificationPreference(notificationPreferencesRequest);
        return ResponseEntity.ok("Notification preferences saved successfully for the user with cdsId: " + notificationPreferencesRequest.getCdsId());
    }

    /**
     * Updates the "isTo" flag for the authenticated user's notification preference matching the given notificationId,
     * then returns whether any user has "isTo" set to true for that notification.
     *
     * @param notification The Notification object containing the notificationId and the desired isTo value.
     * @return A ResponseEntity containing true if any user has isTo set to true for the notificationId, false otherwise.
     */
    @PostMapping("/checkTo")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MyIssuesList','read')")
    public ResponseEntity<Boolean> checkToPreferences(@RequestBody Notification notification) {
        String cdsId = userDetailProvider.getUser().getCdsID();
        LOGGER.info("Start of checkToPreferences in NotificationController for cdsId: {}", cdsId);
        return ResponseEntity.ok(notificationService.checkToPreference(cdsId, notification));
    }

    /**
     * Retrieves the notification preferences item list for a user.
     * If cdsId is provided as a request parameter (from the UI), it is used directly.
     * Otherwise, the cdsId is extracted from the authenticated user's JWT token.
     * If no preferences exist, a default item with all flags set to false is returned.
     *
     * @param cdsId (optional) The user's cdsId passed from the UI as a query parameter.
     * @return A ResponseEntity containing the list of Notification preference items.
     */
    @GetMapping("/notificationPreferences")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MyIssuesList','read')")
    public ResponseEntity<List<Notification>> getUserNotificationPreferences(
            @RequestParam(value = "cdsId", required = false) String cdsId) {
        LOGGER.info("getUserNotificationPreferences called with cdsId parameter: '{}'", cdsId);
        if (cdsId == null || cdsId.isBlank()) {
            cdsId = userDetailProvider.getUser().getCdsID();
            LOGGER.info("cdsId was null/blank, using JWT token cdsId: '{}'", cdsId);
        }
        LOGGER.info("Start of getUserNotificationPreferences in NotificationController for cdsId: {}", cdsId);
        return ResponseEntity.ok(notificationService.getUserNotificationPreferences(cdsId));
    }

    /**
     * Saves or updates the notification preferences for the authenticated user.
     * The cdsId is extracted from the JWT token of the authenticated user.
     * If a preference document already exists, only items matching by notificationId are updated.
     * If no document exists yet, the full list is saved as a new document.
     *
     * @param notifications The list of Notification objects containing the preferences to save.
     * @return A ResponseEntity containing the saved/updated list of Notification items.
     */
    @PostMapping("/user/preferences")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MyIssuesList','read')")
    public ResponseEntity<List<Notification>> saveUserNotificationPreferences(
            @RequestBody List<Notification> notifications) throws GridException {
        String cdsId = userDetailProvider.getUser().getCdsID();
        LOGGER.info("Start of saveUserNotificationPreferences in NotificationController for cdsId: {}", cdsId);
        List<Notification> saved = notificationService.saveUserNotificationPreferences(cdsId, notifications);
        return ResponseEntity.ok(saved);
    }

    /**
     * Retrieves all user notifications for the authenticated user.
     * The cdsId is extracted from the JWT token of the authenticated user.
     * Returns notifications grouped into active, cleared, and snoozed categories
     * (actions, events, deadlines, and user access requests).
     *
     * @return A ResponseEntity containing UserNotifications with all notification categories.
     * @throws GridException if a database or operational error occurs during retrieval.
     */
    @GetMapping("/dashboard-notifications")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MyIssuesList','read')")
    public ResponseEntity<UserNotifications> getUserNotifications() throws GridException {
        String cdsId = userDetailProvider.getUser().getCdsID();
        LOGGER.info("Start of getUserNotifications in NotificationController for cdsId: {}", cdsId);
        UserNotifications userNotifications = notificationService.getUserNotifications(cdsId);
        return ResponseEntity.ok(userNotifications);
    }

    /**
     * Saves user notifications for the authenticated user.
     * The cdsId is extracted from the JWT token of the authenticated user.
     * Saves notifications grouped into active, cleared, and snoozed categories
     * (actions, events, deadlines, and user access requests).
     *
     * @param userNotifications The UserNotifications object containing notification data to save.
     * @return A ResponseEntity containing the saved UserNotifications.
     * @throws GridException if a database or operational error occurs during save operation.
     */
    @PostMapping("/dashboard-notifications")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MyIssuesList','read')")
    public ResponseEntity<UserNotifications> saveUserNotifications(@RequestBody UserNotifications userNotifications) throws GridException {
        String cdsId = userDetailProvider.getUser().getCdsID();
        LOGGER.info("Start of saveUserNotifications in NotificationController for cdsId: {}", cdsId);
        UserNotifications savedNotifications = notificationService.saveUserNotifications(cdsId, userNotifications);
        return ResponseEntity.ok(savedNotifications);
    }

    @PostMapping("/dashboard-notifications/clear-by-date")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MyIssuesList','read')")
    public ResponseEntity<ClearNotificationsByDateResponse> clearUserNotificationsByDate(@Valid @RequestBody(required = false) ClearNotificationsByDateRequest request)
            throws GridException {
        String cdsId = userDetailProvider.getUser().getCdsID();
        LOGGER.info("Start of clearUserNotificationsByDate in NotificationController for cdsId: {}", cdsId);

        if (request == null || request.getTargetDate() == null) {
            LOGGER.warn("Rejected clearUserNotificationsByDate due to missing targetDate for cdsId: {}", cdsId);
            return ResponseEntity.badRequest().build();
        }

        ClearNotificationsByDateResponse response = notificationService.clearUserNotificationsByDate(cdsId, request);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/user-access-request")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MyIssuesList','read')")
    public ResponseEntity<Void> saveUserAccessRequestNotification(@RequestBody(required = false) UserAccessRequestNotificationRequest request) {
        String cdsId = userDetailProvider.getUser().getCdsID();
        LOGGER.info("Start of saveUserAccessRequestNotification in NotificationController for cdsId: {}", cdsId);

        if (request == null || isEmptyUserAccessRequest(request)) {
            LOGGER.warn("Rejected saveUserAccessRequestNotification due to missing or empty request body for cdsId: {}", cdsId);
            return ResponseEntity.badRequest().build();
        }

        if (Boolean.TRUE.equals(request.getNotifyAdmin())
                && (!StringUtils.hasText(request.getNewUserCdsId())
                || !StringUtils.hasText(request.getRole())
                || !StringUtils.hasText(request.getReason()))) {
            LOGGER.warn("Rejected saveUserAccessRequestNotification due to missing required fields for cdsId: {}", cdsId);
            return ResponseEntity.badRequest().build();
        }

        if (!StringUtils.hasText(request.getAccessRequestedBy())) {
            request.setAccessRequestedBy(cdsId);
        }

        notificationService.saveUserAccessRequestNotifications(request);
        return ResponseEntity.ok().build();
    }

    private boolean isEmptyUserAccessRequest(UserAccessRequestNotificationRequest request) {
        return request.getNotifyAdmin() == null
                && !StringUtils.hasText(request.getNewUserCdsId())
                && !StringUtils.hasText(request.getRole())
                && !StringUtils.hasText(request.getReason())
                && !StringUtils.hasText(request.getAccessRequestedBy());
    }
}