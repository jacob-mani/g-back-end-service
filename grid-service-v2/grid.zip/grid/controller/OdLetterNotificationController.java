package com.ford.grid.controller;

import com.ford.grid.common.SystemWideResponses;
import com.ford.grid.exception.GridException;
import com.ford.grid.model.dto.request.OdLetterNotificationApprovalRequest;
import com.ford.grid.model.dto.request.OdLetterNotificationDeleteRequest;
import com.ford.grid.model.dto.request.OdLetterNotificationUpsertRequest;
import com.ford.grid.model.dto.request.OdLetterReviewerActionRequest;
import com.ford.grid.model.dto.response.OdLetterApproverResponse;
import com.ford.grid.model.entity.OdLetterNotification;
import com.ford.grid.service.GRIDMasterService;
import com.ford.grid.service.ODletterService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v2/document-generation")
@Tag(name = "Document Generation", description = "APIs for document generation details")
public class OdLetterNotificationController {

    private static final Logger logger = LoggerFactory.getLogger(OdLetterNotificationController.class);

    private final GRIDMasterService gridMasterService;

    private final ODletterService oDletterService;



    /**
     * Upserts an OD letter notification record using issueNumber + implId + populationId as the
     * parent key and collabId as the nested key inside collabs[].
     * If a collabId exists, it is replaced with incoming values; otherwise, it is inserted.
     */
    @PostMapping("/od-letter-notification/upsert")
    @Operation(summary = "Upsert OD Letter Notification",
            description = "Upserts od_letter_notification by issueNumber, implId, populationId and collabId")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<OdLetterNotification> upsertOdLetterNotification(@RequestBody OdLetterNotificationUpsertRequest request)
            throws GridException {
        logger.info("Received request to upsert od_letter_notification for issueNumber: {}, implId: {}, populationId: {}",
                request != null ? request.getIssueNumber() : null,
                request != null ? request.getImplId() : null,
                request != null ? request.getPopulationId() : null);
        try {
            OdLetterNotification saved = gridMasterService.upsertOdLetterNotification(request);
            logger.info("Successfully upserted od_letter_notification with id: {}", saved.getId());
            return ResponseEntity.ok(saved);
        } catch (IllegalArgumentException ex) {
            logger.warn("Validation failed while upserting od_letter_notification: {}", ex.getMessage());
            throw new GridException(HttpStatus.BAD_REQUEST, "Invalid request for od_letter_notification upsert", ex.getMessage());
        } catch (Exception ex) {
            logger.error("Failed to upsert od_letter_notification. Error: {}", ex.getMessage(), ex);
            throw new GridException(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to upsert od_letter_notification", ex.getMessage());
        }
    }

    @PostMapping("/od-letter-notification/approve-draft")
    @Operation(summary = "Approve OD Letter Draft",
            description = "Marks initialDraftComplete=true and draftCompletionDate=now for a collab, then writes change log")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<OdLetterNotification> approveDraft(@RequestBody OdLetterNotificationApprovalRequest request)
            throws GridException{
        logger.info("Received request to approve draft for issueNumber: {}, collabId: {}, urgency: {}",
                request.getIssueNumber(), request.getCollabId(), request.getUrgency());
        try {
            request.setStatus("draft");
            OdLetterNotification updated = gridMasterService.approveOdLetterDraft(request);
            return ResponseEntity.ok(updated);
        } catch (GridException ex) {
            throw ex;
        } catch (Exception ex) {
            logger.error("Failed to approve od_letter draft. Error: {}", ex.getMessage(), ex);
            throw new GridException(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to approve od_letter draft", ex.getMessage());
        }
    }


    @DeleteMapping("/od-letter-notification/delete")
    @Operation(summary = "Delete OD Letter Notification",
            description = "Deletes od_letter_notification using issueNumber, implId and populationId from request body")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<String> deleteOdLetterNotification(@RequestBody OdLetterNotificationDeleteRequest request)
            throws GridException {
        logger.info("Received request to delete od_letter_notification for issueNumber: {}, implId: {}, populationId: {}, region: {}, brand: {}, fsaNumber: {}, fsaType: {}, docGenStage: {}",
                request != null ? request.getIssueNumber() : null,
                request != null ? request.getImplId() : null,
                request != null ? request.getPopulationId() : null,
                request != null ? request.getRegion() : null,
                request != null ? request.getBrand() : null,
                request != null ? request.getFsaNumber() : null,
                request != null ? request.getFsaType() : null,
                request != null ? request.getDocGenStage() : null);
        try {
            long deletedCount = gridMasterService.deleteOdLetterNotification(request);
            logger.info("Delete completed for issueNumber: {}, implId: {}, populationId: {}. Deleted record count: {}",
                    request != null ? request.getIssueNumber() : null,
                    request != null ? request.getImplId() : null,
                    request != null ? request.getPopulationId() : null,
                    deletedCount);
            return ResponseEntity.ok("Deleted record count: " + deletedCount);
        } catch (IllegalArgumentException ex) {
            logger.warn("Validation failed while deleting od_letter_notification: {}", ex.getMessage());
            throw new GridException(HttpStatus.BAD_REQUEST, "Invalid request for od_letter_notification delete", ex.getMessage());
        } catch (Exception ex) {
            logger.error("Failed to delete od_letter_notification. Error: {}", ex.getMessage(), ex);
            throw new GridException(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to delete od_letter_notification", ex.getMessage());
        }
    }

    @PostMapping("/od-letter-notification/approve-collab")
    @Operation(summary = "Approve OD Letter",
            description = "Updates approver status in a collab for a specific userId")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<OdLetterNotification> approveOdLetterNotification(@RequestBody OdLetterNotificationApprovalRequest request) throws GridException {
        logger.info("Received request to approve od_letter approver for issueNumber: {}, collabId: {}, userId: {}",
                request.getIssueNumber(), request.getCollabId(), request.getUserId());
        try {
            OdLetterNotification updated = gridMasterService.approveOdLetterNotification(request);
            logger.info("Successfully updated approver status for issueNumber: {}, collabId: {}, userId: {}", request.getIssueNumber(), request.getCollabId(), request.getUserId());
            return ResponseEntity.ok(updated);
        } catch (GridException ex) {
            throw ex;
        } catch (Exception ex) {
            logger.error("Failed to approve od_letter approver. Error: {}", ex.getMessage(), ex);
            throw new GridException(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to approve od_letter approver", ex.getMessage());
        }
    }

    /**
     * Processes reviewer remove/reassign actions for OD letter notifications.
     */
    @PostMapping("/od-letter-notification/reviewer-action")
    @Operation(summary = "Process OD Letter reviewer action",
            description = "Processes REMOVE/REASSIGN action based on actionType")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<Map<String, String>> processOdLetterReviewerAction(@RequestBody OdLetterReviewerActionRequest request)
            throws GridException {
        logger.info("Received reviewer action request for issueNumber: {}, actionType: {}",
                request != null ? request.getIssueNumber() : null,
                request != null ? request.getActionType() : null);
        try {
            long updatedCount = gridMasterService.processOdLetterReviewerAction(request);
            Map<String, String> response = new HashMap<>();
            response.put("message", "Updated record count:" + updatedCount);
            return ResponseEntity.ok(response);
//            return ResponseEntity.ok("Updated record count: " + updatedCount);
        } catch (IllegalArgumentException ex) {
            logger.warn("Validation failed while processing reviewer action: {}", ex.getMessage());
            throw new GridException(HttpStatus.BAD_REQUEST, "Invalid reviewer action request", ex.getMessage());
        } catch (Exception ex) {
            logger.error("Failed to process reviewer action. Error: {}", ex.getMessage(), ex);
            throw new GridException(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to process reviewer action", ex.getMessage());
        }
    }

    @GetMapping("/od-letter-notification/select/{issueNumber}/{region}")
    @Operation(summary = "Select OD Letter Notification",
            description = "Fetches od_letter_notification by issueNumber and fileName")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<List<OdLetterNotification>> getOdLetterNotificationByIssueNumberAndFileName(@PathVariable String issueNumber,
                                                                                                      @PathVariable String region,
                                                                                                      @RequestParam String fileName)
            throws GridException {
        logger.info("Received request to fetch od_letter_notification for issueNumber: {} and fileName: {} and region: {}",
                                                issueNumber, fileName, region);


        try {
            List<OdLetterNotification> notifications =
                    gridMasterService.getOdLetterNotificationsByIssueNumberAndFileName(issueNumber,region, fileName);
            logger.info("Fetched {} od_letter_notification record(s) for issueNumber: {} and fileName: {}",
                    notifications.size(), issueNumber, fileName);
            return ResponseEntity.ok(notifications);
        } catch (IllegalArgumentException ex) {
            logger.warn("Validation failed while fetching od_letter_notification: {}", ex.getMessage());
            throw new GridException(HttpStatus.BAD_REQUEST, "Invalid request for od_letter_notification select", ex.getMessage());
        } catch (Exception ex) {
            logger.error("Failed to fetch od_letter_notification. Error: {}", ex.getMessage(), ex);
            throw new GridException(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to fetch od_letter_notification", ex.getMessage());
        }
    }
    /**
     * Upserts an OD letter notification record using issueNumber + implId + populationId as the
     * parent key and collabId as the nested key inside collabs[].
     * If a collabId exists, it is replaced with incoming values; otherwise, it is inserted.
     */
    @PostMapping("/od-letter-notification/selectOdLetter")
    @Operation(summary = "Select OD Letter Notification",
            description = "Select od_letter_notification by issueNumber, implId, populationId and collabId")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<OdLetterNotification> selectOdLetter(@RequestBody OdLetterNotificationUpsertRequest request)
            throws GridException {
        logger.info("Received request to upsert od_letter_notification for issueNumber: {}, implId: {}, populationId: {}",
                request != null ? request.getIssueNumber() : null,
                request != null ? request.getImplId() : null,
                request != null ? request.getPopulationId() : null);
        try {
            OdLetterNotification saved = gridMasterService.getOdLetterNotificationsByIssueNumberByRegionByBrand(request);
            logger.info("Successfully upserted od_letter_notification with id: {}", saved.getId());
            return ResponseEntity.ok(saved);
        } catch (IllegalArgumentException ex) {
            logger.warn("Validation failed while upserting od_letter_notification: {}", ex.getMessage());
            throw new GridException(HttpStatus.BAD_REQUEST, "Invalid request for od_letter_notification upsert", ex.getMessage());
        } catch (Exception ex) {
            logger.error("Failed to upsert od_letter_notification. Error: {}", ex.getMessage(), ex);
            throw new GridException(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to upsert od_letter_notification", ex.getMessage());
        }
    }

    @GetMapping("/od-letter-notification/approvers")
    @Operation(summary = "Get OD Letter approvers",
            description = "Fetches approvers (role, name, userId, status) from collab_1 and collab_2 by issueNumber, region and fsaNumber")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<List<OdLetterApproverResponse>> getOdLetterApprovers(
            @RequestParam String issueNumber,
            @RequestParam String region,
            @RequestParam String fsaNumber) throws GridException {
        logger.info("Received request to fetch OD Letter approvers for issueNumber: {}, region: {}, fsaNumber: {}",
                issueNumber, region, fsaNumber);
        try {
            List<OdLetterApproverResponse> approvers = gridMasterService.getOdLetterApprovers(issueNumber, region, fsaNumber);
            logger.info("Fetched {} OD Letter approver record(s) for issueNumber: {}, region: {}, fsaNumber: {}",
                    approvers.size(), issueNumber, region, fsaNumber);
            return ResponseEntity.ok(approvers);
        } catch (IllegalArgumentException ex) {
            logger.warn("Validation failed while fetching OD Letter approvers: {}", ex.getMessage());
            throw new GridException(HttpStatus.BAD_REQUEST, "Invalid request for od_letter approvers", ex.getMessage());
        } catch (Exception ex) {
            logger.error("Failed to fetch OD Letter approvers. Error: {}", ex.getMessage(), ex);
            throw new GridException(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to fetch od_letter approvers", ex.getMessage());
        }
    }

    /**
     * Upserts an OD letter notification record using issueNumber + implId + populationId as the
     * parent key and collabId as the nested key inside collabs[].
     * If a collabId exists, it is replaced with incoming values; otherwise, it is inserted.
     */
    @PostMapping("/od-letter-notification/selectOdLetterSync")
    @Operation(summary = "Select OD Letter Notification",
            description = "Select od_letter_notification by issueNumber, implId, populationId and collabId")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<OdLetterNotification> selectOdLetterSync(@RequestBody OdLetterNotificationUpsertRequest request)
            throws GridException {
        logger.info("Received request to sync issueNumber: {}, implId: {}, populationId: {}",
                request != null ? request.getIssueNumber() : null,
                request != null ? request.getImplId() : null,
                request != null ? request.getPopulationId() : null);
        try {
            OdLetterNotification saved = oDletterService.getSynNowToGetDocEdit(request);
            logger.info("Successfully upserted od_letter_notification with id: {}", saved.getId());
            return ResponseEntity.ok(saved);
        } catch (IllegalArgumentException ex) {
            logger.warn("Validation failed while upserting od_letter_notification: {}", ex.getMessage());
            throw new GridException(HttpStatus.BAD_REQUEST, "Invalid request for od_letter_notification upsert", ex.getMessage());
        } catch (Exception ex) {
            logger.error("Failed to Sync. Error: {}", ex.getMessage(), ex);
            throw new GridException(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to sync ", ex.getMessage());
        }
    }

    @PostMapping("/od-letter-notification/storeCommentsToOdLetter")
    @Operation(summary = "Store OD Letter comments",
            description = "Stores comments in od_letter_notification using issueNumber, implId, populationId, region, brand and collabId")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read','GRID:AllIssues':'read','GRID:IssueList':'read'})")
    public ResponseEntity<OdLetterNotification> storeCommentsToOdLetter(@RequestBody OdLetterNotificationUpsertRequest request)
            throws GridException {
        logger.info("Received request to store OD Letter comments for issueNumber: {}, implId: {}, populationId: {}",
                request != null ? request.getIssueNumber() : null,
                request != null ? request.getImplId() : null,
                request != null ? request.getPopulationId() : null);
        try {
            OdLetterNotification saved = gridMasterService.upsertOdLetterNotification(request);
            logger.info("Successfully stored OD Letter comments in od_letter_notification with id: {}", saved.getId());
            return ResponseEntity.ok(saved);
        } catch (IllegalArgumentException ex) {
            logger.warn("Validation failed while storing OD Letter comments: {}", ex.getMessage());
            throw new GridException(HttpStatus.BAD_REQUEST, "Invalid request for storing od_letter_notification comments", ex.getMessage());
        } catch (Exception ex) {
            logger.error("Failed to store OD Letter comments. Error: {}", ex.getMessage(), ex);
            throw new GridException(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to store od_letter_notification comments", ex.getMessage());
        }
    }


}




