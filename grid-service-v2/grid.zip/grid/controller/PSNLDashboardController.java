package com.ford.grid.controller;

import com.ford.grid.common.SystemWideResponses;
import com.ford.grid.constants.PSNLDashboardConstants;
import com.ford.grid.exception.GridException;
import com.ford.grid.model.dto.request.PSNLDashboardRequest;
import com.ford.grid.model.dto.request.PSNLPartDetailRequest;
import com.ford.grid.model.dto.request.PSNLShowDetailsUpdateRequest;
import com.ford.grid.model.dto.request.PartTransferRequestDTO;
import com.ford.grid.model.dto.request.PartTransferUndoRequest;
import com.ford.grid.model.dto.response.vehicleparts.PSNLPartDetailSaveResponse;
import com.ford.grid.model.dto.response.vehicleparts.PSNLProgramInfoResponse;
import com.ford.grid.model.dto.response.vehicleparts.PSNLProgramOverviewResponse;
import com.ford.grid.model.dto.response.vehicleparts.PSNLProgramPartDetailResponse;
import com.ford.grid.model.dto.response.vehicleparts.PSNLProgramSummaryResponse;
import com.ford.grid.model.dto.response.vehicleparts.PSNLShowDetailsResponse;
import com.ford.grid.model.dto.response.vehicleparts.PartTransferResponse;
import com.ford.grid.model.entity.KeyValueModel;
import com.ford.grid.security.UserDetailProvider;
import com.ford.grid.service.PSNLDashboardService;
import com.ford.grid.service.PSNLExcelExportService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import java.util.List;

@RestController
@RequestMapping("/api/v2/psnlDashboard")
@RequiredArgsConstructor
public class PSNLDashboardController {

    private static final Logger logger = LoggerFactory.getLogger(PSNLDashboardController.class);

    private final PSNLDashboardService psnlDashboardService;
    private final PSNLExcelExportService psnlExcelExportService;
    private final UserDetailProvider userDetailProvider;

    @PostMapping("/programs")
    @Operation(summary = "Get Program Summaries by Type",
               description = "Retrieve program summaries by type (programType in request body). "
                       + "nonApproved: no FSA number. "
                       + "approved: has FSA, but any affected region has allPartOk = false. "
                       + "launched: has FSA, and all affected regions have allPartOk = true.")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:PSLDashboard','read')")
    public ResponseEntity<List<PSNLProgramSummaryResponse>> getProgramSummaries(
            @RequestBody PSNLDashboardRequest request) {
        logger.info("Getting {} program summaries - filters: region={}, potentialIssueType={}, search={}",
                request.getProgramType(), request.getRegion(), request.getPotentialIssueType(), request.getSearch());

        List<PSNLProgramSummaryResponse> summaries = psnlDashboardService.getProgramSummaries(request);

        logger.info("Found {} {} program summaries", summaries.size(), request.getProgramType());
        return ResponseEntity.ok(summaries);
    }

    @GetMapping("/programs/overview/{populationId}")
    @Operation(summary = "Get Program Overview",
               description = "Retrieve program overview with unique parts (aggregated totalLaunchQty, totalPartRequired across all regions), affected regions, and total vehicle count for a given populationId")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:PSLDashboard','read')")
    public ResponseEntity<PSNLProgramOverviewResponse> getProgramOverview(@PathVariable String populationId) {
        logger.info("Getting program overview for populationId: {}", populationId);

        PSNLProgramOverviewResponse overview = psnlDashboardService.getProgramOverview(populationId);

        if (overview == null) {
            logger.info("No data found for populationId: {}", populationId);
            return ResponseEntity.notFound().build();
        }

        logger.info("Found program overview for populationId: {} with {} parts", populationId,
                overview.getParts() != null ? overview.getParts().size() : 0);
        return ResponseEntity.ok(overview);
    }

    @GetMapping("/getPsnlInfoByPopulation/{populationId}")
    @Operation(summary = "Get PSNL Info by Population",
               description = "Retrieve key program information from the PSNL summary view for a given populationId. "
                       + "Returns FSA number, affected regions, psnlStatus, and issue details. "
                       + "Throws 404 if no confirmed parts data exists for the populationId.")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:PSLDashboard','read')")
    public ResponseEntity<PSNLProgramInfoResponse> getProgramInfo(
            @PathVariable String populationId) throws GridException {
        logger.info("Getting program info for populationId: {}", populationId);
        PSNLProgramInfoResponse response = psnlDashboardService.getProgramInfo(populationId);
        logger.info("Found program info for populationId: {}", populationId);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/programs/{populationId}/{region}")
    @Operation(summary = "Get Program Part Details",
               description = "Retrieve part-level data with region + country quantities and version history "
                       + "from calculate_parts collection for a program by populationId and region.")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:PSLDashboard','read')")
    public ResponseEntity<PSNLProgramPartDetailResponse> getProgramPartDetails(
            @PathVariable String populationId,
            @PathVariable String region) {
        logger.info("Getting program part details for populationId: {}, region: {}", populationId, region);

        PSNLProgramPartDetailResponse response = psnlDashboardService.getProgramPartDetails(populationId, region);

        logger.info("Found {} parts for populationId: {}, region: {}",
                response.getParts() != null ? response.getParts().size() : 0, populationId, region);
        return ResponseEntity.ok(response);
    }

    // ==================== Contact Dropdown Endpoints ====================

    @GetMapping("/supplyChainContacts")
    @Operation(summary = "Get Supply Chain Contacts",
               description = "Retrieve a unique list of supply chain contacts (cdsid and name) from all issue contacts")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:PSLDashboard','read')")
    public ResponseEntity<List<KeyValueModel>> getSupplyChainContacts() {
        logger.info("Getting supply chain contacts");
        List<KeyValueModel> contacts = psnlDashboardService.getSupplyChainContacts();
        logger.info("Found {} unique supply chain contacts", contacts.size());
        return ResponseEntity.ok(contacts);
    }

    @GetMapping("/purchaseLeadContacts")
    @Operation(summary = "Get Purchase Lead Contacts",
               description = "Retrieve a unique list of purchase lead contacts (cdsid and name) from all issue contacts")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:PSLDashboard','read')")
    public ResponseEntity<List<KeyValueModel>> getPurchaseLeadContacts() {
        logger.info("Getting purchase lead contacts");
        List<KeyValueModel> contacts = psnlDashboardService.getPurchaseLeadContacts();
        logger.info("Found {} unique purchase lead contacts", contacts.size());
        return ResponseEntity.ok(contacts);
    }

    @PutMapping("/partDetails")
    @Operation(summary = "Batch Save/Update PSNL Part Details",
               description = "Save or update PSNL part details in batch. Only modified rows should be sent. "
                       + "Each row is identified by populationId + region + engineeringPartNumber. "
                       + "Only non-null fields are updated (partial save). "
                       + "Checkbox booleans: null = not changed. "
                       + "Dropdown booleans (kitRequired, partsPrice): null = user cleared selection.")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:PSLDashboard','update')")
    public ResponseEntity<PSNLPartDetailSaveResponse> savePartDetails(
            @Valid @RequestBody List<PSNLPartDetailRequest> requests) throws GridException {
        logger.info("Saving PSNL part details - batch size: {}", requests.size());
        PSNLPartDetailSaveResponse response = psnlDashboardService.savePartDetails(requests);
        logger.info("Successfully saved {} PSNL part detail records, psnlStatus: {}",
                response.getPartDetails().size(), response.getPsnlStatus());
        return ResponseEntity.ok(response);
    }

    // ==================== Show Details Endpoint ====================

    @GetMapping("/showDetails/{populationId}/{region}")
    @Operation(summary = "Get PSNL Show Details",
               description = "Retrieve contacts, meeting notes, and region info for a given populationId and region. "
                       + "Derives issueNumber and fsaNumber from the PSNL summary view. "
                       + "Returns PS&L Supply Chain, Purchase Lead, RSP Analyst, Production STA, "
                       + "Implementation Lead, Service STA contacts and FCSD-SCM/SEO meeting notes.")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:PSLDashboard','read')")
    public ResponseEntity<PSNLShowDetailsResponse> getShowDetails(
            @PathVariable String populationId,
            @PathVariable String region) {
        logger.info("Getting show details for populationId: {}, region: {}", populationId, region);
        PSNLShowDetailsResponse response = psnlDashboardService.getShowDetails(populationId, region);
        logger.info("Show details returned for populationId: {}, region: {}", populationId, region);
        return ResponseEntity.ok(response);
    }

    @PutMapping("/showDetails")
    @Operation(summary = "Update PSNL Show Details",
               description = "Update contacts and region info for a given populationId and region. "
                       + "Contacts: only entries with isModified=true are saved to issue_contacts. "
                       + "Region info (psnlSignoffDate, scmRating, escalationLeadership, psnlComments): "
                       + "always updated including null values. Meeting notes are excluded.")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:PSLDashboard','update')")
    public ResponseEntity<String> updateShowDetails(
            @Valid @RequestBody PSNLShowDetailsUpdateRequest request) throws GridException {
        logger.info("Updating show details for populationId: {}, region: {}", request.getPopulationId(), request.getRegion());
        String result = psnlDashboardService.updateShowDetails(request);
        logger.info("Show details updated for populationId: {}, region: {}", request.getPopulationId(), request.getRegion());
        return ResponseEntity.ok(result);
    }

    // ==================== Part Transfer Endpoints ====================

    @PostMapping("/partTransfer")
    @Operation(summary = "Request Part Transfer",
               description = "Create a part transfer request from source region to target region. "
                       + "Transfers country-level quantities including sold/unsold breakdown "
                       + "(soldLaunchQty, unSoldLaunchQty, totalLaunchQty, soldPartRequired, unSoldPartRequired, totalPartRequired). "
                       + "Blocks partOk on source region for transferred countries. "
                       + "A country can only have one active transfer from a given source region per part. "
                       + "Response includes MongoDB id per country for undo.")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:PSLDashboard','update')")
    public ResponseEntity<List<PartTransferResponse>> requestPartTransfer(
            @Valid @RequestBody PartTransferRequestDTO request) throws GridException {
        logger.info("Requesting part transfer from {} to {} - {} parts",
                request.getSourceRegion(), request.getTargetRegion(), request.getParts().size());
        List<PartTransferResponse> responses = psnlDashboardService.requestPartTransfer(request);
        logger.info("Part transfer created - {} country documents saved", responses.size());
        return ResponseEntity.ok(responses);
    }

    @PutMapping("/partTransfer/undo")
    @Operation(summary = "Undo Part Transfer",
               description = "Undo (delete) one or more part transfers by their ids. "
                       + "Each transferId represents a single country. "
                       + "The transfer documents are removed from the collection. "
                       + "Only changelog retains audit. partOk on source is recalculated.")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:PSLDashboard','update')")
    public ResponseEntity<Void> undoPartTransfer(
            @Valid @RequestBody PartTransferUndoRequest request) throws GridException {
        logger.info("Undoing part transfers - {} ids, issueNumber: {}", request.getTransferIds().size(), request.getIssueNumber());
        psnlDashboardService.undoPartTransfer(request);
        logger.info("Part transfers undone: {}", request.getTransferIds());
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/partTransfer/{populationId}")
    @Operation(summary = "Get Active Part Transfers",
               description = "List all active part transfer requests for a given populationId. "
                       + "Each transfer includes its MongoDB id for undo operations.")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:PSLDashboard','read')")
    public ResponseEntity<List<PartTransferResponse>> getPartTransfers(@PathVariable String populationId) {
        logger.info("Getting part transfers for populationId: {}", populationId);
        List<PartTransferResponse> transfers = psnlDashboardService.getPartTransfers(populationId);
        logger.info("Found {} active part transfers for populationId: {}", transfers.size(), populationId);
        return ResponseEntity.ok(transfers);
    }

    // ==================== Confirmed Regions Endpoint ====================

    @GetMapping("/confirmedRegions/{populationId}")
    @Operation(summary = "Get Confirmed Regions",
               description = "Returns list of regions where confirmed parts exist for the given populationId. "
                       + "Uses view_psnl_program_summary (built from calculate_parts with isConfirmed = true). "
                       + "A region is included if it has non-empty parts in the view.")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:PSLDashboard','read')")
    public ResponseEntity<List<String>> getConfirmedRegions(@PathVariable String populationId) {
        logger.info("Getting confirmed regions for populationId: {}", populationId);
        List<String> confirmedRegions = psnlDashboardService.getConfirmedRegions(populationId);
        logger.info("Found {} confirmed regions for populationId: {}", confirmedRegions.size(), populationId);
        return ResponseEntity.ok(confirmedRegions);
    }

    // ==================== Excel Export Endpoints ====================

    @GetMapping("/report/{populationId}")
    @Operation(summary = "Export Full PSNL Report",
               description = "Generate Excel with Overview sheet and all affected region sheets. "
                       + "Returns the Excel file as a downloadable stream.")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:PSLDashboard','read')")
    public ResponseEntity<StreamingResponseBody> exportFullReport(
            @PathVariable String populationId) {
        logger.info("Export full PSNL report for populationId: {}", populationId);
        byte[] excelBytes = psnlExcelExportService.generateFullReport(populationId);
        String fileName = "PSNL_Part_Info_Overall_" + populationId + ".xlsx";
        StreamingResponseBody stream = outputStream -> outputStream.write(excelBytes);
        return ResponseEntity.ok()
                .header("Content-Disposition", "attachment; filename=\"" + fileName + "\"")
                .contentType(org.springframework.http.MediaType.parseMediaType(
                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                .body(stream);
    }

    @GetMapping("/report/overview/{populationId}")
    @Operation(summary = "Export PSNL Overview Report",
               description = "Generate Excel with Overview sheet only. "
                       + "Returns the Excel file as a downloadable stream.")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:PSLDashboard','read')")
    public ResponseEntity<StreamingResponseBody> exportOverviewReport(
            @PathVariable String populationId) {
        logger.info("Export overview PSNL report for populationId: {}", populationId);
        byte[] excelBytes = psnlExcelExportService.generateOverviewReport(populationId);
        String fileName = "PSNL_Overview_" + populationId + ".xlsx";
        StreamingResponseBody stream = outputStream -> outputStream.write(excelBytes);
        return ResponseEntity.ok()
                .header("Content-Disposition", "attachment; filename=\"" + fileName + "\"")
                .contentType(org.springframework.http.MediaType.parseMediaType(
                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                .body(stream);
    }

    @GetMapping("/report/{populationId}/{region}")
    @Operation(summary = "Export PSNL Region Report",
               description = "Generate Excel with single region sheet including vehicle profile, "
                       + "region parts, and country breakdown. Returns the Excel file as a downloadable stream.")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:PSLDashboard','read')")
    public ResponseEntity<StreamingResponseBody> exportRegionReport(
            @PathVariable String populationId,
            @PathVariable String region) {
        logger.info("Export region PSNL report for populationId: {}, region: {}", populationId, region);
        byte[] excelBytes = psnlExcelExportService.generateRegionReport(populationId, region);
        String fileName = "PSNL_" + populationId + "_" + region + ".xlsx";
        StreamingResponseBody stream = outputStream -> outputStream.write(excelBytes);
        return ResponseEntity.ok()
                .header("Content-Disposition", "attachment; filename=\"" + fileName + "\"")
                .contentType(org.springframework.http.MediaType.parseMediaType(
                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                .body(stream);
    }

    @PostMapping("/report/overall")
    @Operation(summary = "Export Overall Part Report",
               description = "Generate overall part report based on filter criteria. "
                       + "Report is built asynchronously and emailed to the provided cdsid.")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:PSLDashboard','read')")
    public ResponseEntity<String> exportBulkReport(
            @RequestBody PSNLDashboardRequest request) {
        String cdsid = userDetailProvider.getUser().getCdsID();
        logger.info("Export bulk PSNL report requested by cdsid: {}, programType: {}", cdsid, request.getProgramType());
        psnlExcelExportService.generateAndEmailBulkReport(request, cdsid);
        return ResponseEntity.ok(PSNLDashboardConstants.EXCEL_REPORT_RESPONSE);
    }
}
