package com.ford.grid.controller;

import com.ford.grid.common.SystemWideResponses;
import com.ford.grid.exception.GridException;
import com.ford.grid.model.dto.request.AssignPartRequest;
import com.ford.grid.model.dto.request.vehicleparts.CalculatePartsRequest;
import com.ford.grid.model.dto.response.AssignPartResponse;
import com.ford.grid.model.dto.response.PartsBomValidationResponse;
import com.ford.grid.model.dto.response.vehicleparts.CalculatePartsExceptionResponse;
import com.ford.grid.model.dto.response.vehicleparts.CalculatePartsQuantityResponse;
import com.ford.grid.model.dto.response.vehicleparts.CalculatePartsResponse;
import com.ford.grid.model.dto.response.vehicleparts.CausalPartCheckResponse;
import com.ford.grid.model.dto.response.vehicleparts.ConfirmPartDto;
import com.ford.grid.model.dto.response.vehicleparts.ProfilePartGroupedInfoDto;
import com.ford.grid.service.AssignPartService;
import com.ford.grid.service.CalculatePartsService;
import com.ford.grid.service.PartsBomValidationService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v2/parts")
@RequiredArgsConstructor
@Slf4j
public class PartController {

    private final AssignPartService assignPartService;
    private final CalculatePartsService calculatePartsService;
    private final PartsBomValidationService partsBomValidationService;

    @GetMapping("/getPartDetails/byEngineeringPartNo/{engineeringPartNumber}")
    @Operation(summary = "Part Details", description = "Get Part Details by Engineering Part Number")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<AssignPartResponse> getPartDetails(@PathVariable String engineeringPartNumber) throws GridException {
        log.debug("Get Part Details Started for EngineeringPartNumber- {}", engineeringPartNumber);
        AssignPartResponse response = assignPartService.getPartDetailsFromEngineeringPartNumber(engineeringPartNumber);
        log.debug("Get Part Details Ended for EngineeringPartNumber- {}", engineeringPartNumber);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/getPartDetails/byServicePartNo/{servicePartNo}")
    @Operation(summary = "Part Details", description = "Get Part Details by Service Part Number")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<AssignPartResponse> getPartDetailsByServicePartNo(@PathVariable String servicePartNo) throws GridException {
        log.debug("Get Part Details Started for ServicePartNo- {}", servicePartNo);
        AssignPartResponse response = assignPartService.getPartDetailsFromServicePartNumber(servicePartNo);
        log.debug("Get Part Details Ended for ServicePartNo- {}", servicePartNo);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/getPartDetails/byFinisCode/{finisCode}")
    @Operation(summary = "Part Details", description = "Get Part Details by Finis Code")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<AssignPartResponse> getPartDetailsByFinisCode(@PathVariable String finisCode) throws GridException {
        log.debug("Get Part Details Started for FinisCode- {}", finisCode);
        AssignPartResponse response = assignPartService.getPartDetailsFromFINISCode(finisCode);
        log.debug("Get Part Details Ended for FinisCode- {}", finisCode);
        return ResponseEntity.ok(response);

    }

    @PostMapping("/assignPart")
    @Operation(summary = "Assign Part", description = "Assign Part to profile")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<AssignPartResponse> assignPartToProfile(@RequestBody @Valid AssignPartRequest request) throws GridException {
        log.debug("Assign Part Started for Request- {}", request);
        AssignPartResponse response = assignPartService.assignPartToProfile(request);
        log.debug("Assign Part Ended for Request- {}", request);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/groupByProfile/{populationId}")
    @Operation(summary = "Group Parts by Profile", description = "Group assigned parts by profile for a given population ID")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<ProfilePartGroupedInfoDto> groupByProfile(@PathVariable String populationId) throws GridException {
        log.debug("Group By Profile Started for PopulationId- {}", populationId);
        ProfilePartGroupedInfoDto response = assignPartService.groupByProfile(populationId);
        log.debug("Group By Profile Ended for PopulationId- {}", populationId);
        return ResponseEntity.ok(response);
    }

    @PutMapping("/updatePart")
    @Operation(summary = "Update Part", description = "Update assigned part details")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<AssignPartResponse> updatePart(@RequestBody @Valid AssignPartRequest request) throws GridException {
        log.debug("Update Part Started for Request- {}", request);
        AssignPartResponse response = assignPartService.updateParts(request);
        log.debug("Update Part Ended for Request- {}", request);
        return ResponseEntity.ok(response);
    }

    @DeleteMapping("/removePart/{profileId}/{assignPartId}")
    @Operation(summary = "Remove Part detail from profile", description = "Removes part from profile")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<String> removeProfileFromAssignPart(
            @PathVariable String profileId,
            @PathVariable String assignPartId) throws GridException {
        log.debug("Remove Profile from Assign Part Started for profileId- {}, assignPartId- {}", profileId, assignPartId);
        String result = assignPartService.removeProfileFromAssignPart(profileId, assignPartId);
        log.debug("Remove Profile from Assign Part Ended for profileId- {}, assignPartId- {}", profileId, assignPartId);
        return ResponseEntity.ok(result);
    }

    @GetMapping("/calculateScreen/{populationId}")
    @Operation(summary = "Calculate Screen Region Details", description = "Get calculated screen region details for a given population ID")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<CalculatePartsResponse> getCalculateScreenRegionDetails(@PathVariable String populationId) {
        log.debug("Calculate Screen Region Details Started for PopulationId- {}", populationId);
        CalculatePartsResponse response = calculatePartsService.getCalculateScreenRegionDetails(populationId);
        log.debug("Calculate Screen Region Details Ended for PopulationId- {}", populationId);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/saveProfileRegionDetails")
    @Operation(summary = "Save Profile Region Details", description = "Save profile region details for parts")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<String> saveProfileRegionDetails(@RequestBody @Valid CalculatePartsRequest request) throws GridException {
        log.debug("Save Profile Region Details Started for Request- {}", request);
        String result = calculatePartsService.saveProfileRegionDetails(request);
        log.debug("Save Profile Region Details Ended for Request- {}", request);
        return ResponseEntity.ok(result);
    }

    @GetMapping("/checkCausalParts/{populationId}")
    @Operation(summary = "Check Causal Parts", description = "Check if causal parts are available for a population. Returns available parts if no causal part exists.")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<CausalPartCheckResponse> checkCausalParts(@PathVariable String populationId) {
        log.debug("Check Causal Parts Started for PopulationId- {}", populationId);
        CausalPartCheckResponse response = calculatePartsService.checkCausalParts(populationId);
        log.debug("Check Causal Parts Ended for PopulationId- {}", populationId);
        return ResponseEntity.ok(response);
    }

    @PutMapping("/updateCausalPart/{partId}")
    @Operation(summary = "Update Causal Part", description = "Set a part as causal for the population. Only one causal part is allowed per populationId.")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<String> updateCausalPart(@PathVariable String partId) throws GridException {
        log.debug("Update Causal Part Started for PartId- {}", partId);
        String response = assignPartService.updateCausalPart(partId);
        log.debug("Update Causal Part Ended for PartId- {}", partId);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/calculateParts")
    @Operation(summary = "Calculate Parts Quantities", description = "Calculate required part quantities for a given request")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<List<CalculatePartsQuantityResponse>> calculateParts(
            @RequestBody @Valid CalculatePartsRequest request) throws GridException {
        log.debug("Calculate Parts Started for Request- {}", request);
        List<CalculatePartsQuantityResponse> response = calculatePartsService.calculateParts(request);
        log.debug("Calculate Parts Ended for Request- {}", request);
        return ResponseEntity.ok(response);
    }

    @PutMapping("/confirmParts")
    @Operation(summary = "Confirm Parts", description = "Confirm parts for a given request")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<ConfirmPartDto> confirmParts(@RequestBody @Valid ConfirmPartDto request) throws GridException {
        log.debug("Confirm Parts Started for Request- {}", request);
        ConfirmPartDto response = calculatePartsService.confirmParts(request);
        log.debug("Confirm Parts Ended for Request- {}", request);
        return ResponseEntity.ok(response);
    }


    @GetMapping("/exceptions/{populationId}")
    @Operation(summary = "Get Exception Details", description = "Returns exception details for profiles, assign parts, and calculate parts for a given population ID")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<CalculatePartsExceptionResponse> getExceptionDetails(@PathVariable String populationId) {
        log.debug("Get Exception Details Started for PopulationId- {}", populationId);
        CalculatePartsExceptionResponse response = calculatePartsService.getExceptionDetails(populationId);
        log.debug("Get Exception Details Ended for PopulationId- {}", populationId);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/bomValidation/{populationId}")
    @Operation(summary = "Parts BOM Validation", description = "Returns validation status for VERN count matching and profile-to-part mapping for a given population ID")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<PartsBomValidationResponse> getPartsBomValidation(@PathVariable String populationId) {
        log.debug("Parts BOM Validation Started for PopulationId- {}", populationId);
        PartsBomValidationResponse response = partsBomValidationService.getValidationStatus(populationId);
        log.debug("Parts BOM Validation Ended for PopulationId- {}", populationId);
        return ResponseEntity.ok(response);
    }

}
