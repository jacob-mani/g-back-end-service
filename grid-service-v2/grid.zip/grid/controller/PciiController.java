package com.ford.grid.controller;

import com.ford.grid.model.dto.response.PciiPartInfoResponse;
import com.ford.grid.service.PciiService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Controller for PCII (Part Control Information Integration) APIs.
 * Provides part information lookup from the external Part Control system.
 */
@RestController
@RequestMapping("/api/v2/pcii")
@RequiredArgsConstructor
@Tag(name = "PCII Integration", description = "APIs for Part Control Information Integration (PCII)")
public class PciiController {

    private static final Logger LOGGER = LoggerFactory.getLogger(PciiController.class);

    private final PciiService pciiService;

    @GetMapping("/partinfo")
    @Operation(summary = "Get Part Info from PCII",
            description = "Fetches part information from the Part Control system based on part type, part numbers, and markets")
    public ResponseEntity<PciiPartInfoResponse> getPartInfo(
            @Parameter(description = "Part type (e.g., EPN)", example = "EPN")
            @RequestParam String partType,

            @Parameter(description = "Comma-separated part numbers", example = "AA39F613B90AC")
            @RequestParam String partNos,

            @Parameter(description = "Comma-separated market codes", example = "US")
            @RequestParam(defaultValue = "US") String markets,

            @Parameter(description = "Page number (1-based)", example = "1")
            @RequestParam(defaultValue = "1") int pageNo,

            @Parameter(description = "Page size", example = "10")
            @RequestParam(defaultValue = "10") int pageSize) {

        LOGGER.info("PCII - partinfo request: partType={}, partNos={}, markets={}", partType, partNos, markets);

        PciiPartInfoResponse response = pciiService.getPartInfo(partType, partNos, markets, pageNo, pageSize);

        return ResponseEntity.ok(response);
    }
}

