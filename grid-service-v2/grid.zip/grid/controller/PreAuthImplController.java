package com.ford.grid.controller;

import com.ford.grid.common.SystemWideResponses;
import com.ford.grid.exception.GridException;
import com.ford.grid.model.dto.response.*;
import com.ford.grid.model.dto.response.PreAuthTabMiddleDetailResponse;
import com.ford.grid.model.dto.request.PreAuthTab1Request;
import com.ford.grid.model.dto.request.PreAuthTab5Request;
import com.ford.grid.model.dto.request.PreAuthTab6Request;
import com.ford.grid.model.dto.request.PreAuthTab7Request;
import com.ford.grid.model.dto.request.*;
import com.ford.grid.service.PreAuthImplService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/api/v2/preAuth")
@RequiredArgsConstructor
public class PreAuthImplController {
    private static final Logger LOGGER = LoggerFactory.getLogger(PreAuthImplController.class);

    private final PreAuthImplService preAuthImplService;

    @PostMapping("/savePreAuthTab1")
    @Operation(summary = "save PreAuthImpl", description = "save PreAuth API")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<PreAuthTab1Response> savePreAuthTab1(@RequestBody PreAuthTab1Request preAuthTab1Request) throws GridException {
        LOGGER.info("Start of save PreAuth Tab 1 : {}", preAuthTab1Request);
        PreAuthTab1Response response = preAuthImplService.savePreAuthTab1Details(preAuthTab1Request);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/getDataTab1/{issueNumber}/{forumType}")
    @Operation(summary = "Get PreAuthImpl Details", description = "Fetch PreAuth Tab 1 by Issue Number and Forum Type")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<PreAuthTab1Response> getPreAuthTab1(@PathVariable String issueNumber, @PathVariable String forumType) throws GridException {
        LOGGER.info("Fetching PreAuth1 for issueNumber: {} forumType:{}", issueNumber, forumType);
        PreAuthTab1Response response = preAuthImplService.getPreAuthTab1Details(issueNumber, forumType);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/getDataTab6/{issueNumber}/{forumType}")
    @Operation(summary = "Get PreAuthImpl Details", description = "Fetch PreAuth Tab6 by Issue Number and Forum Type")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<PreAuthTab6Response> getPreAuthTab6(@PathVariable String issueNumber, @PathVariable String forumType) throws GridException {
        LOGGER.info("Fetching PreAuth Tab6 for issueNumber: {} forumType:{}", issueNumber, forumType);
        PreAuthTab6Response response = preAuthImplService.getPreAuthTab6Details(issueNumber, forumType);
        // Check if response is null and throw GridException
        if (response == null) {
            LOGGER.error("PreAuth details for Tab6 not found for issueNumber: {} and forumType: {}", issueNumber, forumType);
            throw new GridException("No data found for the specified issue number and forum type.");
        }
        return ResponseEntity.ok(response);
    }

    @GetMapping("/getDataTab7/{issueNumber}/{forumType}")
    @Operation(summary = "Get PreAuthImpl Details", description = "Fetch PreAuth Tab7 by Issue Number and Forum Type")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<PreAuthTab7Response> getPreAuthTab7(@PathVariable String issueNumber, @PathVariable String forumType) throws GridException {
        LOGGER.info("Fetching PreAuth Tab7 for issueNumber: {} forumType:{}", issueNumber, forumType);
        PreAuthTab7Response response = preAuthImplService.getPreAuthTab7Details(issueNumber, forumType);
        // Check if response is null and throw GridException
        if (response == null) {
            LOGGER.error("PreAuth details for Tab7 not found for issueNumber: {} and forumType: {}", issueNumber, forumType);
            throw new GridException("No data found for the specified issue number and forum type.");
        }
        return ResponseEntity.ok(response);
    }

    @GetMapping("/getDataTab5/{issueNumber}/{forumType}")
    @Operation(summary = "Get PreAuth Tab5", description = "Fetch PreAuth Tab5 details, including Calculate Parts data, by Issue Number and Forum Type")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<PreAuthTab5DetailResponse> getPreAuthTab5(@PathVariable String issueNumber, @PathVariable String forumType) throws GridException {
        LOGGER.info("Fetching PreAuth Tab5 for issueNumber: {} forumType:{}", issueNumber, forumType);
        PreAuthTab5DetailResponse response = preAuthImplService.getPreAuthTab5Details(issueNumber, forumType);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/savePreAuthTab6")
    @Operation(summary = "save PreAuthImpl6", description = "save PreAuth6 API")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<PreAuthTab6Response> savePreAuthTab6(@RequestBody PreAuthTab6Request preAuthTab6Request) throws GridException {
        LOGGER.info("Start of save PreAuth Tab 6 : {}", preAuthTab6Request);
        PreAuthTab6Response response = preAuthImplService.savePreAuthTab6Details(preAuthTab6Request);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/savePreAuthTab7")
    @Operation(summary = "save PreAuthImpl7", description = "save PreAuth7 API")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<PreAuthTab7Response> savePreAuthTab7(@RequestBody PreAuthTab7Request preAuthTab7Request) throws GridException {
        LOGGER.info("Start of save PreAuth Tab 7 : {}", preAuthTab7Request);
        PreAuthTab7Response response = preAuthImplService.savePreAuthTab7Details(preAuthTab7Request);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/savePreAuthTabMiddle")
    @Operation(summary = "Save PreAuthTabMiddle", description = "Save PreAuthTabMiddle details")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<PreAuthTabMiddleResponse> savePreAuthTabMiddle(@Valid @RequestBody PreAuthTabMiddleRequest preAuthTabMiddle) throws GridException {
        LOGGER.info("Start of save PreAuthTabMiddle : {}", preAuthTabMiddle);
        PreAuthTabMiddleResponse response = preAuthImplService.savePreAuthTabMiddle(preAuthTabMiddle);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/getPreAuthTabMiddle/{issueNumber}/{forumType}/{type}")
    @Operation(summary = "Get PreAuthMiddle Details", description = "Fetch PreAuth Tab 2,3,4 by Issue Number and Forum Type")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<List<PreAuthTabMiddleDetailResponse>> getPreAuthTabMiddle(@PathVariable String issueNumber, @PathVariable String forumType, @PathVariable int type) throws GridException {
        LOGGER.info("Fetching PreAuth for issueNumber: {} forumType:{}", issueNumber, forumType);
        List<PreAuthTabMiddleDetailResponse> response = preAuthImplService.getPreAuthTabMiddle(issueNumber, forumType, type);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/savePreAuthTab5")
    @Operation(summary = "save PreAuthImpl5", description = "save PreAuth5 API")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public ResponseEntity<PreAuthTab5Response> savePreAuthTab5(@RequestBody PreAuthTab5Request preAuthTab5Request) throws GridException {
        LOGGER.info("Start of save PreAuth Tab 5 : {}", preAuthTab5Request);
        PreAuthTab5Response response = preAuthImplService.savePreAuthTab5Details(preAuthTab5Request);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/common/getData/{issueNumber}/{forumType}")
    @Operation(summary = "Get PreAuthNav Details", description = "Fetch PreAuth Navigation by Issue Number and Forum Type")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<PreAuthNavLoadResponse> getPreAuthNav(@PathVariable String issueNumber, @PathVariable String forumType) {
        PreAuthNavLoadResponse response = preAuthImplService.findAllByIssueNumber(issueNumber, forumType);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/downloadTab6File/{issueNumber}/{forumType}/{fileType}")
    @Operation(summary = "Download PreAuth Tab6 File", description = "Download Population File or Part Requirement File from PreAuth Tab6")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','read')")
    public ResponseEntity<StreamingResponseBody> downloadPreAuthTab6File(
            @PathVariable String issueNumber,
            @PathVariable String forumType,
            @PathVariable String fileType) throws IOException, GridException {
        LOGGER.info("Download PreAuth Tab6 file request - Issue: {}, ForumType: {}, FileType: {}",
                issueNumber, forumType, fileType);
        return preAuthImplService.downloadPreAuthTab6File(issueNumber, forumType, fileType);
    }
}
