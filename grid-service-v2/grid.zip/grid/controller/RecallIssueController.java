package com.ford.grid.controller;

import com.ford.grid.common.SystemWideResponses;
import com.ford.grid.exception.GridException;
import com.ford.grid.model.dto.request.BaseVehicleCriteriaRequest;
import com.ford.grid.model.dto.request.RecallIssueRequest;
import com.ford.grid.model.dto.request.UploadRequest;
import com.ford.grid.model.dto.response.BaseVehicleCriteriaResponse;
import com.ford.grid.model.dto.response.IssueDetailResponse;
import com.ford.grid.model.dto.response.IssueResponse;
import com.ford.grid.model.dto.response.SuggestedIssueResponse;
import com.ford.grid.model.dto.response.UploadResponse;
import com.ford.grid.model.entity.IssueWatchList;
import com.ford.grid.model.dto.response.IssueWatchResponse;
import com.ford.grid.service.ISignedURLService;
import com.ford.grid.service.RecallIssueService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v2/issue")
@RequiredArgsConstructor
public class RecallIssueController {
    private static final Logger LOGGER = LoggerFactory.getLogger(RecallIssueController.class);

    private final RecallIssueService recallIssueService;
    private final ISignedURLService signedURLService;

    @GetMapping("/getIssue/{issueNumber}")
    @Operation(summary = "Issue", description = "Issue Get API with IssueNumber")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MyIssuesList','read')")
    public ResponseEntity<IssueResponse> getIssues(@PathVariable String issueNumber) {
        return ResponseEntity.ok(recallIssueService.getRecallIssue(issueNumber));
    }

    @GetMapping("/getAllIssues")
    @Operation(summary = "Get All issues", description = "Issues Get API")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MyIssuesList','read')")
    public ResponseEntity<Page<IssueResponse>> getAllIssues(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "issueNumber") String sortBy,
            @RequestParam(defaultValue = "DESC") String direction,
            @RequestParam(required = false) String searchKey) {

        Sort sort = Sort.by(Sort.Direction.fromString(direction), sortBy);
        Pageable pageable = PageRequest.of(page, size, sort);
        return ResponseEntity.ok(recallIssueService.getAllRecallIssue(pageable, searchKey));
    }

    @GetMapping("/getAllIssueDetails")
    @Operation(summary = "Get All issues with joined details", description = "Returns issues with scope info and base vehicle criteria. Pass 'fields' to select specific columns.")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MyIssuesList','read')")
    public ResponseEntity<Page<IssueDetailResponse>> getAllIssueDetails(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "issueNumber") String sortBy,
            @RequestParam(defaultValue = "DESC") String direction,
            @RequestParam(required = false) String searchKey,
            @RequestParam(required = false) Set<String> fields) {

        Sort sort = Sort.by(Sort.Direction.fromString(direction), sortBy);
        Pageable pageable = PageRequest.of(page, size, sort);
        return ResponseEntity.ok(recallIssueService.getAllRecallIssueDetails(pageable, searchKey, fields));
    }

    @PostMapping("/createIssue")
    @Operation(summary = "Create Issue", description = "Issue Create API")
    @SystemWideResponses
    public ResponseEntity<IssueResponse> createIssue(@Valid @RequestBody RecallIssueRequest issueRequest) throws GridException {
        LOGGER.debug("Create Issue Started Title- {}", issueRequest.getIssueTitle());
        IssueResponse issueResponse = recallIssueService.createRecallIssue(issueRequest);
        LOGGER.debug("Create Issue Ended Number- {}", issueResponse.getIssueNumber());
        return new ResponseEntity<>(issueResponse, HttpStatus.CREATED);
    }

    @PostMapping(value = "/createIssueWithFiles", consumes = MediaType.MULTIPART_FORM_DATA_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @Operation(summary = "Create Issue with Files", description = "Create Issue API with file uploads")
    @SystemWideResponses
    public ResponseEntity<IssueResponse> createIssueWithFiles(
            @RequestPart("issueData") RecallIssueRequest issueRequest,
            @RequestPart(value = "files", required = false) List<MultipartFile> files) throws GridException {

        LOGGER.info("Create Issue with Files Started - Title: {}, FileCount: {}",
                issueRequest.getIssueTitle(), files != null ? files.size() : 0);

        // Create the issue first
        IssueResponse issueResponse = recallIssueService.createRecallIssue(issueRequest);

        // Upload files if provided
        if (files != null && !files.isEmpty()) {
            try {
                LOGGER.info("Starting file upload for issue {}", issueResponse.getIssueNumber());

                UploadRequest uploadRequest = UploadRequest.builder()
                        .issueNumber(issueResponse.getIssueNumber())
                        .screenType("IssueCreate")
                        .files(files)
                        .build();

                String fileNames = files.stream().map(MultipartFile::getOriginalFilename)
                        .collect(Collectors.joining(","));

                // Upload the files to GCP bucket using signedURLService
                List<UploadResponse> uploadResponses = signedURLService.uploadFiles(uploadRequest);
                LOGGER.info("File Upload Response: {}", uploadResponses);

                // Update the collection with upload responses
                recallIssueService.updateCollectionWithUploadResponses(
                        issueResponse.getIssueNumber(), "IssueCreate", uploadResponses);

                LOGGER.info("Successfully uploaded {} files for issue {}: {}",
                        uploadResponses.size(), issueResponse.getIssueNumber(), fileNames);
            } catch (Exception e) {
                LOGGER.error("Failed to upload files for issue {}: {}",
                        issueResponse.getIssueNumber(), e.getMessage(), e);
                // Note: Issue is already created, so we log the error but don't fail the request
            }
        }

        LOGGER.debug("Create Issue with Files Ended - Number: {}", issueResponse.getIssueNumber());
        return new ResponseEntity<>(issueResponse, HttpStatus.CREATED);
    }

    @PutMapping("/updateIssue/{issueNumber}")
    @Operation(summary = "Update Issue", description = "Issue Update API")
    @SystemWideResponses
    public ResponseEntity<IssueResponse> updateIssue(@PathVariable String issueNumber, @Valid @RequestBody RecallIssueRequest issueRequest) throws GridException {
        LOGGER.debug("Updated Issue Started Title- {}", issueRequest.getIssueTitle());
        IssueResponse issueResponse = recallIssueService.updateRecallIssue(issueNumber, issueRequest);
        LOGGER.debug("Updated Issue Ended Number- {}", issueResponse.getIssueNumber());
        return new ResponseEntity<>(issueResponse, HttpStatus.OK);
    }

    @PutMapping(value = "/updateIssueWithFiles/{issueNumber}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @Operation(summary = "Update Issue with Files", description = "Update Issue API with file uploads")
    @SystemWideResponses
    public ResponseEntity<IssueResponse> updateIssueWithFiles(
            @PathVariable String issueNumber,
            @RequestPart("issueData") @Valid RecallIssueRequest issueRequest,
            @RequestPart(value = "files", required = false) List<MultipartFile> files) throws GridException {

        LOGGER.info("Update Issue with Files Started - IssueNumber: {}, Title: {}, FileCount: {}",
                issueNumber, issueRequest.getIssueTitle(), files != null ? files.size() : 0);

        // Update the issue first
        IssueResponse issueResponse = recallIssueService.updateRecallIssue(issueNumber, issueRequest);

        // Upload files if provided
        if (files != null && !files.isEmpty()) {
            try {
                LOGGER.info("Starting file upload for issue update {}", issueNumber);

                UploadRequest uploadRequest = UploadRequest.builder()
                        .issueNumber(issueNumber)
                        .screenType("IssueUpdate")
                        .files(files)
                        .build();

                String fileNames = files.stream().map(MultipartFile::getOriginalFilename)
                        .collect(Collectors.joining(","));

                // Upload the files to GCP bucket using signedURLService
                List<UploadResponse> uploadResponses = signedURLService.uploadFiles(uploadRequest);
                LOGGER.info("File Upload Response for update: {}", uploadResponses);

                // Update the collection with upload responses
                recallIssueService.updateCollectionWithUploadResponses(
                        issueNumber, "IssueUpdate", uploadResponses);

                LOGGER.info("Successfully uploaded {} files for issue update {}: {}",
                        uploadResponses.size(), issueNumber, fileNames);
            } catch (Exception e) {
                LOGGER.error("Failed to upload files for issue update {}: {}",
                        issueNumber, e.getMessage(), e);
                // Note: Issue is already updated, so we log the error but don't fail the request
            }
        }

        LOGGER.debug("Update Issue with Files Ended - Number: {}", issueResponse.getIssueNumber());
        return new ResponseEntity<>(issueResponse, HttpStatus.OK);
    }

    /**
     * Uploads files to a cloud storage service and updates the corresponding issue record with the upload details.
     *
     * @param uploadRequest the request containing the files to be uploaded and associated metadata
     * @return a ResponseEntity indicating the result of the upload operation
     */
    @PutMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> uploadFiles(@ModelAttribute UploadRequest uploadRequest) {

        final String issueNumber = uploadRequest.getIssueNumber();
        final String screenType = uploadRequest.getScreenType();
        LOGGER.info("Start of uploadFiles method in SignedURLServiceImpl");
        LOGGER.info("Upload for the issue number : {}", issueNumber);
        LOGGER.info("Screen Type : {}", screenType);

        String fileNames = uploadRequest.getFiles().stream().map(MultipartFile::getOriginalFilename)
                .collect(Collectors.joining(","));

        //Upload the files to GCP bucket
        List<UploadResponse> uploadResponses = signedURLService.uploadFiles(uploadRequest);
        LOGGER.info("File Upload Response: {}", uploadResponses);
        recallIssueService.updateCollectionWithUploadResponses(issueNumber, screenType, uploadResponses);

        LOGGER.info("End of uploadFiles method in SignedURLServiceImpl");
        return ResponseEntity.ok(fileNames + " Uploaded to cloud successfully");
    }

    @GetMapping("/suggestions")
    @Operation(summary = "Get Suggested Issues", description = "Get suggested issues based on title fragment for fuzzy search")
    @SystemWideResponses
    public ResponseEntity<List<SuggestedIssueResponse>> getSuggestedIssues(
            @RequestParam(value = "title") String titleFragment) {
        LOGGER.debug("Getting suggested issues for title fragment: {}", titleFragment);
        List<SuggestedIssueResponse> suggestedIssues = recallIssueService.getSuggestedIssues(titleFragment);
        LOGGER.debug("Found {} suggested issues for title fragment: {}", suggestedIssues.size(), titleFragment);
        return ResponseEntity.ok(suggestedIssues);
    }

    @PutMapping("/updateEmailPreference/{issueNumber}")
    @Operation(summary = "Update Email Preference", description = "Updates email preference for an issue")
    @SystemWideResponses
    public ResponseEntity<String> updateEmailPreference(
            @PathVariable String issueNumber,
            @RequestParam(required = true) boolean disableEmails) {

        LOGGER.debug("Updating email preference for issue: {}, disableEmails: {}", issueNumber, disableEmails);
        String result = recallIssueService.updateEmailPreference(issueNumber, disableEmails);
        LOGGER.debug("Email preference updated for issue: {}", issueNumber);
        return ResponseEntity.ok(result);
    }

    @GetMapping("/getIssueByCdsid/{cdsid}")
    @Operation(summary = "Get Issues by CDSID", description = "Fetches all recall issues associated with the given CDSID from IssueContacts")
    @SystemWideResponses
    public ResponseEntity<Page<IssueResponse>> getMyIssueByCdsid(
            @PathVariable String cdsid,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "issueNumber") String sortBy,
            @RequestParam(defaultValue = "DESC") String direction,
            @RequestParam(required = false) String searchKey) {

        String normalizedCdsid = cdsid != null ? cdsid.trim().toLowerCase() : cdsid;
        LOGGER.info("Fetching recall issues for cdsid: {}, page: {}, size: {}, sortBy: {}, direction: {}, searchKey: {}",
                normalizedCdsid, page, size, sortBy, direction, searchKey);

        Sort sort = Sort.by(Sort.Direction.fromString(direction), sortBy);
        Pageable pageable = PageRequest.of(page, size, sort);

        Page<IssueResponse> recallIssues = recallIssueService.getRecallIssueByCdsid(normalizedCdsid, pageable, searchKey);
        LOGGER.info("Found {} recall issues for cdsid: {} (total: {})",
                recallIssues.getNumberOfElements(), normalizedCdsid, recallIssues.getTotalElements());

        return ResponseEntity.ok(recallIssues);
    }

    @GetMapping("/getBaseVehicleCriteria/{issueNumber}")
    @Operation(summary = "Issue", description = "Issue Get API with BaseVehicleCriteria")
    @SystemWideResponses
    public ResponseEntity<List<BaseVehicleCriteriaResponse>> getBaseCriteria(@PathVariable String issueNumber) {
        return ResponseEntity.ok(recallIssueService.getBaseVehicleCriteria(issueNumber));
    }

    @PostMapping("/createBaseVehicleCriteria")
    @Operation(summary = "Create BaseVehicleCriteria", description = "Create BaseVehicleCriteria API")
    @SystemWideResponses
    public ResponseEntity<List<BaseVehicleCriteriaResponse>> createBaseVehicleCriteria(@RequestBody List<BaseVehicleCriteriaRequest> criteriaRequest) throws GridException {
        List<BaseVehicleCriteriaResponse> baseCriteriaResponse = recallIssueService.createBaseCriteria(criteriaRequest);
        return new ResponseEntity<>(baseCriteriaResponse, HttpStatus.CREATED);
    }

    @PostMapping("/addToWatchList")
    @Operation(summary = "Add to Watch List", description = "Add an issue to user's watch list")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MyIssuesList','read')")
    public ResponseEntity<String> addToWatchList(
            @RequestBody IssueWatchList issueWatchList) {
        LOGGER.debug("Add to Watch List Started - CDSID: {}", issueWatchList.getCdsid());
        recallIssueService.addToWatchList(issueWatchList);
        LOGGER.debug("Add to Watch List Ended - CDSID: {}", issueWatchList.getCdsid());
        return new ResponseEntity<>("Added to Watch List Successfully", HttpStatus.CREATED);
    }

    @GetMapping("/getWatchList")
    @Operation(summary = "Get Watch List", description = "Get all watched issues for a user")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MyIssuesList','read')")
    public ResponseEntity<Page<IssueWatchResponse>> getWatchList(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "issueNumber") String sortBy,
            @RequestParam(defaultValue = "DESC") String direction,
            @RequestParam String cdsid,
            @RequestParam(required = false) String searchKey) {

        String normalizedCdsid = cdsid != null ? cdsid.trim().toLowerCase() : cdsid;
        LOGGER.info("Fetching watch list for cdsid: {}, page: {}, size: {}, sortBy: {}, direction: {}, searchKey: {}",
                normalizedCdsid, page, size, sortBy, direction, searchKey);

        Sort sort = Sort.by(Sort.Direction.fromString(direction), sortBy);
        Pageable pageable = PageRequest.of(page, size, sort);

        Page<IssueWatchResponse> watchList = recallIssueService.getWatchList(pageable, normalizedCdsid, searchKey);
        LOGGER.info("Found {} watched issues for cdsid: {} (total: {})",
                watchList.getNumberOfElements(), normalizedCdsid, watchList.getTotalElements());

        return ResponseEntity.ok(watchList);
    }

    @PostMapping("/getMyIssueDetailsByCdsid")
    @Operation(summary = "Get enriched issues by CDSID", description = "Returns enriched issue details with joined/resolved fields for issues associated with the given CDSID. Pass 'fields' to select specific columns.")
    @SystemWideResponses
    public ResponseEntity<Page<IssueDetailResponse>> getMyIssueDetailsByCdsid(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "issueNumber") String sortBy,
            @RequestParam(defaultValue = "DESC") String direction,
            @RequestParam(required = false) String searchKey,
            @RequestParam(required = false) Set<String> fields, @RequestBody String cdsid) {

        String normalizedCdsid = cdsid != null ? cdsid.trim().toLowerCase() : cdsid;
        LOGGER.info("Fetching enriched issue details for cdsid: {}", normalizedCdsid);
        Sort sort = Sort.by(Sort.Direction.fromString(direction), sortBy);
        Pageable pageable = PageRequest.of(page, size, sort);
        return ResponseEntity.ok(recallIssueService.getMyIssueDetailsByCdsid(normalizedCdsid, pageable, searchKey, fields));
    }

    @PostMapping("/getWatchListDetails")
    @Operation(summary = "Get enriched Watch List", description = "Returns enriched issue details with joined/resolved fields for the user's watch list. Pass 'fields' to select specific columns.")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MyIssuesList','read')")
    public ResponseEntity<Page<IssueDetailResponse>> getWatchListDetails(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "issueNumber") String sortBy,
            @RequestParam(defaultValue = "DESC") String direction,
            @RequestParam(required = false) String searchKey,
            @RequestParam(required = false) Set<String> fields, @RequestBody String cdsid) {

        String normalizedCdsid = cdsid != null ? cdsid.trim().toLowerCase() : cdsid;
        LOGGER.info("Fetching enriched watch list details for cdsid: {}", normalizedCdsid);
        Sort sort = Sort.by(Sort.Direction.fromString(direction), sortBy);
        Pageable pageable = PageRequest.of(page, size, sort);
        return ResponseEntity.ok(recallIssueService.getWatchListDetails(pageable, normalizedCdsid, searchKey, fields));
    }
}
