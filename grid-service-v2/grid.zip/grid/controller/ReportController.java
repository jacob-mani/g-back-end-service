package com.ford.grid.controller;

import com.ford.grid.common.SystemWideResponses;
import com.ford.grid.exception.GridException;
import com.ford.grid.model.dto.request.EPRCDefectReportRequest;
import com.ford.grid.model.dto.request.FsamPreserveRequest;
import com.ford.grid.model.dto.request.FsamPreviewRequest;
import com.ford.grid.model.dto.request.FsamSearchRequest;
import com.ford.grid.model.dto.request.meetingnotes.DownloadMeetingNotesRequest;
import com.ford.grid.model.dto.request.meetingnotes.ExportMeetingNotesRequest;
import com.ford.grid.model.dto.response.EPRCDefectReportResponse;
import com.ford.grid.model.dto.response.meetingnotes.ExportPreviewResponse;
import com.ford.grid.model.dto.response.meetingnotes.FsamPagedResponse;
import com.ford.grid.security.UserDetailProvider;
import com.ford.grid.service.ReportService;
import io.swagger.v3.oas.annotations.Operation;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import java.util.List;

@RestController
@AllArgsConstructor
@RequestMapping("/api/v2/report")
public class ReportController {
    private static final Logger LOGGER = LoggerFactory.getLogger(ReportController.class);

    private final ReportService reportService;
    private final UserDetailProvider userDetailProvider;

    @PostMapping("/eprcDefectReport")
    @Operation(summary = "save Defect Report", description = "save Defect Report Save API")
    @SystemWideResponses
    public ResponseEntity<EPRCDefectReportResponse> saveEprcDefectReport(@RequestBody EPRCDefectReportRequest eprcDefectReportRequest) {
        LOGGER.info("Start of saveEprcDefectReport : {}", eprcDefectReportRequest);
        EPRCDefectReportResponse response = reportService.saveDefectReport(eprcDefectReportRequest);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/getDefectReport/{issueNumber}")
    @Operation(summary = "Get Defect Report", description = "Fetch Defect Report by Issue Number")
    @SystemWideResponses
    public ResponseEntity<EPRCDefectReportResponse> getDefectReportByIssueNumber(@PathVariable String issueNumber) {
        LOGGER.info("Fetching defect Report for issueNumber: {}", issueNumber);
        EPRCDefectReportResponse response = reportService.getDefectReportByIssueNumber(issueNumber);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/shareEprcReport")
    @Operation(summary = "Share Defect Report", description = "Share Defect Report")
    @SystemWideResponses
    public ResponseEntity<String> ShareEprcReport(@RequestParam String userId, @RequestParam String cdsIds, @RequestParam String issueNumber, @RequestParam String partType) {
        return new ResponseEntity<>(reportService.shareReport(userId, cdsIds, issueNumber, partType), HttpStatus.OK);
    }

    @PostMapping("/approveEprcReport")
    @Operation(summary = "Approve Defect Report", description = "Approve Defect Report")
    @SystemWideResponses
    public ResponseEntity<String> ApproveEprcReport(@RequestParam String userId, @RequestParam String cdsIds, @RequestParam String issueNumber, @RequestParam String partType) {
        return new ResponseEntity<>(reportService.eprcDefectReportApproveEmail(userId, cdsIds, issueNumber, partType), HttpStatus.OK);
    }

    @PostMapping("/exportMeetingNotes")
    @Operation(
        summary = "Export Meeting Notes Preview (Paginated)",
        description = "Returns meeting notes grouped by forum (CCRG, CSF, EPRC, GOVERNMENT). " +
                      "Supports server-side pagination: send 'page' (0-based) and 'pageSize' (>0) to paginate. " +
                      "Omit pageSize (or send 0) to get ALL records in one response. " +
                      "Required fields: leadRegion (String), forumType (List<String>). " +
                      "Response includes 'allIssueNumbers' — a lightweight list of ALL matching issue numbers " +
                      "(regardless of pagination) so the UI can maintain cross-page selection state. " +
                      "Each forum block contains issList (paginated), totalCount, page, pageSize, totalPages, hasNextPage, hasPreviousPage.")
    @SystemWideResponses
    public ResponseEntity<ExportPreviewResponse> exportMeetingNotes(
            @RequestBody ExportMeetingNotesRequest request) {
        LOGGER.info("exportMeetingNotes — cdsid: {}, region: {}, forums: {}",
                request.getCdsid(), request.getLeadRegion(), request.getForumType());
        ExportPreviewResponse response = reportService.loadNotesPreview(request);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/exportMeetingNotes/download")
    @Operation(
        summary = "Download Meeting Notes as DOCX",
        description = "Builds and streams a Word (.docx) document containing meeting notes. " +
                      "forumType accepts a List<String> e.g. [\"CCRG\",\"CSF\"]. " +
                      "leadRegion and forumType are mandatory. " +
                      "Each issue gets a row in a 6-column table: " +
                      "ID/Phase/Forum | Program/Title/Meetings | Days Open | Affected Volume | Contacts | Notes.")
    @SystemWideResponses
    public ResponseEntity<StreamingResponseBody> downloadMeetingNotesDocx(
            @RequestBody DownloadMeetingNotesRequest request) throws GridException {
        LOGGER.info("downloadMeetingNotesDocx — cdsid={}, region={}, forums={}",
                request.getCdsid(), request.getLeadRegion(), request.getForumType());
        return reportService.exportMeetingNotesAsDocx(request);
    }
    @GetMapping("/fsam")
    @Operation(summary     = "Get FSAM Report List",
            description = "Fetches all FSAM records from the DB (unpaged), then optionally slices the result. " +
                          "Pass page (0-based) and pageSize (> 0) to receive a page slice. " +
                          "Omit both params (or pass pageSize=0) to receive the full list in one response.")
    @SystemWideResponses
    public ResponseEntity<FsamPagedResponse> getFsamList(
            @RequestParam(name = "leadRegion") String leadRegion,
            @RequestParam(name = "viewType") String viewType,
            @RequestParam(name = "page",     defaultValue = "0") int page,
            @RequestParam(name = "pageSize", defaultValue = "0") int pageSize) throws GridException {

        if (viewType == null || viewType.trim().isEmpty()) {
            throw new GridException("viewType must not be null or blank");
        }
        String cdsid = userDetailProvider.getUser().getCdsID();
        LOGGER.info("getFsamList — leadRegion={} | viewType={} | cdsid={} | page={} | pageSize={}",
                leadRegion, viewType, cdsid, page, pageSize);

        FsamPagedResponse fsamPagedResponse = reportService.getFsamList(leadRegion, viewType, cdsid, page, pageSize);

        LOGGER.info("getFsamList — returning {}/{} records (page={}, pageSize={})",
                fsamPagedResponse.getData().size(), fsamPagedResponse.getTotalCount(), page, pageSize);

        return ResponseEntity.ok(fsamPagedResponse);
    }

    @PostMapping("/preserve")
    @Operation(
            summary     = "Preserve FSAM Report Order",
            description = "Saves the custom serial-number ordering for one or more FSAM rows and returns the ordered list. " +
                          "Pass page (0-based) and pageSize (> 0) for a page slice, or omit / pageSize=0 to return all records.")
    @SystemWideResponses
    public ResponseEntity<FsamPagedResponse> preserveFsamList(
            @RequestBody List<FsamPreserveRequest> fsamReq,
            @RequestParam String leadRegion,
            @RequestParam String viewType,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "0") int pageSize) throws GridException {
        String cdsid = userDetailProvider.getUser().getCdsID();
        FsamPagedResponse result =
                reportService.preserveFsamList(fsamReq, leadRegion, viewType, cdsid, page, pageSize);
        return ResponseEntity.ok(result);
    }
    @PostMapping("/fsam/download")
    @Operation(
            summary     = "Download FSAM Report as Excel",
            description = "Exports the FSAM preview selection as a .xlsx file.")
    @SystemWideResponses
    public ResponseEntity<StreamingResponseBody> exportFsamReportAsExcel(
            @RequestBody FsamPreviewRequest request) throws GridException {

        LOGGER.info("exportFsamReportAsExcel — leadRegion={} | viewType={} | cdsid={} | selectedIssues={}",
                request.getLeadRegion(), request.getViewType(), request.getCdsid(),
                request.getSelectedIssues() != null ? request.getSelectedIssues().size() : "all");

        return reportService.exportFsamReportAsExcel(request);
    }

    @PostMapping("/preview")
    @Operation(
            summary     = "Preview FSAM Report List",
            description = "Returns the complete (unpaginated) FSAM report list for a single lead region, " +
                          "filtered by the selected issue numbers (selectedIssues) and optionally by forum chair (selectCCList). " +
                          "All matching records are returned in one response — page/pageSize are not accepted.")
    @SystemWideResponses
    public ResponseEntity<FsamPagedResponse> getFsamPreviewList(
            @RequestBody FsamPreviewRequest request) throws GridException {
        LOGGER.info("getFsamPreviewList — leadRegion={} | viewType={} | cdsid={} | selectCCList={} | page={} | pageSize={}",
                request.getLeadRegion(), request.getViewType(), request.getCdsid(),
                request.getSelectCCList(), request.getPage(), request.getPageSize());
        FsamPagedResponse result = reportService.getFsamPreviewList(request);
        return ResponseEntity.ok(result);
    }

    @PostMapping("/fsam/search")
    @Operation(
            summary     = "Global FSAM Search",
            description = "Searches FSAM records within the specified lead region using a free-text keyword.")
    @SystemWideResponses
    public ResponseEntity<FsamPagedResponse> searchFsamList(
            @RequestBody FsamSearchRequest request) throws GridException {
        LOGGER.info("searchFsamList — leadRegion='{}' | searchKey='{}' | page={} | pageSize={}",
                request.getLeadRegion(), request.getSearchKey(), request.getPage(), request.getPageSize());
        FsamPagedResponse result = reportService.searchFsamList(request);
        return ResponseEntity.ok(result);
    }
}



