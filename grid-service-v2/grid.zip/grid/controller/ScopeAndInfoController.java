package com.ford.grid.controller;

import com.ford.grid.common.SystemWideResponses;
import com.ford.grid.exception.GridException;
import com.ford.grid.model.dto.request.ScopeAndInfoRequest;
import com.ford.grid.model.dto.response.AffectedRegionResponse;
import com.ford.grid.model.dto.response.ScopeAndInfoResponse;
import com.ford.grid.service.ScopeAndInfoService;
import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.Set;

/**
 * Controller for handling Scope and Information related endpoints.
 */
@RestController
@RequestMapping("/api/v2")
@RequiredArgsConstructor
public class ScopeAndInfoController {
    private static final Logger LOGGER = LoggerFactory.getLogger(ScopeAndInfoController.class);
    private final ScopeAndInfoService scopeAndInfoService;

    /**
     * Endpoint to get scope and information by issue number.
     *
     * @param issueNumber the issue number to retrieve scope and information for
     * @return ResponseEntity containing the scope and information response
     */
    @GetMapping("/getScopeAndInfo/{issueNumber}")
    public ResponseEntity<ScopeAndInfoResponse> getScopeAndInfo(@PathVariable String issueNumber) {
        LOGGER.info("Start of getScopeAndInfo for issue number: {}", issueNumber);
        return ResponseEntity.ok(scopeAndInfoService.getScopeAndInfoByIssueNumber(issueNumber));
    }

    /**
     * Endpoint to save scope and information.
     *
     * @param request the scope and information request payload
     * @return ResponseEntity containing the saved scope and information response
     */
    @PostMapping("/saveScopeAndInfo")
    public ResponseEntity<ScopeAndInfoResponse> saveScopeAndInfo(@RequestBody ScopeAndInfoRequest request)  {
        LOGGER.info("Start of saveScopeAndInfo for issue number: {}", request.getIssueNumber());

        ScopeAndInfoResponse response;
        try {
            response = scopeAndInfoService.saveScopeAndInfo(request);
        } catch (GridException gridException) {
            LOGGER.error("Error saving ScopeAndInfo: {}", gridException.getMessage());
            return ResponseEntity.status(gridException.getStatus()).body(null);
        }
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @GetMapping("/getAffectedRegions/{issueNumber}")
    @Operation(summary = "Get Affected Regions", description = "Retrieves all affected regions for a given issue number")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:MyIssuesList','read')")
    public ResponseEntity<Set<AffectedRegionResponse>> getAffectedRegions(@PathVariable String issueNumber) {
        return ResponseEntity.ok(scopeAndInfoService.getAffectedRegions(issueNumber));
    }
}