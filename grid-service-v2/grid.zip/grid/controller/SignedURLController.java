package com.ford.grid.controller;

import com.ford.grid.model.dto.request.FileData;
import com.ford.grid.model.dto.request.SignedURLRequest;
import com.ford.grid.model.dto.request.UploadRequest;
import com.ford.grid.model.dto.response.SignedURLResponse;
import com.ford.grid.model.dto.response.UploadResponse;
import com.ford.grid.service.ISignedURLService;
import com.ford.grid.restserviceclient.CloudClient;
import com.google.cloud.storage.HttpMethod;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

import static org.springframework.http.MediaType.APPLICATION_OCTET_STREAM_VALUE;

/**
 * Controller for handling requests related to signed URLs.
 * This controller provides an endpoint to generate signed URLs for file uploads.
 */
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v2")
public class SignedURLController {
    private static final Logger LOGGER = LoggerFactory.getLogger(SignedURLController.class);

    private final ISignedURLService signedURLService;
    private final CloudClient cloudClient;

    /**
     * Endpoint to generate signed URLs for file uploads.
     *
     * @param filesList the request containing the list of files to generate signed URLs for
     * @return a ResponseEntity containing a list of signed URL responses
     *
     * <p> Sample Request payload : {"filesList": [{"originalFileName": "CreateIssue_Test.png","desiredGCSFileName": "CreateIssue_Test.png", "contentType": "application/octet-stream"}]} </p>
     * <p>Sample CURL request:
     * curl -v -X PUT --upload-file ".\CreateIssue_Test.png"
     * -H "Content-Type: application/octet-stream" "${SIGNED_URL}"
     * </p>
     */
    @PutMapping(value = "/signedURL", produces = MediaType.APPLICATION_JSON_VALUE)
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:UploadDocuments':'update'})")
    public ResponseEntity<List<SignedURLResponse>> getSignedURLToAddNewResource(@RequestBody SignedURLRequest filesList) {
        LOGGER.info("Start of getSignedURL method in SignedURLController with filesList: {}", filesList);
        return ResponseEntity.ok(signedURLService.getSignedURL(filesList, HttpMethod.PUT));
    }

    /**
     * Direct multipart upload endpoint that uploads files to GCS on the server side and
     * returns the stored metadata together with a signed download URL.
     *
     * <p>This mirrors the population custom-view download flow: upload first, then generate
     * a signed GET URL for the already-uploaded object. It is useful for 14D attachments when
     * clients cannot reliably create PUT signed URLs.</p>
     */
    @PostMapping(value = "/files/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:UploadDocuments':'update'})")
    public ResponseEntity<List<UploadResponse>> uploadFiles(@ModelAttribute UploadRequest uploadRequest) {
        LOGGER.info("Start of direct uploadFiles method in SignedURLController for issueNumber={}, screenType={}",
                uploadRequest.getIssueNumber(), uploadRequest.getScreenType());

        if (!StringUtils.hasText(uploadRequest.getIssueNumber()) || !StringUtils.hasText(uploadRequest.getScreenType())) {
            return ResponseEntity.badRequest().build();
        }

        if (CollectionUtils.isEmpty(uploadRequest.getFiles())) {
            return ResponseEntity.badRequest().build();
        }

        return ResponseEntity.ok(signedURLService.uploadFiles(uploadRequest));
    }

    /**
     * Endpoint to generate signed URLs for file deletions.
     *
     * @param filesList the request containing the list of files to generate signed URLs for
     * @return a ResponseEntity containing a list of signed URL responses
     */
    @DeleteMapping(value = "/signedURL", produces = MediaType.APPLICATION_JSON_VALUE)
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:UploadDocuments':'delete'})")
    public ResponseEntity<List<SignedURLResponse>> getSignedURLToDeleteResource(@RequestBody SignedURLRequest filesList) {
        LOGGER.info("Start of getSignedURLToDeleteResource method in SignedURLController with filesList: {}", filesList);
        return ResponseEntity.ok(signedURLService.getSignedURL(filesList, HttpMethod.DELETE));
    }

    /**
     * Endpoint to generate signed URLs for downloading files.
     *
     * @param requestParams the request parameters containing file information
     * @return a ResponseEntity containing a list of signed URL responses
     *
     * <p> SAMPLE CURL request: curl -v -X GET -o "${LOCAL_FILENAME}" "${SIGNED_URL}" </p>
     */
    @GetMapping(value = "/signedURL", produces = MediaType.APPLICATION_JSON_VALUE)
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:UploadDocuments':'read'})")
    public ResponseEntity<List<SignedURLResponse>> getSignedURLToGetResource(@RequestParam Map<String, String> requestParams) {
        LOGGER.info("Start of getSignedURLToGetResource method in SignedURLController with request parameters: {}", requestParams);

        String fileName = requestParams.get("fileName");
        if (!StringUtils.hasText(fileName))
            return ResponseEntity.badRequest().build();

        FileData downloadFile = FileData.builder().originalFileName(fileName).
                desiredGCSFileName(fileName).contentType(APPLICATION_OCTET_STREAM_VALUE).build();
        SignedURLRequest signedURLRequest = new SignedURLRequest(List.of(downloadFile));
        LOGGER.debug("signedURLRequest in getSignedURLToGetResource= {}", signedURLRequest);

        return ResponseEntity.ok(signedURLService.getSignedURL(signedURLRequest, HttpMethod.GET));
    }

    /**
     * Endpoint to get a signed URL for any file by its GCS file name.
     * This endpoint works for images, documents, text files, etc.
     *
     * @param gcsFileName      the GCS file name (including folder path)
     * @param originalFileName optional original/display filename to use for download naming
     * @return a ResponseEntity containing the signed URL response for the file
     */
    @PostMapping(value = "/files", produces = MediaType.APPLICATION_JSON_VALUE)
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:UploadDocuments':'read'})")
      public ResponseEntity<SignedURLResponse> getSignedUrlForFile(
            @RequestParam(value = "originalFileName", required = false) String originalFileName, @RequestBody String gcsFileName) {
          LOGGER.info("Start of getSignedUrlForFile method in SignedURLController with gcsFileName: {}, originalFileName: {}",
                gcsFileName, originalFileName);

        if (!StringUtils.hasText(gcsFileName)) {
            LOGGER.warn("GCS filename is empty or null");
            return ResponseEntity.badRequest().build();
        }

        try {
            SignedURLResponse response = signedURLService.getFileByGcsFileName(gcsFileName, originalFileName);
            LOGGER.info("Signed URL generated for GCS file: {}", gcsFileName);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            LOGGER.error("Error generating signed URL for GCS file {}: {}", gcsFileName, e.getMessage());
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Endpoint to delete a file directly from Google Cloud Storage.
     *
     * @param gcsFileName the GCS file name (including folder path) to delete
     * @return a ResponseEntity indicating success or failure
     */
    @DeleteMapping(value = "/files", produces = MediaType.APPLICATION_JSON_VALUE)
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:UploadDocuments':'read'})")
    public ResponseEntity<String> deleteFileFromGCS(@RequestParam(value = "gcsFileName") String gcsFileName) {
        LOGGER.info("Start of deleteFileFromGCS method in SignedURLController with gcsFileName: {}", gcsFileName);

        if (!StringUtils.hasText(gcsFileName)) {
            LOGGER.warn("GCS filename is empty or null");
            return ResponseEntity.badRequest().body("gcsFileName is required");
        }

        try {
            cloudClient.deleteFileFromGCS(gcsFileName);
            LOGGER.info("Successfully deleted file from GCS: {}", gcsFileName);
            return ResponseEntity.ok("File deleted successfully: " + gcsFileName);
        } catch (Exception e) {
            LOGGER.error("Error deleting file from GCS {}: {}", gcsFileName, e.getMessage());
            return ResponseEntity.internalServerError().body("Failed to delete file: " + e.getMessage());
        }
    }
}