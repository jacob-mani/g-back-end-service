package com.ford.grid.controller;

import com.ford.grid.common.SystemWideResponses;
import com.ford.grid.model.dto.request.EmmScheduleRequest;
import com.ford.grid.model.dto.request.IssueTrgScheduleRequest;
import com.ford.grid.model.dto.request.SaveTrgRecommendationRequest;
import com.ford.grid.model.dto.request.TrgScheduleRequest;
import com.ford.grid.model.dto.response.EmmScheduleResponse;
import com.ford.grid.model.dto.response.IssueTrgScheduleResponse;
import com.ford.grid.model.dto.response.TrgScheduleResponse;
import com.ford.grid.service.TrgService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v2/trg")
@AllArgsConstructor
public class TrgController {

    private final TrgService trgService;

    @GetMapping("/getEmmSchedule/{issueNumber}")
    @Operation(summary = "Get EMM Schedule", description = "Get EMM Schedule by issue number")
    @SystemWideResponses
    public ResponseEntity<EmmScheduleResponse> getEmmSchedule(
            @PathVariable String issueNumber) {
        return ResponseEntity.ok(
                trgService.getEmmScheduleByKeys(issueNumber)
        );
    }

    @PostMapping("/emmSchedule")
    @Operation(summary = "Save EMM Schedule", description = "Save EMM Schedule")
    @SystemWideResponses
    public ResponseEntity<EmmScheduleResponse> saveEmmSchedule(@RequestBody EmmScheduleRequest request) {
        return ResponseEntity.ok(trgService.saveEmmSchedule(request));
    }

    // ==================== Population-Level TRG Schedule APIs (DEPRECATED) ====================
    // Going forward, only issue_trg_schedule is used with populationList on each agenda item.
    // The trg_schedule collection (population-level) is no longer used.

    /*
    @GetMapping("/getTrgSchedule/{issueNumber}/{implId}/{populationId}")
    @Operation(summary = "Get TRG Schedule", description = "Get TRG Schedule by issue number, impl ID and population ID")
    @SystemWideResponses
    public ResponseEntity<TrgScheduleResponse> getTrgSchedule(
            @PathVariable String issueNumber,
            @PathVariable String implId,
            @PathVariable String populationId) {
        return ResponseEntity.ok(
                trgService.getTrgScheduleByKeys(issueNumber, implId, populationId)
        );
    }

    @PostMapping("/trgSchedule")
    @Operation(summary = "Save TRG Schedule", description = "Save TRG Schedule at population level")
    @SystemWideResponses
    public ResponseEntity<TrgScheduleResponse> saveTrgSchedule(@RequestBody TrgScheduleRequest request) {
        return ResponseEntity.ok(trgService.saveTrgSchedule(request));
    }
    */

    // ==================== Issue-Level TRG Schedule APIs ====================

    @GetMapping("/getIssueTrgSchedule/{issueNumber}")
    @Operation(summary = "Get Issue-Level TRG Schedule", description = "Get TRG Schedule at issue level by issue number")
    @SystemWideResponses
    public ResponseEntity<IssueTrgScheduleResponse> getIssueTrgSchedule(
            @PathVariable String issueNumber) {
        return ResponseEntity.ok(
                trgService.getIssueTrgSchedule(issueNumber)
        );
    }

    @PostMapping("/issueTrgSchedule")
    @Operation(summary = "Save Issue-Level TRG Schedule", description = "Save TRG Schedule at issue level")
    @SystemWideResponses
    public ResponseEntity<IssueTrgScheduleResponse> saveIssueTrgSchedule(
            @RequestBody IssueTrgScheduleRequest request) {
        return ResponseEntity.ok(trgService.saveIssueTrgSchedule(request));
    }

    // ==================== TRG Recommendation API ====================

    @PostMapping("/issueTrgRecommendation")
    @Operation(summary = "Save TRG Recommendations",
            description = "Saves one or more TRG Recommendations on agenda items identified by sequenceId.")
    @SystemWideResponses
    public ResponseEntity<IssueTrgScheduleResponse> saveTrgRecommendation(
            @Valid @RequestBody SaveTrgRecommendationRequest request) {
        return ResponseEntity.ok(trgService.saveTrgRecommendations(request));
    }

    @DeleteMapping("/issueTrgAgenda/{issueNumber}/{sequenceId}")
    @Operation(summary = "Delete TRG Agenda Item",
            description = "Deletes a TRG Agenda item from the issue-level TRG schedule by issueNumber and sequenceId.")
    @SystemWideResponses
    public ResponseEntity<IssueTrgScheduleResponse> deleteIssueTrgAgenda(
            @PathVariable String issueNumber,
            @PathVariable int sequenceId) {
        return ResponseEntity.ok(trgService.deleteIssueTrgAgenda(issueNumber, sequenceId));
    }

    @DeleteMapping("/emmAgenda/{issueNumber}/{sequenceId}")
    @Operation(summary = "Delete EMM Agenda Item",
            description = "Deletes an EMM Agenda item from the EMM schedule by issueNumber and sequenceId.")
    @SystemWideResponses
    public ResponseEntity<EmmScheduleResponse> deleteEmmAgenda(
            @PathVariable String issueNumber,
            @PathVariable int sequenceId) {
        return ResponseEntity.ok(trgService.deleteEmmAgenda(issueNumber, sequenceId));
    }
}
