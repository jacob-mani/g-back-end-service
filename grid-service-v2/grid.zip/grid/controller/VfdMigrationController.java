package com.ford.grid.controller;

import com.ford.grid.service.VfdMigrationService;
import com.ford.grid.service.impl.vern.VernResponseService;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v2/migrate")
public class VfdMigrationController {
    private static final Logger LOGGER = LoggerFactory.getLogger(VfdMigrationController.class);

    private final VfdMigrationService vfdMigrationService;
    private final VernResponseService vernResponseService;

    @PostMapping("/vfdSelectionMap")
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:IssueList','update')")
    public ResponseEntity<Map<String, Integer>> migrateVfdRequestsToSelectionMap() {
        LOGGER.info("Starting migration from vfd_request to vfd_vern_selection_map");
        Map<String, Integer> result = vfdMigrationService.migrateVfdRequestsToSelectionMap();
        LOGGER.info("Migration finished: {}", result);
        return ResponseEntity.ok(result);
    }

    @PostMapping("/wers/{vernNumber}/{version}/{revision}")
    public void saveWERSAttributes(@PathVariable String vernNumber, @PathVariable String version, @PathVariable String revision) {
        LOGGER.info("Start of saveWERSAttributes for vern Number ID:{}", vernNumber);
        vernResponseService.saveVFDWERSAttributes(vernNumber, Integer.parseInt(version), Integer.parseInt(revision));
        LOGGER.info("End of saveWERSAttributes for vern Number ID:{}", vernNumber);
    }

    @PostMapping("/vern/{vernNumber}/{version}/{revision}")
    public void saveVernMapping(@PathVariable String vernNumber, @PathVariable String version, @PathVariable String revision) {
        LOGGER.info("Start of saveVernMapping for vern Number ID:{}", vernNumber);
        vernResponseService.saveVERNProfileMapping(vernNumber, Integer.parseInt(version), Integer.parseInt(revision));
        LOGGER.info("End of saveVernMapping for vern Number ID:{}", vernNumber);
    }

    @PostMapping("/WERSAttributes")
    public void saveWERSAttributes() {
        LOGGER.info("Start of saveWERSAttributes");
        vernResponseService.migrateWERSAttributes();
        LOGGER.info("End of saveWERSAttributes");
    }
}