package com.ford.grid.controller.arc.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Configuration for Collab approver SLA breach reminder settings.
 */
@Component
public class CollabSlaConfig {

    @Value("${collab.sla.breach.hours}")
    private int slaBreachHours;

    @Value("${collab.sla.reminder.template}")
    private String reminderTemplateName;

    @Value("${collab.sla.reminder.subject.prefix}")
    private String subjectPrefix;

    @Value("${grid.ui.base-url}")
    private String uiBaseUrl;

    public int getSlaBreachHours()
    {
        return slaBreachHours;
    }

    public String getReminderTemplateName() {
        return reminderTemplateName;
    }

    public String getSubjectPrefix()
    {
        return subjectPrefix;
    }

    public String getUiBaseUrl()
    {
        return uiBaseUrl;
    }
}

