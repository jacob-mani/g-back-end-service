package com.ford.grid.controller.arc.config;

import com.ford.grid.constants.AzureAuthConstants;
import com.ford.grid.util.WebClientUtil;
import com.microsoft.graph.core.requests.GraphClientFactory;
import com.microsoft.graph.serviceclient.GraphServiceClient;
import com.microsoft.kiota.authentication.AccessTokenProvider;
import com.microsoft.kiota.authentication.AllowedHostsValidator;
import com.microsoft.kiota.authentication.BaseBearerTokenAuthenticationProvider;
import com.microsoft.kiota.http.OkHttpRequestAdapter;
import okhttp3.OkHttpClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URI;
import java.net.UnknownHostException;
import java.util.Map;

/**
 * Provides a {@link GraphServiceClient} authenticated via Entra ID (OAuth2 client credentials).
 * <p>
 * Acquires an access token by reusing {@link WebClientUtil#getAzureToken} which posts
 * client credentials to the Entra token endpoint, then wraps the token in a
 * {@link GraphServiceClient} for Microsoft Graph API calls.
 */
@Component
public class EntraGraphClientProvider {

    private static final Logger LOGGER = LoggerFactory.getLogger(EntraGraphClientProvider.class);

    private final WebClientUtil webClientUtil;

    @Value("${graph_clientid}")
    private String clientId;

    @Value("${graph_clientsecret}")
    private String clientSecret;

    private volatile OkHttpClient cachedHttpClient;

    public EntraGraphClientProvider(WebClientUtil webClientUtil) {
        this.webClientUtil = webClientUtil;
    }

    private OkHttpClient getHttpClient() {
        if (cachedHttpClient == null) {
            synchronized (this) {
                if (cachedHttpClient == null) {
                    cachedHttpClient = buildHttpClient();
                }
            }
        }
        return cachedHttpClient;
    }

    /**
     * Creates and returns a {@link GraphServiceClient} with a fresh Entra ID access token.
     *
     * @return an authenticated GraphServiceClient ready for Microsoft Graph API calls
     * @throws RuntimeException if token acquisition fails
     */
    public GraphServiceClient getClient() {
        String accessToken = getAccessToken();

        BaseBearerTokenAuthenticationProvider authProvider =
                new BaseBearerTokenAuthenticationProvider(new EntraAccessTokenProvider(accessToken));
        return new GraphServiceClient(new OkHttpRequestAdapter(authProvider, null, null, getHttpClient()));
    }

    /**
     * Acquires a fresh Entra ID (client-credentials) access token for Microsoft Graph.
     * <p>
     * Exposed so callers can issue raw Graph HTTP requests (e.g. a DELETE that must
     * explicitly set {@code If-Match: *}) using the exact same credentials as the SDK client.
     *
     * @return a bearer access token string for the Graph scope
     */
    public String getAccessToken() {
        String accessToken = webClientUtil.getAzureToken(
                clientId.trim(), clientSecret.trim(), AzureAuthConstants.GRAPH_SCOPE, null);
        LOGGER.debug("Entra Graph token acquired for clientId={}", clientId.trim());
        return accessToken;
    }

    /**
     * Builds a proxy-aware {@link OkHttpClient} for Microsoft Graph API HTTP calls.
     */
    private OkHttpClient buildHttpClient() {
        OkHttpClient base = GraphClientFactory.create().build();
        try {
            InetAddress.getByName(AzureAuthConstants.FORD_PROXY_SERVER);
            Proxy proxy = new Proxy(Proxy.Type.HTTP,
                    new InetSocketAddress(AzureAuthConstants.FORD_PROXY_SERVER, AzureAuthConstants.FORD_PROXY_PORT));
            LOGGER.info("Using Ford proxy {}:{}", AzureAuthConstants.FORD_PROXY_SERVER, AzureAuthConstants.FORD_PROXY_PORT);
            return base.newBuilder().proxy(proxy).build();
        } catch (UnknownHostException e) {
            LOGGER.warn("Ford proxy not reachable, using direct connection");
            return base;
        }
    }

    /**
     * Wraps a pre-fetched Entra access token for use by {@link GraphServiceClient}.
     */
    private static class EntraAccessTokenProvider implements AccessTokenProvider {

        private final String token;

        EntraAccessTokenProvider(String token) {
            this.token = token;
        }

        @Override
        public String getAuthorizationToken(URI uri, Map<String, Object> additionalAuthenticationContext) {
            return token;
        }

        @Override
        public AllowedHostsValidator getAllowedHostsValidator() {
            return new AllowedHostsValidator("graph.microsoft.com");
        }
    }
}
