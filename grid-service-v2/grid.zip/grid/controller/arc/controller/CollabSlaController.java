package com.ford.grid.controller.arc.controller;

import com.ford.grid.common.SystemWideResponses;
import com.ford.grid.controller.arc.service.CollabSlaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api/v2/collab-sla")
public class CollabSlaController {

    @Autowired
    private CollabSlaService collabSlaService;

    /**
     * Triggers an SLA breach scan for all pending Collab approvers and sends reminder emails.
     */
    @PostMapping("/approvalReminders")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:CheckList','read')")
    public ResponseEntity<Map<String, String>> sendApprovalReminders() {
        String result = collabSlaService.sendPendingApprovalReminders();
        return ResponseEntity.ok(Map.of("message", result));
    }
}
