package com.ford.grid.controller.arc.controller;

import com.ford.grid.common.SystemWideResponses;
import com.ford.grid.controller.arc.request.*;
import com.ford.grid.controller.arc.response.DraftNotificationPreviewResponse;
import com.ford.grid.controller.arc.response.SharePointDiscardResponse;
import com.ford.grid.controller.arc.response.SharePointEditorInfo;
import com.ford.grid.controller.arc.response.SharePointFileEditorsResponse;
import com.ford.grid.controller.arc.service.DraftNotificationService;
import com.ford.grid.controller.arc.service.SharePointService;
import com.ford.grid.exception.GridException;
import com.ford.grid.model.dto.response.DocuSignEnvelope;
import com.ford.grid.service.GovDocumentsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

import static com.azure.core.implementation.http.rest.RestProxyUtils.LOGGER;

@RestController
@RequestMapping("/api/v2/sharepointfile")
public class SharePointController {
    @Autowired
    SharePointService sharePointService;

    @Autowired
    DraftNotificationService draftNotificationService;

    @Autowired
    GovDocumentsService govDocumentsService;

    @Value("${graph_fileName}")
    private String fileName;

    @Value("${docusign.local-fallback-signer:${DOCUSIGN_LOCAL_FALLBACK_SIGNER:}}")
    private String localFallbackSigner;

    @Value("${docusign.local-fallback-signer-name:Local Test Signer}")
    private String localFallbackSignerName;

    @Value("${spring.profiles.active:default}")
    private String activeProfile;

    /**
     * Returns editor history for a file in SharePoint.
     */
    @GetMapping("/arc-sharepoint/edited-users")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:CheckList','read')")
    public ResponseEntity<?> getEditedUsersForSharePointFiles() throws GridException {
        String fileSource = "";
        return ResponseEntity.ok(sharePointService.getEditorsByFileName(fileName, fileSource));
    }

    /**
     * Fetches all files from a GCP bucket folder and uploads them to a SharePoint folder.
     *
     * @param gcpFolderPath        GCP bucket folder path
     * @param sharePointFolderPath SharePoint folder path
     * @return list of SharePointUploadResponse with each uploaded file's SharePoint link
     */
    @PostMapping("/arc-sharepoint/draftUpload")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:CheckList','read')")
    public ResponseEntity<?> uploadDraftFiles(
            @RequestParam("gcpFolderPath") String gcpFolderPath,
            @RequestParam("sharePointFolderPath") String sharePointFolderPath) throws GridException {
        return ResponseEntity.ok(sharePointService.uploadDraftFiles(gcpFolderPath, sharePointFolderPath));
    }

    /**
     * Sends a review reminder email to the specified reviewers
     * with a list of documents pending review.
     *
     * @param request contains reviewerEmails and pendingDocuments
     * @return success message
     */
    @PostMapping("/arc-sharepoint/sendReminder")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:CheckList','read')")
    public ResponseEntity<?> sendReviewReminder(@RequestBody SharePointReminderRequest request) throws GridException {
        sharePointService.sendReviewReminder(request);
        return ResponseEntity.ok(Map.of("message", "Review reminder email sent successfully",
                "recipientCount", request.getReviewerEmails().size(),
                "documentCount", request.getPendingDocuments().size()));
    }



    @PostMapping("/arc-sharepoint/sendDraftNotificationToReviewers")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:CheckList','read')")
    public ResponseEntity<?> sendDraftNotificationToReviewers(
            @RequestBody DraftNotificationReviewersRequest request) throws GridException {
        draftNotificationService.sendDraftNotificationToReviewers(request);
        return ResponseEntity.ok(Map.of(
                "message", "Draft notification email sent successfully",
                "fsaNumber", request.getFsaNumber(),
                "recipientCount", request.getReviewerCdsids() != null ? request.getReviewerCdsids().size() : 0
        ));
    }

    /**
     * Deletes a SharePoint file by its full URL.
     */
    @DeleteMapping("/arc-sharepoint/file-by-url")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:CheckList','update')")
    public ResponseEntity<SharePointDiscardResponse> deleteSharePointFileByUrl(@RequestParam("fileUrl") String fileUrl) throws GridException {
        if (!StringUtils.hasText(fileUrl)) {
            throw new GridException(HttpStatus.BAD_REQUEST, "InvalidFileUrl", "fileUrl must not be blank");
        }

        SharePointDiscardResponse response = sharePointService.deleteFileByUrlWithLockInfo(fileUrl.trim());

        HttpStatus status;
        if (response.isSuccess()) {
            status = HttpStatus.OK;
        } else if ("BLOCKED_BY_OPEN_FILES".equals(response.getStatus())
                || "BLOCKED_BY_CHECKED_OUT_FILES".equals(response.getStatus())) {
            status = HttpStatus.CONFLICT;
        } else {
            status = HttpStatus.INTERNAL_SERVER_ERROR;
        }
        return ResponseEntity.status(status).body(response);
    }

    /**
     * Grants SharePoint edit/write access for all files in the given fileSource to the provided users.
     * No invitation email is sent by SharePoint for this operation.
     */
    @PostMapping("/arc-sharepoint/grantWriteAccess")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:CheckList','update')")
    public void grantWriteAccess(@RequestBody GrantWriteAccessRequest request) throws GridException {
        if (request == null) {
            throw new GridException(HttpStatus.BAD_REQUEST, "InvalidRequest", "Request body is required");
        }
         sharePointService.grantWriteAccess(request.getFileSource(), request.getCdsIds());
    }

    /* Builds the  email server-side (recipients, subject, rendered HTML body and
     * all template values) and returns it for UI review/editing. Does NOT send.
     */
    @PostMapping("/arc-sharepoint/draftNotification/preview")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:CheckList','read')")
    public ResponseEntity<DraftNotificationPreviewResponse> previewDraftNotification(
            @RequestBody DraftNotificationPreviewRequest request) throws GridException {
        LOGGER.info("Start of previewDraftNotification in SharePointController - fsaNumber: {}, fsaType: {}, issueNumber: {}, screenName: {}",
                request.getFsaNumber(), request.getFsaType(), request.getIssueNumber(), request.getScreenName());
        return ResponseEntity.ok(draftNotificationService.previewDraftNotification(request));
    }

    /**
     * Sends collab1 ,collab 2 emails
     */
    @PostMapping(value = "/arc-sharepoint/draftNotification/send",
            consumes = org.springframework.http.MediaType.MULTIPART_FORM_DATA_VALUE)
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:CheckList','read')")
    public ResponseEntity<?> sendEditedDraftNotification(
            @RequestPart("payload") DraftNotificationSendRequest request,
            @RequestPart(value = "files", required = false) org.springframework.web.multipart.MultipartFile[] files
    ) throws GridException {
        LOGGER.info("Start of sendEditedDraftNotification in SharePointController - fsaNumber: {}, fsaType: {}, issueNumber: {}, toList: {}, ccList: {}, files: {}",
                request.getFsaNumber(), request.getFsaType(), request.getIssueNumber(),
                request.getToList() != null ? request.getToList().size() : 0,
                request.getCcList() != null ? request.getCcList().size() : 0,
                files != null ? files.length : 0);
        draftNotificationService.sendEditedDraftNotification(request, files);
        return ResponseEntity.ok(Map.of(
                "message", "Draft notification email sent successfully",
                "fsaNumber", request.getFsaNumber(),
                "fsaType", request.getFsaType(),
                "recipientCount", request.getToList() != null ? request.getToList().size() : 0,
                "attachmentCount", files != null ? files.length : 0));
    }

}