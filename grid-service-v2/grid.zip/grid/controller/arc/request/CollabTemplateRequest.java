package com.ford.grid.controller.arc.request;


import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.web.multipart.MultipartFile;
import com.ford.grid.model.dto.request.*;

import java.util.List;

/**
 * Request payload for adding a new Collab Template.
 * Accepts multipart form data including template metadata and an uploaded file.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Request payload to upload ARC collaboration templates", additionalProperties = Schema.AdditionalPropertiesValue.FALSE)
public class CollabTemplateRequest {

    @NotBlank(message = "region is required")
    @Size(max = 100, message = "region cannot exceed 100 characters")
    @Schema(maxLength = 100, pattern = "^[a-zA-Z0-9_\\-\\s]+$", example = "NA")
    private String region;

    @NotBlank(message = "market is required")
    @Size(max = 100, message = "market cannot exceed 100 characters")
    @Schema(maxLength = 100, pattern = "^[a-zA-Z0-9_\\-\\s]+$", example = "USA")
    private String market;

    @NotBlank(message = "potentialType is required")
    @Size(max = 100, message = "potentialType cannot exceed 100 characters")
    @Schema(maxLength = 100, pattern = "^[a-zA-Z0-9_\\-\\s]+$", example = "Safety Compliance")
    private String potentialType;

    @NotBlank(message = "templateType is required")
    @Size(max = 150, message = "templateType cannot exceed 150 characters")
    @Schema(maxLength = 150, pattern = "^[a-zA-Z0-9_\\-\\s]+$", example = "Advanced Notice")
    private String templateType;

    @NotNull(message = "file is required")
    @Schema(description = "Template file to upload", type = "string", format = "binary", maxLength = 255)
    private MultipartFile file;

    @Size(max = 50, message = "uploadDate cannot exceed 50 characters")
    @Pattern(regexp = "^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}\\.\\d{3}Z$", message = "uploadDate must use format yyyy-MM-dd'T'HH:mm:ss.SSSZ")
    @Schema(maxLength = 50, pattern = "^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}\\.\\d{3}Z$", example = "2026-08-24T11:16:45.666Z")
    private String uploadDate;

    @Size(max = 20, message = "uploadedCdsid cannot exceed 20 characters")
    @Pattern(regexp = "^[a-zA-Z0-9]*$", message = "uploadedCdsid must be alphanumeric")
    @Schema(maxLength = 20, pattern = "^[a-zA-Z0-9]*$", example = "BD21")
    private String uploadedCdsid;

    @NotEmpty(message = "brandType is required and must have at least one value")
    @Size(max = 20, message = "brandType cannot exceed 20 entries")
    @ArraySchema(maxItems = 20, schema = @Schema(maxLength = 100, pattern = "^[a-zA-Z0-9_\\-\\s]+$", example = "Ford"))
    @Schema(description = "List of brand types (e.g. [\"Ford\", \"Lincoln\"])")
    private List<String> brandType;

    /**
     * Optional pre-built template entries. When provided, used as supplementary
     * metadata; the file upload and request fields take precedence for GCS path
     * and version derivation.
     */
    @Valid
    @Size(max = 100, message = "templates cannot exceed 100 items")
    @ArraySchema(maxItems = 100)
    private List<DocumentAddTemplateRequest> templates;

}


