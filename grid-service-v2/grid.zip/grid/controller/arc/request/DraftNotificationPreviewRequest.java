package com.ford.grid.controller.arc.request;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DraftNotificationPreviewRequest {

    private String issueNumber;
    private String region;
    private String fsaNumber;
    private String fsaType;
    private String implId;
    private String populationId;
    private String brand;
    private boolean active;
    private List<String> reviewerCdsids;
    private boolean urgency;

    /**
     * "collab1" = Collab 1 (Review GRID); anything else = Collab 2 (ASO/OGC concurrence).
     */
    private String screenName;

    /**
     * RSP Analyst display name, supplied by the UI, injected into the collab 1 body.
     */
    private String rspAnalystName;

    /**
     * RSP Analyst CDSID, supplied by the UI, injected into the collab 1 body.
     */
    private String rspAnalystCdsid;

    /**
     * Date and time when draft documents were created — drives the review deadline.
     */
    private LocalDateTime draftCompletionTime;

    /**
     * SLA (2 business days, "2 Business Days")
     */
    private Boolean urgencyIndicator;

    /**
     * SharePoint document links used to build documentFolderPath and documentDetails.
     */
    private List<String> documentLinks;

    /**
     * SharePoint folder path supplied by the UI. When present it is used directly as the email's
     * folder-path link; otherwise it is derived from {@link #documentLinks}.
     */
    private String documentFolderPath;

    /**
     * Advance Notice → skip the attestation attachment.
     */
    private boolean advanceNotice;

    /**
     * Labor operation codes involved → adds @Osepchook to the TO list.
     */
    private boolean laborOpsInvolved;

    /**
     * Software repair — DB-derived; overwritten by applyDbDerivedProgramFlags.
     */
    @JsonIgnore
    private boolean softwareRepair;

    /**
     * Software type: "FDRS", "IDS", "OTA", "SETI" — used only if softwareRepair = true.
     */
    private String softwareType;

    /**
     * Software module replacement → adds DSSH lead TO.
     */
    private boolean softwareModuleReplacement;

    /**
     * Technical instructions attached — DB-derived; overwritten by applyDbDerivedProgramFlags.
     */
    @JsonIgnore
    private boolean technicalInstructions;

    /**
     * Tyres involved — DB-derived; overwritten by applyDbDerivedProgramFlags.
     */
    @JsonIgnore
    private boolean tyres;

    /**
     * Bosch involved → adds Bosch technical authors to CC.
     */
    private boolean bosch;

    /**
     * Program calls out a tool → adds tools SME to CC.
     */
    private boolean serviceTools;

    /**
     * ESST involved → adds ESST SME to CC.
     */
    private boolean esst;

    /**
     * Battery Electric Vehicle → adds BEV distribution to CC.
     */
    private boolean bev;

    /**
     * Parts involved — DB-derived; used for logging and downstream context only.
     */
    @JsonIgnore
    private boolean partsInvolved;
    private Map<String, String> rspAnalyst;


}
