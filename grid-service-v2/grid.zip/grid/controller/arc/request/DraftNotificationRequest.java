package com.ford.grid.controller.arc.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Request body for sending email notifications on draft FSA documents generated.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DraftNotificationRequest {

    private String issueNumber;
    private String fsaNumber;
    private String fsaType;
    private String titleDescription;
    private String region;
    private List<String> documentLinks;

    /** Date and time when draft documents were created */
    private LocalDateTime draftCompletionTime;

    private boolean softwareRepair;

    /** Software type: "FDRS", "IDS", "OTA", "SETI"  if softwareRepair = true */
    private String softwareType;

    /** True if the issue is related to this */
    private boolean bev;
    private boolean tyres;
    private boolean serviceTools;
    private boolean bosch;
    private boolean technicalInstructions;
    private boolean softwareModuleReplacement;
    private List<String> additionalTo;
    private List<String> additionalCc;
}


