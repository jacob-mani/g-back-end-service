package com.ford.grid.controller.arc.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.OffsetDateTime;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DraftNotificationReviewersRequest {

    private List<String> reviewerCdsids;
    private String issueNumber;
    private OffsetDateTime draftCompletionDate;
    private String fsaNumber;
    private String fsaType;
    private String titleDescription;
    private Boolean urgencyIndicator;
    private List<String> documentLinks;
}

