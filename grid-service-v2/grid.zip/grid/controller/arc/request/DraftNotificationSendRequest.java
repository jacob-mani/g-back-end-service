package com.ford.grid.controller.arc.request;

import com.ford.grid.controller.arc.response.RecipientDetail;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

/**
 * Request body posted by the UI when the user clicks "Send" after editing the
 * previewed draft notification. The HTML body is sent verbatim — the Thymeleaf
 * template is not re-rendered, so the user's edits are preserved.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DraftNotificationSendRequest {

    private String issueNumber;
    private String fsaNumber;
    private String fsaType;
    private List<RecipientDetail> toList;
    private List<RecipientDetail> ccList;
    private String subject;
    private String htmlBody;
    private String screenName;
    private String documentFolderPath;
    private boolean includeAttestationAttachment;
}
