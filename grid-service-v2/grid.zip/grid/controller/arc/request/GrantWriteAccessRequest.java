package com.ford.grid.controller.arc.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class GrantWriteAccessRequest {

    private String fileSource;
    private List<String> cdsIds;
}

