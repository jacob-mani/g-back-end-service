package com.ford.grid.controller.arc.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SharePointReminderRequest {

    private List<String> reviewerEmails;
    private List<String> pendingDocuments;
    private String subject;
    private String screenName;
    private String fsaNumber;
    private String issueNumber;
    private String cdsUserName;
    private boolean urgency;
    private String folderPath;
    private String cdsName;
}

