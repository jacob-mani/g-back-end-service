package com.ford.grid.controller.arc.response;


import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Response payload returned after a Collab Template upload operation.
 * Contains the uploader's CDSID, upload date, and the file path
 * where the template was stored.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Response payload for uploaded ARC collaboration templates", additionalProperties = Schema.AdditionalPropertiesValue.FALSE)
public class CollabTemplateResponse {

    @Schema(maxLength = 20, pattern = "^[a-zA-Z0-9]*$", example = "AB12345")
    private String uploadedCdsid;

    @Schema(maxLength = 50, pattern = "^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}(?:\\.\\d{3})?Z$", example = "2026-08-24T11:16:45.666Z")
    private String uploadDate;

    @Schema(maxLength = 255, pattern = "^[^<>\\\"|?*]+$", example = "OwnerLetter_v1.docx")
    private String fileName;

    @Schema(maxLength = 2000, pattern = "^[^<>\\\"|?*]+$", example = "ARC/prod/SafetyRecalls/NorthAmerica/UnitedStates/Ford/Owner_Letter/OwnerLetter_v1.docx")
    private String filePath;
}
