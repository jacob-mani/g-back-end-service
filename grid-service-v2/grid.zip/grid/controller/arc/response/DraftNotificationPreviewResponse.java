package com.ford.grid.controller.arc.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

/**
 * Preview payload returned to the UI before a draft notification email is sent.
 * Carries the resolved recipients, subject, fully rendered HTML body and the
 * complete set of template values so the user can review/edit them, then post
 * the edited values back to the send endpoint.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DraftNotificationPreviewResponse {

    private String issueNumber;
    private String fsaNumber;
    private String fsaType;

    /** Resolved primary recipients — editable in the UI. Each entry carries cdsid + name (when known) + email. */
    private List<RecipientDetail> toList;

    /** Resolved CC recipients — editable in the UI. Each entry carries cdsid + name (when known) + email. */
    private List<RecipientDetail> ccList;

    /**
     * Collab 1 fixed Review-GRID TO recipients, keyed by @link com.ford.grid.controller.arc.service.impl.FixedContactGroup key
     * (e.g. {@code "gcamp"}, {@code "psl"}, {@code "software"}). Empty map for Collab 2.
     * Preserves the enum's declared group order.
     */
    private Map<String, List<String>> fixedTo;

    /**
     * Collab 1 fixed Review-GRID CC recipients, keyed by @link com.ford.grid.controller.arc.service.impl.FixedContactGroup key
     * (e.g. {@code "bosch-authors"}, {@code "tools"}, {@code "bev"}). Empty map for Collab 2.
     * Preserves the enum's declared group order.
     */
    private Map<String, List<String>> fixedCc;

    private String subject;

    private String htmlBody;
    private List<String> attachmentNames;
    private String documentFolderPath;
    private List<Map<String, String>> documentDetails;
    private Map<String, Object> templateData;
    private String fdAuthor;
    private String pdContact;
    private String pslAnalyst;
    private String gcampCoordinator;
    private Boolean urgent;
    private String dueDate;
    private String slaText;
    private String rspName;
    private String rspcdsId;
}
