package com.ford.grid.controller.arc.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Recipient details returned by /preview to allow the UI to render chips with
 * both display name and cdsid. Only {@code email} is guaranteed non-null;
 * {@code cdsid} and {@code name} may be null when the source is a raw email
 * (from draft_notification_contacts config or a GCS-uploaded CC file).
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.ALWAYS)
public class RecipientDetail {

    /** Ford CDSID (e.g. "nkaminsk") or null when the source only supplied an email. */
    private String cdsid;

    /** Human-readable display name (e.g. "Kaminski, Nick") or null when unavailable. */
    private String name;

    /** Delivery address (e.g. "nkaminsk@ford.com" or "external@vendor.com") — always populated. */
    private String email;
}
