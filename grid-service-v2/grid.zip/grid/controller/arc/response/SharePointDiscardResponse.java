package com.ford.grid.controller.arc.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SharePointDiscardResponse {
    private boolean success;
    private String status;
    private String fileUrl;
    private String message;
    private List<SharePointOpenFileInfo> openFiles;
}
