package com.ford.grid.controller.arc.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * Represents a single edit entry from a file's version history.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SharePointEditorInfo {

    //CDSID
    private String cdsId;
    //Azure  user object ID
    private String principalId;
    private String displayName;
    private String email;
    private String permissionLevel;
    private Date date;
}
