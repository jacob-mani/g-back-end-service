package com.ford.grid.controller.arc.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Response for GET /arc-sharepoint/file-editors?fileName=...
 * Contains file details + all users who edited the file (from version history).
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SharePointFileEditorsResponse {

    private String fileName;
    private String fileUrl;
    private List<SharePointEditorInfo> editors;
    private int totalEdits;

}

