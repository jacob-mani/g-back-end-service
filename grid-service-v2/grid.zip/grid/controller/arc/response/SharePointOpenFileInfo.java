package com.ford.grid.controller.arc.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Details of a single file that is currently open/locked and is therefore blocking a Discard.
 * Surfaced to the UI so the analyst knows which file to have closed and who to contact.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SharePointOpenFileInfo {

    /** Name of the file that could not be deleted. */
    private String fileName;

    /** ISO-8601 timestamp of the file's last modification, when available. */
    private String lastModified;

    /** The user who last modified the file, when available. */
    private String activity;

    private String lastEditedAgo;
    private List<SharePointEditorInfo> editors;
}
