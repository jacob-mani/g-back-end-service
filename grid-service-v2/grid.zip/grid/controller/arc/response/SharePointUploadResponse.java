package com.ford.grid.controller.arc.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Response returned after successfully uploading a document to SharePoint.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SharePointUploadResponse {

    private String fileName;
    private String fileUrl;
    private String fileId;
    private String driveItemId;
    private long size;

}

