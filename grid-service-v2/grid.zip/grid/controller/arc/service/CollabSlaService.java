package com.ford.grid.controller.arc.service;

public interface CollabSlaService {

    String sendPendingApprovalReminders();
}

