package com.ford.grid.controller.arc.service;

import com.ford.grid.controller.arc.request.DraftNotificationPreviewRequest;
import com.ford.grid.controller.arc.request.DraftNotificationReviewersRequest;
import com.ford.grid.controller.arc.request.DraftNotificationSendRequest;
import com.ford.grid.controller.arc.response.DraftNotificationPreviewResponse;
import com.ford.grid.exception.GridException;

/**
 * Service for sending email notifications when draft documents are generated.
 */
public interface DraftNotificationService {

    /**
     * Sends draft notification template email to the explicitly provided reviewer CDSIDs.
     */
    void sendDraftNotificationToReviewers(DraftNotificationReviewersRequest request) throws GridException;

    DraftNotificationPreviewResponse previewDraftNotification(DraftNotificationPreviewRequest request) throws GridException;

    void sendEditedDraftNotification(DraftNotificationSendRequest request,
                                     org.springframework.web.multipart.MultipartFile[] uploadedFiles)
            throws GridException;
}

