package com.ford.grid.controller.arc.service;

import com.ford.grid.controller.arc.request.SharePointReminderRequest;
import com.ford.grid.controller.arc.response.SharePointDiscardResponse;
import com.ford.grid.controller.arc.response.SharePointFileEditorsResponse;
import com.ford.grid.controller.arc.response.SharePointUploadResponse;
import com.ford.grid.exception.GridException;
import com.ford.grid.model.dto.response.UploadGCSFileResponse;

import java.util.List;

public interface SharePointService {

    SharePointFileEditorsResponse getEditorsByFileName(String fileName,String fileSource) throws GridException;

    /**
     * Fetches all files from a GCP bucket folder and uploads them to a SharePoint folder
     */
    List<SharePointUploadResponse> uploadDraftFiles(String gcpFolderPath, String sharePointFolderPath) throws GridException;

    /**
     * Downloads the latest version of a file by name from SharePoint.
     * @param fileName the name of the file to download
     * @return byte array containing the file content
     * @throws GridException if the file is not found or download fails
     */
    byte[] downloadFileByFileName(String fileName) throws GridException;

    /**
     * Sends a review reminder email to the given reviewers with a list of pending documents.
     *
     * @param request contains reviewer emails and pending document names
     */
    void sendReviewReminder(SharePointReminderRequest request) throws GridException;
    /**
     * Downloads a SharePoint file by its web URL and returns the raw content as a byte array.
     *
     * @param fileUrl the SharePoint web URL of the file (e.g. https://ford.sharepoint.com/sites/.../file.docx)
     * @return the file content as byte[]
     * @throws GridException if the URL is invalid, the file is not found, or the download fails
     */
    byte[] downloadFileByUrl(String fileUrl) throws GridException;

    SharePointUploadResponse uploadFileFromBytes(byte[] gcsFile,
                                                 String fileName,
                                                 String sharePointFolderPath) throws GridException;

    /**
     * Creates the full SharePoint folder hierarchy for the given path.
     * Each segment in the path is created individually if it does not already exist.
     *
     * @param sharePointFolderPath the full folder path relative to the drive root
     *                             (e.g. "GRID/DraftDocuments/N242457300/IMPL001/POP001")
     * @throws GridException if the path is blank or the folder creation fails
     */
    void createSharePointFolder(String sharePointFolderPath) throws GridException;

    void deleteFileByUrl(String fullFileUrlPath) throws GridException;

    SharePointDiscardResponse deleteFileByUrlWithLockInfo(String fullFileUrlPath) throws GridException;

    /**
     * Grants SharePoint edit/write access to the given users for all files in the provided folder source.
     *
     * @param fileSource SharePoint folder URL or relative folder path
     * @param cdsIds     Ford CDSIDs to grant edit access to
     * @throws GridException if files cannot be resolved or permissions cannot be granted
     */
    void grantWriteAccess(String fileSource, List<String> cdsIds) throws GridException;
	
    /**
     * Lists all files inside the given SharePoint folder, downloads each one via Graph API,
     * and uploads them to GCS under the specified GCS folder path.
     *
     * @param sharepointFolderPath  SharePoint folder path to download files from
     * @param metadataSourceList    list of {@link UploadGCSFileResponse} providing metadata context
     *                              (issueNumber, implId, populationId, etc.) for building responses
     * @param uploadedGcsFolderPath GCS destination folder path (e.g. "grid-red/FSA-2024-001")
     * @param notificationType      resolved notification type to set on each response
     * @return list of {@link UploadGCSFileResponse} with GCS file path and version number populated
     * @throws GridException if SharePoint listing/download or GCS upload fails
     */
    List<UploadGCSFileResponse> downloadSharePointFolderAndUploadToGcs(
            String sharepointFolderPath,
            List<UploadGCSFileResponse> metadataSourceList,
            String uploadedGcsFolderPath,
            String notificationType) throws GridException;

    String buildSharePointUrl(String sharePointFolderPath);
    public void forceDeleteItem( String itemId, String name) throws GridException;

}
