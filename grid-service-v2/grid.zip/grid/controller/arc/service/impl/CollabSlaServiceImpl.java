package com.ford.grid.controller.arc.service.impl;

import com.ford.grid.constants.CollabSlaConstants;
import com.ford.grid.controller.arc.config.CollabSlaConfig;
import com.ford.grid.controller.arc.service.CollabSlaService;
import com.ford.grid.model.dto.MailRequest;
import com.ford.grid.model.entity.OdLetterApprover;
import com.ford.grid.model.entity.OdLetterCollab;
import com.ford.grid.model.entity.OdLetterNotification;
import com.ford.grid.repository.OdLetterNotificationRepository;
import com.ford.grid.service.impl.MailService;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.thymeleaf.context.Context;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Scans all OD Letter notifications, identifies pending approvers whose SLA has been breached and sending reminder emails.
 */
@Service
@RequiredArgsConstructor
public class CollabSlaServiceImpl implements CollabSlaService {

    private static final Logger LOGGER = LoggerFactory.getLogger(CollabSlaServiceImpl.class);

    private final OdLetterNotificationRepository odLetterNotificationRepository;
    private final MailService mailService;
    private final CollabSlaConfig slaConfig;

    @Override
    public String sendPendingApprovalReminders() {
        LOGGER.info(CollabSlaConstants.LOG_SCAN_START);

        List<OdLetterNotification> notifications = odLetterNotificationRepository.findWithPendingApprovers();
        int totalReminders = 0;
        int totalIssuesScanned = 0;

        for (OdLetterNotification notification : notifications) {
            totalIssuesScanned++;
            if (notification.getCollabs() == null || notification.getCollabs().isEmpty()) {
                continue;
            }

            // Group pending collabs by approver userId
            Map<String, List<PendingItem>> approverPendingItems = new LinkedHashMap<>();

            for (OdLetterCollab collab : notification.getCollabs()) {
                if (collab.getApprovers() == null || collab.getApprovers().isEmpty()) {
                    continue;
                }

                for (OdLetterApprover approver : collab.getApprovers()) {
                    if (!isPending(approver)) {
                        continue;
                    }

                    String recipientId = approver.getUserId().toLowerCase().trim();
                    approverPendingItems
                            .computeIfAbsent(recipientId, k -> new ArrayList<>())
                            .add(new PendingItem(collab, approver));
                }
            }

            // Send one email per approver with all their pending documents
            for (Map.Entry<String, List<PendingItem>> entry : approverPendingItems.entrySet()) {
                try {
                    sendReminderEmail(notification, entry.getKey(), entry.getValue());
                    totalReminders++;
                } catch (Exception e) {
                    LOGGER.error(CollabSlaConstants.LOG_SEND_FAILED,
                            notification.getIssueNumber(), entry.getKey(), e.getMessage(), e);
                }
            }
        }

        String summary = String.format(
                CollabSlaConstants.LOG_SUMMARY_FORMAT,
                totalIssuesScanned, totalReminders);
        LOGGER.info(summary);
        return summary;
    }

    private boolean isPending(OdLetterApprover approver) {
        if (approver.getUserId() == null || approver.getUserId().isBlank()) {
            return false;
        }
        String status = approver.getStatus();
        return status == null || status.isBlank()
                || CollabSlaConstants.STATUS_PENDING.equalsIgnoreCase(status.trim());
    }

    private void sendReminderEmail(OdLetterNotification notification,
                                   String recipientId,
                                   List<PendingItem> pendingItems) {

        // Use first item's approver for the name
        OdLetterApprover firstApprover = pendingItems.get(0).approver;
        String approverName = firstApprover.getName() != null ? firstApprover.getName() : recipientId;

        String collabLabels = pendingItems.stream()
                .map(p -> p.collab.getCollabLabel())
                .distinct()
                .collect(Collectors.joining(", "));

        String subject = slaConfig.getSubjectPrefix() + CollabSlaConstants.SUBJECT_SEPARATOR + notification.getIssueNumber()
                + CollabSlaConstants.SUBJECT_SEPARATOR + collabLabels;

        String issueLink = slaConfig.getUiBaseUrl() + notification.getIssueNumber();

        // Build the list of pending document details for the template
        List<Map<String, String>> pendingDocuments = new ArrayList<>();
        for (PendingItem item : pendingItems) {
            Map<String, String> doc = new LinkedHashMap<>();
            doc.put(CollabSlaConstants.KEY_COLLAB_ID, item.collab.getCollabId());
            doc.put(CollabSlaConstants.KEY_COLLAB_LABEL, item.collab.getCollabLabel());
            doc.put(CollabSlaConstants.KEY_FILE_NAME, item.collab.getFileName() != null ? item.collab.getFileName() : CollabSlaConstants.NOT_AVAILABLE);
            doc.put(CollabSlaConstants.KEY_FILE_SOURCE, item.collab.getFileSource() != null ? item.collab.getFileSource() : CollabSlaConstants.NOT_AVAILABLE);
            doc.put(CollabSlaConstants.KEY_APPROVER_ROLE, item.approver.getRole() != null ? item.approver.getRole() : CollabSlaConstants.NOT_AVAILABLE);
            doc.put(CollabSlaConstants.KEY_STATUS, item.approver.getStatus() != null ? item.approver.getStatus() : CollabSlaConstants.STATUS_PENDING_DISPLAY);
            pendingDocuments.add(doc);
        }

        Context context = new Context();
        context.setVariable(CollabSlaConstants.CTX_ISSUE_NUMBER, notification.getIssueNumber());
        context.setVariable(CollabSlaConstants.CTX_APPROVER_NAME, approverName);
        context.setVariable(CollabSlaConstants.CTX_SLA_HOURS, slaConfig.getSlaBreachHours());
        context.setVariable(CollabSlaConstants.CTX_CAMPAIGN_NAME, notification.getCampaignName());
        context.setVariable(CollabSlaConstants.CTX_UI_BASE_URL, slaConfig.getUiBaseUrl());
        context.setVariable(CollabSlaConstants.CTX_ISSUE_LINK, issueLink);
        context.setVariable(CollabSlaConstants.CTX_PENDING_DOCUMENTS, pendingDocuments);
        context.setVariable(CollabSlaConstants.CTX_PENDING_COUNT, pendingItems.size());

        MailRequest mailRequest = MailRequest.builder()
                .recipients(List.of(recipientId))
                .cc(Collections.emptyList())
                .subject(subject)
                .mailTemplateName(slaConfig.getReminderTemplateName())
                .notificationType(CollabSlaConstants.NOTIFICATION_TYPE)
                .context(context)
                .build();

        try {
            mailService.sendEmail(mailRequest, false);
        } catch (jakarta.mail.MessagingException e) {
            throw new RuntimeException(CollabSlaConstants.ERR_SEND_FAILED_PREFIX + recipientId, e);
        }
        LOGGER.info(CollabSlaConstants.LOG_REMINDER_SENT,
                recipientId, notification.getIssueNumber(), pendingItems.size());
    }

    /** Helper class to hold a collab + approver pair */
    private static class PendingItem {
        final OdLetterCollab collab;
        final OdLetterApprover approver;

        PendingItem(OdLetterCollab collab, OdLetterApprover approver) {
            this.collab = collab;
            this.approver = approver;
        }
    }
}
