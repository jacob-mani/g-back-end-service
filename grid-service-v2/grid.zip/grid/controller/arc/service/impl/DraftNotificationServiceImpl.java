package com.ford.grid.controller.arc.service.impl;

import com.ford.grid.constants.ContactConstants;
import com.ford.grid.constants.DraftNotificationConstants;
import com.ford.grid.constants.FsamContactTitleConstants;
import com.ford.grid.controller.arc.request.DraftNotificationPreviewRequest;
import com.ford.grid.controller.arc.request.DraftNotificationReviewersRequest;
import com.ford.grid.controller.arc.request.DraftNotificationSendRequest;
import com.ford.grid.controller.arc.response.DraftNotificationPreviewResponse;
import com.ford.grid.controller.arc.response.RecipientDetail;
import com.ford.grid.controller.arc.service.DraftNotificationService;
import com.ford.grid.controller.arc.utill.FixedContactGroup;
import com.ford.grid.controller.arc.utill.SharePointGcpUtil;
import com.ford.grid.exception.GridException;
import com.ford.grid.model.dto.MailRequest;
import com.ford.grid.model.dto.response.IssueKeyStakeholdersResponse;
import com.ford.grid.model.entity.*;
import com.ford.grid.repository.ContactGroupRepository;
import com.ford.grid.repository.DraftNotificationContactRepository;
import com.ford.grid.repository.IssueContactsRepository;
import com.ford.grid.repository.OdLetterNotificationRepository;
import com.ford.grid.service.IssueContactsService;
import com.ford.grid.service.impl.MailService;
import com.ford.grid.util.BusinessDayCalculator;
import lombok.RequiredArgsConstructor;
import org.apache.poi.xwpf.extractor.XWPFWordExtractor;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.safety.Safelist;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.InputStreamSource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.util.HtmlUtils;
import org.thymeleaf.context.Context;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.ford.grid.service.impl.OdLetterUrgencyNotificationServiceImpl.*;

/**
 * Sends email notifications when draft documents are generated.
 */
@Service
@RequiredArgsConstructor
public class DraftNotificationServiceImpl implements DraftNotificationService {

    private static final Logger LOGGER = LoggerFactory.getLogger(DraftNotificationServiceImpl.class);

    private static final String ENV_PROD = "prod";
    private static final String REVIEWER_SUBJECT_PREFIX_PROD = "Action Request: FSA Number - ";
    private static final String REVIEWER_SUBJECT_PREFIX_NON_PROD = "THIS IS TEST EMAIL - NO ACTION NEEDED - ";
    private static final String REVIEWER_SUBJECT_INFIX = " Concurrence and Or Comment - ";
    private static final String COLLAB_1_MASTER_BODY_PATH = "templates/mail/Template_Collab_1_Email_Notification_Master.html";
    private static final String COLLAB_2_MASTER_BODY_PATH = "templates/mail/Template_Collab_2_Email_Notification_Master.html";
    private static final Map<String, String> SOFTWARE_TYPE_TO_TO_CATEGORY = Map.of(DraftNotificationConstants.SOFTWARE_FDRS, DraftNotificationConstants.CAT_SOFTWARE_FDRS, DraftNotificationConstants.SOFTWARE_IDS, DraftNotificationConstants.CAT_SOFTWARE_IDS, DraftNotificationConstants.SOFTWARE_OTA, DraftNotificationConstants.CAT_SOFTWARE_OTA, DraftNotificationConstants.SOFTWARE_SETI, DraftNotificationConstants.CAT_SOFTWARE_SETI);
    private static final List<String> FALLBACK_ROOT_CAUSE_TITLES = List.of("director", "14dAuthor", "supervisor", "manager", "vld", "frcPresenter", "responsibleDirector");

    private static final Pattern GCS_CC_ENTRY_PATTERN = Pattern.compile("\"(?<name>[^\"]*)\"\\s*<(?<addr>[^>]+)>" + "|(?<plain>[\\w.+-]+@[\\w.-]+\\.[a-zA-Z]{2,})");

    private static final Pattern VALID_EMAIL_PATTERN = Pattern.compile("^[A-Za-z0-9!#$%&'*+/=?^_`{|}~.-]+@[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?(?:\\.[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?)*\\.[A-Za-z]{2,}$");
    /** Whitespace anywhere in an address, and stray wrapping quotes/separators/brackets at the ends. */
    private static final Pattern ADDRESS_WHITESPACE = Pattern.compile("\\s+");
    private static final Pattern ADDRESS_WRAP_CHARS = Pattern.compile("^[\"';,<>]+|[\"';,<>]+$");
    private final MailService mailService;
    private final IssueContactsRepository issueContactsRepository;
    private final OdLetterNotificationRepository odLetterNotificationRepository;
    private final DraftNotificationContactRepository draftContactRepository;
    private final SharePointGcpUtil sharePointGcpUtil;
    private final ContactGroupRepository contactGroupRepository;
    private final Map<String, String> colabMasterBodyCache = new ConcurrentHashMap<>();

    @Autowired
    private IssueContactsService issueContactsService;

    @Value("${draft.notification.cc.gcs.filepath:}")
    private String ccGcsFilePath;

    @Value("${draft.notification.attestation.folder.path:}")
    private String attestationFolderPath;

    @Value("${draft.notification.attestation.file.name:}")
    private String attestationFileName;

    //  email subject add for other env
    @Value("${document.template.generate.llm.api.env}")
    private String emailSub;

    // Base URL of the GRID issue page; the issueNumber is appended to build the deep link.
    @Value("${grid.ui.base-url:}")
    private String gridUiBaseUrl;

    private volatile List<String> rootCauseOwnerTitlesCache = Collections.emptyList();

    /**
     * Extracts unique, non-blank delivery email addresses from a list of {@link RecipientDetail}
     * chips posted by the UI. Null entries/emails are skipped and order is preserved.
     */
    private static List<String> extractEmails(List<RecipientDetail> recipients) {
        if (recipients == null) {
            return Collections.emptyList();
        }
        Set<String> seen = new HashSet<>();
        return recipients.stream()
                .filter(Objects::nonNull)
                .map(RecipientDetail::getEmail)
                .map(DraftNotificationServiceImpl::normalizeRecipientEmail)
                .filter(Objects::nonNull)
                .filter(email -> seen.add(email.toLowerCase()))
                .collect(Collectors.toList());
    }

    /**
     * Cleans and validates a single recipient address just before it is sent, so a malformed value
     * can never reach the mail server (which would abort the whole email with errors like
     * "domain contains illegal character"). Returns a deliverable address, or {@code null} when the
     * value is blank or cannot be repaired into a valid address (in which case it is dropped and the
     * rest of the recipients are still emailed). Handling:
     * <ul>
     *   <li>unwraps {@code "Display Name" <addr>} / {@code <addr>} wrappers and strips stray
     *       whitespace and surrounding quotes/semicolons/commas/brackets;</li>
     *   <li>treats a bare token with no {@code '@'} as a Ford cdsid and appends {@code @ford.com};</li>
     *   <li>repairs an erroneously appended Ford domain (possibly repeated) on an already
     *       {@code '@'}-qualified address, e.g. {@code mladen@renkim.com@ford.com} or the
     *       TLD-dropped {@code mladen@renkim@ford.com} both become {@code mladen@renkim.com};</li>
     *   <li>rejects anything that still fails strict {@link #VALID_EMAIL_PATTERN} validation.</li>
     * </ul>
     */
    private static String normalizeRecipientEmail(String raw) {
        if (raw == null) {
            return null;
        }
        String value = raw.trim();
        // Unwrap "Display Name" <addr> or bare <addr>: keep only the text inside the angle brackets.
        int lt = value.lastIndexOf('<');
        int gt = value.lastIndexOf('>');
        if (lt >= 0 && gt > lt) {
            value = value.substring(lt + 1, gt);
        }
        // A real address never contains whitespace or wrapping quotes/separators; strip them.
        value = ADDRESS_WHITESPACE.matcher(value).replaceAll("");
        value = ADDRESS_WRAP_CHARS.matcher(value).replaceAll("");
        if (value.isEmpty()) {
            return null;
        }

        if (!value.contains("@")) {
            // Bare cdsid -> Ford delivery address, matching the rest of the recipient-building logic.
            value = value + DraftNotificationConstants.FORD_EMAIL_SUFFIX;
        } else {
            // Peel off each erroneously appended '@ford.com' while more than one '@' remains and the
            // text before the suffix is itself an address (handles double- and triple-append cases).
            String repaired = value;
            while (repaired.indexOf('@') != repaired.lastIndexOf('@')
                    && repaired.toLowerCase().endsWith(DraftNotificationConstants.FORD_EMAIL_SUFFIX)) {
                String candidate = repaired.substring(0, repaired.length() - DraftNotificationConstants.FORD_EMAIL_SUFFIX.length());
                if (!candidate.contains("@")) {
                    break;
                }
                repaired = candidate;
            }
            if (!repaired.equals(value)) {
                // The original TLD may have been dropped when the Ford suffix was appended; restore it.
                if (!repaired.substring(repaired.lastIndexOf('@') + 1).contains(".")) {
                    repaired = repaired + ".com";
                }
                LOGGER.warn("Repaired malformed recipient address '{}' -> '{}'", value, repaired);
                value = repaired;
            }
        }

        if (!VALID_EMAIL_PATTERN.matcher(value).matches()) {
            LOGGER.warn("Dropping invalid recipient address '{}' (normalized to '{}') from the send list", raw, value);
            return null;
        }
        return value;
    }

    /**
     * Wraps a caught exception as the standard INTERNAL_SERVER_ERROR draft-notification failure.
     */
    private static GridException wrapAsDraftNotificationFailure(Exception cause) {
        return new GridException(HttpStatus.INTERNAL_SERVER_ERROR, DraftNotificationConstants.ERR_DRAFT_NOTIFICATION_FAILED, DraftNotificationConstants.MSG_DRAFT_NOTIFICATION_FAILED_PREFIX + cause.getClass().getSimpleName() + " - " + cause.getMessage());
    }

    /**
     * Stores one GCS-derived recipient (display name may be null) into the map using the same dedup
     * semantics as Ford emails collapse to cdsid, external emails key by lowercase full email. If a
     * later hit for the same key brings a non-null name and the existing entry had none, upgrade
     * the entry in place.
     */
    private static void addGcsEntryToMap(Map<String, RecipientDetail> ccMap, String rawName, String rawEmail) {
        if (rawEmail == null || rawEmail.isBlank()) return;
        String email = rawEmail.trim();
        String name = (rawName == null || rawName.isBlank()) ? null : rawName.trim();
        // The GCS file sometimes uses the address itself as the quoted "name"
        // (e.g. "fordteam@renkim.com" <fordteam@renkim.com>). Drop such labels.
        if (name != null && name.equalsIgnoreCase(email)) {
            name = null;
        }

        boolean isFord = email.toLowerCase().endsWith(DraftNotificationConstants.FORD_EMAIL_SUFFIX);
        String cdsid = isFord ? email.substring(0, email.indexOf('@')).toLowerCase() : null;
        String key = isFord ? cdsid : email.toLowerCase();

        RecipientDetail existing = ccMap.get(key);
        if (existing != null) {
            if (existing.getName() == null && name != null) {
                ccMap.put(key, RecipientDetail.builder().cdsid(existing.getCdsid()).name(name).email(existing.getEmail()).build());
            }
            return;
        }
        ccMap.put(key, RecipientDetail.builder().cdsid(cdsid).name(name).email(email).build());
    }

    /**
     * Puts a Ford contact (cdsid + optional display name) into the recipient map. De-dupes by cdsid
     * so behaviour matches the set-based flow. If an existing entry lacks a name, upgrades it in
     * place when a name becomes available.
     */
    private static void putFordRecipient(Map<String, RecipientDetail> target, String cdsid, String name) {
        if (cdsid == null || cdsid.isBlank()) return;
        String norm = cdsid.toLowerCase().trim();
        String trimmedName = (name == null || name.isBlank()) ? null : name.trim();

        // Derive the delivery address without ever double-appending the Ford domain:
        //  - bare cdsid ("uharris")            -> append @ford.com  ("uharris@ford.com")
        //  - ford email ("uharris@ford.com")   -> collapse to cdsid, keep dedup-by-cdsid
        //  - external email ("ursula@renkim.com") -> use AS-IS, never append @ford.com
        // Prevents invalid addresses like "ursula@renkim@ford.com" ("domain contains illegal character").
        String cdsidVal;
        String email;
        String key;
        if (norm.contains("@")) {
            if (norm.endsWith(DraftNotificationConstants.FORD_EMAIL_SUFFIX)) {
                cdsidVal = norm.substring(0, norm.indexOf('@'));
                if (cdsidVal.isBlank()) return;
                email = cdsidVal + DraftNotificationConstants.FORD_EMAIL_SUFFIX;
                key = cdsidVal;
            } else {
                cdsidVal = null;
                email = norm;
                key = norm;
            }
        } else {
            cdsidVal = norm;
            email = norm + DraftNotificationConstants.FORD_EMAIL_SUFFIX;
            key = norm;
        }

        RecipientDetail existing = target.get(key);
        if (existing != null) {
            if (existing.getName() == null && trimmedName != null) {
                target.put(key, RecipientDetail.builder().cdsid(cdsidVal).name(trimmedName).email(email).build());
            }
            return;
        }
        target.put(key, RecipientDetail.builder().cdsid(cdsidVal).name(trimmedName).email(email).build());
    }

    /**
     * Adds a single role-based stakeholder {@link Contacts} to the recipient map (null-safe).
     * Delegates to {@link #putFordRecipient} so email derivation and cdsid de-duplication are shared.
     */
    private static void addStakeholderRecipient(Map<String, RecipientDetail> target, Contacts contact) {
        if (contact != null) {
            putFordRecipient(target, contact.getCdsid(), contact.getName());
        }
    }

    /**
     * Adds every role-based stakeholder {@link Contacts} in the list to the recipient map (null-safe).
     */
    private static void addStakeholderRecipients(Map<String, RecipientDetail> target, List<Contacts> contacts) {
        if (contacts != null) {
            contacts.forEach(c -> addStakeholderRecipient(target, c));
        }
    }

    /**
     * Puts a raw contact string (email or bare cdsid, from config/GCS) into the map. Mirrors
     * addListContacts semantics: external emails preserved intact, Ford emails collapse to cdsid,
     * bare cdsids kept as-is. Name is always null.
     */
    private static void putRawContact(Map<String, RecipientDetail> target, String raw) {
        if (raw == null) return;
        String trimmed = raw.trim();
        if (trimmed.isBlank()) return;

        // External email: keep full address, no cdsid, no name; key by lowercase email.
        if (trimmed.contains("@") && !trimmed.toLowerCase().endsWith(DraftNotificationConstants.FORD_EMAIL_SUFFIX)) {
            String key = trimmed.toLowerCase();
            if (target.containsKey(key)) return;
            target.put(key, RecipientDetail.builder().cdsid(null).name(null).email(trimmed).build());
            return;
        }

        // Ford email or bare cdsid: reduce to lowercase cdsid, matching the set-based path.
        String cdsid = trimmed.contains("@") ? trimmed.substring(0, trimmed.indexOf('@')).toLowerCase() : trimmed.toLowerCase();
        if (target.containsKey(cdsid)) return;
        target.put(cdsid, RecipientDetail.builder().cdsid(cdsid).name(null).email(cdsid + DraftNotificationConstants.FORD_EMAIL_SUFFIX).build());
    }

    /**
     * Throws BAD_REQUEST GridException when the value is null or blank.
     */
    private static void requireNonBlank(String value, String errorCode, String errorMessage) throws GridException {
        if (!StringUtils.hasText(value)) {
            throw new GridException(HttpStatus.BAD_REQUEST, errorCode, errorMessage);
        }
    }

    @Override
    public void sendDraftNotificationToReviewers(DraftNotificationReviewersRequest request) throws GridException {

        List<String> recipients = request.getReviewerCdsids();
        if (recipients.isEmpty()) {
            throw new GridException(HttpStatus.BAD_REQUEST, "NoReviewers", "Reviewer CDSID list must not be empty");
        }

        String fsaNumber = request.getFsaNumber().trim();
        String fsaType = request.getFsaType().trim();
        String subject = buildEmailSubject(fsaNumber, fsaType);

        List<Map<String, String>> documentDetails = new ArrayList<>();
        if (request.getDocumentLinks() != null) {
            documentDetails = request.getDocumentLinks().stream().filter(Objects::nonNull).map(String::trim).filter(link -> !link.isBlank()).map(link -> {
                Map<String, String> doc = new LinkedHashMap<>();
                doc.put(DraftNotificationConstants.KEY_FILE_NAME, extractFileNameFromPath(link));
                doc.put(DraftNotificationConstants.KEY_FILE_LINK, link);
                return doc;
            }).toList();
        }

        LOGGER.info("<----Before Urgency---> {} ", request);
        Boolean urgent = (null == request.getUrgencyIndicator() ? false : request.getUrgencyIndicator());
        LOGGER.info("<----after Urgency---> {} ", urgent);
        int slaBusinessDays = urgent ? 1 : 2;
        String slaText = urgent ? URGENT_SLA_TEXT : STANDARD_SLA_TEXT;
        OffsetDateTime offsetDraftDate = request.getDraftCompletionDate();
        LocalDateTime draftCompletionLocalDateTime = offsetDraftDate != null ? offsetDraftDate.toLocalDateTime() : LocalDateTime.now();
        LocalDateTime dueDateTime = addBusinessDays(draftCompletionLocalDateTime, slaBusinessDays);

        Context context = new Context();
        context.setVariable(DraftNotificationConstants.CTX_FSA_NUMBER, fsaNumber);
        context.setVariable(DraftNotificationConstants.CTX_FSA_TYPE, fsaType);
        context.setVariable(DraftNotificationConstants.CTX_TITLE_DESCRIPTION, request.getTitleDescription() != null && !request.getTitleDescription().isBlank() ? request.getTitleDescription() : DraftNotificationConstants.DEFAULT_TITLE_DESCRIPTION);
        context.setVariable(DraftNotificationConstants.CTX_DOCUMENT_LINKS, documentDetails);
        context.setVariable(DraftNotificationConstants.CTX_REVIEW_DEADLINE, DEADLINE_FORMATTER.format(dueDateTime) + " (SLA: " + slaText + ")");
        context.setVariable(DraftNotificationConstants.CTX_RECIPIENT_NAME, DraftNotificationConstants.DEFAULT_RECIPIENT_NAME);

        try {
            MailRequest mailRequest = MailRequest.builder()
                    .recipients(recipients).subject(subject)
                    .mailTemplateName(DraftNotificationConstants.TEMPLATE_DRAFT_NOTIFICATION)
                    .notificationType(DraftNotificationConstants.NOTIFICATION_TYPE_NOT_APPLICABLE)
                    .context(context).build();

            //       mailService.sendEmail(mailRequest, false);
            LOGGER.info("Draft notification template email sent to {} reviewer(s) for fsaNumber={}", recipients.size(), fsaNumber);
        } catch (Exception e) {
            LOGGER.error("Draft notification to reviewers failed: {}", e.getMessage(), e);
            throw new GridException(HttpStatus.INTERNAL_SERVER_ERROR, DraftNotificationConstants.ERR_DRAFT_NOTIFICATION_FAILED, DraftNotificationConstants.MSG_DRAFT_NOTIFICATION_FAILED_PREFIX + e.getClass().getSimpleName() + " - " + e.getMessage());
        }
    }

    private String buildEmailSubject(String fsaNumber, String fsaType) {
        LOGGER.debug("buildEmailSubject - env={}, fsa={} {}", emailSub, fsaNumber, fsaType);
        String prefix = "prod".equalsIgnoreCase(emailSub) ? "Action Request : FSA - " : "THIS IS TEST EMAIL - NO ACTION NEEDED || FSA - ";
        return prefix + fsaNumber + " Concurrence and Or Comment - " + fsaType;
    }

    /**
     * Loads ALL active contacts from MongoDB in a single DB call and groups them into a nested map:
     * category → type → list of emails.
     */
    private Map<String, Map<String, List<String>>> loadAllContactsGrouped() {
        List<DraftNotificationContact> allContacts = draftContactRepository.findByActive(true);
        LOGGER.info("Loaded {} active draft notification contact(s) from MongoDB", allContacts.size());

        Map<String, Map<String, List<String>>> contactMap = new HashMap<>();
        for (DraftNotificationContact contact : allContacts) {
            if (contact.getEmail() == null || contact.getEmail().isBlank()) continue;
            contactMap.computeIfAbsent(contact.getCategory(), k -> new HashMap<>()).computeIfAbsent(contact.getType(), k -> new ArrayList<>()).add(contact.getEmail());
        }
        return contactMap;
    }

    private List<String> getContactEmails(Map<String, Map<String, List<String>>> contactMap, String category, String type) {
        return contactMap.getOrDefault(category, Collections.emptyMap()).getOrDefault(type, Collections.emptyList());
    }

    private Map<String, InputStreamSource> downloadAttestationFile() {
        try {
            String folderPath = this.attestationFolderPath;
            String fileName = this.attestationFileName;

            if (folderPath == null || folderPath.isBlank() || fileName == null || fileName.isBlank()) {
                LOGGER.warn("Attestation folder path or file name not configured in properties.");
                return null;
            }

            String gcpFilePath = folderPath.endsWith("/") ? folderPath + fileName : folderPath + "/" + fileName;
            LOGGER.info("Downloading attestation from GCS: '{}'", gcpFilePath);
            byte[] fileBytes = sharePointGcpUtil.downloadFileFromGcp(gcpFilePath);

            Map<String, InputStreamSource> attachments = new LinkedHashMap<>();
            attachments.put(fileName, new ByteArrayResource(fileBytes));
            return attachments;
        } catch (Exception e) {
            LOGGER.warn("Could not download attestation file from GCS: {}", e.getMessage());
            return null;
        }
    }

    private String extractFileNameFromPath(String path) {
        if (path == null || path.isBlank()) return path;
        if (path.contains(DraftNotificationConstants.FILE_QUERY_PARAM)) {
            try {
                String query = path.substring(path.indexOf('?') + 1);
                for (String param : query.split("&")) {
                    if (param.startsWith(DraftNotificationConstants.FILE_QUERY_PARAM)) {
                        return URLDecoder.decode(param.substring(DraftNotificationConstants.FILE_QUERY_PARAM.length()), StandardCharsets.UTF_8);
                    }
                }
            } catch (Exception e) {
                LOGGER.warn("Could not parse file name from URL: {}", path);
            }
        }
        String cleanPath = path.contains("?") ? path.substring(0, path.indexOf('?')) : path;
        int lastSlash = Math.max(cleanPath.lastIndexOf('/'), cleanPath.lastIndexOf('\\'));
        return lastSlash >= 0 ? cleanPath.substring(lastSlash + 1) : cleanPath;
    }

    private LocalDateTime addBusinessDays(LocalDateTime start, int businessDays) {
        return BusinessDayCalculator.plusBusinessDays(start, businessDays);
    }

    /**
     * Builds the full email (recipients, subject, HTML body, template data) for UI review. Does NOT
     * send.
     */
    @Override
    public DraftNotificationPreviewResponse previewDraftNotification(DraftNotificationPreviewRequest request) throws GridException {
        LOGGER.info("previewDraftNotification start - fsa={} {}, issue={}, screen={}", request.getFsaNumber(), request.getFsaType(), request.getIssueNumber(), request.getScreenName());

        validateRequestPreview(request);
        // applyDbDerivedProgramFlagsPreview(request); // enable if values needs to be fetch frm DB

        IssueContacts issueContacts = fetchIssueContactsPreview(request);
        // /preview does NOT read draft_notification_contacts; category-based CC groups will come
        // from config later.
        Map<String, Map<String, List<String>>> contactMap = Collections.emptyMap(); // loadAllContactsGrouped();

        List<OdLetterApprover> collabReviewers = odLetterNotificationRepository.findByIssueNumberAndImplIdAndPopulationIdAndRegionAndBrandAndActive(
                        request.getIssueNumber(),
                        request.getImplId(),
                        request.getPopulationId(),
                        request.getRegion(),
                        request.getBrand(),
                        true
                ).map(OdLetterNotification::getCollabs).stream().flatMap(List::stream)
                .filter(Objects::nonNull).filter(collab -> !StringUtils.hasText(request.getScreenName())
                        || request.getScreenName().equalsIgnoreCase(collab.getCollabLabel()))
                .map(OdLetterCollab::getApprovers).filter(Objects::nonNull)
                .flatMap(List::stream).filter(Objects::nonNull)
                .toList();
        Set<String> allowedReviewerTitles = collabReviewers.stream()
                .map(OdLetterApprover::getTitle)
                .filter(StringUtils::hasText)
                .map(String::trim)
                .map(String::toLowerCase)
                .collect(Collectors.toSet());

        List<RecipientDetail> toList;
        List<RecipientDetail> ccList = List.of();
        if ("collab1".equalsIgnoreCase(request.getScreenName())) {
            IssueKeyStakeholdersResponse keyStakeholders = issueContactsService.getKeyStakeholdersByIssueNumber(
                    request.getIssueNumber(),
                    request.getRegion(),
                    request.getFsaNumber(),
                    "collab1");

            Map<String, RecipientDetail> toMap = new LinkedHashMap<>();
            // addStakeholderRecipients(toMap, keyStakeholders.getAllCustomContacts());
            if (keyStakeholders.getStakeholders() != null) {
                IssueKeyStakeholdersResponse.Stakeholders stakeholders = keyStakeholders.getStakeholders();
                addStakeholderRecipients(toMap, Stream.of(
                                stakeholders.getKeyContacts(),
                                stakeholders.getFcsdContacts())
                        .filter(Objects::nonNull)
                        .flatMap(List::stream)
                        .filter(Objects::nonNull)
                        .filter(c -> allowedReviewerTitles.isEmpty() || (StringUtils.hasText(c.getTitle())
                                && allowedReviewerTitles.contains(c.getTitle().trim().toLowerCase())))
                        .toList());

            }
            // Keep stakeholder contacts as primary source, then backfill any missing OD approvers.
            collabReviewers.forEach(approver -> putFordRecipient(toMap, approver.getUserId(), approver.getName()));
            toList = new ArrayList<>(toMap.values());

            ccList = buildCcListPreview(issueContacts, request, contactMap);

            Map<String, RecipientDetail> ccMapcollab1 = new LinkedHashMap<>();
            if (keyStakeholders != null && keyStakeholders.getStakeholders() != null) {
                IssueKeyStakeholdersResponse.Stakeholders stakeholders = keyStakeholders.getStakeholders();
                List<Contacts> rspAnalysts = Stream.of(
                                stakeholders.getKeyContacts(),
                                stakeholders.getFcsdContacts(),
                                stakeholders.getStaticContacts())
                        .filter(Objects::nonNull)
                        .flatMap(List::stream)
                        .filter(c -> c != null && "rspAnalyst".equalsIgnoreCase(c.getTitle()))
                        .collect(Collectors.toList());
                addStakeholderRecipients(ccMapcollab1, rspAnalysts);
            }
            ccList.addAll(new ArrayList<>(ccMapcollab1.values()));

        } else {
            // Collab 2: TO = Impl Lead + ASO Lead Investigator + OGC (CSF/CCRG attorney);
            // CC = CCRG Chair.
            Map<String, RecipientDetail> toMap = new LinkedHashMap<>();
            IssueKeyStakeholdersResponse keyStakeholders = issueContactsService.getKeyStakeholdersByIssueNumber(
                    request.getIssueNumber(),
                    request.getRegion(),
                    request.getFsaNumber(),
                    "collab2");
            if (keyStakeholders.getStakeholders() != null) {
                addStakeholderRecipients(toMap, keyStakeholders.getStakeholders().getKeyContacts());
                addStakeholderRecipients(toMap, keyStakeholders.getStakeholders().getFcsdContacts());
                addStakeholderRecipients(toMap, keyStakeholders.getStakeholders().getStaticContacts());
            }
            toList = new ArrayList<>(toMap.values());

            Map<String, RecipientDetail> ccMap = new LinkedHashMap<>();
            if (null != keyStakeholders && keyStakeholders.getStakeholders() != null) {
                IssueKeyStakeholdersResponse.Stakeholders stakeholders = keyStakeholders.getStakeholders();
                List<Contacts> chairContacts = Stream.of(
                                stakeholders.getKeyContacts(),
                                stakeholders.getFcsdContacts(),
                                stakeholders.getStaticContacts())
                        .filter(Objects::nonNull)
                        .flatMap(List::stream)
                        .filter(c -> c != null
                                &&("rspAnalyst".equalsIgnoreCase(c.getTitle())
                               || FsamContactTitleConstants.CCRG_CHAIR.equalsIgnoreCase(c.getTitle())
                             //   || FsamContactTitleConstants.CSF_CHAIR.equalsIgnoreCase(c.getTitle())
                              //  || FsamContactTitleConstants.EPRC_CHAIR.equalsIgnoreCase(c.getTitle())
                        ))
                        .collect(Collectors.toList());
                addStakeholderRecipients(ccMap, chairContacts);
            }
            //addContactsByTitleWithName(ccMap, issueContacts, ContactConstants.CCRG_CHAIR_ID);
            ccList = new ArrayList<>(ccMap.values());
        }

        // Fixed program-flag-gated Review-GRID distribution lists (Collab 1 only), grouped by
        // FixedContactGroup key.
        Map<String, List<String>> fixedTo = new LinkedHashMap<>();
        Map<String, List<String>> fixedCc = new LinkedHashMap<>();
        if ("collab1".equalsIgnoreCase(request.getScreenName())) {
            resolveFixedContacts(fixedTo, fixedCc, request);
        }

        String subject = buildEmailSubject(request.getFsaNumber(), request.getFsaType());
        SlaComputation previewSla = computeSla(request.isUrgency(), request.getDraftCompletionTime());
        List<Map<String, String>> documentDetails = buildDocumentDetails(request.getDocumentLinks());

        // /preview serves the static master HTML with placeholders; no server-side template
        // variables are populated.
        Context context = new Context();


        // Static master template returned to the UI editor (user fills {…} placeholders).
        String documentFolderPath =
                StringUtils.hasText(request.getDocumentFolderPath())
                        ? request.getDocumentFolderPath().trim()
                        : deriveDocumentFolderPath(request.getDocumentLinks());
        String htmlBody = injectFolderPathIntoMaster(loadColabMasterBody(request.getScreenName()), documentFolderPath);
        htmlBody = injectGridLink(htmlBody, request.getIssueNumber());
        Map<String, String> rspAnalyst = request.getRspAnalyst();
        String rspAnalystName = rspAnalyst != null ? rspAnalyst.get("name") : null;
        String rspAnalystCdsid = rspAnalyst != null ? rspAnalyst.get("cdsid") : null;
        htmlBody = injectRspAnalyst(htmlBody, rspAnalystName, rspAnalystCdsid);
        htmlBody = injectSla(htmlBody, previewSla);
        Map<String, InputStreamSource> attachments = resolveAttachmentsPreview(request);
        List<String> attachmentNames = attachments != null ? new ArrayList<>(attachments.keySet()) : Collections.emptyList();
        Map<String, Object> templateData = extractTemplateData(context);

        LOGGER.info("previewDraftNotification end - to={}, cc={}, fixedToGroups={}, fixedCcGroups={}," + " attachments={}", toList.size(), ccList.size(), fixedTo.size(), fixedCc.size(), attachmentNames.size());

        return DraftNotificationPreviewResponse.builder().
                issueNumber(request.getIssueNumber()).
                fsaNumber(request.getFsaNumber()).
                fsaType(request.getFsaType()).
                toList(toList).ccList(ccList).
                fixedTo(fixedTo).fixedCc(fixedCc).
                subject(subject).htmlBody(htmlBody).
                attachmentNames(attachmentNames).
                documentFolderPath(documentFolderPath)
                .documentDetails(documentDetails)
                .templateData(templateData)
                .fdAuthor(buildContactDisplayLabel(issueContacts, ContactConstants.FDAUTHOR_TITLE))
                .pdContact(buildContactDisplayLabel(issueContacts, ContactConstants.ROOT_CAUSE_OWNER))
                .pslAnalyst(buildContactDisplayLabel(issueContacts, ContactConstants.RSP_ANALYST))
                .gcampCoordinator(buildContactDisplayLabel(issueContacts, ContactConstants.GCAMP_COORDINATOR))
                .urgent(previewSla.urgent()).dueDate(previewSla.formattedDeadline())
                .slaText(previewSla.slaText()).build();
    }

    // ── /preview enrichment: RecipientDetail accumulators (name + cdsid + email) ────
    // These map-based helpers are used by the /preview build path.

    /**
     * Sends the draft notification using UI-edited recipients, subject and HTML body (template not
     * re-rendered).
     */
    @Override
    public void sendEditedDraftNotification(DraftNotificationSendRequest request, MultipartFile[] uploadedFiles) throws GridException {
        LOGGER.info("sendEditedDraftNotification start - fsa={} {}, issue={}, to={}, cc={}, files={}", request.getFsaNumber(), request.getFsaType(), request.getIssueNumber(), request.getToList() != null ? request.getToList().size() : 0, request.getCcList() != null ? request.getCcList().size() : 0, uploadedFiles != null ? uploadedFiles.length : 0);

        if (!StringUtils.hasText(request.getSubject())) {
            throw new GridException(HttpStatus.BAD_REQUEST, "NoSubject", "Email subject must not be empty");
        }
        if (!StringUtils.hasText(request.getHtmlBody())) {
            throw new GridException(HttpStatus.BAD_REQUEST, "NoBody", "Email body must not be empty");
        }
        List<RecipientDetail> toRecipients = request.getToList();
        if (toRecipients == null || toRecipients.isEmpty()) {
            throw new GridException(HttpStatus.BAD_REQUEST, "NoRecipients", "Recipient (TO) list must not be empty");
        }
        List<String> toList = extractEmails(toRecipients);
        if (toList.isEmpty()) {
            throw new GridException(HttpStatus.BAD_REQUEST, "NoRecipients", "Recipient (TO) list must not be empty");
        }

        Map<String, InputStreamSource> attachments = buildEditedAttachments(request, uploadedFiles);
        boolean hasAttachments = attachments != null && !attachments.isEmpty();
        String htmlBody = injectFolderPathIntoMaster(request.getHtmlBody(), request.getDocumentFolderPath());
        htmlBody = injectGridLink(htmlBody, request.getIssueNumber());
        // The body is user-editable and posted back from the UI, so sanitise it before it is
        // emailed: strip scripts / event handlers / dangerous URLs while preserving all normal
        // email formatting (tables, inline styles, colours, links, images).
        htmlBody = sanitizeEmailHtml(htmlBody);

        try {
            List<String> ccList = request.getCcList() != null ? extractEmails(request.getCcList()) : Collections.emptyList();
            MailRequest mailRequest = MailRequest.builder().recipients(toList).cc(ccList).subject(request.getSubject()).htmlBody(htmlBody).notificationType(DraftNotificationConstants.NOTIFICATION_TYPE_NOT_APPLICABLE).attachments(attachments).build();

            mailService.sendEmail(mailRequest, hasAttachments);
            LOGGER.info("sendEditedDraftNotification - edited draft notification sent for fsa={} {} to" + " {} recipient(s), {} cc", request.getFsaNumber(), request.getFsaType(), toList.size(), ccList.size());
        } catch (Exception e) {
            LOGGER.error("sendEditedDraftNotification - failed for fsa={} {}. Cause: {}: {}", request.getFsaNumber(), request.getFsaType(), e.getClass().getSimpleName(), e.getMessage(), e);
            throw wrapAsDraftNotificationFailure(e);
        }
    }

    /**
     * Sanitises user-supplied email HTML before it is sent, removing active/dangerous content
     * (e.g. {@code <script>}, event-handler attributes such as {@code onclick}, {@code <iframe>},
     * {@code <object>}, {@code <form>}, and {@code javascript:} URLs) while preserving the markup
     * a formatted email legitimately needs — tables, inline {@code style}/colour/size attributes,
     * images and links. This keeps the rendered email visually identical for legitimate content
     * and neutralises injected scripts (defence against stored/HTML injection & XSS).
     *
     * <p>Returns the input unchanged when it is null/blank; on any unexpected sanitiser error the
     * original body is returned so a valid notification is never silently dropped.</p>
     */
    private String sanitizeEmailHtml(String html) {
        if (html == null || html.isBlank()) {
            return html;
        }
        try {
            // Start from the "relaxed" allow-list (block-level + inline formatting, tables, images,
            // links restricted to safe protocols) and additionally permit the presentation
            // attributes commonly used in HTML emails so appearance is preserved.
            Safelist safelist = Safelist.relaxed()
                    .addTags("font", "hr", "center", "tbody", "thead", "tfoot")
                    .addAttributes(":all", "style", "class", "id", "align", "valign", "dir",
                            "width", "height", "bgcolor", "color", "face", "size",
                            "cellpadding", "cellspacing", "border")
                    .addProtocols("img", "src", "http", "https", "cid", "data")
                    .preserveRelativeLinks(true);

            // Keep the body fragment output (no <html>/<head> wrapper) and disable pretty-printing
            // so whitespace-sensitive email layout is not reflowed.
            Document.OutputSettings outputSettings = new Document.OutputSettings().prettyPrint(false);

            return Jsoup.clean(html, "", safelist, outputSettings);
        } catch (RuntimeException e) {
            LOGGER.warn("sanitizeEmailHtml - could not sanitise email body, sending original. Cause: {}",
                    e.getMessage());
            return html;
        }
    }

    /**
     * /preview: loads issue_contacts for (issueNumber, region); throws NOT_FOUND if the document is
     * missing.
     */
    private IssueContacts fetchIssueContactsPreview(DraftNotificationPreviewRequest request) throws GridException {
        IssueContacts issueContacts = issueContactsRepository.findByIssueNumberRegionAndSegment
                (request.getIssueNumber(), request.getRegion());
        if (issueContacts == null) {
            LOGGER.warn("fetchIssueContactsPreview - no issue_contacts document found for" + " issueNumber='{}' region='{}'", request.getIssueNumber(), request.getRegion());
            throw new GridException(HttpStatus.NOT_FOUND, DraftNotificationConstants.ERR_ISSUE_NOT_FOUND, DraftNotificationConstants.MSG_ISSUE_NOT_FOUND_PREFIX + request.getIssueNumber() + "'");
        }
        return issueContacts;
    }


    /**
     * /preview: CC list — CCE/PM contacts + conditional category groups
     * (Bosch/service-tools/ESST/BEV/static) + GCS-file emails.
     */
    private List<RecipientDetail> buildCcListPreview(IssueContacts issueContacts, DraftNotificationPreviewRequest request, Map<String, Map<String, List<String>>> contactMap) {
        Map<String, RecipientDetail> ccMap = new LinkedHashMap<>();

        // Disablling below lines because of user will manully enter the cc list as of now - enable if needs from grid db
        if (request.isBosch()) {
            addEmailsByCategoryAndTypeWithName(ccMap, contactMap, DraftNotificationConstants.CAT_BOSCH, DraftNotificationConstants.CONTACT_TYPE_CC);
        }
        // orotunda — included for any tool (general service tools and/or ESST)
        if (request.isServiceTools() || request.isEsst()) {
            addEmailsByCategoryAndTypeWithName(ccMap, contactMap, DraftNotificationConstants.CAT_SERVICE_TOOLS, DraftNotificationConstants.CONTACT_TYPE_CC);
        }
        // jatwood9 — included only when an ESST is involved
        if (request.isEsst()) {
            addEmailsByCategoryAndTypeWithName(ccMap, contactMap, DraftNotificationConstants.CAT_ESST, DraftNotificationConstants.CONTACT_TYPE_CC);
        }
        if (request.isBev()) {
            addEmailsByCategoryAndTypeWithName(ccMap, contactMap, DraftNotificationConstants.CAT_BEV, DraftNotificationConstants.CONTACT_TYPE_CC);
        }

        addEmailsByCategoryAndTypeWithName(ccMap, contactMap, DraftNotificationConstants.CAT_STATIC, DraftNotificationConstants.CONTACT_TYPE_CC);

        addExtraCcFromGcsFileWithName(ccMap);
        // Note: additionalCc is a send-only field and is not part of the preview request contract.

        return new ArrayList<>(ccMap.values());
    }

    /**
     * Same rule as addContactsByTitle, but stores cdsid + name + email in a RecipientDetail map.
     */
    private void addContactsByTitleWithName(Map<String, RecipientDetail> target, IssueContacts issueContacts, String title) {
        if (issueContacts.getContacts() == null) return;
        for (Contacts contact : issueContacts.getContacts()) {
            if (title.equalsIgnoreCase(contact.getTitle())) {
                putFordRecipient(target, contact.getCdsid(), contact.getName());
            }
        }
    }


    /**
     * Same rule as addContactsByGroupId, but stores cdsid + name + email in a RecipientDetail map.
     */
    private void addContactsByGroupIdWithName(Map<String, RecipientDetail> target, IssueContacts issueContacts, String groupId) {
        if (issueContacts.getCustomContacts() == null) return;
        for (CustomContacts contact : issueContacts.getCustomContacts()) {
            if (groupId.equalsIgnoreCase(contact.getGroupId())) {
                putFordRecipient(target, contact.getCdsid(), contact.getName());
            }
        }
    }


    /**
     * Mirror of addListContacts — raw email/cdsid strings from draft_notification_contacts config.
     * Name is null.
     */
    private void addListContactsWithName(Map<String, RecipientDetail> target, List<String> contacts) {
        if (contacts == null) return;
        for (String contact : contacts) {
            putRawContact(target, contact);
        }
    }

    /**
     * Mirror of addEmailsByCategoryAndType.
     */
    private void addEmailsByCategoryAndTypeWithName(Map<String, RecipientDetail> target, Map<String, Map<String, List<String>>> contactMap, String category, String type) {
        addListContactsWithName(target, getContactEmails(contactMap, category, type));
    }

    /**
     * /preview: parses the GCS CC-list .docx and captures the display name from {@code "Name"
     * <email>} entries plus any bare emails, in a single regex scan over the concatenated document
     * text. Names default to {@code null} when only an email is available.
     */
    private void addExtraCcFromGcsFileWithName(Map<String, RecipientDetail> ccMap) {
        String ccFilePath = ccGcsFilePath;
        if (ccFilePath == null || ccFilePath.isBlank()) {
            LOGGER.warn("CC GCS file path (draft.notification.cc.gcs.filepath) not configured for the" + " active Spring profile; skipping named CC extraction. No emails/names" + " will be added from the GCS file.");
            return;
        }

        try {
            LOGGER.info("Reading extra CC list from GCS (with names): '{}'", ccFilePath);
            byte[] fileBytes = sharePointGcpUtil.downloadFileFromGcp(ccFilePath);

            try (XWPFDocument document = new XWPFDocument(new ByteArrayInputStream(fileBytes)); XWPFWordExtractor extractor = new XWPFWordExtractor(document)) {
                // Use the full-document extractor so text inside tables (a common layout
                // for CC lists) is included; getParagraphs() alone omits table cells.
                String allText = extractor.getText();
                LOGGER.info("Extracted {} characters of text from GCS CC file '{}'", allText == null ? 0 : allText.length(), ccFilePath);

                int addedBefore = ccMap.size();
                Matcher match = GCS_CC_ENTRY_PATTERN.matcher(allText == null ? "" : allText);
                while (match.find()) {
                    String named = match.group("name");
                    String email = (named != null) ? match.group("addr") : match.group("plain");
                    LOGGER.info("Parsed GCS CC entry -> name='{}', email='{}'", named, email);
                    addGcsEntryToMap(ccMap, named, email);
                }
                LOGGER.info("GCS CC extraction added {} new recipient(s) from '{}'", ccMap.size() - addedBefore, ccFilePath);
            }
        } catch (Exception e) {
            LOGGER.warn("Could not read CC list from GCS (with names): {}", e.getMessage(), e);
        }
    }

    /**
     * Populates the Collab 1 fixed Review-GRID distribution lists based on the request's program
     * flags and other criteria.
     */
    private void resolveFixedContacts(Map<String, List<String>> fixedTo, Map<String, List<String>> fixedCc, DraftNotificationPreviewRequest request) {
        for (FixedContactGroup group : FixedContactGroup.values()) {
            if (!group.applies(request) || group.getEmails().isEmpty()) {
                continue;
            }
            Map<String, List<String>> bucket = group.getTarget() == FixedContactGroup.Target.TO ? fixedTo : fixedCc;
            bucket.computeIfAbsent(group.getKey(), k -> new ArrayList<>()).addAll(group.getEmails());
        }
    }

    /**
     * Builds the fileName, fileLink list for the template from the raw document links.
     */
    private List<Map<String, String>> buildDocumentDetails(List<String> documentLinks) {
        if (documentLinks == null || documentLinks.isEmpty()) return Collections.emptyList();
        return documentLinks.stream().filter(Objects::nonNull).map(String::trim).filter(link -> !link.isBlank()).map(link -> {
            Map<String, String> doc = new LinkedHashMap<>();
            doc.put(DraftNotificationConstants.KEY_FILE_NAME, extractFileNameFromPath(link));
            doc.put(DraftNotificationConstants.KEY_FILE_LINK, link);
            return doc;
        }).toList();
    }

    /**
     * Computes the urgency-aware review SLA window used by /preview and
     * sendEditedDraftNotification. Urgent = 1 business day ,standard = 2 business days
     */
    private SlaComputation computeSla(Boolean urgency, LocalDateTime draftCompletion) {

        boolean urgent = Boolean.TRUE.equals(urgency);
        int slaBusinessDays = urgent ? 1 : 2;
        String slaText = urgent ? URGENT_SLA_TEXT : STANDARD_SLA_TEXT;
        LocalDateTime base = draftCompletion != null ? draftCompletion : LocalDateTime.now();
        LocalDateTime due = BusinessDayCalculator.plusBusinessDays(base, slaBusinessDays);
        String formatted = DEADLINE_FORMATTER.format(due) + " (SLA: " + slaText + ")";
        return new SlaComputation(urgent, due, slaText, formatted);
    }

    /**
     * Derives a single containing-folder path from the document links so the email shows one
     * folder, not many files.
     */
    private String deriveDocumentFolderPath(List<String> documentLinks) {
        if (documentLinks == null || documentLinks.isEmpty()) return null;
        return documentLinks.stream().filter(Objects::nonNull).map(String::trim).filter(link -> !link.isBlank()).map(this::stripFileSegment).filter(StringUtils::hasText).findFirst().orElse(null);
    }

    /**
     * Drops any query string and the trailing file segment from a path, returning the parent
     * folder.
     */
    private String stripFileSegment(String link) {
        String clean = link.contains("?") ? link.substring(0, link.indexOf('?')) : link;
        while (clean.endsWith("/")) {
            clean = clean.substring(0, clean.length() - 1);
        }
        int lastSlash = Math.max(clean.lastIndexOf('/'), clean.lastIndexOf('\\'));
        if (lastSlash <= 0) {
            return clean;
        }
        String lastSegment = clean.substring(lastSlash + 1);
        return lastSegment.contains(".") ? clean.substring(0, lastSlash) : clean;
    }

    private String injectFolderPathIntoMaster(String htmlBody, String folderPath) {
        if (htmlBody == null || !htmlBody.contains("{{documentFolderPath}}")) {
            return htmlBody;
        }
        String safeUrl = StringUtils.hasText(folderPath) ? HtmlUtils.htmlEscape(folderPath.trim()) : "";
        return htmlBody.replace("{{documentFolderPath}}", safeUrl);
    }

    // Matches a GRID issue anchor (inner text starts with "GRID#") and captures its href value for rewriting.
    private static final Pattern GRID_ANCHOR_HREF_PATTERN =
            Pattern.compile("(<a\\b[^>]*?\\bhref=\")[^\"]*(\"[^>]*>\\s*GRID#)", Pattern.CASE_INSENSITIVE);

    // Sets the GRID issue link to the absolute deep link: substitutes the {{gridIssueUrl}}/{{issueNumber}}
    // tokens in the master template, or repairs an already-rendered anchor whose href was relativized/blanked by the UI editor.
    private String injectGridLink(String htmlBody, String issueNumber) {
        if (htmlBody == null) {
            return null;
        }

        String issue = StringUtils.hasText(issueNumber) ? issueNumber.trim() : "";
        String base = StringUtils.hasText(gridUiBaseUrl) ? gridUiBaseUrl.trim() : "";
        String issueUrl = "";
        if (!base.isEmpty() && !issue.isEmpty()) {
            issueUrl = (base.endsWith("/") ? base : base + "/") + issue + "/checklist/";
        } else if (base.isEmpty()) {
            LOGGER.warn("injectGridLink - 'grid.ui.base-url' is blank; GRID link href will be empty for issue={}", issue);
        }
        String escapedUrl = HtmlUtils.htmlEscape(issueUrl);

        if (htmlBody.contains("{{gridIssueUrl}}") || htmlBody.contains("{{issueNumber}}")) {
            return htmlBody
                    .replace("{{gridIssueUrl}}", escapedUrl)
                    .replace("{{issueNumber}}", HtmlUtils.htmlEscape(issue));
        }

        if (!issueUrl.isEmpty()) {
            Matcher matcher = GRID_ANCHOR_HREF_PATTERN.matcher(htmlBody);
            StringBuffer repaired = new StringBuffer();
            boolean found = false;
            while (matcher.find()) {
                found = true;
                matcher.appendReplacement(repaired,
                        Matcher.quoteReplacement(matcher.group(1) + escapedUrl + matcher.group(2)));
            }
            matcher.appendTail(repaired);
            if (found) {
                LOGGER.info("injectGridLink - repaired GRID anchor href to absolute deep link for issue={}", issue);
                return repaired.toString();
            }
        }
        return htmlBody;
    }

    /**
     * Substitutes the {@code {{rspAnalystName}}} and {@code {{rspAnalystCdsid}}} tokens with the
     * given RSP Analyst name and CDSID, so the "For questions, contact the RSP Analyst" block is
     * populated. The preview flow sources these from the request's {@code rspAnalyst} map (keys
     * {@code name} / {@code cdsid}); the send
     * flow sources them from {@link DraftNotificationSendRequest} ({@code rspName} / {@code rspcdsId}).
     * Returns the body unchanged when neither token is present (e.g. collab 2). Values are
     * HTML-escaped since substitution is a raw string replace.
     */
    private String injectRspAnalyst(String htmlBody, String rspAnalystName, String rspAnalystCdsid) {
        if (htmlBody == null
                || (!htmlBody.contains("{{rspAnalystName}}") && !htmlBody.contains("{{rspAnalystCdsid}}"))) {
            return htmlBody;
        }
        String name = StringUtils.hasText(rspAnalystName) ? rspAnalystName.trim() : "";
        String cdsid = StringUtils.hasText(rspAnalystCdsid) ? rspAnalystCdsid.trim() : "";
        return htmlBody
                .replace("{{rspAnalystName}}", HtmlUtils.htmlEscape(name))
                .replace("{{rspAnalystCdsid}}", HtmlUtils.htmlEscape(cdsid));
    }

    /**
     * Substitutes the {@code {{slaDeadline}}} token with the computed review deadline (formatted
     * date/time plus the "(SLA: N Business Day(s))" suffix), so the "provide your approval …
     * by …" line reflects the urgency-driven due date. Returns the body unchanged when the token
     * is absent. The value is HTML-escaped since substitution is a raw string replace.
     */
    private String injectSla(String htmlBody, SlaComputation sla) {
        if (htmlBody == null || !htmlBody.contains("{{slaDeadline}}")) {
            return htmlBody;
        }
        String deadline = sla != null && StringUtils.hasText(sla.formattedDeadline())
                ? sla.formattedDeadline().trim()
                : "";
        return htmlBody.replace("{{slaDeadline}}", HtmlUtils.htmlEscape(deadline));
    }

    /**
     * Loads the static Co-Lab master body ({…} placeholders) served to the UI editor by /preview;
     * served from in-memory cache.
     */
    private String loadColabMasterBody(String screenName) {
        String path = "collab1".equalsIgnoreCase(screenName) ? COLLAB_1_MASTER_BODY_PATH : COLLAB_2_MASTER_BODY_PATH;
        String cached = colabMasterBodyCache.get(path);
        if (cached != null) {
            return cached;
        }
        try (InputStream is = new ClassPathResource(path).getInputStream()) {
            String body = new String(is.readAllBytes(), StandardCharsets.UTF_8);
            colabMasterBodyCache.put(path, body);
            return body;
        } catch (IOException e) {
            LOGGER.warn("loadColabMasterBody - could not read '{}': {}: {}", path, e.getClass().getSimpleName(), e.getMessage(), e);
            return "";
        }
    }

    /**
     * /preview: returns the attestation attachment; skipped for Advance Notice FSAs.
     */
    private Map<String, InputStreamSource> resolveAttachmentsPreview(DraftNotificationPreviewRequest request) {
        if (!request.isAdvanceNotice() && StringUtils.hasText(attestationFileName)) {
            return downloadAttestationFile();
        }
        return null;
    }

    /**
     * Copies every Thymeleaf context variable into an ordered map for the preview response.
     */
    private Map<String, Object> extractTemplateData(Context context) {
        Map<String, Object> data = new LinkedHashMap<>();
        for (String name : context.getVariableNames()) {
            data.put(name, context.getVariable(name));
        }
        return data;
    }

    /**
     * Builds "Name (cdsid@ford.com)" labels for all contacts sharing a title, joined with "; @".
     */
    private String buildContactDisplayLabel(IssueContacts issueContacts, String title) {
        List<String> labels = getContactsByTitle(issueContacts, title).stream().filter(c -> StringUtils.hasText(c.getCdsid()) || StringUtils.hasText(c.getName())).map(c -> {
            String name = c.getName();
            String cdsid = StringUtils.hasText(c.getCdsid()) ? c.getCdsid().toLowerCase().trim() : null;
            if (StringUtils.hasText(name) && StringUtils.hasText(cdsid)) {
                return name + " (" + cdsid + "@ford.com)";
            } else if (StringUtils.hasText(cdsid)) {
                return cdsid + "@ford.com";
            }
            return name;
        }).filter(StringUtils::hasText).collect(Collectors.toList());

        return labels.isEmpty() ? null : String.join("; @", labels);
    }

    /**
     * Returns all contacts[] entries whose title matches (case-insensitive); empty list if none.
     */
    private List<Contacts> getContactsByTitle(IssueContacts issueContacts, String title) {
        if (issueContacts == null || issueContacts.getContacts() == null) return Collections.emptyList();
        return issueContacts.getContacts().stream().filter(c -> title.equalsIgnoreCase(c.getTitle())).collect(Collectors.toList());
    }

    /**
     * Returns cached Root Cause Owners titles; retries the DB once if cache is empty, else uses the
     * hardcoded fallback.
     */
    private List<String> getRootCauseOwnerTitles() {
        List<String> cached = rootCauseOwnerTitlesCache;
        if (!cached.isEmpty()) {
            return cached;
        }
        try {
            List<String> titles = contactGroupRepository.findByGroupName(ContactConstants.ROOT_CAUSE_OWNERS).map(cg -> cg.getFieldIds().stream().map(FieldIds::getId).collect(Collectors.toList())).orElse(Collections.emptyList());
            if (!titles.isEmpty()) {
                rootCauseOwnerTitlesCache = titles;
                return titles;
            }
        } catch (Exception e) {
            LOGGER.warn("getRootCauseOwnerTitles - fallback lookup failed: {}: {}", e.getClass().getSimpleName(), e.getMessage());
        }
        return FALLBACK_ROOT_CAUSE_TITLES;
    }

    /**
     * /preview: fails fast on missing issueNumber, fsaNumber or fsaType.
     */
    private void validateRequestPreview(DraftNotificationPreviewRequest request) throws GridException {
        requireNonBlank(request.getIssueNumber(), DraftNotificationConstants.ERR_NO_ISSUE_NUMBER, DraftNotificationConstants.MSG_ISSUE_NUMBER_EMPTY);
        requireNonBlank(request.getFsaNumber(), DraftNotificationConstants.ERR_NO_FSA_NUMBER, DraftNotificationConstants.MSG_FSA_NUMBER_EMPTY);
    }

    /**
     * Combines uploaded multipart files with the optional attestation file into the mail attachment
     * map.
     */
    private Map<String, InputStreamSource> buildEditedAttachments(DraftNotificationSendRequest request, MultipartFile[] uploadedFiles) throws GridException {
        Map<String, InputStreamSource> attachments = new LinkedHashMap<>();

        if (uploadedFiles != null) {
            for (MultipartFile file : uploadedFiles) {
                if (file == null || file.isEmpty()) continue;
                try {
                    String name = StringUtils.hasText(file.getOriginalFilename()) ? file.getOriginalFilename() : "attachment-" + (attachments.size() + 1);
                    attachments.put(name, new ByteArrayResource(file.getBytes()));
                } catch (IOException e) {
                    throw new GridException(HttpStatus.BAD_REQUEST, "InvalidAttachment", "Could not read uploaded file: " + file.getOriginalFilename());
                }
            }
        }

        if (request.isIncludeAttestationAttachment()) {
            Map<String, InputStreamSource> attestation = downloadAttestationFile();
            if (attestation != null) {
                attachments.putAll(attestation);
            }
        }

        return attachments.isEmpty() ? null : attachments;
    }

    private void buildTolistForIssueNo(String issueNumber, String implId, String populationId, String brand, String region, boolean active) {

    }

    /**
     * SLA computation result shared by /preview (response fields) and sendEditedDraftNotification
     * (mail context).
     */
    private record SlaComputation(boolean urgent, LocalDateTime dueDateTime, String slaText, String formattedDeadline) {
    }
}
