package com.ford.grid.controller.arc.service.impl;

import com.ford.grid.constants.AzureAuthConstants;
import com.ford.grid.controller.arc.request.SharePointReminderRequest;
import com.ford.grid.controller.arc.response.SharePointDiscardResponse;
import com.ford.grid.controller.arc.response.SharePointEditorInfo;
import com.ford.grid.controller.arc.response.SharePointFileEditorsResponse;
import com.ford.grid.controller.arc.response.SharePointOpenFileInfo;
import com.ford.grid.controller.arc.response.SharePointUploadResponse;
import com.ford.grid.controller.arc.service.SharePointService;
import com.ford.grid.controller.arc.utill.SharePointGcpUtil;
import com.ford.grid.exception.GridException;
import com.ford.grid.model.dto.MailRequest;
import com.ford.grid.model.dto.response.UploadGCSFileResponse;
import com.ford.grid.service.impl.MailService;
import com.google.cloud.storage.Blob;
import com.ford.grid.controller.arc.config.EntraGraphClientProvider;
import com.microsoft.graph.drives.item.items.item.checkin.CheckinPostRequestBody;
import com.microsoft.graph.drives.item.items.item.invite.InvitePostRequestBody;
import com.microsoft.graph.models.*;
import com.microsoft.graph.models.odataerrors.ODataError;

import com.microsoft.kiota.ApiException;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.thymeleaf.context.Context;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
/**
 * Implementation of SharePointService.
 * Provides business logic for retrieving SharePoint file details and editor history
 * via the Microsoft Graph API.
 */
@Service
@RequiredArgsConstructor
public class SharePointServiceImpl implements SharePointService {

    private static final Logger LOGGER = LoggerFactory.getLogger(SharePointServiceImpl.class);
    private static final Pattern CDSID_IN_PARENS = Pattern.compile("\\(([A-Za-z0-9._-]+)\\)");
    private static final Pattern CDSID_TOKEN = Pattern.compile("[A-Za-z0-9._-]+");

    /** Cap on how many open-file lock holders we resolve/report */
    private static final int MAX_LOCK_HOLDERS_REPORTED = 10;

    /** Cap on how many recent editors we list per blocking file (from its version history). */
    private static final int MAX_EDITORS_PER_FILE = 10;

    /** If the blocking file was modified within this many minutes of "now"*/
    private static final long EDIT_RECENCY_MINUTES = 10L;

    private static final boolean ENABLE_FILE_VERSIONING = true;

    private final EntraGraphClientProvider entraGraphClientProvider;
    private final SharePointGcpUtil sharePointGcpUtil;
    private final MailService mailService;

    @Value("${grid.ui.base-url:}")
    private String gridUiBaseUrl;


    //  email subject add for other env
    @Value("${document.template.generate.llm.api.env}")
    private String emailSub;

    /**
     * Retrieves file details and all editors (from version history) for a given file name.
     * Flow: Resolve Site → Get Drive → List Root → Find Folder → Find File → Get Versions → Return.
     *
     * @param fileName the name of the file to look up in SharePoint
     * @return SharePointFileEditorsResponse containing file metadata and editor details
     * @throws GridException if the file name is invalid, the site/drive/folder/file cannot be found,
     *                       or a Graph API error occurs
     */
    @Override
    public SharePointFileEditorsResponse getEditorsByFileName(String fileName,String fileSource) throws GridException {
        LOGGER.info("getEditorsByFileName – started. fileName='{}'", fileName);

        if (fileName == null || fileName.isBlank()) {
            throw new GridException(HttpStatus.BAD_REQUEST, "InvalidFileName", "File name must not be empty");
        }

        String siteId = resolveSiteId();
        String driveId = resolveDriveId(siteId);
        String normalizedFolderPath = resolveDriveRelativeFolderPath(fileSource);


        // Resolve the target folder by path in a single Graph API call.
        // Validates that the folder exists; throws if not found.
        DriveItem targetFolder = getFolderByPath(siteId, driveId, normalizedFolderPath);
        LOGGER.info("Found target folder: name='{}', id={}", targetFolder.getName(), targetFolder.getId());


        DriveItemCollectionResponse folderChildren;
        try {
            folderChildren = listChildren(siteId, driveId, targetFolder.getId());
        } catch (ODataError e) {
            logODataError("list folder '" + normalizedFolderPath + "'", e);
            throw new GridException(HttpStatus.INTERNAL_SERVER_ERROR, "FolderListError",
                    "Could not list files in folder");
        }
        if (folderChildren == null || folderChildren.getValue() == null) {
            throw new GridException(HttpStatus.NOT_FOUND, "FileNotFound",
                    "No files found in folder '" + normalizedFolderPath + "'");
        }

        DriveItem matchedFile = findMatchingFile(folderChildren.getValue(), fileName, normalizedFolderPath);
        LOGGER.info("Found file: name='{}', id={}", matchedFile.getName(), matchedFile.getId());


        List<SharePointEditorInfo> editors = getEditorsFromVersionHistory(siteId, driveId, matchedFile.getId());

        LOGGER.info("File '{}' → {} edit(s): {}", matchedFile.getName(), editors.size(),
                editors.stream().map(u -> u.getDisplayName() + " (" + u.getCdsId() + ") " + u.getDate())
                        .toList());

        return SharePointFileEditorsResponse.builder()
                .fileName(matchedFile.getName())
                .fileUrl(matchedFile.getWebUrl())
                .editors(editors)
                .totalEdits(editors.size())
                .build();
    }


    /**
     * Fetches all files from a GCP bucket folder and uploads each one to the given SharePoint folder.
     * @param gcpFolderPath
     * @param sharePointFolderPath
     * @return list of SharePointUploadResponse
     */
    @Override
    public List<SharePointUploadResponse> uploadDraftFiles(String gcpFolderPath, String sharePointFolderPath) throws GridException {
        if (gcpFolderPath == null || gcpFolderPath.isBlank()) {
            throw new GridException(HttpStatus.BAD_REQUEST, "Invalid GcpFolder", "GCP folder path must not be empty");
        }
        if (sharePointFolderPath == null || sharePointFolderPath.isBlank()) {
            throw new GridException(HttpStatus.BAD_REQUEST, "Invalid SPFolder", "SharePoint folder path must not be empty");
        }

        List<Blob> gcpFiles = sharePointGcpUtil.listFilesInGcpFolder(gcpFolderPath);

        if (gcpFiles.isEmpty()) {
            throw new GridException(HttpStatus.NOT_FOUND, "NoFilesInGcp",
                    "No files found in GCP folder '" + gcpFolderPath + "'");
        }

        String siteId = resolveSiteId();
        String driveId = resolveDriveId(siteId);
        String normalizedTargetPath = normalizeFolderPathForDrive(sharePointFolderPath);
        ensureFolderExists(siteId, driveId, normalizedTargetPath);

        String encodedFolderPath = sharePointGcpUtil.encodeSharePointPath(normalizedTargetPath);
        List<SharePointUploadResponse> responses = new ArrayList<>();

        List<String> existingFileNames = new ArrayList<>();
        if (ENABLE_FILE_VERSIONING) {
            existingFileNames = getExistingFileNames(siteId, driveId, normalizedTargetPath);
        }

        for (Blob blob : gcpFiles) {
            String originalFileName = sharePointGcpUtil.extractFileName(blob.getName());

            String fileName = ENABLE_FILE_VERSIONING
                    ? resolveVersionedFileName(originalFileName, existingFileNames)
                    : originalFileName;

            LOGGER.info("Fetching '{}' from GCP, size={} bytes", fileName, blob.getSize());
            byte[] fileContent = blob.getContent();

            String encodedFileName = sharePointGcpUtil.encodeSharePointPath(fileName);
            String uploadUrl = String.format("%s/sites/%s/drives/%s/root:/%s/%s:/content",
                    AzureAuthConstants.GRAPH_BASE_URL, siteId, driveId, encodedFolderPath, encodedFileName);

            LOGGER.info("Uploading '{}' to SharePoint: {}", fileName, uploadUrl);

            try (InputStream inputStream = new ByteArrayInputStream(fileContent)) {
                DriveItem uploaded = entraGraphClientProvider.getClient()
                        .drives().byDriveId("_").items().byDriveItemId("_").content()
                        .withUrl(uploadUrl)
                        .put(inputStream);

                LOGGER.info("Uploaded '{}' → webUrl={}", uploaded.getName(), uploaded.getWebUrl());

                responses.add(SharePointUploadResponse.builder()
                        .fileName(uploaded.getName())
                        .fileUrl(uploaded.getWebUrl())
                        .fileId(uploaded.getId())
                        .build());

                // Track the uploaded file name so subsequent files in the same batch don't collide
                if (ENABLE_FILE_VERSIONING) {
                    existingFileNames.add(fileName.toLowerCase());
                }
            } catch (ODataError e) {
                logODataError("upload '" + fileName + "'", e);
                throw new GridException(HttpStatus.INTERNAL_SERVER_ERROR, "UploadFailed",
                        "Failed to upload '" + fileName + "' to SharePoint");
            } catch (IOException e) {
                LOGGER.error("IO error uploading '{}': {}", fileName, e.getMessage());
                throw new GridException(HttpStatus.INTERNAL_SERVER_ERROR, "UploadIOError",
                        "IO error uploading '" + fileName + "'");
            }
        }

        LOGGER.info("uploadDraftFiles – uploaded {} file(s) from GCP to SharePoint.", responses.size());
        return responses;
    }


    private List<String> getExistingFileNames(String siteId, String driveId, String folderPath) {
        try {
            DriveItem folder = getFolderByPath(siteId, driveId, folderPath);
            DriveItemCollectionResponse children = listChildren(siteId, driveId, folder.getId());
            if (children != null && children.getValue() != null) {
                return children.getValue().stream()
                        .filter(item -> item.getFile() != null && item.getName() != null)
                        .map(item -> item.getName().toLowerCase())
                        .collect(Collectors.toCollection(ArrayList::new));
            }
        } catch (Exception e) {
            LOGGER.warn("Could not fetch existing files in '{}': {}", folderPath, e.getMessage());
        }
        return new ArrayList<>();
    }


    private String resolveVersionedFileName(String originalFileName, List<String> existingNames) {
        if (!existingNames.contains(originalFileName.toLowerCase())) {
            return originalFileName;
        }

        String baseName;
        String extension;
        int dotIndex = originalFileName.lastIndexOf('.');
        if (dotIndex > 0) {
            baseName = originalFileName.substring(0, dotIndex);
            extension = originalFileName.substring(dotIndex);
        } else {
            baseName = originalFileName;
            extension = "";
        }

        int version = 1;
        String versionedName;
        do {
            versionedName = baseName + "_v" + version + extension;
            version++;
        } while (existingNames.contains(versionedName.toLowerCase()));

        LOGGER.info("File '{}' already exists – renamed to '{}'", originalFileName, versionedName);
        return versionedName;
    }

    /**
     * Resolves the SharePoint site ID.
     */
    private String resolveSiteId() throws GridException {
        try {
            Site site = entraGraphClientProvider.getClient().sites().bySiteId(AzureAuthConstants.SITE_HOST_AND_PATH).get();
            LOGGER.info("Resolved site: id={}, name={}", site.getId(), site.getDisplayName());
            return site.getId();
        } catch (ODataError e) {
            logODataError("resolve site", e);
            throw new GridException(HttpStatus.INTERNAL_SERVER_ERROR, "SiteNotFound",
                    "Could not resolve SharePoint site");
        }
    }

    /**
     * Resolves the first drive ID for the given site.
     */
    private String resolveDriveId(String siteId) throws GridException {
        DriveCollectionResponse drivesResponse;
        try {
            drivesResponse = entraGraphClientProvider.getClient().sites().bySiteId(siteId).drives().get();
        } catch (ODataError e) {
            logODataError("list drives", e);
            throw new GridException(HttpStatus.INTERNAL_SERVER_ERROR, "DriveListError", "Could not list drives");
        }
        if (drivesResponse == null || drivesResponse.getValue() == null || drivesResponse.getValue().isEmpty()) {
            throw new GridException(HttpStatus.NOT_FOUND, "NoDrive", "No drives found for site " + siteId);
        }
        Drive drive = drivesResponse.getValue().stream()
                .filter(d -> d.getName() != null &&
                        ("Documents".equalsIgnoreCase(d.getName()) || "Shared Documents".equalsIgnoreCase(d.getName())))
                .findFirst()
                .orElse(drivesResponse.getValue().get(0));
        LOGGER.info("Using drive: id={}, name={}", drive.getId(), drive.getName());
        return drive.getId();
    }

    private String normalizeFolderPathForDrive(String folderPath) {
        if (folderPath == null) {
            return "";
        }

        String normalized = folderPath.trim().replace('\\', '/');
        while (normalized.startsWith("/")) {
            normalized = normalized.substring(1);
        }

        if (normalized.regionMatches(true, 0, "Shared Documents/", 0, "Shared Documents/".length())) {
            normalized = normalized.substring("Shared Documents/".length());
        } else if (normalized.regionMatches(true, 0, "Documents/", 0, "Documents/".length())) {
            normalized = normalized.substring("Documents/".length());
        }

        return normalized;
    }


    private void ensureFolderExists(String siteId, String driveId, String folderPath) throws GridException {
        try {
            getFolderByPath(siteId, driveId, folderPath);
            LOGGER.info("Folder '{}' already exists.", folderPath);
        } catch (GridException e) {
            LOGGER.info("Folder '{}' not found – creating it.", folderPath);
            createFolderPath(siteId, driveId, folderPath);
        }
    }

    private void createFolderPath(String siteId, String driveId, String folderPath) throws GridException {
        String[] segments = Arrays.stream(folderPath.split("/"))
                .filter(s -> !s.isBlank())
                .toArray(String[]::new);

        String parentItemId = "root";

        for (String segment : segments) {
            // Check if this segment already exists under the parent
            String existingId = findChildFolderByName(siteId, driveId, parentItemId, segment);
            if (existingId != null) {
                parentItemId = existingId;
                continue;
            }

            String createUrl = String.format("%s/sites/%s/drives/%s/items/%s/children",
                    AzureAuthConstants.GRAPH_BASE_URL, siteId, driveId, parentItemId);

            DriveItem newFolder = new DriveItem();
            newFolder.setName(segment);
            newFolder.setFolder(new com.microsoft.graph.models.Folder());

            try {
                DriveItem created = entraGraphClientProvider.getClient()
                        .drives().byDriveId("_").items().byDriveItemId("_").children()
                        .withUrl(createUrl)
                        .post(newFolder);
                parentItemId = created.getId();
                LOGGER.info("Created folder segment '{}' with id={}", segment, parentItemId);
            } catch (ODataError ex) {
                logODataError("create folder segment '" + segment + "'", ex);
                throw new GridException(HttpStatus.INTERNAL_SERVER_ERROR, "FolderCreateFailed",
                        "Could not create folder '" + segment + "' in path '" + folderPath + "'");
            }
        }
    }

    private String findChildFolderByName(String siteId, String driveId, String parentItemId, String folderName) {
        try {
            DriveItemCollectionResponse children = listChildren(siteId, driveId, parentItemId);
            if (children != null && children.getValue() != null) {
                return children.getValue().stream()
                        .filter(item -> item.getFolder() != null && folderName.equalsIgnoreCase(item.getName()))
                        .map(DriveItem::getId)
                        .findFirst()
                        .orElse(null);
            }
        } catch (Exception e) {
            LOGGER.warn("Could not list children of '{}': {}", parentItemId, e.getMessage());
        }
        return null;
    }


    private DriveItemCollectionResponse listChildren(String siteId, String driveId, String itemId) {
        String url = String.format("%s/sites/%s/drives/%s/items/%s/children",
                AzureAuthConstants.GRAPH_BASE_URL, siteId, driveId, itemId);
        return entraGraphClientProvider.getClient()
                .drives().byDriveId("_").items().byDriveItemId("_").children()
                .withUrl(url)
                .get();
    }


    private DriveItem getFolderByPath(String siteId, String driveId, String folderPath) throws GridException {

        String encodedPath = Arrays.stream(folderPath.split("/"))
                .filter(s -> !s.isBlank())
                .map(segment -> URLEncoder.encode(segment, StandardCharsets.UTF_8).replace("+", "%20"))
                .collect(Collectors.joining("/"));

        String url = String.format("%s/sites/%s/drives/%s/root:/%s",
                AzureAuthConstants.GRAPH_BASE_URL, siteId, driveId, encodedPath);

        LOGGER.info("Resolving folder by path URL: {}", url);

        try {
            DriveItem folder = entraGraphClientProvider.getClient()
                    .drives().byDriveId("_").items().byDriveItemId("_")
                    .withUrl(url)
                    .get();

            if (folder == null || folder.getFolder() == null) {
                throw new GridException(HttpStatus.NOT_FOUND, "FolderNotFound",
                        "Path '" + folderPath + "' exists but is not a folder");
            }

            return folder;
        } catch (ODataError e) {
            logODataError("resolve folder path '" + folderPath + "'", e);
            throw new GridException(HttpStatus.NOT_FOUND, "FolderNotFound",
                    "Folder '" + folderPath + "' not found in SharePoint drive");
        }
    }


    private DriveItemVersionCollectionResponse listVersions(String siteId, String driveId, String itemId) {
        String url = String.format("%s/sites/%s/drives/%s/items/%s/versions",
                AzureAuthConstants.GRAPH_BASE_URL, siteId, driveId, itemId);
        return entraGraphClientProvider.getClient()
                .drives().byDriveId("_").items().byDriveItemId("_").versions()
                .withUrl(url)
                .get();
    }

    /**
     * Fetches version history for a file and extracts editor information from each version.
     * Duplicate editors are preserved (each edit is a separate entry).
     *
     * @param siteId  the resolved SharePoint site ID
     * @param driveId the drive ID within the site
     * @param itemId  the file item ID
     * @return list of SharePointEditorInfo representing every edit event
     * @throws GridException if the Graph API call for version history fails
     */
    private List<SharePointEditorInfo> getEditorsFromVersionHistory(String siteId, String driveId, String itemId) throws GridException {
        List<SharePointEditorInfo> editors = new ArrayList<>();

        try {
            DriveItemVersionCollectionResponse versions = listVersions(siteId, driveId, itemId);

            if (versions != null && versions.getValue() != null) {
                LOGGER.info("Item {} has {} version(s)", itemId, versions.getValue().size());

                for (DriveItemVersion version : versions.getValue()) {
                    if (version.getLastModifiedBy() != null && version.getLastModifiedBy().getUser() != null) {
                        var user = version.getLastModifiedBy().getUser();
                        String displayName = user.getDisplayName() != null ? user.getDisplayName() : "";
                        String userId = user.getId() != null ? user.getId() : "";
                        String email = extractEmail(user.getAdditionalData());
                        Date editDate = version.getLastModifiedDateTime() != null
                                ? Date.from(version.getLastModifiedDateTime().toInstant()) : null;

                        // If email is missing but we have an Azure AD object ID, attempt a Graph user lookup
                        // to retrieve the userPrincipalName / mail which is required for DocuSign routing.
                        if ((email == null || email.isBlank()) && !userId.isBlank()) {
                            String lookedUp = lookupUserEmailById(userId);
                            if (lookedUp != null && !lookedUp.isBlank()) {
                                LOGGER.info("Resolved email '{}' for userId={} via Graph user lookup", lookedUp, userId);
                                email = lookedUp;
                            }
                        }

                        String cdsId = extractCdsId(email, displayName, userId);

                        // Include the editor if we have at least one usable identity field.
                        if (!cdsId.isEmpty() || (email != null && !email.isBlank()) || !displayName.isBlank()) {
                            editors.add(SharePointEditorInfo.builder()
                                    .cdsId(cdsId)
                                    .principalId(userId)
                                    .displayName(displayName)
                                    .email(email)
                                    .permissionLevel("--")
                                    .date(editDate)
                                    .build());
                        }
                    }
                }
            }
        } catch (ODataError e) {
            logODataError("fetch version history for item " + itemId, e);
            throw new GridException(HttpStatus.INTERNAL_SERVER_ERROR, "VersionHistoryError",
                    "Could not fetch version history for file");
        }

        return editors;
    }

    /**
     * Attempts to retrieve a user's email / UPN from Graph API using their Azure AD object ID.
     * Returns null (not throwing) if the lookup fails so callers can degrade gracefully.
     */
    private String lookupUserEmailById(String userId) {
        try {
            String url = String.format("%s/users/%s?$select=mail,userPrincipalName,displayName",
                    AzureAuthConstants.GRAPH_BASE_URL, userId);
            com.microsoft.graph.models.User graphUser = entraGraphClientProvider.getClient()
                    .users().byUserId("_")
                    .withUrl(url)
                    .get();
            if (graphUser == null) {
                return null;
            }
            // Prefer mail; fall back to userPrincipalName
            if (graphUser.getMail() != null && !graphUser.getMail().isBlank()) {
                return graphUser.getMail().trim();
            }
            if (graphUser.getUserPrincipalName() != null && !graphUser.getUserPrincipalName().isBlank()) {
                return graphUser.getUserPrincipalName().trim();
            }
        } catch (Exception e) {
            LOGGER.warn("Could not look up user email for userId='{}': {}", userId, e.getMessage());
        }
        return null;
    }


    private String extractEmail(Map<String, Object> additionalData) {
        if (additionalData == null) return "";
        Object email = additionalData.get("email");
        if (email == null) email = additionalData.get("userPrincipalName");
        return email != null ? String.valueOf(email) : "";
    }


    private String extractCdsId(String email, String displayName, String userId) {
        if (email != null && email.contains("@")) {
            String localPart = email.substring(0, email.indexOf('@')).trim();
            if (isLikelyCdsid(localPart)) {
                return localPart.toLowerCase();
            }
        }

        if (displayName != null && !displayName.isBlank()) {
            String trimmedName = displayName.trim();

            Matcher parensMatch = CDSID_IN_PARENS.matcher(trimmedName);
            if (parensMatch.find()) {
                String candidate = parensMatch.group(1);
                if (isLikelyCdsid(candidate)) {
                    return candidate.toLowerCase();
                }
            }

            int backslashPos = trimmedName.lastIndexOf('\\');
            if (backslashPos >= 0 && backslashPos < trimmedName.length() - 1) {
                String candidate = trimmedName.substring(backslashPos + 1).trim();
                if (isLikelyCdsid(candidate)) {
                    return candidate.toLowerCase();
                }
            }

            if (isLikelyCdsid(trimmedName)) {
                return trimmedName.toLowerCase();
            }
        }

        // Azure object ID is not a usable signer identity for email composition.
        return "";
    }

    private boolean isLikelyCdsid(String value) {
        if (value == null) {
            return false;
        }
        String trimmed = value.trim();
        return !trimmed.isEmpty() && !trimmed.contains("@") && CDSID_TOKEN.matcher(trimmed).matches();
    }


    private void logODataError(String operation, ODataError e) {
        String code = e.getError() != null ? e.getError().getCode() : "unknown";

        String msg  = e.getError() != null ? e.getError().getMessage() : "No details available";
        LOGGER.error("Graph API error during '{}': code={}, message={}", operation, code, msg);
    }

    /**
     * Downloads a file by name from SharePoint and returns its content as bytes.
     * Flow: Resolve Site → Get Drive → Find Folder → Find File → Download Content.
     *
     * @param fileName the name of the file to download
     * @return byte array containing the file content
     * @throws GridException if the file is not found or download fails
     */
    @Override
    public byte[] downloadFileByFileName(String fileName) throws GridException {
        LOGGER.info("downloadFileByFileName – started. fileName='{}'", fileName);

        if (fileName == null || fileName.isBlank()) {
            throw new GridException(HttpStatus.BAD_REQUEST, "InvalidFileName", "File name must not be empty");
        }

        String siteId = resolveSiteId();
        String driveId = resolveDriveId(siteId);
        String normalizedFolderPath = normalizeFolderPathForDrive(AzureAuthConstants.FOLDER_PATH);
        DriveItem targetFolder = getFolderByPath(siteId, driveId, normalizedFolderPath);

        DriveItemCollectionResponse folderChildren;
        try {
            folderChildren = listChildren(siteId, driveId, targetFolder.getId());
        } catch (ODataError e) {
            logODataError("list folder for download '" + normalizedFolderPath + "'", e);
            throw new GridException(HttpStatus.INTERNAL_SERVER_ERROR, "FolderListError",
                    "Could not list files in folder");
        }

        if (folderChildren == null || folderChildren.getValue() == null) {
            throw new GridException(HttpStatus.NOT_FOUND, "FileNotFound",
                    "No files found in folder '" + normalizedFolderPath + "'");
        }

        DriveItem matchedFile = findMatchingFile(folderChildren.getValue(), fileName, normalizedFolderPath);

        LOGGER.info("Found file to download: name='{}', id={}, size={} bytes",
                matchedFile.getName(), matchedFile.getId(), matchedFile.getSize());

        return downloadFileById(siteId, driveId, matchedFile.getId(), fileName);
    }

    /**
     * Sends a review reminder email to the specified reviewers.
     * The email includes a list of documents pending review.
     *
     * @param request contains reviewer email addresses and pending document details
     * @throws GridException if reviewer emails or pending documents are empty
     */
    @Override
    public void sendReviewReminder(SharePointReminderRequest request) throws GridException {
        LOGGER.info("sendReviewReminder – started. reviewers={}, pendingDocs={}",
                request.getReviewerEmails(), request.getPendingDocuments());

        if (request.getReviewerEmails() == null || request.getReviewerEmails().isEmpty()) {
            throw new GridException(HttpStatus.BAD_REQUEST, "NoReviewers", "Reviewer email list must not be empty");
        }
        if (request.getPendingDocuments() == null || request.getPendingDocuments().isEmpty()) {
            throw new GridException(HttpStatus.BAD_REQUEST, "NoPendingDocs", "Pending documents list must not be empty");
        }


        List<String> cdsIds = request.getReviewerEmails().stream()
                .map(email -> email.contains("@") ? email.substring(0, email.indexOf('@')).toLowerCase() : email.toLowerCase())
                .distinct()
                .toList();

        String subject = buildEmailSubject(request.getFsaNumber(), request.getScreenName(), request.isUrgency());

//        String subject = (request.getSubject() != null && !request.getSubject().isBlank())
//                ? request.getSubject()
//                : "Reminder: " + request.getPendingDocuments().size() + " document(s) pending your review - " + request.getFsaNumber();

        // Build a list of maps with fileName and fileLink for each pending document
        List<Map<String, String>> documentDetails = request.getPendingDocuments().stream()
                .map(docPath -> {
                    String fileName = extractFileNameFromPath(docPath);
                    Map<String, String> doc = new java.util.LinkedHashMap<>();
                    doc.put("fileName", fileName);
                    doc.put("fileLink", docPath);
                    return doc;
                })
                .toList();

        Context context = new Context();
        context.setVariable("folderPath", documentDetails);
        context.setVariable("fsaNumber", request.getFsaNumber());
        context.setVariable("cdsUserName", request.getCdsUserName());
        context.setVariable("urgency", request.isUrgency());
        String reviewerName = org.apache.commons.lang3.StringUtils.capitalize(cdsIds.get(0));
        context.setVariable("reviewerName", reviewerName);
        context.setVariable("issueNumber", request.getIssueNumber());

        try {
            String base = StringUtils.hasText(gridUiBaseUrl) ? gridUiBaseUrl.trim() : "";
            String gridUrl = "";
            if (!base.isEmpty() && StringUtils.hasText(request.getIssueNumber())) {
                gridUrl = (base.endsWith("/") ? base : base + "/") + request.getIssueNumber() + "/checklist/";
            }
            context.setVariable("gridUrl",gridUrl);

            MailRequest mailRequest = MailRequest.builder()
                    .recipients(cdsIds)
                    .subject(subject)
                    .mailTemplateName(resolveReminderTemplate(request.getScreenName()))
                    .notificationType("Not-Applicable")
                    .context(context)
                    .forceSend(true)
                    .build();

            String mailResult = mailService.sendEmail(mailRequest, false);
            if ("Emails disabled for this issue".equals(mailResult)) {
                LOGGER.warn("Review reminder NOT sent - emails are disabled for issue: {}", request.getIssueNumber());
            } else {
                LOGGER.info("Review reminder email sent to: {}", cdsIds);
            }
        } catch (Exception e) {
            LOGGER.error("Failed to send review reminder email: {}", e.getMessage(), e);
            throw new GridException(HttpStatus.INTERNAL_SERVER_ERROR, "EmailSendFailed",
                    "Failed to send review reminder email: " + e.getClass().getSimpleName() + " - " + e.getMessage());
        }
    }

    private String buildEmailSubject(String fsaNumber, String collabId, boolean urgency) {
        LOGGER.debug("buildEmailSubject - env={}, fsa={} {}", emailSub, fsaNumber);
        //THIS IS TEST EMAIL - NO ACTION NEEDED (FSA - <FSANumber>) Collab 1 - SLA 2 Business Days” for collab 1 reviewer email
        String sla = "SLA 2 Business Days";
        if (urgency) {
            sla = "SLA 1 Business Days";
        }
        String prefix = "prod".equalsIgnoreCase(emailSub) ? "Action Request : FSA - " : "THIS IS TEST EMAIL - NO " + "ACTION NEEDED || REMINDER : FSA - ";
        return prefix + fsaNumber + " - " + sla;

    }


    /**
     * Downloads a file by its ID from SharePoint and returns its content as bytes.
     *
     * @param siteId   the SharePoint site ID
     * @param driveId  the drive ID
     * @param fileId   the file/item ID in SharePoint
     * @param fileName the file name (for logging)
     * @return byte array containing the file content
     * @throws GridException if the download fails
     */
    private byte[] downloadFileById(String siteId, String driveId, String fileId, String fileName) throws GridException {
        String contentUrl = String.format("%s/sites/%s/drives/%s/items/%s/content",
                AzureAuthConstants.GRAPH_BASE_URL, siteId, driveId, fileId);
        try {
            LOGGER.info("Downloading file '{}' from: {}", fileName, contentUrl);
            InputStream contentStream = entraGraphClientProvider.getClient()
                    .drives().byDriveId("_").items().byDriveItemId("_").content()
                    .withUrl(contentUrl)
                    .get();

            if (contentStream == null) {
                throw new GridException(HttpStatus.NOT_FOUND, "FileContentNotFound",
                        "File content not found for '" + fileName + "'");
            }

            byte[] fileContent = contentStream.readAllBytes();
            LOGGER.info("Successfully downloaded '{}': {} bytes", fileName, fileContent.length);
            return fileContent;

        } catch (ODataError e) {
            logODataError("download file '" + fileName + "'", e);
            throw new GridException(HttpStatus.INTERNAL_SERVER_ERROR, "DownloadFailed",
                    "Failed to download file '" + fileName + "' from SharePoint");
        } catch (IOException e) {
            LOGGER.error("IO error downloading '{}': {}", fileName, e.getMessage());
            throw new GridException(HttpStatus.INTERNAL_SERVER_ERROR, "DownloadIOError",
                    "IO error while downloading '" + fileName + "'");
        }
    }

    private DriveItem findMatchingFile(List<DriveItem> items, String requestedFileName, String folderPath) throws GridException {
        if (items == null || items.isEmpty()) {
            throw new GridException(HttpStatus.NOT_FOUND, "FileNotFound",
                    "No files found in folder '" + folderPath + "'");
        }

        String requested = requestedFileName == null ? "" : requestedFileName.trim();

        // Prefer exact case-insensitive match.
        DriveItem exact = items.stream()
                .filter(item -> item.getFile() != null && item.getName() != null)
                .filter(item -> requested.equalsIgnoreCase(item.getName()))
                .findFirst()
                .orElse(null);
        if (exact != null) {
            return exact;
        }

        // If caller omits extension, try base-name match (e.g., report -> report.docx).
        if (!requested.contains(".")) {
            List<DriveItem> baseMatches = items.stream()
                    .filter(item -> item.getFile() != null && item.getName() != null)
                    .filter(item -> requested.equalsIgnoreCase(stripExtension(item.getName())))
                    .toList();

            if (baseMatches.size() == 1) {
                return baseMatches.get(0);
            }
            if (baseMatches.size() > 1) {
                throw new GridException(HttpStatus.BAD_REQUEST, "AmbiguousFileName",
                        "Multiple files match base name '" + requested + "'. Please include full file name with extension.");
            }
        }

        throw new GridException(HttpStatus.NOT_FOUND, "FileNotFound",
                "File '" + requestedFileName + "' not found in folder '" + folderPath + "'");
    }

    private String stripExtension(String fileName) {
        if (fileName == null) {
            return "";
        }
        int dotIndex = fileName.lastIndexOf('.');
        return dotIndex > 0 ? fileName.substring(0, dotIndex) : fileName;
    }

    /**
     * Extracts the file name from a full path or URL
     */
    private String extractFileNameFromPath(String path) {
        if (path == null || path.isBlank()) return path;

        // Handle SharePoint Doc.aspx URLs with file= query parameter
        // e.g. .../_layouts/15/Doc.aspx?...&file=Safety%20Bulletin.docx&...
        if (path.contains("file=")) {
            try {
                String query = path.substring(path.indexOf('?') + 1);
                for (String param : query.split("&")) {
                    if (param.startsWith("file=")) {
                        return java.net.URLDecoder.decode(param.substring(5), StandardCharsets.UTF_8);
                    }
                }
            } catch (Exception e) {
                LOGGER.warn("Could not parse file name from URL query: {}", path);
            }
        }

        // Remove query string if URL
        String cleanPath = path.contains("?") ? path.substring(0, path.indexOf('?')) : path;
        int lastSlash = Math.max(cleanPath.lastIndexOf('/'), cleanPath.lastIndexOf('\\'));
        return lastSlash >= 0 ? cleanPath.substring(lastSlash + 1) : cleanPath;
    }
    /**
     * Resolves the Thymeleaf email template
     */
    private String resolveReminderTemplate(String screenName) {
        if (screenName == null || screenName.isBlank()) {
            return "Template_SharePoint_Review_Reminder";
        }
        return switch (screenName.toLowerCase()) {
         //   case "collab1" -> "Template_SharePoint_Review_Reminder_Collab1";
            //   case "collab2" -> "Template_SharePoint_Review_Reminder_Collab2";
            default -> "Template_SharePoint_Review_Reminder";
        };
    }

    /**
     * Downloads a SharePoint file by its web URL and returns the raw content as a byte array.
     * The method resolves the site and drive, then uses the Graph API
     * GET /sites/{siteId}/drives/{driveId}/root:/{itemPath}:/content to stream the file.
     *
     * @param fullFileUrlPath the SharePoint web URL of the file
     *                (e.g. https://ford.sharepoint.com/sites/MySite/Shared%20Documents/folder/file.docx)
     * @return the file content as byte[]
     * @throws GridException if the URL is blank, the file cannot be resolved, or the download fails
     */
    @Override
    public byte[] downloadFileByUrl(String fullFileUrlPath) throws GridException {
        //fileUrl="https://azureford.sharepoint.com/sites/FieldServiceActions/Shared Documents/Dummy Test for Factsheet/25-091 Fact Sheet Draft -25-091-1-0.docx";
        String fileUrl = (StringUtils.hasText(fullFileUrlPath) && fullFileUrlPath.contains("?d=")) ? fullFileUrlPath.split("\\?d=")[0] : fullFileUrlPath;
        LOGGER.info("downloadFileByUrl – started. fileUrl='{}'", fileUrl);

        if (fileUrl == null || fileUrl.isBlank()) {
            throw new GridException(HttpStatus.BAD_REQUEST, "InvalidFileUrl", "File URL must not be empty");
        }

        String siteId = resolveSiteId();
        String driveId = resolveDriveId(siteId);

        // Build the content download URL using the web URL via the /root:/{path}:/content pattern.
        // The Graph API supports: GET /sites/{siteId}/drives/{driveId}/root:/{relative-path}:/content
        // We extract the server-relative path from the full web URL.
        String serverRelativePath = extractServerRelativePath(fileUrl);
        LOGGER.info("Extracted server-relative path: '{}'", serverRelativePath);

        String encodedPath = Arrays.stream(serverRelativePath.split("/"))
                .filter(s -> !s.isBlank())
                .map(segment -> URLEncoder.encode(segment, StandardCharsets.UTF_8).replace("+", "%20"))
                .collect(Collectors.joining("/"));

        String downloadUrl = String.format("%s/sites/%s/drives/%s/root:/%s:/content",
                AzureAuthConstants.GRAPH_BASE_URL, siteId, driveId, encodedPath);

        LOGGER.info("Download URL: {}", downloadUrl);

        try (InputStream inputStream = entraGraphClientProvider.getClient()
                .drives().byDriveId("_").items().byDriveItemId("_").content()
                .withUrl(downloadUrl)
                .get();
             ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {

            if (inputStream == null) {
                throw new GridException(HttpStatus.NOT_FOUND, "FileContentEmpty",
                        "No content returned for file URL: " + fileUrl);
            }

            byte[] chunk = new byte[8192];
            int bytesRead;
            while ((bytesRead = inputStream.read(chunk)) != -1) {
                buffer.write(chunk, 0, bytesRead);
            }

            byte[] content = buffer.toByteArray();
            LOGGER.info("downloadFileByUrl – downloaded {} byte(s) for URL='{}'", content.length, fileUrl);
            return content;

        } catch (ODataError e) {
            logODataError("download file by URL '" + fileUrl + "'", e);
            throw new GridException(HttpStatus.INTERNAL_SERVER_ERROR, "DownloadFailed",
                    "Failed to download file from SharePoint: " + fileUrl);
        } catch (IOException e) {
            LOGGER.error("IO error while reading file content: {}", e.getMessage());
            throw new GridException(HttpStatus.INTERNAL_SERVER_ERROR, "DownloadIOError",
                    "Could not read file content from SharePoint");
        }
    }



    /**
     * Extracts the drive-relative path (i.e., the path after the library root) from a full SharePoint web URL.
     * Example input:  https://ford.sharepoint.com/sites/MySite/Shared%20Documents/Folder/file.docx
     * Example output: Folder/file.docx
     * <p>
     * The method strips the known site and library prefixes, leaving only the folder/file portion
     * needed by the Graph API root:/{path} syntax.
     *
     * @param fileUrl the full SharePoint web URL
     * @return the drive-relative path suitable for Graph API "root:/{path}:/content"
     * @throws GridException if the URL cannot be parsed into a recognisable path
     */
    private String extractServerRelativePath(String fileUrl) throws GridException {
        try {
            // Decode percent-encoded characters so path segments are human-readable
            String decoded = java.net.URLDecoder.decode(fileUrl, StandardCharsets.UTF_8);

            // Strip the protocol and host (e.g. "https://ford.sharepoint.com")
            int schemeEnd = decoded.indexOf("://");
            if (schemeEnd < 0) {
                throw new GridException(HttpStatus.BAD_REQUEST, "InvalidFileUrl",
                        "Cannot parse SharePoint URL: " + fileUrl);
            }
            int hostEnd = decoded.indexOf('/', schemeEnd + 3);
            if (hostEnd < 0) {
                throw new GridException(HttpStatus.BAD_REQUEST, "InvalidFileUrl",
                        "Cannot parse SharePoint URL (no path found): " + fileUrl);
            }
            String fullPath = decoded.substring(hostEnd + 1); // e.g. "sites/MySite/Shared Documents/Folder/file.docx"

            // Remove the leading "sites/{siteName}/" prefix so that we are left with the library-relative path
            // e.g. "Shared Documents/Folder/file.docx"
            String[] segments = fullPath.split("/", -1);
            int startIndex = 0;
            if (segments.length >= 2 && "sites".equalsIgnoreCase(segments[0])) {
                startIndex = 2; // skip "sites" and the site name
            }

            // Remove the document library name (first remaining segment, e.g. "Shared Documents")
            // so the result is relative to the drive root, e.g. "Folder/file.docx"
            if (segments.length > startIndex + 1) {
                startIndex += 1;
            }

            String relativePath = String.join("/",
                    Arrays.copyOfRange(segments, startIndex, segments.length));

            if (relativePath.isBlank()) {
                throw new GridException(HttpStatus.BAD_REQUEST, "InvalidFileUrl",
                        "Could not determine file path from URL: " + fileUrl);
            }
            return relativePath;
        } catch (GridException e) {
            throw e;
        } catch (Exception e) {
            LOGGER.error("Unexpected error parsing SharePoint URL '{}': {}", fileUrl, e.getMessage());
            throw new GridException(HttpStatus.BAD_REQUEST, "InvalidFileUrl",
                    "Cannot parse SharePoint URL: " + fileUrl);
        }
    }

    /**
     * Uploads a file provided as raw byte[] to a SharePoint folder using the Graph API.
     * Flow: validate inputs → resolve siteId → resolve driveId → ensure folder exists
     *       → handle versioning → PUT content via Graph API → return file name + web URL.
     *
     * @param gcsFile              raw bytes of the file to upload (e.g. from GCS download)
     * @param fileName             desired file name in SharePoint (e.g. "draft_N242457300.docx")
     * @param sharePointFolderPath SharePoint folder path relative to drive root
     *                             (e.g. "GRID/DraftDocuments/N242457300")
     * @return SharePointUploadResponse with fileName and fileUrl
     * @throws GridException on validation failure, Graph API error, or IO error
     */
    @Override
    public SharePointUploadResponse uploadFileFromBytes(byte[] gcsFile,
                                                        String fileName,
                                                        String sharePointFolderPath) throws GridException {
        LOGGER.info("uploadFileFromBytes – started. fileName='{}', folder='{}'", fileName, sharePointFolderPath);

        // ── Validation ────────────────────────────────────────────────────────────────
        if (gcsFile == null || gcsFile.length == 0) {
            throw new GridException(HttpStatus.BAD_REQUEST, "EmptyFileContent",
                    "File bytes must not be null or empty");
        }
        if (!StringUtils.hasText(fileName)) {
            throw new GridException(HttpStatus.BAD_REQUEST, "InvalidFileName",
                    "File name must not be empty");
        }
        if (!StringUtils.hasText(sharePointFolderPath)) {
            throw new GridException(HttpStatus.BAD_REQUEST, "InvalidFolderPath",
                    "SharePoint folder path must not be empty");
        }

        // ── Resolve Site and Drive ────────────────────────────────────────────────────
        String siteId  = resolveSiteId();
        String driveId = resolveDriveId(siteId);

        // ── Ensure target folder exists (creates it if missing) ──────────────────────
        ensureFolderExists(siteId, driveId, sharePointFolderPath);

        // ── Versioning: rename if a file with the same name already exists ───────────
        String resolvedFileName = fileName;
        if (ENABLE_FILE_VERSIONING) {
            List<String> existingFileNames = getExistingFileNames(siteId, driveId, sharePointFolderPath);
            resolvedFileName = resolveVersionedFileName(fileName, existingFileNames);
        }

        // ── Build Graph API upload URL ────────────────────────────────────────────────
        String encodedFolderPath = sharePointGcpUtil.encodeSharePointPath(sharePointFolderPath);
        String encodedFileName   = sharePointGcpUtil.encodeSharePointPath(resolvedFileName);

        String uploadUrl = String.format("%s/sites/%s/drives/%s/root:/%s/%s:/content",
                AzureAuthConstants.GRAPH_BASE_URL, siteId, driveId, encodedFolderPath, encodedFileName);

        LOGGER.info("Uploading '{}' ({} bytes) to SharePoint URL: {}", resolvedFileName, gcsFile.length, uploadUrl);

        // ── PUT file content via Graph API ────────────────────────────────────────────
        try (InputStream inputStream = new ByteArrayInputStream(gcsFile)) {

            DriveItem uploaded = entraGraphClientProvider.getClient()
                    .drives().byDriveId("_").items().byDriveItemId("_").content()
                    .withUrl(uploadUrl)
                    .put(inputStream);

           /* CreateLinkPostRequestBody linkPostRequestBody = new CreateLinkPostRequestBody();
            linkPostRequestBody.setType("edit");
            linkPostRequestBody.setScope("organization");

            Permission permission = entraGraphClientProvider.getClient()
                    .drives().byDriveId("_").items().byDriveItemId("_")
                    .createLink()
                    .post(linkPostRequestBody);
            LOGGER.info("<--uploaded.getId():----> " + uploaded.getId());*/
            /*Permission permission = entraGraphClientProvider.getClient()
                    .drives().byDriveId(driveId)
                    .items().byDriveItemId(uploaded.getId())
                    .createLink()
                    .post(linkPostRequestBody);

            LOGGER.info("<---Loggers Org share link:----> " + permission.getLink().getWebUrl());*/


            if (uploaded == null) {
                throw new GridException(HttpStatus.INTERNAL_SERVER_ERROR, "UploadFailed",
                        "Graph API returned null response for file '" + resolvedFileName + "'");
            }

            String directUrl = buildDirectSharePointUrl(sharePointFolderPath, resolvedFileName, uploaded);
            LOGGER.info("uploadFileFromBytes – success. fileName='{}', directUrl='{}'",
                    uploaded.getName(), directUrl);

            return SharePointUploadResponse.builder()
                    .fileName(uploaded.getName())
                    .fileUrl(directUrl)
                    .fileId(uploaded.getId())
                    .build();

        } catch (ODataError e) {
            logODataError("upload bytes '" + resolvedFileName + "'", e);
            throw new GridException(HttpStatus.INTERNAL_SERVER_ERROR, "UploadFailed",
                    "Failed to upload '" + resolvedFileName + "' to SharePoint folder '" + sharePointFolderPath + "'");
        } catch (IOException e) {
            LOGGER.error("IO error while uploading '{}': {}", resolvedFileName, e.getMessage());
            throw new GridException(HttpStatus.INTERNAL_SERVER_ERROR, "UploadIOError",
                    "IO error during upload of '" + resolvedFileName + "'");
        }
    }

    /**
     * Creates the full SharePoint folder hierarchy for the given path by invoking
     * {@code ensureFolderExists()} which walks each path segment and creates it if absent.
     *
     * <p>Example: passing "GRID/DraftDocuments/N242457300/IMPL001/POP001" will ensure all
     * five folder levels exist, creating any missing segments in order.</p>
     *
     * @param sharePointFolderPath the full folder path relative to the drive root
     *                             (e.g. "GRID/DraftDocuments/N242457300/IMPL001/POP001")
     * @throws GridException if the path is blank, site/drive resolution fails,
     *                       or any folder segment cannot be created
     */
    @Override
    public void createSharePointFolder(String sharePointFolderPath) throws GridException {
        LOGGER.info("createSharePointFolder – started. path='{}'", sharePointFolderPath);

        if (!StringUtils.hasText(sharePointFolderPath)) {
            throw new GridException(HttpStatus.BAD_REQUEST, "InvalidFolderPath",
                    "SharePoint folder path must not be blank");
        }

        String siteId  = resolveSiteId();
        String driveId = resolveDriveId(siteId);

        ensureFolderExists(siteId, driveId, sharePointFolderPath);

        LOGGER.info("createSharePointFolder – folder hierarchy ready. path='{}'", sharePointFolderPath);
    }

    private String buildDirectSharePointUrl(String sharePointFolderPath, String fileName, DriveItem uploaded) {
        // Extract GUID from eTag: "{fae2d1ab-2a9c-44ba-a23d-999ce4bbffff},1" → "fae2d1ab2a9c44baa23d999ce4bbffff"
            /*String dParam = "";
            String eTag = uploaded.getETag();
            if (eTag != null && eTag.contains("{") && eTag.contains("}")) {
                String guid = eTag.substring(eTag.indexOf('{') + 1, eTag.indexOf('}'));
                dParam = "?d=w" + guid.replace("-", "").toLowerCase();
            }*/
        // Build: https://azureford.sharepoint.com/sites/FieldServiceActions/Shared Documents/{folderPath}/{fileName}?d=w{guid}
            /*String directUrl = AzureAuthConstants.SHAREPOINT_SITE_BASE_URL
                    + "/" + AzureAuthConstants.SHAREPOINT_DOCUMENT_LIBRARY
                    + "/" + sharePointFolderPath
                    + "/" + fileName
                    + dParam;*/
        //Requirement has to have the sharepoint folder as url not full url
        String directUrl = AzureAuthConstants.SHAREPOINT_SITE_BASE_URL
                + "/" + AzureAuthConstants.SHAREPOINT_DOCUMENT_LIBRARY
                + "/" + sharePointFolderPath;

        return directUrl;
    }

    /**
     * delete file by url
     */
    private DeleteAttempt attemptDeleteFileByUrl(String fullFileUrlPath) throws GridException {
        // Strip any ?d= viewer suffix (same as downloadFileByUrl)
        String fileUrl = (StringUtils.hasText(fullFileUrlPath) && fullFileUrlPath.contains("?d="))
                ? fullFileUrlPath.split("\\?d=")[0]
                : fullFileUrlPath;

        LOGGER.info("deleteFileByUrl – started. fileUrl='{}'", fileUrl);

        if (!StringUtils.hasText(fileUrl)) {
            throw new GridException(HttpStatus.BAD_REQUEST, "InvalidFileUrl",
                    "File URL must not be empty");
        }

        String siteId  = resolveSiteId();
        String driveId = resolveDriveId(siteId);

        // Extract the drive-relative path from the full URL
        // e.g. "GRID/DraftDocuments/N242457300/draft_file.docx"
        String serverRelativePath = extractServerRelativePath(fileUrl);
        LOGGER.info("deleteFileByUrl – extracted relative path: '{}'", serverRelativePath);

        // URL-encode each path segment (spaces → %20)
        String encodedPath = Arrays.stream(serverRelativePath.split("/"))
                .filter(s -> !s.isBlank())
                .map(segment -> URLEncoder.encode(segment, StandardCharsets.UTF_8).replace("+", "%20"))
                .collect(Collectors.joining("/"));

        // Build Graph API URL to resolve the item:
        // GET /sites/{siteId}/drives/{driveId}/root:/{encodedPath}
        String resolveUrl = String.format("%s/sites/%s/drives/%s/root:/%s",
                AzureAuthConstants.GRAPH_BASE_URL, siteId, driveId, encodedPath);

        LOGGER.info("deleteFileByUrl – resolving item at: {}", resolveUrl);

        // Step 1: Resolve the item to get its ID
        String itemId;
        try {
            DriveItem item = entraGraphClientProvider.getClient()
                    .drives().byDriveId("_").items().byDriveItemId("_")
                    .withUrl(resolveUrl)
                    .get();

            if (item == null || item.getId() == null) {
                throw new GridException(HttpStatus.NOT_FOUND, "FileNotFound",
                        "File not found at URL: " + fileUrl);
            }
            itemId = item.getId();
            LOGGER.info("deleteFileByUrl – resolved itemId='{}', name='{}'", itemId, item.getName());

        } catch (ODataError e) {
            logODataError("resolve item for delete '" + fileUrl + "'", e);
            throw new GridException(HttpStatus.NOT_FOUND, "FileNotFound",
                    "File not found or cannot be accessed at URL: " + fileUrl);
        }

        // Step 2: DELETE the item by its ID
        // DELETE /sites/{siteId}/drives/{driveId}/items/{itemId}
        String deleteUrl = String.format("%s/sites/%s/drives/%s/items/%s",
                AzureAuthConstants.GRAPH_BASE_URL, siteId, driveId, itemId);

        LOGGER.info("deleteFileByUrl – deleting item at: {}", deleteUrl);

        // ── Pre-delete guard: block if any target file is CHECKED OUT ────────────────
        // Checkout is a persistent, server-side state (unlike a mere view), so it can be
        // reliably detected and the delete refused before anything is touched.
        List<LockHolder> checkedOut = detectCheckedOutHolders(siteId, driveId, itemId);
        if (!checkedOut.isEmpty()) {
            LOGGER.warn("deleteFileByUrl – blocked: {} checked-out file(s). itemId='{}', url='{}'",
                    checkedOut.size(), itemId, fileUrl);
            return DeleteAttempt.checkedOut(checkedOut, siteId, driveId, itemId, fileUrl);
        }

        // ── Single, non-forcing delete via the Graph SDK ────────────────────────────
        // No "If-Match" and no retry loop: if the item (or, for a folder, any file inside
        // it) is OPEN/EDITED/LOCKED, SharePoint rejects the delete (e.g. 423 Locked) and we
        // surface that as a "file is open" response instead of forcing the delete through.
        try {
            entraGraphClientProvider.getClient()
                    .drives().byDriveId("_").items().byDriveItemId("_")
                    .withUrl(deleteUrl)
                    .delete();

            LOGGER.info("deleteFileByUrl – successfully deleted (nothing open/locked/checked-out). "
                    + "itemId='{}', url='{}'", itemId, fileUrl);
            return new DeleteAttempt(true, 204, null, siteId, driveId, itemId, fileUrl);

        } catch (ODataError e) {
            int status = e.getResponseStatusCode();
            String code = e.getError() != null ? e.getError().getCode() : null;
            String msg = e.getError() != null ? e.getError().getMessage() : e.getMessage();
            String detail = ((code != null ? code : "") + " " + (msg != null ? msg : "")).trim();
            logODataError("delete item '" + itemId + "'", e);
            LOGGER.error("deleteFileByUrl – delete blocked/failed. status={}, itemId='{}', url='{}', detail={}",
                    status, itemId, fileUrl, detail);
            return new DeleteAttempt(false, status, detail, siteId, driveId, itemId, fileUrl);

        } catch (Exception e) {
            // Never propagate from the DELETE step: return an outcome instead.
            LOGGER.error("deleteFileByUrl – unexpected error deleting itemId='{}', url='{}': {}",
                    itemId, fileUrl, e.getMessage(), e);
            return new DeleteAttempt(false, -1, e.getMessage(), siteId, driveId, itemId, fileUrl);
        }
    }


    @Override
    public void deleteFileByUrl(String fullFileUrlPath) throws GridException {
        attemptDeleteFileByUrl(fullFileUrlPath);
    }


    @Override
    public SharePointDiscardResponse deleteFileByUrlWithLockInfo(String fullFileUrlPath) throws GridException {
        DeleteAttempt outcome = attemptDeleteFileByUrl(fullFileUrlPath);

        if (outcome.success) {
            return SharePointDiscardResponse.builder()
                    .success(true)
                    .status("DELETED")
                    .fileUrl(outcome.fileUrl)
                    .message("SharePoint item discarded successfully.")
                    .openFiles(Collections.emptyList())
                    .build();
        }

        // Checked-out files are a distinct, explicit block (detected before the delete ran).
        if (outcome.checkedOut) {
            List<SharePointOpenFileInfo> checkedOutFiles = new ArrayList<>();
            for (LockHolder h : outcome.holders) {
                checkedOutFiles.add(SharePointOpenFileInfo.builder()
                        .fileName(h.fileName)
                        .lastModified(h.lastModified)
                        .activity("CHECKED_OUT")
                        .lastEditedAgo(h.lastEditedAgo)
                        .editors(h.editors)
                        .build());
            }
            String checkoutMessage = buildCheckoutMessage(outcome.holders);
            LOGGER.warn("deleteFileByUrlWithLockInfo – discard blocked (checked out). url='{}', files={}, message='{}'",
                    outcome.fileUrl, checkedOutFiles.size(), checkoutMessage);
            return SharePointDiscardResponse.builder()
                    .success(false)
                    .status("BLOCKED_BY_CHECKED_OUT_FILES")
                    .fileUrl(outcome.fileUrl)
                    .message(checkoutMessage)
                    .openFiles(checkedOutFiles)
                    .build();
        }

        boolean looksLocked = outcome.status == 412 || outcome.status == 423
                || (outcome.body != null
                    && (outcome.body.contains("resourceModified")
                        || outcome.body.contains("resourceLocked")
                        || outcome.body.toLowerCase().contains("locked")));

        List<LockHolder> holders = looksLocked ? detectLockHolders(outcome) : Collections.emptyList();
        String message = buildLockMessage(looksLocked, holders);

        List<SharePointOpenFileInfo> openFiles = new ArrayList<>();
        for (LockHolder h : holders) {
            openFiles.add(SharePointOpenFileInfo.builder()
                    .fileName(h.fileName)
                    .lastModified(h.lastModified)
                    .activity(h.activity)
                    .lastEditedAgo(h.lastEditedAgo)
                    .editors(h.editors)
                    .build());
        }

        LOGGER.warn("deleteFileByUrlWithLockInfo – discard blocked. locked={}, status={}, url='{}', openFiles={}, message='{}'",
                looksLocked, outcome.status, outcome.fileUrl, openFiles.size(), message);

        return SharePointDiscardResponse.builder()
                .success(false)
                .status(looksLocked ? "BLOCKED_BY_OPEN_FILES" : "FAILED")
                .fileUrl(outcome.fileUrl)
                .message(message)
                .openFiles(openFiles)
                .build();
    }

    /**
     * Builds a user-facing message When the failure looks like a lock (412/423), it uses the pre-resolved open file(s)
     * and who last modified each (the likely editor) so the analyst knows who to contact.
     * Handles multiple open files held by multiple users.
     */
    private String buildLockMessage(boolean looksLocked, List<LockHolder> holders) {
        if (!looksLocked) {
            return "Discard Failed\nPlease try again, or contact support if the problem persists.";
        }
        if (holders.isEmpty()) {
            return "Discard Failed\nOne or more files in this folder are currently open\n"
                    + "Please ensure all files are closed and try again\n";
        }

        StringBuilder message = new StringBuilder("Discard Failed\n")
                .append("The following files are currently open and could not be deleted:\n");
        for (LockHolder h : holders) {
            String file = StringUtils.hasText(h.fileName) ? h.fileName : "A file in this folder";
            message.append(file).append(" ,").append(formatUsers(h)).append('\n');
        }
        message.append("Action Required: Please request the users to close the local files and try discard again.");
        return message.toString();
    }

    /**
     * Builds the user-facing message for a discard blocked because one or more files are
     * checked out. Names each checked-out file and (best-effort) who holds it.
     */
    private String buildCheckoutMessage(List<LockHolder> holders) {
        if (holders == null || holders.isEmpty()) {
            return "Discard Failed\nOne or more files are currently checked out\n"
                    + "Please ensure all files are checked in and try again\n";
        }
        StringBuilder message = new StringBuilder("Discard Failed\n")
                .append("The following files are checked out and could not be deleted:\n");
        for (LockHolder h : holders) {
            String file = StringUtils.hasText(h.fileName) ? h.fileName : "A file in this folder";
            message.append(file).append(" ,").append(formatUser(h)).append('\n');
        }
        message.append("Action Required: Please ask the users to check in the files and try discard again.");
        return message.toString();
    }

    /**
     * Best-effort detection of files that are CHECKED OUT under the target item (folder or
     * single file). A checkout is a persistent, queryable state exposed by Graph via the
     * {@code publication} facet ({@code publication.level == "checkout"}), so it can be
     * reliably caught before a delete. Never throws — returns an empty list on any failure.
     */
    private List<LockHolder> detectCheckedOutHolders(String siteId, String driveId, String itemId) {
        List<LockHolder> holders = new ArrayList<>();
        try {
            List<DriveItem> candidates = new ArrayList<>();

            DriveItemCollectionResponse children = null;
            try {
                children = listChildren(siteId, driveId, itemId);
            } catch (Exception ignore) {
                // Target may be a single file (not a folder) → handled below.
            }
            if (children != null && children.getValue() != null) {
                for (DriveItem child : children.getValue()) {
                    if (child.getFile() != null) {
                        candidates.add(child);
                    }
                }
            }
            if (candidates.isEmpty()) {
                DriveItem self = getItemById(siteId, driveId, itemId);
                if (self != null && self.getFile() != null) {
                    candidates.add(self);
                }
            }

            for (DriveItem candidate : candidates) {
                if (holders.size() >= MAX_LOCK_HOLDERS_REPORTED) {
                    break;
                }
                DriveItem full = getItemWithPublication(siteId, driveId, candidate.getId());
                if (isCheckedOut(full)) {
                    holders.add(toLockHolder(full,
                            collectRecentEditors(siteId, driveId, full.getId())));
                }
            }

            if (!holders.isEmpty()) {
                LOGGER.info("detectCheckedOutHolders – {} checked-out file(s) under itemId='{}': {}",
                        holders.size(), itemId,
                        holders.stream().map(h -> h.fileName + " -> "
                                        + (StringUtils.hasText(h.displayName) ? h.displayName : "?"))
                                .collect(Collectors.toList()));
            }
        } catch (Exception e) {
            LOGGER.warn("detectCheckedOutHolders – could not evaluate checkout state for itemId='{}': {}",
                    itemId, e.getMessage());
        }
        return holders;
    }

    /**
     * Fetches a single item selecting the {@code publication} facet (and last-modified info)
     * needed to determine checkout state. Returns null on failure.
     */
    private DriveItem getItemWithPublication(String siteId, String driveId, String itemId) {
        try {
            String url = String.format(
                    "%s/sites/%s/drives/%s/items/%s?$select=id,name,publication,lastModifiedBy,lastModifiedDateTime",
                    AzureAuthConstants.GRAPH_BASE_URL, siteId, driveId, itemId);
            return entraGraphClientProvider.getClient()
                    .drives().byDriveId("_").items().byDriveItemId("_")
                    .withUrl(url)
                    .get();
        } catch (Exception e) {
            LOGGER.warn("getItemWithPublication – could not fetch itemId='{}': {}", itemId, e.getMessage());
            return null;
        }
    }

    /** True when the item's publication facet reports a checked-out state. */
    private boolean isCheckedOut(DriveItem item) {
        return item != null
                && item.getPublication() != null
                && "checkout".equalsIgnoreCase(item.getPublication().getLevel());
    }

    /**
     * Formats a lock holder as "Display Name (cdsid)" when both are known, falling back to the
     * cdsid, then to a generic label when the user cannot be resolved.
     */
    private String formatUser(LockHolder h) {
        if (StringUtils.hasText(h.displayName)) {
            return StringUtils.hasText(h.cdsId) ? h.displayName + " (" + h.cdsId + ")" : h.displayName;
        }
        if (StringUtils.hasText(h.cdsId)) {
            return h.cdsId;
        }
        return "another user";
    }

    /**
     * Formats every distinct user associated with an open/locked file as
     * "Display Name (cdsid); Display Name (cdsid)". SharePoint/Graph does not expose a live
     * "currently open by" list, so the users are derived from the recent version-history
     * editors ({@link LockHolder#editors}, already de-duplicated per person and capped).
     * Falls back to the single last-modifier when no editor list is available.
     */
    private String formatUsers(LockHolder h) {
        if (h.editors != null && !h.editors.isEmpty()) {
            String joined = h.editors.stream()
                    .map(this::formatEditor)
                    .filter(StringUtils::hasText)
                    .distinct()
                    .collect(Collectors.joining("; "));
            if (StringUtils.hasText(joined)) {
                return joined;
            }
        }
        return formatUser(h);
    }

    /** Formats a single editor as "Display Name (cdsid)", falling back to name or cdsid alone. */
    private String formatEditor(SharePointEditorInfo editor) {
        if (editor == null) {
            return "";
        }
        String name = editor.getDisplayName();
        String cds = editor.getCdsId();
        if (StringUtils.hasText(name)) {
            return StringUtils.hasText(cds) ? name + " (" + cds + ")" : name;
        }
        return StringUtils.hasText(cds) ? cds : "";
    }

    /**
     * Best-effort identification of which file(s) are holding the folder open and who last
     * modified them. Reuses {@link #listChildren} and the existing user-resolution helpers.
     * Never throws — returns an empty list when the holder cannot be determined.
     */
    private List<LockHolder> detectLockHolders(DeleteAttempt outcome) {
        List<LockHolder> holders = new ArrayList<>();
        try {
            List<DriveItem> candidates = new ArrayList<>();

            DriveItemCollectionResponse children = null;
            try {
                children = listChildren(outcome.siteId, outcome.driveId, outcome.itemId);
            } catch (Exception ignore) {
                // Target may be a file (not a folder), or cannot be listed → handled below.
            }
            if (children != null && children.getValue() != null) {
                for (DriveItem child : children.getValue()) {
                    if (child.getFile() != null) {
                        candidates.add(child);
                    }
                }
            }
            if (candidates.isEmpty()) {
                DriveItem self = getItemById(outcome.siteId, outcome.driveId, outcome.itemId);
                if (self != null && self.getFile() != null) {
                    candidates.add(self);
                }
            }

            // Most-recently-modified first: on an actively edited file the last modifier is the editor.
            candidates.sort((a, b) -> {
                OffsetDateTime da = a.getLastModifiedDateTime();
                OffsetDateTime db = b.getLastModifiedDateTime();
                if (da == null && db == null) return 0;
                if (da == null) return 1;
                if (db == null) return -1;
                return db.compareTo(da);
            });

            for (DriveItem item : candidates) {
                if (holders.size() >= MAX_LOCK_HOLDERS_REPORTED) {
                    break;
                }
                List<SharePointEditorInfo> editors =
                        collectRecentEditors(outcome.siteId, outcome.driveId, item.getId());
                holders.add(toLockHolder(item, editors));
            }

            if (holders.isEmpty()) {
                LOGGER.info("detectLockHolders – no candidate files found for blocked delete. itemId='{}'",
                        outcome.itemId);
            } else {
                LOGGER.info("detectLockHolders – identified {} candidate open file(s) for blocked delete. "
                        + "itemId='{}'. Likely holder: file='{}', editor='{}', cdsId='{}'. All candidates: {}",
                        holders.size(), outcome.itemId,
                        holders.get(0).fileName, holders.get(0).displayName, holders.get(0).cdsId,
                        holders.stream()
                                .map(h -> h.fileName + " -> " + h.displayName
                                        + " (" + (StringUtils.hasText(h.cdsId) ? h.cdsId : "?") + ")")
                                .collect(Collectors.toList()));
            }
        } catch (Exception e) {
            LOGGER.warn("detectLockHolders – could not determine lock holder for itemId='{}': {}",
                    outcome.itemId, e.getMessage());
        }
        return holders;
    }

    private LockHolder toLockHolder(DriveItem item, List<SharePointEditorInfo> editors) {
        String displayName = "";
        String userId = "";
        String email = "";
        if (item.getLastModifiedBy() != null && item.getLastModifiedBy().getUser() != null) {
            var user = item.getLastModifiedBy().getUser();
            displayName = user.getDisplayName() != null ? user.getDisplayName() : "";
            userId = user.getId() != null ? user.getId() : "";
            email = extractEmail(user.getAdditionalData());
        }
        if ((email == null || email.isBlank()) && !userId.isBlank()) {
            String lookedUp = lookupUserEmailById(userId);
            if (lookedUp != null && !lookedUp.isBlank()) {
                email = lookedUp;
            }
        }
        String cdsId = extractCdsId(email, displayName, userId);
        OffsetDateTime lastModifiedOdt = item.getLastModifiedDateTime();
        String lastModified = lastModifiedOdt != null ? lastModifiedOdt.toString() : null;
        String activity = (lastModifiedOdt != null
                && lastModifiedOdt.isAfter(OffsetDateTime.now().minusMinutes(EDIT_RECENCY_MINUTES)))
                ? "EDITING" : "OPEN";
        String lastEditedAgo = formatLastEditedAgo(lastModifiedOdt);
        return new LockHolder(item.getName(), displayName, cdsId, email, lastModified, activity,
                lastEditedAgo, editors != null ? editors : new ArrayList<>());
    }


    private List<SharePointEditorInfo> collectRecentEditors(String siteId, String driveId, String itemId) {
        List<SharePointEditorInfo> editors = new ArrayList<>();
        try {
            DriveItemVersionCollectionResponse versions = listVersions(siteId, driveId, itemId);
            if (versions == null || versions.getValue() == null) {
                return editors;
            }
            // Keep only the most recent saved version per distinct person.
            java.util.LinkedHashMap<String, SharePointEditorInfo> byPerson = new java.util.LinkedHashMap<>();
            java.util.Map<String, OffsetDateTime> latest = new java.util.HashMap<>();
            for (DriveItemVersion version : versions.getValue()) {
                if (version.getLastModifiedBy() == null || version.getLastModifiedBy().getUser() == null) {
                    continue;
                }
                var user = version.getLastModifiedBy().getUser();
                String displayName = user.getDisplayName() != null ? user.getDisplayName() : "";
                String userId = user.getId() != null ? user.getId() : "";
                String email = extractEmail(user.getAdditionalData());
                if ((email == null || email.isBlank()) && !userId.isBlank()) {
                    String lookedUp = lookupUserEmailById(userId);
                    if (lookedUp != null && !lookedUp.isBlank()) {
                        email = lookedUp;
                    }
                }
                String cdsId = extractCdsId(email, displayName, userId);
                if (cdsId.isEmpty() && (email == null || email.isBlank()) && displayName.isBlank()) {
                    continue;
                }
                String key = !cdsId.isEmpty() ? cdsId
                        : ((email != null && !email.isBlank()) ? email.toLowerCase() : displayName.toLowerCase());
                OffsetDateTime dt = version.getLastModifiedDateTime();
                OffsetDateTime prev = latest.get(key);
                if (prev == null || (dt != null && dt.isAfter(prev))) {
                    latest.put(key, dt);
                    byPerson.put(key, SharePointEditorInfo.builder()
                            .cdsId(cdsId)
                            .principalId(userId)
                            .displayName(displayName)
                            .email(email)
                            .permissionLevel("--")
                            .date(dt != null ? Date.from(dt.toInstant()) : null)
                            .build());
                }
            }
            editors.addAll(byPerson.values());
            // Most-recent save first.
            editors.sort((a, b) -> {
                Date da = a.getDate();
                Date db = b.getDate();
                if (da == null && db == null) return 0;
                if (da == null) return 1;
                if (db == null) return -1;
                return db.compareTo(da);
            });
            if (editors.size() > MAX_EDITORS_PER_FILE) {
                return new ArrayList<>(editors.subList(0, MAX_EDITORS_PER_FILE));
            }
        } catch (Exception e) {
            LOGGER.warn("collectRecentEditors – could not read version history for itemId='{}': {}",
                    itemId, e.getMessage());
        }
        return editors;
    }

    /**
     * Formats how long ago the file was last edited (saved) as a coarse human-readable string,
     * e.g. "just now", "12 minutes ago", "2 hours ago", "3 days ago".
     *
     * <p>NOTE: This is the time since the last <em>save</em> ({@code lastModifiedDateTime}), NOT how
     * long the file has been open. Microsoft Graph does not expose a lock/open-session start time,
     * so a true "open for X" duration is not obtainable; this is the closest reliable signal.</p>
     */
    private String formatLastEditedAgo(OffsetDateTime lastModifiedOdt) {
        if (lastModifiedOdt == null) {
            return null;
        }
        Duration elapsed = Duration.between(lastModifiedOdt, OffsetDateTime.now());
        if (elapsed.isNegative()) {
            elapsed = Duration.ZERO;
        }
        long minutes = elapsed.toMinutes();
        if (minutes < 1) {
            return "just now";
        }
        if (minutes < 60) {
            return minutes + (minutes == 1 ? " minute ago" : " minutes ago");
        }
        long hours = elapsed.toHours();
        if (hours < 24) {
            return hours + (hours == 1 ? " hour ago" : " hours ago");
        }
        long days = elapsed.toDays();
        return days + (days == 1 ? " day ago" : " days ago");
    }

    private DriveItem getItemById(String siteId, String driveId, String itemId) {
        try {
            String url = String.format("%s/sites/%s/drives/%s/items/%s",
                    AzureAuthConstants.GRAPH_BASE_URL, siteId, driveId, itemId);
            return entraGraphClientProvider.getClient()
                    .drives().byDriveId("_").items().byDriveItemId("_")
                    .withUrl(url)
                    .get();
        } catch (Exception e) {
            LOGGER.warn("getItemById – could not fetch itemId='{}': {}", itemId, e.getMessage());
            return null;
        }
    }

    /** Immutable outcome of a delete attempt (see {@link #attemptDeleteFileByUrl}). */
    private static final class DeleteAttempt {
        final boolean success;
        final int status;
        final String body;
        final String siteId;
        final String driveId;
        final String itemId;
        final String fileUrl;
        final boolean checkedOut;
        final List<LockHolder> holders;

        DeleteAttempt(boolean success, int status, String body,
                      String siteId, String driveId, String itemId, String fileUrl) {
            this(success, status, body, siteId, driveId, itemId, fileUrl, false, Collections.emptyList());
        }

        DeleteAttempt(boolean success, int status, String body,
                      String siteId, String driveId, String itemId, String fileUrl,
                      boolean checkedOut, List<LockHolder> holders) {
            this.success = success;
            this.status = status;
            this.body = body;
            this.siteId = siteId;
            this.driveId = driveId;
            this.itemId = itemId;
            this.fileUrl = fileUrl;
            this.checkedOut = checkedOut;
            this.holders = holders != null ? holders : Collections.emptyList();
        }

        /** Outcome for a delete blocked because one or more target files are checked out. */
        static DeleteAttempt checkedOut(List<LockHolder> holders, String siteId, String driveId,
                                        String itemId, String fileUrl) {
            return new DeleteAttempt(false, 423, "checkedOut", siteId, driveId, itemId, fileUrl, true, holders);
        }
    }

    /** The file that is (likely) holding the folder open and who last modified it. */
    private static final class LockHolder {
        final String fileName;
        final String displayName;
        final String cdsId;
        final String email;
        final String lastModified;
        final String activity;
        final String lastEditedAgo;
        final List<SharePointEditorInfo> editors;

        LockHolder(String fileName, String displayName, String cdsId, String email,
                   String lastModified, String activity, String lastEditedAgo,
                   List<SharePointEditorInfo> editors) {
            this.fileName = fileName;
            this.displayName = displayName;
            this.cdsId = cdsId;
            this.email = email;
            this.lastModified = lastModified;
            this.activity = activity;
            this.lastEditedAgo = lastEditedAgo;
            this.editors = editors;
        }
    }

    /**
     * Resolves the drive-relative folder path from a fileSource value (stored in MongoDB).
     * <p>
     * fileSource is always a <b>folder-only</b> URL built by {@code buildDirectSharePointUrl()}
     * (e.g. {@code https://azureford.sharepoint.com/sites/.../Shared Documents/Bulletins & Letters/Test/Issues/26S18}).
     * This method converts it to the drive-relative path the Graph API needs
     * (e.g. {@code Bulletins & Letters/Test/Issues/26S18}).
     * Falls back to {@link AzureAuthConstants#FOLDER_PATH} when fileSource is null/blank.
     *
     * @param fileSource full SharePoint folder URL or relative path
     * @return drive-relative folder path
     * @throws GridException if a full URL cannot be parsed
     */
    private String resolveDriveRelativeFolderPath(String fileSource) throws GridException {
        if (!StringUtils.hasText(fileSource)) {
            LOGGER.info("fileSource is empty – using default FOLDER_PATH");
            return normalizeFolderPathForDrive(AzureAuthConstants.FOLDER_PATH);
        }

        // Strip query params (?d=...) and fragments (#section)
        String clean = fileSource.trim();
        int cut = clean.indexOf('?');
        if (cut >= 0) clean = clean.substring(0, cut);
        cut = clean.indexOf('#');
        if (cut >= 0) clean = clean.substring(0, cut);

        // Full URL → extract drive-relative path; otherwise treat as already-relative
        String folderPath = clean.startsWith("http")
                ? extractServerRelativePath(clean)
                : normalizeFolderPathForDrive(clean);

        // Strip trailing slashes
        while (folderPath.endsWith("/")) {
            folderPath = folderPath.substring(0, folderPath.length() - 1);
        }

        // If the LAST segment looks like a file (has extension), strip it to keep folder only
        int lastSlash = folderPath.lastIndexOf('/');
        if (lastSlash > 0 && folderPath.substring(lastSlash + 1).contains(".")) {
            folderPath = folderPath.substring(0, lastSlash);
        }

        LOGGER.info("resolveDriveRelativeFolderPath: '{}' → '{}'", fileSource, folderPath);
        return folderPath;
    }

    @Override
    public void grantWriteAccess(String fileSource, List<String> cdsIds) throws GridException {
        LOGGER.info("grantWriteAccess – started. fileSource='{}', cdsIds={}", fileSource, cdsIds);

        validateGrantWriteAccessRequest(fileSource, cdsIds);

        String siteId = resolveSiteId();
        String driveId = resolveDriveId(siteId);
        String folderPath = resolveDriveRelativeFolderPath(fileSource);
        var graphClient = entraGraphClientProvider.getClient();

        List<DriveItem> fileItems = resolveAllFilesByFolder(siteId, driveId, folderPath);

        List<String> failedUsers = new ArrayList<>();
        for (DriveItem targetFile : fileItems) {
            String normalizedFileName = targetFile.getName();
            String inviteUrl = String.format("%s/sites/%s/drives/%s/items/%s/invite",
                    AzureAuthConstants.GRAPH_BASE_URL, siteId, driveId, targetFile.getId());

            for (String cdsId : cdsIds) {
                if (!StringUtils.hasText(cdsId)) {
                    continue;
                }
                String normalizedCdsId = cdsId.trim().toLowerCase();
                try {
                    InvitePostRequestBody requestBody = buildInviteRequestBody(normalizedCdsId);
                    graphClient
                            .drives().byDriveId("_").items().byDriveItemId("_")
                            .invite()
                            .withUrl(inviteUrl)
                            .post(requestBody);
                    LOGGER.info("grantWriteAccess – granted edit access to '{}' for file '{}'", normalizedCdsId, normalizedFileName);
                } catch (ODataError e) {
                    logODataError("grant write access to '" + normalizedCdsId + "' on file '" + normalizedFileName + "'", e);
                    failedUsers.add(normalizedFileName + ":" + normalizedCdsId);
                } catch (Exception e) {
                    LOGGER.error("grantWriteAccess – unexpected error granting access to '{}' for file '{}': {}", normalizedCdsId, normalizedFileName, e.getMessage(), e);
                    failedUsers.add(normalizedFileName + ":" + normalizedCdsId);
                }
            }
        }

        if (!failedUsers.isEmpty()) {
            LOGGER.error("grantWriteAccess – failed to grant access to the following users: {}", String.join(", ", failedUsers));
        }
        LOGGER.info("grantWriteAccess – completed successfully for {} file(s) in fileSource='{}'", fileItems.size(), fileSource);
    }

    private void validateGrantWriteAccessRequest(String fileSource, List<String> cdsIds) throws GridException {
        if (!StringUtils.hasText(fileSource)) {
            throw new GridException(HttpStatus.BAD_REQUEST, "InvalidFileSource", "fileSource must not be empty");
        }
        if (cdsIds == null || cdsIds.isEmpty() || cdsIds.stream().noneMatch(StringUtils::hasText)) {
            throw new GridException(HttpStatus.BAD_REQUEST, "InvalidCdsIds", "cdsIds must contain at least one non-blank user id");
        }
    }

    private List<DriveItem> resolveAllFilesByFolder(String siteId, String driveId, String folderPath) throws GridException {
        DriveItem targetFolder = getFolderByPath(siteId, driveId, folderPath);
        DriveItemCollectionResponse folderChildren;
        try {
            folderChildren = listChildren(siteId, driveId, targetFolder.getId());
        } catch (ODataError e) {
            logODataError("list folder '" + folderPath + "' for write access", e);
            throw new GridException(HttpStatus.INTERNAL_SERVER_ERROR, "FolderListError",
                    "Could not list files in folder '" + folderPath + "'");
        }
        if (folderChildren == null || folderChildren.getValue() == null) {
            throw new GridException(HttpStatus.NOT_FOUND, "FileNotFound",
                    "No files found in folder '" + folderPath + "'");
        }

        List<DriveItem> fileItems = folderChildren.getValue().stream()
                .filter(item -> item != null && item.getFile() != null)
                .toList();

        if (fileItems.isEmpty()) {
            throw new GridException(HttpStatus.NOT_FOUND, "FileNotFound",
                    "No files found in folder '" + folderPath + "'");
        }

        return fileItems;
    }

    private InvitePostRequestBody buildInviteRequestBody(String cdsId) {
        InvitePostRequestBody requestBody = new InvitePostRequestBody();
        requestBody.setRequireSignIn(true);
        requestBody.setSendInvitation(false);
        requestBody.setRoles(List.of("write"));

        DriveRecipient recipient = new DriveRecipient();
        // If the input already contains '@', treat it as a full email; otherwise append @ford.com
        String email = cdsId.contains("@") ? cdsId : cdsId + "@ford.com";
        recipient.setEmail(email);
        requestBody.setRecipients(List.of(recipient));
        return requestBody;
    }
	
	    /**
     * Lists all files inside the given SharePoint folder path, downloads each file via
     * the Microsoft Graph API, uploads them to GCS, and returns a list of
     * {@link UploadGCSFileResponse} with the GCS file path and version number populated.
     *
     * <p>Flow:
     * <ol>
     *   <li>Resolve SharePoint siteId and driveId.</li>
     *   <li>List all {@link DriveItem} children under {@code sharepointFolderPath}.</li>
     *   <li>For each file item: download content → form GCS path → upload to GCS.</li>
     *   <li>Build and collect a {@link UploadGCSFileResponse} per uploaded file.</li>
     * </ol>
     *
     * @param sharepointFolderPath  SharePoint folder path to list and download files from
     * @param metadataSourceList    provides shared metadata context (issueNumber, implId, etc.)
     * @param uploadedGcsFolderPath base GCS destination folder path
     * @param notificationType      notification type to tag on every response entry
     * @return list of {@link UploadGCSFileResponse} populated with GCS path and version number
     * @throws GridException if the folder cannot be found, a download fails, or a GCS upload fails
     */
    @Override
    public List<UploadGCSFileResponse> downloadSharePointFolderAndUploadToGcs(
            String sharepointFolderPath,
            List<UploadGCSFileResponse> metadataSourceList,
            String uploadedGcsFolderPath,
            String notificationType) throws GridException {

        LOGGER.info("downloadSharePointFolderAndUploadToGcs - sharepointFolderPath: {}, uploadedGcsFolderPath: {}, notificationType: {}",
                sharepointFolderPath, uploadedGcsFolderPath, notificationType);

        if (!StringUtils.hasText(sharepointFolderPath)) {
            throw new GridException(HttpStatus.BAD_REQUEST, "InvalidFolderPath",
                    "sharepointFolderPath must not be empty");
        }
        if (!StringUtils.hasText(uploadedGcsFolderPath)) {
            throw new GridException(HttpStatus.BAD_REQUEST, "InvalidGcsFolderPath",
                    "uploadedGcsFolderPath must not be empty");
        }

        // Use first element from metadataSourceList as shared context (issueNumber, implId, etc.)
        UploadGCSFileResponse metadataContext = (metadataSourceList != null && !metadataSourceList.isEmpty())
                ? metadataSourceList.get(0)
                : null;

        // Step 1: Resolve site and drive
        String siteId = resolveSiteId();
        String driveId = resolveDriveId(siteId);

        // Step 2: Get the folder DriveItem by path
        // resolveDriveRelativeFolderPath handles both full SharePoint URLs and relative paths
        String normalizedFolderPath = resolveDriveRelativeFolderPath(sharepointFolderPath);
        DriveItem targetFolder = getFolderByPath(siteId, driveId, normalizedFolderPath);
        LOGGER.info("Resolved SharePoint folder: name='{}', id='{}'", targetFolder.getName(), targetFolder.getId());

        // Step 3: List all children (files) in the folder
        DriveItemCollectionResponse folderChildren;
        try {
            folderChildren = listChildren(siteId, driveId, targetFolder.getId());
        } catch (ODataError e) {
            logODataError("list children of folder '" + normalizedFolderPath + "'", e);
            throw new GridException(HttpStatus.INTERNAL_SERVER_ERROR, "FolderListError",
                    "Could not list files in SharePoint folder: " + sharepointFolderPath);
        }

        if (folderChildren == null || folderChildren.getValue() == null || folderChildren.getValue().isEmpty()) {
            LOGGER.warn("downloadSharePointFolderAndUploadToGcs - no files found in folder: {}", sharepointFolderPath);
            return new ArrayList<>();
        }

        List<UploadGCSFileResponse> result = new ArrayList<>();

        // Step 4: Download each file and upload to GCS
        for (DriveItem item : folderChildren.getValue()) {
            // Skip sub-folders — process only files
            if (item.getFile() == null) {
                LOGGER.info("Skipping non-file item: '{}'", item.getName());
                continue;
            }

            String sharepointFileName = item.getName();
            LOGGER.info("Processing SharePoint file: '{}'", sharepointFileName);

            // Build download URL using item ID
            String downloadUrl = String.format("%s/sites/%s/drives/%s/items/%s/content",
                    com.ford.grid.constants.AzureAuthConstants.GRAPH_BASE_URL, siteId, driveId, item.getId());

            // Download file bytes from SharePoint
            byte[] sharepointFile;
            try (java.io.InputStream inputStream = entraGraphClientProvider.getClient()
                    .drives().byDriveId("_").items().byDriveItemId("_").content()
                    .withUrl(downloadUrl)
                    .get();
                 java.io.ByteArrayOutputStream buffer = new java.io.ByteArrayOutputStream()) {

                if (inputStream == null) {
                    LOGGER.warn("No content returned for file '{}' — skipping", sharepointFileName);
                    continue;
                }
                byte[] chunk = new byte[8192];
                int bytesRead;
                while ((bytesRead = inputStream.read(chunk)) != -1) {
                    buffer.write(chunk, 0, bytesRead);
                }
                sharepointFile = buffer.toByteArray();
                LOGGER.info("Downloaded '{}' from SharePoint — {} byte(s)", sharepointFileName, sharepointFile.length);

            } catch (ODataError e) {
                logODataError("download file '" + sharepointFileName + "'", e);
                LOGGER.error("Failed to download '{}' from SharePoint — skipping", sharepointFileName);
                continue;
            } catch (java.io.IOException e) {
                LOGGER.error("IO error reading '{}' from SharePoint — skipping. Reason: {}", sharepointFileName, e.getMessage());
                continue;
            }

            // Step 5: Form GCS path and upload
            String uploadedGcsFilePath = String.join("/", uploadedGcsFolderPath, sharepointFileName);
            LOGGER.info("Uploading '{}' to GCS path: '{}'", sharepointFileName, uploadedGcsFilePath);

            String versionId;
            try {
                versionId = sharePointGcpUtil.uploadFileToGcsAndGetVersionId(uploadedGcsFilePath, sharepointFile);
                LOGGER.info("Uploaded '{}' to GCS — versionId: {}", sharepointFileName, versionId);
            } catch (GridException e) {
                LOGGER.error("GCS upload failed for '{}' — skipping. Reason: {}", sharepointFileName, e.getMessage());
                continue;
            }


            // Step 6: Build response entry
            UploadGCSFileResponse uploadResponse = UploadGCSFileResponse.builder()
                    .fileName(sharepointFileName)
                    .filePath(uploadedGcsFilePath)
                    .versionNumber(versionId)
                    .notificationType(notificationType)
                    .issueNumber(metadataContext != null ? metadataContext.getIssueNumber() : null)
                    .implId(metadataContext != null ? metadataContext.getImplId() : null)
                    .populationId(metadataContext != null ? metadataContext.getPopulationId() : null)
                    .fsaNumber(metadataContext != null ? metadataContext.getFsaNumber() : null)
                    .market(metadataContext != null ? metadataContext.getMarket() : null)
                    .build();

            result.add(uploadResponse);
        }
        //force delete the folder after all files are downloaded and uploaded to GCS.
       /* folderChildren.getValue().stream()
                .filter(item -> item.getFolder() != null)
                .forEach(folderItem -> {
                    try {
                        forceDeleteItem(folderItem.getId(), folderItem.getName());
                    } catch (GridException e) {
                        LOGGER.error("Failed to delete folder '{}' after processing. Reason: {}", folderItem.getName(), e.getMessage());
                    }
                });*/
        for (DriveItem item : folderChildren.getValue()) {
            try {
                forceDeleteItem(item.getId(), item.getName());
            } catch (GridException e) {
                LOGGER.error("Failed to delete folder '{}' after processing. Reason: {}", item.getName(), e.getMessage());
                // Surface open/locked files to the caller; tolerate other delete failures.
                if (HttpStatus.CONFLICT.equals(e.getStatus())) {
                    throw e;
                }
            }
        }

        LOGGER.info("downloadSharePointFolderAndUploadToGcs - completed. Files uploaded to GCS: {}", result.size());
        return result;
    }

   @Override
   public String buildSharePointUrl(String sharePointFolderPath) {
       return AzureAuthConstants.SHAREPOINT_SITE_BASE_URL
               + "/" + AzureAuthConstants.SHAREPOINT_DOCUMENT_LIBRARY
               + "/" + sharePointFolderPath;
   }

   @Override
   public void forceDeleteItem(String itemId, String name) throws GridException {
        int attempt = 0;
       String siteId = resolveSiteId();
       String driveId = resolveDriveId(siteId);

        while (true) {
        try {
            String url = String.format("%s/drives/%s/items/%s", AzureAuthConstants.GRAPH_BASE_URL, driveId, itemId);
            entraGraphClientProvider.getClient()
                    .drives().byDriveId("_").items().byDriveItemId("_")
                    .withUrl(url)
                    .delete();
            LOGGER.info("forceDeleteItem – successfully deleted item '{}'", name);
            return;
        } catch (ApiException ex) {
            attempt++;
            boolean isLocked = ex.getResponseStatusCode() == 423
                    || ex.getResponseStatusCode() == 409
                    || ex.getResponseStatusCode() == 412;

            if (isLocked && attempt <= 3) {
                System.out.println("Locked, releasing checkout for: " + name + " (attempt " + attempt + ")");
                releaseLock(driveId, itemId, name);
                continue; // retry delete
            }

            if (isLocked) {
                // Retries exhausted and the item is still open/locked — surface which file
                // is open and who has it open, instead of failing silently.
                String message = buildOpenFileMessage(siteId, driveId, itemId, name);
                LOGGER.warn("forceDeleteItem – giving up; item still open/locked. name='{}', message='{}'",
                        name, message);
                throw new GridException(HttpStatus.CONFLICT, message, message);
            }

            LOGGER.error("forceDeleteItem – failed to delete '{}': {}", name, ex.getMessage());
            return; // non-lock failure: give up on this item, move on to the rest (unchanged behavior)
        }
    }
  }

    /**
     * Builds a user-facing message for a force-delete that was blocked because the item
     * (or a file inside a folder) is currently OPEN/locked in SharePoint. Reuses the existing
     * lock-holder detection ({@link #detectLockHolders}) and user-formatting helpers so the
     * message names the open file(s) and who has them open. Never throws.
     */
    private String buildOpenFileMessage(String siteId, String driveId, String itemId, String name) {
        List<LockHolder> holders;
        try {
            DeleteAttempt blocked = new DeleteAttempt(false, 423, "resourceLocked",
                    siteId, driveId, itemId, name);
            holders = detectLockHolders(blocked);
        } catch (Exception e) {
            LOGGER.warn("buildOpenFileMessage – could not resolve lock holders for '{}': {}",
                    name, e.getMessage());
            holders = Collections.emptyList();
        }

        if (holders.isEmpty()) {
            return "Unable to delete '" + name + "' — the file is currently open.\n"
                    + "Please ensure all files are closed and try again.";
        }

        StringBuilder message = new StringBuilder(
                "Unable to delete – the following file(s) are currently open:\n");
        for (LockHolder h : holders) {
            String file = StringUtils.hasText(h.fileName) ? h.fileName : name;
            message.append(file).append(" , opened by ").append(formatUsers(h)).append('\n');
        }
        message.append("Action Required: Please ask the users to close the files and try again.");
        return message.toString();
    }
    private void releaseLock(String driveId, String itemId, String name) {
        try {
            CheckinPostRequestBody body = new CheckinPostRequestBody();
            body.setComment("Checked in automatically by force-delete tool prior to removal.");
            entraGraphClientProvider.getClient().drives().byDriveId(driveId).items().byDriveItemId(itemId).checkin().post(body);
        } catch (ApiException ex) {
        }
    }
}