package com.ford.grid.controller.arc.utill;

import com.ford.grid.constants.DraftNotificationConstants;
import com.ford.grid.controller.arc.request.DraftNotificationPreviewRequest;

import java.util.List;
import java.util.function.Predicate;

/**
 * Declarative registry of the Collab 1 "Review GRID" fixed distribution groups.
 * to , cc
 *
 * <p>GCAMP and PS&amp;L are always included; every other group is gated by its program flag.
 * To add/remove an address or a group, edit this enum (values are compiled in — a redeploy applies them).
 */
public enum FixedContactGroup {

    // ── Always included ───────────────────────────────────────────────────────
    GCAMP("gcamp",Target.TO, r -> true,
            List.of("nkaminsk@ford.com", "dcure2@ford.com", "lciolli@ford.com",
                    "hratclif@ford.com", "lveerapp@ford.com")),
    PSL("psl", Target.TO, r -> true,
            List.of("jrajend3@ford.com")),

    // ── Software (TO) ─────────────────────────────────────────────────────────
    // Included when either the DB-derived softwareRepair flag is true OR the request carries
    // an explicit softwareType (FDRS/IDS/OTA/SETI). Keeps sdiwakar on the TO line whenever a
    // software program is indicated even if the DB flag has not yet flipped.
    SOFTWARE("software", Target.TO,
            r -> r.isSoftwareRepair()
                    || (r.getSoftwareType() != null && !r.getSoftwareType().isBlank()),
            List.of("sdiwakar@ford.com")),
    DSSH("dssh", Target.TO,
            r -> r.isSoftwareRepair() || r.isSoftwareModuleReplacement(),
            List.of("mgoebelb@ford.com")),
    FDRS("fdrs", Target.TO,
            r -> DraftNotificationConstants.SOFTWARE_FDRS.equalsIgnoreCase(r.getSoftwareType()),
            List.of("junder29@ford.com", "mmceach6@ford.com")),
    IDS("ids", Target.TO,
            r -> DraftNotificationConstants.SOFTWARE_IDS.equalsIgnoreCase(r.getSoftwareType()),
            List.of("bswanso3@ford.com")),
    OTA("ota", Target.TO,
            r -> DraftNotificationConstants.SOFTWARE_OTA.equalsIgnoreCase(r.getSoftwareType()),
            List.of("sraina1@ford.com")),
    SETI("seti", Target.TO,
            r -> DraftNotificationConstants.SOFTWARE_SETI.equalsIgnoreCase(r.getSoftwareType()),
            List.of("pgiles1@ford.com")),

    // ── Tyres (TO) ────────────────────────────────────────────────────────────
    TYRES("tyres", Target.TO, DraftNotificationPreviewRequest::isTyres,
            List.of("bgree120@ford.com", "lconahan@ford.com")),

    // ── Bosch technical leads (TO) — when Technical Instructions are attached ──
    BOSCH_LEADS("bosch-leads", Target.TO, DraftNotificationPreviewRequest::isTechnicalInstructions,
            List.of("Kimberly.Chryczyk-Burkitt@etas.com", "Dave.Grove@etas.com",
                    "Khristopher.Hallmark@etas.com")),

    // ── Bosch technical authors (CC) ──────────────────────────────────────────
    BOSCH_AUTHORS("bosch-authors", Target.CC, DraftNotificationPreviewRequest::isBosch,
            List.of("Marina.Gross@etas.com", "John.Richardson@etas.com",
                    "Jeff.Swindlehurst@etas.com")),

    // ── Tools / ESST (CC) ─────────────────────────────────────────────────────
    TOOLS("tools", Target.CC, r -> r.isServiceTools() || r.isEsst(),
            List.of("orotunda@ford.com")),
    ESST("esst", Target.CC, DraftNotificationPreviewRequest::isEsst,
            List.of("jatwood9@ford.com")),

    // ── Battery Electric Vehicles (CC) ────────────────────────────────────────
    BEV("bev", Target.CC, DraftNotificationPreviewRequest::isBev,
            List.of("kreedy3@ford.com", "kpalme44@ford.com", "mwhitte6@ford.com",
                    "msimps74@ford.com", "rsethi6@ford.com", "afarnst2@ford.com",
                    "bbuckhal@ford.com", "engwenya@ford.com"));

    /** Whether the group's e-mails go on the TO or the CC line. */
    public enum Target { TO, CC }

    private final String key;
    private final Target target;
    private final Predicate<DraftNotificationPreviewRequest> applies;
    private final List<String> emails;

    FixedContactGroup(String key, Target target,
                      Predicate<DraftNotificationPreviewRequest> applies, List<String> emails) {
        this.key = key;
        this.target = target;
        this.applies = applies;
        this.emails = emails;
    }

    public String getKey() {
        return key;
    }

    public Target getTarget() {
        return target;
    }

    public List<String> getEmails() {
        return emails;
    }

    /** True when this group should be included for the given request's program flags. */
    public boolean applies(DraftNotificationPreviewRequest request) {
        return applies.test(request);
    }
}
