package com.ford.grid.controller.arc.utill;

import com.ford.grid.constants.AzureAuthConstants;
import com.ford.grid.exception.GridException;
import com.ford.grid.restserviceclient.CloudClient;
import com.google.api.gax.paging.Page;
import com.google.cloud.storage.Blob;
import com.google.cloud.storage.BlobId;
import com.google.cloud.storage.BlobInfo;
import com.google.cloud.storage.Storage;
import com.ford.grid.controller.arc.config.EntraGraphClientProvider;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.io.InputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Utility class for SharePoint + GCP integration operations.
 */
@Component
@RequiredArgsConstructor
public class SharePointGcpUtil {

    private static final Logger LOGGER = LoggerFactory.getLogger(SharePointGcpUtil.class);

    private final CloudClient cloudClient;
    private final EntraGraphClientProvider entraGraphClientProvider;


    public List<Blob> listFilesInGcpFolder(String folderPath) {
        String prefix = folderPath.endsWith("/") ? folderPath : folderPath + "/";
        LOGGER.info("Listing files from GCP bucket '{}' with prefix '{}'",
                cloudClient.getGridBucketName(), prefix);

        Storage gcpStorage = cloudClient.getGCPStorage();
        Page<Blob> blobs = gcpStorage.list(cloudClient.getGridBucketName(),
                Storage.BlobListOption.prefix(prefix),
                Storage.BlobListOption.currentDirectory());

        List<Blob> files = new ArrayList<>();
        for (Blob blob : blobs.iterateAll()) {
            if (blob.getSize() != null && blob.getSize() > 0 && !blob.getName().endsWith("/")) {
                files.add(blob);
            }
        }

        LOGGER.info("Found {} file(s) in GCP folder '{}'", files.size(), folderPath);
        return files;
    }


    public String encodeSharePointPath(String folderPath) {
        return Arrays.stream(folderPath.split("/"))
                .filter(s -> !s.isBlank())
                .map(segment -> URLEncoder.encode(segment, StandardCharsets.UTF_8).replace("+", "%20"))
                .collect(Collectors.joining("/"));
    }

    public String extractFileName(String gcpFullPath) {
        return gcpFullPath.substring(gcpFullPath.lastIndexOf('/') + 1);
    }

    /**
     * Downloads a file from a GCP bucket
     *
     * @param file the full blob path inside the bucket
     * @return the file content as a byte array
     * @throws IllegalArgumentException if the file path is null or blank
     * @throws RuntimeException         if the file is not found or cannot be downloaded
     */
    public byte[] downloadFileFromGcp(String file) {
        if (file == null || file.isBlank()) {
            throw new IllegalArgumentException("GCP file path must not be null or blank");
        }

        LOGGER.info("Downloading file from GCP bucket '{}', path='{}'",
                cloudClient.getGridBucketName(), file);

        Storage gcpStorage = cloudClient.getGCPStorage();
        Blob blob = gcpStorage.get(cloudClient.getGridBucketName(), file);

        if (blob == null || !blob.exists()) {
            throw new RuntimeException("File not found in GCP: " + file);
        }

        byte[] content = blob.getContent();
        LOGGER.info("Downloaded file '{}', size={} bytes", file, content.length);
        return content;
    }

    /**
     * Uploads a file as byte[] to the GCS bucket and returns the GCS generation number
     * as the version ID. Each upload to the same path creates a new generation number
     * (requires bucket versioning to be enabled for full version history).
     *
     * @param fileName the desired file name / path inside the GCS bucket
     *                 (e.g. "GRID/DraftDocuments/N242457/draft_Ford.docx")
     * @param fileData the raw file content as a byte array
     * @return the GCS generation number of the uploaded blob, used as the version ID
     * @throws IllegalArgumentException if fileName is blank or fileData is null/empty
     * @throws RuntimeException         if the GCS upload fails
     */
    public String uploadFileToGcsAndGetVersionId(String fileName, byte[] fileData) throws GridException {


        String bucketName = cloudClient.getGridBucketName();
        LOGGER.info("Uploading file to GCS - bucket: '{}', fileName: '{}', size: {} byte(s)",
                bucketName, fileName, fileData.length);

        long startTime = System.currentTimeMillis();
        try {
            Storage gcpStorage = cloudClient.getGCPStorage();

            // Resolve content type from file extension
            String contentType = resolveContentType(fileName);
            LOGGER.info("Resolved content type for '{}': {}", fileName, contentType);

            // Build BlobInfo — generation number is auto-assigned by GCS on each create call
            BlobInfo blobInfo = BlobInfo.newBuilder(BlobId.of(bucketName, fileName))
                    .setContentType(contentType)
                    .build();

            // Upload to GCS — returned Blob contains the generation (version) number
            Blob uploadedBlob = gcpStorage.create(blobInfo, fileData);

            String versionId = String.valueOf(uploadedBlob.getGeneration());
            long duration = System.currentTimeMillis() - startTime;

            LOGGER.info("GCS upload successful - bucket: '{}', fileName: '{}', size: {} byte(s), versionId (generation): {}, duration: {} ms",
                    bucketName, fileName, fileData.length, versionId, duration);

            return versionId;

        } catch (Exception e) {
            long duration = System.currentTimeMillis() - startTime;
            LOGGER.error("GCS upload failed - bucket: '{}', fileName: '{}', duration: {} ms, error: {}",
                    bucketName, fileName, duration, e.getMessage(), e);
            throw new GridException(HttpStatus.INTERNAL_SERVER_ERROR, "GCS Upload Failed",
                    "Failed to upload file to GCS: " + fileName + " - " + e.getMessage());
        }
    }

    /**
     * Resolves the MIME content type based on the file name extension.
     *
     * @param fileName the file name to inspect
     * @return the resolved MIME type string
     */
    private String resolveContentType(String fileName) {
        if (!StringUtils.hasText(fileName)) {
            return MediaType.APPLICATION_OCTET_STREAM_VALUE;
        }
        String lower = fileName.toLowerCase();
        if (lower.endsWith(".pdf"))   return "application/pdf";
        if (lower.endsWith(".docx"))  return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
        if (lower.endsWith(".doc"))   return "application/msword";
        if (lower.endsWith(".xlsx"))  return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
        if (lower.endsWith(".xls"))   return "application/vnd.ms-excel";
        if (lower.endsWith(".json"))  return MediaType.APPLICATION_JSON_VALUE;
        if (lower.endsWith(".txt"))   return MediaType.TEXT_PLAIN_VALUE;
        if (lower.endsWith(".png"))   return MediaType.IMAGE_PNG_VALUE;
        if (lower.endsWith(".jpg") || lower.endsWith(".jpeg")) return MediaType.IMAGE_JPEG_VALUE;
        return MediaType.APPLICATION_OCTET_STREAM_VALUE;
    }
}
