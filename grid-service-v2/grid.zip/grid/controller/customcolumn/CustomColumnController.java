package com.ford.grid.controller.customcolumn;

import com.ford.grid.exception.GridException;
import com.ford.grid.model.dto.request.customcolumn.viewbydoc.CustomViewByDocRequest;
import com.ford.grid.model.dto.request.customcolumn.viewbyfsa.CustomViewByFsaRequest;
import com.ford.grid.model.dto.request.customcolumn.viewbyhwparts.CustomViewByHwPartsRequest;
import com.ford.grid.model.dto.request.customcolumn.viewbyissue.CustomViewByIssueRequest;
import com.ford.grid.model.dto.request.customcolumn.viewbylaunch.CustomViewByLaunchRequest;
import com.ford.grid.model.dto.request.customcolumn.viewbypopulation.CustomViewByPopulationRequest;
import com.ford.grid.model.dto.request.customcolumn.viewbyrepairprofile.CustomViewByRepairProfileRequest;
import com.ford.grid.model.dto.request.customcolumn.viewbyswparts.CustomViewBySwPartsRequest;
import com.ford.grid.model.dto.response.CustomViewDownloadResponse;
import com.ford.grid.model.dto.response.SchedulerInfoResponse;
import com.ford.grid.model.dto.response.customcolumn.viewbydoc.CustomViewByDocMatResponse;
import com.ford.grid.model.dto.response.customcolumn.viewbydoc.CustomViewByDocResponse;
import com.ford.grid.model.dto.response.customcolumn.viewbyforuminvestigationmat.CustomViewByForumInvestigationMatResponse;
import com.ford.grid.model.dto.response.customcolumn.viewbyfsa.CustomViewByFsaMatResponse;
import com.ford.grid.model.dto.response.customcolumn.viewbyfsa.CustomViewByFsaResponse;
import com.ford.grid.model.dto.response.customcolumn.viewbyhwparts.CustomViewByHwPartsMatResponse;
import com.ford.grid.model.dto.response.customcolumn.viewbyhwparts.CustomViewByHwPartsResponse;
import com.ford.grid.model.dto.response.customcolumn.viewbyissue.CustomViewByIssueMatResponse;
import com.ford.grid.model.dto.response.customcolumn.viewbyissue.CustomViewByIssueResponse;
import com.ford.grid.model.dto.response.customcolumn.viewbylaunch.CustomViewByLaunchResponse;
import com.ford.grid.model.dto.response.customcolumn.viewbypopulation.CustomViewByPopulationMatResponse;
import com.ford.grid.model.dto.response.customcolumn.viewbypopulation.CustomViewByPopulationResponse;
import com.ford.grid.model.dto.response.customcolumn.viewbyrepairprofile.CustomViewByRepairProfileResponse;
import com.ford.grid.model.dto.response.customcolumn.viewbyrepairprofilemat.CustomViewByRepairProfileMatResponse;
import com.ford.grid.model.dto.response.customcolumn.viewbyswparts.CustomViewBySwPartsResponse;
import com.ford.grid.model.dto.response.customcolumn.viewbyswpartsmat.CustomViewBySwPartsMatResponse;
import com.ford.grid.schedule.MaterializedViewScheduleTask;
import com.ford.grid.service.MaterializedViewRefreshService;
import com.ford.grid.service.customcolumn.CustomViewDownloadService;
import com.ford.grid.service.customcolumn.viewbydoc.ViewByDocService;
import com.ford.grid.service.customcolumn.viewbydocmat.DocumentMatViewService;
import com.ford.grid.service.customcolumn.viewbyforuminvestigationmat.ForumInvestigationMatViewService;
import com.ford.grid.service.customcolumn.viewbyfsa.CustomViewByFsaService;
import com.ford.grid.service.customcolumn.viewbyfsmat.FsaMatViewService;
import com.ford.grid.service.customcolumn.viewbyhwparts.CustomViewByHwPartsService;
import com.ford.grid.service.customcolumn.viewbyhwpartsmat.HwPartsMatViewService;
import com.ford.grid.service.customcolumn.viewbyissue.CustomViewByIssueService;
import com.ford.grid.service.customcolumn.viewbyissuemat.IssueMaterializeViewService;
import com.ford.grid.service.customcolumn.viewbylaunch.CustomViewByLaunchService;
import com.ford.grid.service.customcolumn.viewbylaunchmat.LaunchMatViewService;
import com.ford.grid.service.customcolumn.viewbypopulation.CustomViewByPopulationService;
import com.ford.grid.service.customcolumn.viewbypopulationmat.PopulationMatViewService;
import com.ford.grid.service.customcolumn.viewbyrepairprofile.CustomViewByRepairProfileService;
import com.ford.grid.service.customcolumn.viewbyrepairprofilemat.RepairProfileMatViewService;
import com.ford.grid.service.customcolumn.viewbyswparts.CustomViewBySwPartsService;
import com.ford.grid.service.customcolumn.viewbyswpartsmat.SwPartsMatViewService;
import lombok.AllArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.InputStreamSource;
import org.springframework.http.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * REST Controller for fetching data via saved custom views.
 *
 * <p>Mandatory query parameter:
 * <ul>
 *   <li>{@code customViewId} — the {@code _id} of the document in {@code user_custom_preferences}</li>
 * </ul>
 *
 * <p>Optional query parameters:
 * <ul>
 *   <li>{@code search}        — free-text search across the selected activeColumns only (default: none)</li>
 *   <li>{@code page}          — zero-based page number (default: 0)</li>
 *   <li>{@code size}          — records per page (default: 10)</li>
 *   <li>{@code sortBy}        — field to sort by (default: "issueNumber")</li>
 *   <li>{@code sortDirection} — "ASC" or "DESC" (default: "ASC")</li>
 * </ul>
 */
@RestController
@RequestMapping("/api/v2/customview")
@AllArgsConstructor
public class CustomColumnController {

    private static final Logger LOGGER = LoggerFactory.getLogger(CustomColumnController.class);

    private static final String DEFAULT_PAGE = "0";
    private static final String DEFAULT_SIZE = "10";
    private static final String DEFAULT_SORT_DIRECTION = "ASC";
    private static final String DEFAULT_SORT_BY_ISSUE = "issueNumber";
    private final CustomViewByIssueService customViewByIssueService;
    private final CustomViewByPopulationService customViewByPopulationService;
    private final CustomViewByLaunchService customViewByLaunchService;
    private final CustomViewByRepairProfileService customViewByRepairProfileService;
    private final CustomViewBySwPartsService customViewBySwPartsService;
    private final CustomViewByFsaService customViewByFsaService;
    private final ViewByDocService viewByDocService;
    private final MaterializedViewRefreshService materializedViewRefreshService;
    private final CustomViewDownloadService customViewDownloadService;
    private final CustomViewByHwPartsService customViewByHwPartsService;
    private final LaunchMatViewService launchMatViewService;
    private final ForumInvestigationMatViewService forumInvestigationMatViewService;
    private final PopulationMatViewService populationMatViewService;
    private final RepairProfileMatViewService repairProfileMatViewService;
    private final FsaMatViewService fsaMatViewService;
    private final DocumentMatViewService documentMatViewService;
    private final HwPartsMatViewService hwPartsMatViewService;
    private final SwPartsMatViewService swPartsMatViewService;
    private final MaterializedViewScheduleTask materializedViewScheduleTask;

    private final IssueMaterializeViewService issueMaterializeViewService;


    // ─── Shared helpers to eliminate duplicated log/response boilerplate ─────

    @FunctionalInterface
    private interface ServiceCall<T> {
        T execute() throws GridException;
    }

    private void logRequest(String endpoint, String customViewId, String search,
                            int page, int size, String sortBy, String sortDirection) {
        LOGGER.info("CustomColumnController - GET {} | customViewId: {}, search: '{}', page: {}, size: {}, sortBy: {}, sortDirection: {}",
                endpoint, customViewId, search, page, size, sortBy, sortDirection);
    }

    private <T> ResponseEntity<T> executeAndLog(String endpoint, ServiceCall<T> serviceCall,
                                                java.util.function.Function<T, Collection<?>> dataExtractor,
                                                java.util.function.ToIntFunction<T> currentPageExtractor,
                                                java.util.function.ToIntFunction<T> totalPagesExtractor) throws GridException {
        LOGGER.info("CustomColumnController - GET {} invoking service...", endpoint);
        T response;
        try {
            response = serviceCall.execute();
        } catch (GridException e) {
            LOGGER.error("CustomColumnController - GET {} service threw GridException: {}", endpoint, e.getMessage(), e);
            throw e;
        } catch (Exception e) {
            LOGGER.error("CustomColumnController - GET {} service threw unexpected exception: {}", endpoint, e.getMessage(), e);
            throw e;
        }
        Collection<?> data = dataExtractor.apply(response);
        int recordCount = data != null ? data.size() : 0;
        int currentPage = currentPageExtractor.applyAsInt(response) + 1;
        int totalPages = totalPagesExtractor.applyAsInt(response);
        LOGGER.info("CustomColumnController - GET {} returning {} records (page {}/{})",
                endpoint, recordCount, currentPage, totalPages);
        if (recordCount == 0) {
            LOGGER.warn("CustomColumnController - GET {} returned EMPTY data (0 records). Check service/repository logs for details.", endpoint);
        }
        return ResponseEntity.ok(response);
    }

    /**
     * GET /api/v2/customview/issue
     */
    @GetMapping("/issue")
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read'})")
    public ResponseEntity<CustomViewByIssueResponse> getCustomViewByIssue(
            @RequestParam String customViewId,
            @RequestParam(required = false) String search,
            @RequestParam(required = false, defaultValue = DEFAULT_PAGE) int page,
            @RequestParam(required = false, defaultValue = DEFAULT_SIZE) int size,
            @RequestParam(required = false, defaultValue = DEFAULT_SORT_BY_ISSUE) String sortBy,
            @RequestParam(required = false, defaultValue = DEFAULT_SORT_DIRECTION) String sortDirection) throws GridException {

        logRequest("/issue", customViewId, search, page, size, sortBy, sortDirection);

        CustomViewByIssueRequest request = new CustomViewByIssueRequest();
        request.setCustomViewId(customViewId);
        request.setSearch(search);
        request.setPage(page);
        request.setSize(size);
        request.setSortBy(sortBy);
        request.setSortDirection(sortDirection);

        return executeAndLog("/issue", () -> customViewByIssueService.getCustomViewByIssue(request),
                CustomViewByIssueResponse::getData,
                CustomViewByIssueResponse::getCurrentPage,
                CustomViewByIssueResponse::getTotalPages);

    }


    /**
     * GET /api/v2/customview/download
     * <p>
     * Downloads all data from a custom view as an Excel file (.xlsx).
     * Uses the same data populating logic as /issue endpoint but exports ALL records (no pagination).
     *
     * @param customViewId mandatory — _id of the user_custom_preferences document
     * @return Excel file with all records from the custom view
     */
    @GetMapping("/download")
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read'})")
    public ResponseEntity<InputStreamSource> downloadCustomViewByIssue(
            @RequestParam String customViewId) throws GridException {

        LOGGER.info("CustomColumnController - GET /download | customViewId: {}", customViewId);

        try {
            // Call service to generate Excel file
            InputStreamSource excelFile = customViewByIssueService.downloadCustomViewByIssue(customViewId);

            // Validate the generated file
            if (excelFile == null) {
                LOGGER.error("CustomColumnController - Excel file generation returned null for customViewId: {}", customViewId);
                throw new GridException(HttpStatus.INTERNAL_SERVER_ERROR,
                        "Export failed", "Failed to generate Excel file. Please try again.");
            }

            // Sanitize customViewId for use in filename (alphanumeric + underscore/hyphen only)
            String sanitizedViewId = customViewId.replaceAll("[^a-zA-Z0-9_-]", "_");

            // Build filename with timestamp
            String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
            String filename = "CustomView_" + sanitizedViewId + "_" + timestamp + ".xlsx";

            LOGGER.info("CustomColumnController - successfully generated and returning Excel file: {}", filename);

            // Use Spring's ContentDisposition builder for safe header construction
            ContentDisposition contentDisposition =
                    ContentDisposition.attachment()
                            .filename(filename)
                            .build();

            // Return Excel file with appropriate headers
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, contentDisposition.toString())
                    .contentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                    .body(excelFile);
        } catch (GridException e) {
            LOGGER.error("CustomColumnController - GridException during download for customViewId: {} - Error: {}",
                    customViewId, e.getMessage(), e);
            throw e;
        } catch (Exception e) {
            LOGGER.error("CustomColumnController - Unexpected error during download for customViewId: {} - Error: {}",
                    customViewId, e.getMessage(), e);
            throw new GridException(HttpStatus.INTERNAL_SERVER_ERROR,
                    "Export failed", "An unexpected error occurred during export. Please try again or contact support.");
        }
    }

    /**
     * GET /api/v2/customview/stream-download
     *
     * <p>Memory-efficient streaming Excel download for any custom view. Uses a MongoDB
     * server-side cursor and Apache POI {@code SXSSFWorkbook} to write rows directly to
     * the HTTP response — no full result set is ever held in memory.
     *
     * <p>Supports all view types (issue, forumInvestigation, population, launch,
     * repairProfile, swParts, documents). Contact-type columns are excluded because
     * they require a second-collection join that is incompatible with pure streaming.
     *
     * @param customViewId mandatory — {@code _id} of the user_custom_preferences document
     * @param search       optional free-text search (null = no search)
     * @return JSON with fileName and signedUrl
     */
    @GetMapping("/stream-download")
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read'})")
    public ResponseEntity<CustomViewDownloadResponse> streamDownloadCustomView(
            @RequestParam String customViewId,
            @RequestParam(required = false) String search) throws GridException {

        LOGGER.info("CustomColumnController - GET /stream-download | customViewId: {}, search: '{}'",
                customViewId, search);

        CustomViewDownloadResponse response =
                customViewDownloadService.streamDownload(customViewId, search);

        LOGGER.info("CustomColumnController - stream-download returning GCS response | fileName: {}",
                response.getFileName());

        return ResponseEntity.ok(response);
    }


    /**
     * GET /api/v2/customview/forumInvestigation
     */
    @GetMapping("/forumInvestigation")
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read'})")
    public ResponseEntity<CustomViewByForumInvestigationMatResponse> getCustomViewByForumInvestigation(
            @RequestParam String customViewId,
            @RequestParam(required = false) String search,
            @RequestParam(required = false, defaultValue = DEFAULT_PAGE) int page,
            @RequestParam(required = false, defaultValue = DEFAULT_SIZE) int size,
            @RequestParam(required = false, defaultValue = DEFAULT_SORT_BY_ISSUE) String sortBy,
            @RequestParam(required = false, defaultValue = DEFAULT_SORT_DIRECTION) String sortDirection) throws GridException {

        if (StringUtils.isNotBlank(sortBy) && DEFAULT_SORT_BY_ISSUE.equalsIgnoreCase(sortBy)) {
            sortBy = DEFAULT_SORT_BY_ISSUE;
        }
        final String resolvedSortBy = sortBy;

        logRequest("/forumInvestigation", customViewId, search, page, size, sortBy, sortDirection);

        return executeAndLog("/forumInvestigation",
                () -> forumInvestigationMatViewService.getForumInvestigationMatView(
                        customViewId, search, page, size, resolvedSortBy, sortDirection),
                r -> r.getData().getContent(),
                r -> r.getData().getNumber(),
                r -> r.getData().getTotalPages());
    }

    /**
     * GET /api/v2/customview/documents
     */
    @GetMapping("/documents")
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read'})")
    public ResponseEntity<CustomViewByDocResponse> getCustomViewByDocument(
            @RequestParam String customViewId,
            @RequestParam(required = false) String search,
            @RequestParam(required = false, defaultValue = DEFAULT_PAGE) int page,
            @RequestParam(required = false, defaultValue = DEFAULT_SIZE) int size,
            @RequestParam(required = false, defaultValue = DEFAULT_SORT_BY_ISSUE) String sortBy,
            @RequestParam(required = false, defaultValue = DEFAULT_SORT_DIRECTION) String sortDirection) throws GridException {

        logRequest("/documents", customViewId, search, page, size, sortBy, sortDirection);

        CustomViewByDocRequest request = new CustomViewByDocRequest();
        request.setCustomViewId(customViewId);
        request.setSearch(search);
        request.setPage(page);
        request.setSize(size);
        request.setSortBy(sortBy);
        request.setSortDirection(sortDirection);

        return executeAndLog("/documents",
                () -> viewByDocService.getCustomViewByDocument(request),
                CustomViewByDocResponse::getData,
                CustomViewByDocResponse::getCurrentPage,
                CustomViewByDocResponse::getTotalPages);
    }

    /**
     * GET /api/v2/customview/population
     */
    @GetMapping("/population")
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read'})")
    public ResponseEntity<CustomViewByPopulationResponse> getCustomViewByPopulation(
            @RequestParam String customViewId,
            @RequestParam(required = false) String search,
            @RequestParam(required = false, defaultValue = DEFAULT_PAGE) int page,
            @RequestParam(required = false, defaultValue = DEFAULT_SIZE) int size,
            @RequestParam(required = false, defaultValue = DEFAULT_SORT_BY_ISSUE) String sortBy,
            @RequestParam(required = false, defaultValue = DEFAULT_SORT_DIRECTION) String sortDirection) throws GridException {

        logRequest("/population", customViewId, search, page, size, sortBy, sortDirection);

        CustomViewByPopulationRequest request = new CustomViewByPopulationRequest();
        request.setCustomViewId(customViewId);
        request.setSearch(search);
        request.setPage(page);
        request.setSize(size);
        request.setSortBy(sortBy);
        request.setSortDirection(sortDirection);

        return executeAndLog("/population",
                () -> customViewByPopulationService.getCustomViewByPopulation(request),
                CustomViewByPopulationResponse::getData,
                CustomViewByPopulationResponse::getCurrentPage,
                CustomViewByPopulationResponse::getTotalPages);
    }

    /**
     * GET /api/v2/customview/launch
     */
    @GetMapping("/launch")
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read'})")
    public ResponseEntity<CustomViewByLaunchResponse> getCustomViewByLaunch(
            @RequestParam String customViewId,
            @RequestParam(required = false) String search,
            @RequestParam(required = false, defaultValue = DEFAULT_PAGE) int page,
            @RequestParam(required = false, defaultValue = DEFAULT_SIZE) int size,
            @RequestParam(required = false, defaultValue = DEFAULT_SORT_BY_ISSUE) String sortBy,
            @RequestParam(required = false, defaultValue = DEFAULT_SORT_DIRECTION) String sortDirection) throws GridException {

        logRequest("/launch", customViewId, search, page, size, sortBy, sortDirection);

        CustomViewByLaunchRequest request = new CustomViewByLaunchRequest();
        request.setCustomViewId(customViewId);
        request.setSearch(search);
        request.setPage(page);
        request.setSize(size);
        request.setSortBy(sortBy);
        request.setSortDirection(sortDirection);

        return executeAndLog("/launch",
                () -> customViewByLaunchService.getCustomViewByLaunch(request),
                r -> r.getData().getContent(),
                r -> r.getData().getNumber(),
                r -> r.getData().getTotalPages());
    }

    /**
     * GET /api/v2/customview/repairProfile
     */
    @GetMapping("/repairProfile")
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read'})")
    public ResponseEntity<CustomViewByRepairProfileResponse> getCustomViewByRepairProfile(
            @RequestParam String customViewId,
            @RequestParam(required = false) String search,
            @RequestParam(required = false, defaultValue = DEFAULT_PAGE) int page,
            @RequestParam(required = false, defaultValue = DEFAULT_SIZE) int size,
            @RequestParam(required = false, defaultValue = DEFAULT_SORT_BY_ISSUE) String sortBy,
            @RequestParam(required = false, defaultValue = DEFAULT_SORT_DIRECTION) String sortDirection) throws GridException {

        logRequest("/repairProfile", customViewId, search, page, size, sortBy, sortDirection);

        CustomViewByRepairProfileRequest request = new CustomViewByRepairProfileRequest();
        request.setCustomViewId(customViewId);
        request.setSearch(search);
        request.setPage(page);
        request.setSize(size);
        request.setSortBy(sortBy);
        request.setSortDirection(sortDirection);

        return executeAndLog("/repairProfile",
                () -> customViewByRepairProfileService.getCustomViewByRepairProfile(request),
                CustomViewByRepairProfileResponse::getData,
                CustomViewByRepairProfileResponse::getCurrentPage,
                CustomViewByRepairProfileResponse::getTotalPages);
    }

    /**
     * GET /api/v2/customview/swParts
     */
    @GetMapping("/swParts")
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read'})")
    public ResponseEntity<CustomViewBySwPartsResponse> getCustomViewBySwParts(
            @RequestParam String customViewId,
            @RequestParam(required = false) String search,
            @RequestParam(required = false, defaultValue = DEFAULT_PAGE) int page,
            @RequestParam(required = false, defaultValue = DEFAULT_SIZE) int size,
            @RequestParam(required = false, defaultValue = DEFAULT_SORT_BY_ISSUE) String sortBy,
            @RequestParam(required = false, defaultValue = DEFAULT_SORT_DIRECTION) String sortDirection) throws GridException {

        logRequest("/swParts", customViewId, search, page, size, sortBy, sortDirection);

        CustomViewBySwPartsRequest request = new CustomViewBySwPartsRequest();
        request.setCustomViewId(customViewId);
        request.setSearch(search);
        request.setPage(page);
        request.setSize(size);
        request.setSortBy(sortBy);
        request.setSortDirection(sortDirection);

        return executeAndLog("/swParts",
                () -> customViewBySwPartsService.getCustomViewBySwParts(request),
                CustomViewBySwPartsResponse::getData,
                CustomViewBySwPartsResponse::getCurrentPage,
                CustomViewBySwPartsResponse::getTotalPages);
    }

    /**
     * GET /api/v2/customview/fsa
     */
    @GetMapping("/fsa")
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read'})")
    public ResponseEntity<CustomViewByFsaResponse> getCustomViewByFsa(
            @RequestParam String customViewId,
            @RequestParam(required = false) String search,
            @RequestParam(required = false, defaultValue = DEFAULT_PAGE) int page,
            @RequestParam(required = false, defaultValue = DEFAULT_SIZE) int size,
            @RequestParam(required = false, defaultValue = DEFAULT_SORT_BY_ISSUE) String sortBy,
            @RequestParam(required = false, defaultValue = DEFAULT_SORT_DIRECTION) String sortDirection) throws GridException {

        logRequest("/fsa", customViewId, search, page, size, sortBy, sortDirection);

        CustomViewByFsaRequest request = new CustomViewByFsaRequest();
        request.setCustomViewId(customViewId);
        request.setSearch(search);
        request.setPage(page);
        request.setSize(size);
        request.setSortBy(sortBy);
        request.setSortDirection(sortDirection);

        return executeAndLog("/fsa",
                () -> customViewByFsaService.getCustomViewByFsa(request),
                CustomViewByFsaResponse::getData,
                CustomViewByFsaResponse::getCurrentPage,
                CustomViewByFsaResponse::getTotalPages);
    }

    /**
     * GET /api/v2/customview/refresh-status
     * Returns the last refresh status for all materialized views.
     */
    @GetMapping("/refresh-status")
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read'})")
    public ResponseEntity<List<Map<String, Object>>> getRefreshStatus() {
        LOGGER.info("CustomColumnController - GET /refresh-status");
        List<Map<String, Object>> statuses = materializedViewRefreshService.getAllRefreshStatuses();
        return ResponseEntity.ok(statuses);
    }

    /**
     * GET /api/v2/customview/hwParts
     */
    @GetMapping("/hwParts")
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read'})")
    public ResponseEntity<CustomViewByHwPartsResponse> getCustomViewByHwParts(
            @RequestParam String customViewId,
            @RequestParam(required = false) String search,
            @RequestParam(required = false, defaultValue = DEFAULT_PAGE) int page,
            @RequestParam(required = false, defaultValue = DEFAULT_SIZE) int size,
            @RequestParam(required = false, defaultValue = DEFAULT_SORT_BY_ISSUE) String sortBy,
            @RequestParam(required = false, defaultValue = DEFAULT_SORT_DIRECTION) String sortDirection) throws GridException {

        logRequest("/hwParts", customViewId, search, page, size, sortBy, sortDirection);

        CustomViewByHwPartsRequest request = new CustomViewByHwPartsRequest();
        request.setCustomViewId(customViewId);
        request.setSearch(search);
        request.setPage(page);
        request.setSize(size);
        request.setSortBy(sortBy);
        request.setSortDirection(sortDirection);

        return executeAndLog("/hwParts",
                () -> customViewByHwPartsService.getCustomViewByHwParts(request),
                CustomViewByHwPartsResponse::getData,
                CustomViewByHwPartsResponse::getCurrentPage,
                CustomViewByHwPartsResponse::getTotalPages);
    }

    /**
     * GET /api/v2/customview/launch-mat
     *
     * <p>Fetches launch data from the {@code view_by_launch_mat} materialized collection.
     * Resolves effective columns by comparing user preference activeColumns against
     * custom_column definitions. Contact columns are excluded.
     */
    @GetMapping("/launch-mat")
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read'})")
    public ResponseEntity<CustomViewByLaunchResponse> getLaunchMatView(
            @RequestParam String customViewId,
            @RequestParam(required = false) String search,
            @RequestParam(required = false, defaultValue = DEFAULT_PAGE) int page,
            @RequestParam(required = false, defaultValue = DEFAULT_SIZE) int size,
            @RequestParam(required = false, defaultValue = DEFAULT_SORT_BY_ISSUE) String sortBy,
            @RequestParam(required = false, defaultValue = DEFAULT_SORT_DIRECTION) String sortDirection) throws GridException {

        logRequest("/launch-mat", customViewId, search, page, size, sortBy, sortDirection);

        return executeAndLog("/launch-mat",
                () -> launchMatViewService.getLaunchMatView(customViewId, search, page, size, sortBy, sortDirection),
                r -> r.getData().getContent(),
                r -> r.getData().getNumber(),
                r -> r.getData().getTotalPages());
    }

    /**
     * GET /api/v2/customview/launch-mat/download
     *
     * <p>Streaming Excel download for launch materialized view data.
     * Uses a server-side cursor and SXSSFWorkbook for memory-efficient generation.
     * Uploads to GCS and returns a signed download URL.
     */
    @GetMapping("/launch-mat/download")
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read'})")
    public ResponseEntity<CustomViewDownloadResponse> downloadLaunchMatView(
            @RequestParam String customViewId,
            @RequestParam(required = false) String search) throws GridException {

        LOGGER.info("CustomColumnController - GET /launch-mat/download | customViewId: {}, search: '{}'",
                customViewId, search);

        CustomViewDownloadResponse response =
                launchMatViewService.downloadLaunchMatView(customViewId, search);

        LOGGER.info("CustomColumnController - launch-mat/download returning | fileName: {}",
                response.getFileName());

        return ResponseEntity.ok(response);
    }

    /**
     * GET /api/v2/customview/document-mat
     *
     * <p>Fetches document data from the {@code view_by_documents_mat} materialized collection.
     * Resolves effective columns by comparing user preference activeColumns against
     * custom_column definitions. Contact columns are joined post-query against leadRegion.
     */
    @GetMapping("/document-mat")
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read'})")
    public ResponseEntity<CustomViewByDocMatResponse> getDocumentMatView(
            @RequestParam String customViewId,
            @RequestParam(required = false) String search,
            @RequestParam(required = false, defaultValue = DEFAULT_PAGE) int page,
            @RequestParam(required = false, defaultValue = DEFAULT_SIZE) int size,
            @RequestParam(required = false, defaultValue = DEFAULT_SORT_BY_ISSUE) String sortBy,
            @RequestParam(required = false, defaultValue = DEFAULT_SORT_DIRECTION) String sortDirection) throws GridException {

        logRequest("/document-mat", customViewId, search, page, size, sortBy, sortDirection);

        return executeAndLog("/document-mat",
                () -> documentMatViewService.getDocumentMatView(customViewId, search, page, size, sortBy, sortDirection),
                r -> r.getData().getContent(),
                r -> r.getData().getNumber(),
                r -> r.getData().getTotalPages());
    }

    /**
     * GET /api/v2/customview/document-mat/download
     *
     * <p>Streaming Excel download for document materialized view data.
     * Uses a server-side cursor and SXSSFWorkbook for memory-efficient generation.
     * Uploads to GCS and returns a signed download URL.
     */
    @GetMapping("/document-mat/download")
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read'})")
    public ResponseEntity<CustomViewDownloadResponse> downloadDocumentMatView(
            @RequestParam String customViewId,
            @RequestParam(required = false) String search) throws GridException {

        LOGGER.info("CustomColumnController - GET /document-mat/download | customViewId: {}, search: '{}'",
                customViewId, search);

        CustomViewDownloadResponse response =
                documentMatViewService.downloadDocumentMatView(customViewId, search);

        LOGGER.info("CustomColumnController - document-mat/download returning | fileName: {}",
                response.getFileName());

        return ResponseEntity.ok(response);
    }

    /**
     * GET /api/v2/customview/hwParts-mat
     *
     * <p>Fetches HW parts data from the {@code view_by_hwParts_mat} materialized collection.
     * Resolves effective columns by comparing user preference activeColumns against
     * custom_column definitions. Contact columns are joined post-query against contactRegion.
     */
    @GetMapping("/hwParts-mat")
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read'})")
    public ResponseEntity<CustomViewByHwPartsMatResponse> getHwPartsMatView(
            @RequestParam String customViewId,
            @RequestParam(required = false) String search,
            @RequestParam(required = false, defaultValue = DEFAULT_PAGE) int page,
            @RequestParam(required = false, defaultValue = DEFAULT_SIZE) int size,
            @RequestParam(required = false, defaultValue = DEFAULT_SORT_BY_ISSUE) String sortBy,
            @RequestParam(required = false, defaultValue = DEFAULT_SORT_DIRECTION) String sortDirection) throws GridException {

        logRequest("/hwParts-mat", customViewId, search, page, size, sortBy, sortDirection);

        return executeAndLog("/hwParts-mat",
                () -> hwPartsMatViewService.getHwPartsMatView(customViewId, search, page, size, sortBy, sortDirection),
                r -> r.getData().getContent(),
                r -> r.getData().getNumber(),
                r -> r.getData().getTotalPages());
    }

    /**
     * GET /api/v2/customview/hwParts-mat/download
     *
     * <p>Streaming Excel download for HW parts materialized view data.
     * Uses a server-side cursor and SXSSFWorkbook for memory-efficient generation.
     * Uploads to GCS and returns a signed download URL.
     */
    @GetMapping("/hwParts-mat/download")
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read'})")
    public ResponseEntity<CustomViewDownloadResponse> downloadHwPartsMatView(
            @RequestParam String customViewId,
            @RequestParam(required = false) String search) throws GridException {

        LOGGER.info("CustomColumnController - GET /hwParts-mat/download | customViewId: {}, search: '{}'",
                customViewId, search);

        CustomViewDownloadResponse response =
                hwPartsMatViewService.downloadHwPartsMatView(customViewId, search);

        LOGGER.info("CustomColumnController - hwParts-mat/download returning | fileName: {}",
                response.getFileName());

        return ResponseEntity.ok(response);
    }

    /**
     * GET /api/v2/customview/software-mat
     *
     * <p>Fetches software parts data from the {@code view_by_swParts_mat} materialized collection.
     * Resolves effective columns by comparing user preference activeColumns against
     * custom_column definitions. Contact columns are joined post-query.
     */
    @GetMapping("/software-mat")
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read'})")
    public ResponseEntity<CustomViewBySwPartsMatResponse> getSwPartsMatView(
            @RequestParam String customViewId,
            @RequestParam(required = false) String search,
            @RequestParam(required = false, defaultValue = DEFAULT_PAGE) int page,
            @RequestParam(required = false, defaultValue = DEFAULT_SIZE) int size,
            @RequestParam(required = false, defaultValue = DEFAULT_SORT_BY_ISSUE) String sortBy,
            @RequestParam(required = false, defaultValue = DEFAULT_SORT_DIRECTION) String sortDirection) throws GridException {

        logRequest("/software-mat", customViewId, search, page, size, sortBy, sortDirection);

        return executeAndLog("/software-mat",
                () -> swPartsMatViewService.getSwPartsMatView(customViewId, search, page, size, sortBy, sortDirection),
                r -> r.getData().getContent(),
                r -> r.getData().getNumber(),
                r -> r.getData().getTotalPages());
    }

    /**
     * GET /api/v2/customview/software-mat/download
     *
     * <p>Streaming Excel download for software parts materialized view data.
     * Uses SXSSFWorkbook for memory-efficient generation.
     * Uploads to GCS and returns a signed download URL.
     */
    @GetMapping("/software-mat/download")
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read'})")
    public ResponseEntity<CustomViewDownloadResponse> downloadSwPartsMatView(
            @RequestParam String customViewId,
            @RequestParam(required = false) String search) throws GridException {

        LOGGER.info("CustomColumnController - GET /software-mat/download | customViewId: {}, search: '{}'",
                customViewId, search);

        CustomViewDownloadResponse response =
                swPartsMatViewService.downloadSwPartsMatView(customViewId, search);

        LOGGER.info("CustomColumnController - software-mat/download returning | fileName: {}",
                response.getFileName());

        return ResponseEntity.ok(response);
    }

    /**
     * GET /api/v2/customview/population-mat
     *
     * <p>Fetches population data from the {@code view_by_population_mat} materialized collection.
     * Resolves effective columns by comparing user preference activeColumns against
     * custom_column definitions. Contact columns are joined post-query.
     */
    @GetMapping("/population-mat")
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read'})")
    public ResponseEntity<CustomViewByPopulationMatResponse> getPopulationMatView(
            @RequestParam String customViewId,
            @RequestParam(required = false) String search,
            @RequestParam(required = false, defaultValue = DEFAULT_PAGE) int page,
            @RequestParam(required = false, defaultValue = DEFAULT_SIZE) int size,
            @RequestParam(required = false, defaultValue = DEFAULT_SORT_BY_ISSUE) String sortBy,
            @RequestParam(required = false, defaultValue = DEFAULT_SORT_DIRECTION) String sortDirection) throws GridException {

        logRequest("/population-mat", customViewId, search, page, size, sortBy, sortDirection);

        return executeAndLog("/population-mat",
                () -> populationMatViewService.getPopulationMatView(customViewId, search, page, size, sortBy, sortDirection),
                r -> r.getData().getContent(),
                r -> r.getData().getNumber(),
                r -> r.getData().getTotalPages());
    }

    /**
     * GET /api/v2/customview/population-mat/download
     *
     * <p>Streaming Excel download for population materialized view data.
     * Uses SXSSFWorkbook for memory-efficient generation.
     * Uploads to GCS and returns a signed download URL.
     */
    @GetMapping("/population-mat/download")
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read'})")
    public ResponseEntity<CustomViewDownloadResponse> downloadPopulationMatView(
            @RequestParam String customViewId,
            @RequestParam(required = false) String search) throws GridException {

        LOGGER.info("CustomColumnController - GET /population-mat/download | customViewId: {}, search: '{}'",
                customViewId, search);

        CustomViewDownloadResponse response =
                populationMatViewService.downloadPopulationMatView(customViewId, search);

        LOGGER.info("CustomColumnController - population-mat/download returning | fileName: {}",
                response.getFileName());

        return ResponseEntity.ok(response);
    }

    /**
     * GET /api/v2/customview/repair-profile-mat
     *
     * <p>Fetches repair profile data from the {@code view_by_repairProfile_mat} materialized collection.
     * Resolves effective columns by comparing user preference activeColumns against
     * custom_column definitions. Contact columns are joined post-query.
     */
    @GetMapping("/repair-profile-mat")
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read'})")
    public ResponseEntity<CustomViewByRepairProfileMatResponse> getRepairProfileMatView(
            @RequestParam String customViewId,
            @RequestParam(required = false) String search,
            @RequestParam(required = false, defaultValue = DEFAULT_PAGE) int page,
            @RequestParam(required = false, defaultValue = DEFAULT_SIZE) int size,
            @RequestParam(required = false, defaultValue = DEFAULT_SORT_BY_ISSUE) String sortBy,
            @RequestParam(required = false, defaultValue = DEFAULT_SORT_DIRECTION) String sortDirection) throws GridException {

        logRequest("/repair-profile-mat", customViewId, search, page, size, sortBy, sortDirection);

        return executeAndLog("/repair-profile-mat",
                () -> repairProfileMatViewService.getRepairProfileMatView(customViewId, search, page, size, sortBy, sortDirection),
                r -> r.getData().getContent(),
                r -> r.getData().getNumber(),
                r -> r.getData().getTotalPages());
    }

    /**
     * GET /api/v2/customview/repair-profile-mat/download
     *
     * <p>Streaming Excel download for repair profile materialized view data.
     * Uses SXSSFWorkbook for memory-efficient generation.
     * Uploads to GCS and returns a signed download URL.
     */
    @GetMapping("/repair-profile-mat/download")
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read'})")
    public ResponseEntity<CustomViewDownloadResponse> downloadRepairProfileMatView(
            @RequestParam String customViewId,
            @RequestParam(required = false) String search) throws GridException {

        LOGGER.info("CustomColumnController - GET /repair-profile-mat/download | customViewId: {}, search: '{}'",
                customViewId, search);

        CustomViewDownloadResponse response =
                repairProfileMatViewService.downloadRepairProfileMatView(customViewId, search);

        LOGGER.info("CustomColumnController - repair-profile-mat/download returning | fileName: {}",
                response.getFileName());

        return ResponseEntity.ok(response);
    }

    /**
     * GET /api/v2/customview/fsa-mat
     *
     * <p>Fetches FSA data from the {@code view_by_fsa_mat} materialized collection.
     * Resolves effective columns by comparing user preference activeColumns against
     * custom_column definitions. Contact columns are joined post-query against impactedRegion.
     */
    @GetMapping("/fsa-mat")
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read'})")
    public ResponseEntity<CustomViewByFsaMatResponse> getFsaMatView(
            @RequestParam String customViewId,
            @RequestParam(required = false) String search,
            @RequestParam(required = false, defaultValue = DEFAULT_PAGE) int page,
            @RequestParam(required = false, defaultValue = DEFAULT_SIZE) int size,
            @RequestParam(required = false, defaultValue = DEFAULT_SORT_BY_ISSUE) String sortBy,
            @RequestParam(required = false, defaultValue = DEFAULT_SORT_DIRECTION) String sortDirection) throws GridException {

        logRequest("/fsa-mat", customViewId, search, page, size, sortBy, sortDirection);

        return executeAndLog("/fsa-mat",
                () -> fsaMatViewService.getFsaMatView(customViewId, search, page, size, sortBy, sortDirection),
                r -> r.getData().getContent(),
                r -> r.getData().getNumber(),
                r -> r.getData().getTotalPages());
    }

    /**
     * GET /api/v2/customview/fsa-mat/download
     *
     * <p>Streaming Excel download for FSA materialized view data.
     * Uploads to GCS and returns a signed download URL.
     */
    @GetMapping("/fsa-mat/download")
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read'})")
    public ResponseEntity<CustomViewDownloadResponse> downloadFsaMatView(
            @RequestParam String customViewId,
            @RequestParam(required = false) String search) throws GridException {

        LOGGER.info("CustomColumnController - GET /fsa-mat/download | customViewId: {}, search: '{}'",
                customViewId, search);

        CustomViewDownloadResponse response =
                fsaMatViewService.downloadFsaMatView(customViewId, search);

        LOGGER.info("CustomColumnController - fsa-mat/download returning | fileName: {}",
                response.getFileName());

        return ResponseEntity.ok(response);
    }

    /**
     * GET /api/v2/customview/forumInvestigation/download
     *
     * <p>Streaming Excel download for forum investigation data.
     * Uploads to GCS and returns a signed download URL.
     */
    @GetMapping("/forumInvestigation/download")
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read'})")
    public ResponseEntity<CustomViewDownloadResponse> downloadForumInvestigationMatView(
            @RequestParam String customViewId,
            @RequestParam(required = false) String search) throws GridException {

        LOGGER.info("CustomColumnController - GET /forumInvestigation/download | customViewId: {}, search: '{}'",
                customViewId, search);

        CustomViewDownloadResponse response =
                forumInvestigationMatViewService.downloadForumInvestigationMatView(customViewId, search);

        LOGGER.info("CustomColumnController - forumInvestigation/download returning | fileName: {}",
                response.getFileName());

        return ResponseEntity.ok(response);
    }

    // ─── Scheduler Info & Manual Trigger ─────────────────────────────────────────

    /**
     * Returns the last completed scheduler run time, next scheduled run time, and running status.
     */
    @GetMapping("/scheduler-info")
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read'})")
    public ResponseEntity<SchedulerInfoResponse> getSchedulerInfo() {
        LOGGER.info("CustomColumnController - GET /scheduler-info");

        java.time.Instant lastRun = materializedViewScheduleTask.getLastCompletedRunTime();
        java.time.Instant nextRun = materializedViewScheduleTask.getNextScheduledRunTime();

        SchedulerInfoResponse info = SchedulerInfoResponse.builder()
                .lastCompletedRunTime(lastRun != null ? lastRun.toString() : "Never")
                .nextScheduledRunTime(nextRun != null ? nextRun.toString() : "Unknown")
                .currentlyRunning(materializedViewScheduleTask.isRunning())
                .build();

        return ResponseEntity.ok(info);
    }

    /**
     * Manually triggers a full materialized view refresh. Returns 409 if already running.
     */
    @PostMapping("/trigger-refresh")
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read'})")
    public ResponseEntity<Map<String, String>> triggerRefresh() {
        LOGGER.info("CustomColumnController - POST /trigger-refresh");

        boolean started = materializedViewScheduleTask.triggerManualRefresh();
        if (!started) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body(Map.of("status", "REJECTED", "message", "Refresh is already in progress."));
        }
        return ResponseEntity.ok(Map.of("status", "STARTED", "message", "Materialized view refresh triggered successfully."));
    }

    @GetMapping("/issue-mat")
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read'})")
    public ResponseEntity<CustomViewByIssueMatResponse> getIssueDetails(
            @RequestParam String customViewId,
            @RequestParam(required = false) String search,
            @RequestParam(required = false, defaultValue = DEFAULT_PAGE) int page,
            @RequestParam(required = false, defaultValue = DEFAULT_SIZE) int size,
            @RequestParam(required = false, defaultValue = DEFAULT_SORT_BY_ISSUE) String sortBy,
            @RequestParam(required = false, defaultValue = DEFAULT_SORT_DIRECTION) String sortDirection) {
        LOGGER.info("Start of getIssueDetails in CustomColumnController");

        CustomViewByIssueMatResponse issueDetails;
        try {
            issueDetails = issueMaterializeViewService.getIssueDetails(customViewId, search, page, size, sortBy, sortDirection);
        } catch (GridException e) {
            LOGGER.info("Exception when calling issueMaterializeViewService.getIssueDetails: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }

        return ResponseEntity.ok(issueDetails);
    }


    @GetMapping("/issue-mat/download")
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read'})")
    public ResponseEntity<CustomViewDownloadResponse> downloadIssues(@RequestParam
                                                                         String customViewId, @RequestParam(required = false) String search) throws GridException {
        LOGGER.info("Start of downloadIssues in CustomColumnController");
        LOGGER.info("Custom view id:{}", customViewId);
        LOGGER.info("Search Key:{}", search);

        CustomViewDownloadResponse customViewDownloadResponse = issueMaterializeViewService.downloadIssueMatView(customViewId, search);
        LOGGER.info("Download file name:{}", customViewDownloadResponse.getFileName());
        LOGGER.info("Download file URL:{}", customViewDownloadResponse.getSignedUrl());

        return ResponseEntity.ok(customViewDownloadResponse);
    }
}
