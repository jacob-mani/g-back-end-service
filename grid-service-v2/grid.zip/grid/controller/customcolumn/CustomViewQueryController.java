package com.ford.grid.controller.customcolumn;

import com.ford.grid.exception.GridException;
import com.ford.grid.model.dto.response.CustomViewDownloadResponse;
import com.ford.grid.model.dto.response.customcolumn.viewbyemm.CustomViewByEmmResponse;
import com.ford.grid.model.dto.response.customcolumn.viewbytrg.CustomViewByTrgResponse;
import com.ford.grid.service.customcolumn.viewbyemm.EmmViewService;
import com.ford.grid.service.customcolumn.viewbytrg.TrgViewService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

/**
 * REST Controller for custom views using direct MongoDB aggregation queries.
 *
 * <p>This controller provides endpoints for custom views that use direct query approach
 * instead of materialized views. This pattern is more suitable for views that:
 * <ul>
 *   <li>Need real-time data without scheduler delays</li>
 *   <li>Combine data from multiple collections dynamically</li>
 *   <li>Have complex filtering/enrichment requirements</li>
 * </ul>
 *
 * <p>Supported views:
 * <ul>
 *   <li><b>TRG View</b> - Combines issue-level and population-level TRG schedule data</li>
 *   <li><i>Future views can be added here following the same pattern</i></li>
 * </ul>
 */
@RestController
@RequestMapping("/api/v2/customviewv2")
@RequiredArgsConstructor
@Tag(name = "Custom View Query API", description = "Custom view endpoints using direct MongoDB aggregation queries")
public class CustomViewQueryController {

    private static final Logger logger = LoggerFactory.getLogger(CustomViewQueryController.class);

    private static final String DEFAULT_PAGE = "0";
    private static final String DEFAULT_SIZE = "10";
    private static final String DEFAULT_SORT_DIRECTION = "ASC";
    private static final String DEFAULT_SORT_BY = "issueNumber";

    private final TrgViewService trgViewService;
    private final EmmViewService emmViewService;

    // =========================================================================
    // TRG View Endpoints
    // =========================================================================

    /**
     * GET /api/v2/customview/trg
     *
     * <p>Fetches TRG data based on the custom view configuration.
     * Combines data from both issue-level (issue_trg_schedule) and
     * population-level (trg_schedule) collections.
     *
     * @param customViewId   mandatory — _id of the user_custom_preferences document
     * @param search         optional free-text search string
     * @param page           zero-based page number (default: 0)
     * @param size           records per page (default: 10)
     * @param sortBy         field to sort by (default: issueNumber)
     * @param sortDirection  ASC or DESC (default: ASC)
     * @return paginated TRG data with custom view metadata
     */
    @GetMapping("/trg")
    @Operation(summary = "Get TRG Custom View Data",
            description = "Fetches paginated TRG data from issue-level and population-level collections using direct aggregation")
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read'})")
    public ResponseEntity<CustomViewByTrgResponse> getTrgCustomView(
            @RequestParam String customViewId,
            @RequestParam(required = false) String search,
            @RequestParam(required = false, defaultValue = DEFAULT_PAGE) int page,
            @RequestParam(required = false, defaultValue = DEFAULT_SIZE) int size,
            @RequestParam(required = false, defaultValue = DEFAULT_SORT_BY) String sortBy,
            @RequestParam(required = false, defaultValue = DEFAULT_SORT_DIRECTION) String sortDirection)
            throws GridException {

        logger.info("[CustomViewQuery] TRG GET — customViewId={}, search='{}', page={}, size={}, sortBy={}, sortDir={}",
                customViewId, search, page, size, sortBy, sortDirection);

        CustomViewByTrgResponse response = trgViewService.getTrgDetails(
                customViewId, search, page, size, sortBy, sortDirection);

        logger.info("[CustomViewQuery] TRG — Returning {} records, page {}/{}, total {}",
                response.getData().getContent().size(),
                response.getData().getNumber() + 1,
                response.getData().getTotalPages(),
                response.getData().getTotalElements());

        return ResponseEntity.ok(response);
    }

    /**
     * GET /api/v2/customview/trg/download
     *
     * <p>Downloads all TRG data as an Excel file based on the custom view configuration.
     * Uses streaming approach to handle large datasets efficiently.
     *
     * @param customViewId mandatory — _id of the user_custom_preferences document
     * @param search       optional free-text search string
     * @return download response with fileName and signedUrl to the generated Excel file
     */
    @GetMapping("/trg/download")
    @Operation(summary = "Download TRG Custom View Data",
            description = "Downloads all TRG data as an Excel file using direct aggregation")
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read'})")
    public ResponseEntity<CustomViewDownloadResponse> downloadTrgCustomView(
            @RequestParam String customViewId,
            @RequestParam(required = false) String search) throws GridException {

        logger.info("[CustomViewQuery] TRG DOWNLOAD — customViewId={}, search='{}'", customViewId, search);

        CustomViewDownloadResponse response = trgViewService.downloadTrgView(customViewId, search);

        logger.info("[CustomViewQuery] TRG Download generated: {}", response.getFileName());

        return ResponseEntity.ok(response);
    }

    // =========================================================================
    // EMM View Endpoints
    // =========================================================================

    /**
     * GET /api/v2/customviewv2/emm
     *
     * <p>Fetches EMM data based on the custom view configuration.
     * Queries emm_schedule collection using direct aggregation.
     */
    @GetMapping("/emm")
    @Operation(summary = "Get EMM Custom View Data",
            description = "Fetches paginated EMM data from emm_schedule collection using direct aggregation")
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read'})")
    public ResponseEntity<CustomViewByEmmResponse> getEmmCustomView(
            @RequestParam String customViewId,
            @RequestParam(required = false) String search,
            @RequestParam(required = false, defaultValue = DEFAULT_PAGE) int page,
            @RequestParam(required = false, defaultValue = DEFAULT_SIZE) int size,
            @RequestParam(required = false, defaultValue = DEFAULT_SORT_BY) String sortBy,
            @RequestParam(required = false, defaultValue = DEFAULT_SORT_DIRECTION) String sortDirection)
            throws GridException {

        logger.info("[CustomViewQuery] EMM GET — customViewId={}, search='{}', page={}, size={}, sortBy={}, sortDir={}",
                customViewId, search, page, size, sortBy, sortDirection);

        CustomViewByEmmResponse response = emmViewService.getEmmDetails(
                customViewId, search, page, size, sortBy, sortDirection);

        logger.info("[CustomViewQuery] EMM — Returning {} records, page {}/{}, total {}",
                response.getData().getContent().size(),
                response.getData().getNumber() + 1,
                response.getData().getTotalPages(),
                response.getData().getTotalElements());

        return ResponseEntity.ok(response);
    }

    /**
     * GET /api/v2/customviewv2/emm/download
     *
     * <p>Downloads all EMM data as an Excel file based on the custom view configuration.
     */
    @GetMapping("/emm/download")
    @Operation(summary = "Download EMM Custom View Data",
            description = "Downloads all EMM data as an Excel file using direct aggregation")
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read'})")
    public ResponseEntity<CustomViewDownloadResponse> downloadEmmCustomView(
            @RequestParam String customViewId,
            @RequestParam(required = false) String search) throws GridException {

        logger.info("[CustomViewQuery] EMM DOWNLOAD — customViewId={}, search='{}'", customViewId, search);

        CustomViewDownloadResponse response = emmViewService.downloadEmmView(customViewId, search);

        logger.info("[CustomViewQuery] EMM Download generated: {}", response.getFileName());

        return ResponseEntity.ok(response);
    }
}
