package com.ford.grid.controller.dashboard;

import com.ford.grid.model.dto.request.dashboard.AdvancedFilter;
import com.ford.grid.model.dto.response.dashboard.CustomColumnsResponse;
import com.ford.grid.model.dto.response.dashboard.UserPreferenceResponse;
import com.ford.grid.service.dashboard.CustomViewService;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v2/custom")
@RequiredArgsConstructor
public class CustomViewController {
    private static final Logger LOGGER = LoggerFactory.getLogger(CustomViewController.class);
    private final CustomViewService customViewService;

    /**
     * Endpoint to retrieve all applicable custom columns for the dashboard.
     *
     * @return ResponseEntity containing a list of CustomColumnsResponse objects.
     */
    @GetMapping(value = "/allColumns")
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read'})")
    public ResponseEntity<List<CustomColumnsResponse>> getAllApplicableCustomColumns() {
        LOGGER.info("Start of getAllApplicableCustomColumns method in CustomViewController");
        return ResponseEntity.ok(customViewService.getAllApplicableCustomColumns());
    }

    /**
     * Endpoint to retrieve applicable custom columns for issue numbers.
     *
     * @return ResponseEntity containing a list of CustomColumnsResponse objects for issue numbers.
     */
    @GetMapping("/issueListColumns")
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read'})")
    public ResponseEntity<List<CustomColumnsResponse>> issueListColumns() {
        return ResponseEntity.ok(customViewService.getApplicableColumnsForIssueNumber());
    }

    /**
     * Endpoint to retrieve applicable custom columns for FSA numbers.
     *
     * @return ResponseEntity containing a list of CustomColumnsResponse objects for FSA numbers.
     */
    @GetMapping("/fsaListColumns")
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read'})")
    public ResponseEntity<List<CustomColumnsResponse>> fsaListColumns() {
        return ResponseEntity.ok(customViewService.getApplicableColumnsForFSANumber());
    }

    /**
     * Endpoint to save advanced filters for the dashboard.
     *
     * @param advancedFilters List of AdvancedFilter objects to be saved.
     * @return ResponseEntity containing a UserPreferenceResponse object with the saved preferences.
     */
    @PostMapping
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:IssueList','update')")
    public ResponseEntity<UserPreferenceResponse> saveAdvancedFilters(@RequestBody List<AdvancedFilter> advancedFilters) {
        LOGGER.info("Start of saveAdvancedFilters method in CustomViewController");
        return ResponseEntity.ok(customViewService.saveAdvancedFilters(advancedFilters));
    }

    /**
     * Endpoint to retrieve user preferences for the dashboard, including row count and advanced filters.
     *
     * @return ResponseEntity containing a UserPreferenceResponse object with the user preferences.
     */
    @GetMapping
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:MyIssuesList':'read'})")
    public ResponseEntity<UserPreferenceResponse> getUserPreference() {
        LOGGER.info("Start of getUserPreference method in CustomViewController");
        return ResponseEntity.ok(customViewService.getUserPreference());
    }

    /**
     * Endpoint to save user preferences for the dashboard, including row count and advanced filters.
     *
     * @param rowCount The number of rows to be displayed in the dashboard.
     * @return ResponseEntity containing a UserPreferenceResponse object with the saved preferences.
     */
    @PostMapping("/saveUserPreference/{rowCount}")
    @PreAuthorize("@gridAuthorizeService.isAuthorized({'GRID:IssueList':'update'})")
    public ResponseEntity<UserPreferenceResponse> saveUserPreference(@PathVariable int rowCount) {
        return ResponseEntity.ok(customViewService.saveUserPreference(rowCount));
    }
}