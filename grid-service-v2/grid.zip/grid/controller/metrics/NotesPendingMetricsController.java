package com.ford.grid.controller.metrics;

import com.ford.grid.common.SystemWideResponses;
import com.ford.grid.exception.GridException;
import com.ford.grid.model.dto.response.metrics.ApproverStageCountResponse;
import com.ford.grid.model.dto.response.metrics.NotesPendingApprovalRowResponse;
import com.ford.grid.model.dto.response.metrics.NotesPendingOverviewResponse;
import com.ford.grid.service.metrics.NotesPendingMetricsService;
import io.swagger.v3.oas.annotations.Operation;
import lombok.AllArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Metrics for the CCRG (forumType=1) / PIR (forumType=6) Notes Pending review workflow.
 */
@RestController
@RequestMapping("/api/v2/metrics/notes-pending")
@AllArgsConstructor
public class NotesPendingMetricsController {

    private final NotesPendingMetricsService notesPendingMetricsService;

    @GetMapping("/overview")
    @Operation(summary = "Notes Pending overview", description = "Total issues, total issues in the selected forum, and forum status breakdown. Optionally restricted by region(s)/issue number(s).")
    @SystemWideResponses
    public ResponseEntity<NotesPendingOverviewResponse> getOverview(
            @RequestParam(defaultValue = "1") String forumType,
            @RequestParam(required = false) List<String> leadRegions,
            @RequestParam(required = false) List<String> issueNumbers) throws GridException {
        return ResponseEntity.ok(notesPendingMetricsService.getOverview(forumType, leadRegions, issueNumbers));
    }

    @GetMapping("/approver-stage-summary")
    @Operation(summary = "Notes Pending approver stage summary", description = "Count of issues currently blocked at each approver stage, for the graph. Optionally restricted by approver name(s)/region(s)/issue number(s).")
    @SystemWideResponses
    public ResponseEntity<List<ApproverStageCountResponse>> getApproverStageSummary(
            @RequestParam(defaultValue = "1") String forumType,
            @RequestParam(required = false) List<String> approverNames,
            @RequestParam(required = false) List<String> leadRegions,
            @RequestParam(required = false) List<String> issueNumbers) throws GridException {
        return ResponseEntity.ok(notesPendingMetricsService.getApproverStageSummary(forumType, approverNames, leadRegions, issueNumbers));
    }

    @GetMapping("/approver-names")
    @Operation(summary = "Notes Pending approver names", description = "Distinct, sorted approver names currently in the Notes Pending table — used to populate the Approver filter dropdown.")
    @SystemWideResponses
    public ResponseEntity<List<String>> getApproverNames(
            @RequestParam(defaultValue = "1") String forumType) throws GridException {
        return ResponseEntity.ok(notesPendingMetricsService.getApproverNames(forumType));
    }

    @GetMapping("/issue-numbers-by-contact")
    @Operation(summary = "Issue numbers by contact", description = "Resolves issue numbers (from issue_contacts) where the given contact-type/role is assigned to the given cdsid, restricted to issues in the given lead region. Used by the Filter Report's Region + Contact Type + Name combo.")
    @SystemWideResponses
    public ResponseEntity<List<String>> getIssueNumbersByContact(
            @RequestParam String leadRegion,
            @RequestParam String contactType,
            @RequestParam String cdsid) throws GridException {
        return ResponseEntity.ok(notesPendingMetricsService.getIssueNumbersByContact(leadRegion, contactType, cdsid));
    }

    @GetMapping("/approval-table")
    @Operation(summary = "Notes Pending approval table", description = "Paginated, sortable rows — one row per reached approver stage per issue currently in Notes Pending / Pending Regulator Alignment. Optionally filter to a single approver stage's currently-pending rows, and/or by multi-select Region/Approver Stage/Approver dropdowns, and/or by a resolved issue number list.")
    @SystemWideResponses
    public ResponseEntity<Page<NotesPendingApprovalRowResponse>> getApprovalTable(
            @RequestParam(defaultValue = "1") String forumType,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "issueNumber") String sortBy,
            @RequestParam(defaultValue = "asc") String sortDirection,
            @RequestParam(required = false) String approverStage,
            @RequestParam(required = false) List<String> approverStages,
            @RequestParam(required = false) List<String> approverNames,
            @RequestParam(required = false) List<String> leadRegions,
            @RequestParam(required = false) List<String> issueNumbers) throws GridException {
        return ResponseEntity.ok(notesPendingMetricsService.getApprovalTable(forumType, page, size, sortBy, sortDirection, approverStage,
                approverStages, approverNames, leadRegions, issueNumbers));
    }

    @GetMapping("/approval-table/download")
    @Operation(summary = "Download Notes Pending approval table", description = "Full (non-paginated) approval table as an xlsx or csv download. Optionally filter to a single approver stage's currently-pending rows, and/or by multi-select Region/Approver Stage/Approver dropdowns, and/or by a resolved issue number list.")
    @SystemWideResponses
    public ResponseEntity<StreamingResponseBody> downloadApprovalTable(
            @RequestParam(defaultValue = "1") String forumType,
            @RequestParam(defaultValue = "issueNumber") String sortBy,
            @RequestParam(defaultValue = "asc") String sortDirection,
            @RequestParam(defaultValue = "xlsx") String format,
            @RequestParam(required = false) String approverStage,
            @RequestParam(required = false) List<String> approverStages,
            @RequestParam(required = false) List<String> approverNames,
            @RequestParam(required = false) List<String> leadRegions,
            @RequestParam(required = false) List<String> issueNumbers) throws GridException {
        byte[] fileBytes = notesPendingMetricsService.downloadApprovalTable(forumType, sortBy, sortDirection, format, approverStage,
                approverStages, approverNames, leadRegions, issueNumbers);

        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
        String forumLabel = "6".equals(forumType) ? "PIR" : "CCRG";
        boolean isCsv = "csv".equalsIgnoreCase(format);
        String fileName = "NotesPending_" + forumLabel + "_" + timestamp + (isCsv ? ".csv" : ".xlsx");
        String contentType = isCsv ? "text/csv"
                : "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

        StreamingResponseBody stream = outputStream -> outputStream.write(fileBytes);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fileName + "\"")
                .header("Access-Control-Expose-Headers", "Content-Disposition")
                .contentType(MediaType.parseMediaType(contentType))
                .body(stream);
    }
}
