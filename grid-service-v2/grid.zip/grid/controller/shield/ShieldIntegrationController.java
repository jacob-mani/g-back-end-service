package com.ford.grid.controller.shield;

import com.ford.grid.common.SystemWideResponses;
import com.ford.grid.exception.GridException;
import com.ford.grid.model.dto.request.shield.ShieldCreateIssueRequest;
import com.ford.grid.model.dto.response.IssueResponse;
import com.ford.grid.service.ShieldIntegrationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * REST controller for SHIELD third-party system integration.
 * Exposed without OAuth2 authentication (permitAll) for system-to-system calls.
 */
@RestController
@RequestMapping("/api/shield")
@RequiredArgsConstructor
@Tag(name = "SHIELD Integration", description = "APIs for SHIELD third-party system to create issues in GRID")
public class ShieldIntegrationController {

    private static final Logger LOGGER = LoggerFactory.getLogger(ShieldIntegrationController.class);

    private final ShieldIntegrationService shieldIntegrationService;

    @PostMapping(value = "/createIssue", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @Operation(summary = "Create Issue from SHIELD",
            description = "Creates an issue with CCRG forum and investigation analysis data from SHIELD system",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    description = "Shield issue creation request payload",
                    required = true,
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = ShieldCreateIssueRequest.class),
                            examples = @ExampleObject(name = "CreateIssueExample",
                                    summary = "Sample SHIELD create issue request",
                                    value = "{\"openedDate\":\"2024-01-15\",\"issueTitle\":\"Engine misfire under load\","
                                            + "\"issueDescription\":\"Intermittent engine misfire reported under high load conditions\","
                                            + "\"leadRegion\":\"NA\",\"segment\":\"Trucks\",\"causalTypes\":[1],"
                                            + "\"forumType\":\"1\",\"agency\":\"NHTSA\","
                                            + "\"forumOpenDate\":\"2024-01-20\",\"alertId\":\"ALERT-2024-001\","
                                            + "\"vehicleInfo\":[{\"modelYear\":[2024],\"brand\":\"Ford\",\"vehicleLine\":\"Explorer\"}],"
                                            + "\"status\":\"OPEN\",\"createdBy\":\"user@ford.com\"}"))))
    @ApiResponse(responseCode = "201", description = "Issue created successfully",
            content = @Content(mediaType = "application/json",
                    schema = @Schema(implementation = IssueResponse.class)))
    @SystemWideResponses
    public ResponseEntity<IssueResponse> createIssueFromShield(
            @Valid @RequestBody ShieldCreateIssueRequest request) throws GridException {
        LOGGER.info("SHIELD - Create Issue request received. AlertId: {}, Title: {}",
                request.getAlertId(), request.getIssueTitle());

        IssueResponse response = shieldIntegrationService.createIssueFromShield(request);

        LOGGER.info("SHIELD - Create Issue completed. IssueNumber: {}, AlertId: {}",
                response.getIssueNumber(), request.getAlertId());
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }
}

