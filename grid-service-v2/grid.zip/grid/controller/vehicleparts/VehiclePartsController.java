package com.ford.grid.controller.vehicleparts;

import com.ford.grid.exception.GridException;
import com.ford.grid.model.dto.request.vehicleparts.*;
import com.ford.grid.model.entity.vehicleparts.VehicleLineProfile;
import com.ford.grid.service.VehiclePartsService;
import com.ford.grid.service.impl.vfd.VFDService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v2/vehicle-parts/profile")
public class VehiclePartsController {
    private static final Logger LOGGER = LoggerFactory.getLogger(VehiclePartsController.class);
    private final VehiclePartsService vehiclePartsService;
    private final VFDService vfdService;

    /**
     * Retrieves vehicle parts details based on the provided population ID.
     *
     * @param populationId the population ID for which to retrieve vehicle parts details
     * @return ResponseEntity containing DefineProfileDetails
     */
    @GetMapping("{populationId}")
    public ResponseEntity<DefineProfileDetails> getVehiclePartsDetails(@PathVariable String populationId) {
        LOGGER.info("Start of getVehiclePartsDetails in VehiclePartsController : {}", populationId);
        return ResponseEntity.ok(vehiclePartsService.getVehiclePartsDetails(populationId));
    }

    /**
     * Retrieves vehicle profile details based on the provided population ID and profile name.
     *
     * @param populationId the population ID
     * @param profileId    the profile ID
     * @return ResponseEntity containing VehicleLineProfileDTO
     */
    @GetMapping("{populationId}/{profileId}")
    public ResponseEntity<VehicleLineProfileDTO> getVehicleProfileDetailsByProfileId(@PathVariable String populationId, @PathVariable String profileId) {
        LOGGER.info("Start of getVehicleProfileDetailsByProfileId in VehiclePartsController : {}, {}", populationId, profileId);

        try {
            return ResponseEntity.ok(vehiclePartsService.getVehicleProfileDetails(populationId, profileId));
        } catch (GridException gridException) {
            LOGGER.info("Exception in getVehicleProfileDetails: {}", gridException.getMessage());
            return ResponseEntity.status(gridException.getStatus()).body(null);
        }
    }

    /**
     * Retrieves vehicle profile data based on the provided VehicleProfileRequest.
     *
     * @param vehicleProfileRequest the request containing parameters to fetch vehicle profile data
     * @return ResponseEntity containing a list of vehicle profile data
     */
    @PostMapping("/vehicle-selection")
    public ResponseEntity<List<ProfileDetailKeyValue>> getVehicleProfile(@RequestBody VehicleProfileRequest vehicleProfileRequest) {
        LOGGER.info("Start of getVehicleProfile in VehiclePartsController");
        LOGGER.info("VehiclePartsDTO received: {}", vehicleProfileRequest);
        return ResponseEntity.ok(vehiclePartsService.getDataVehicleProfile(vehicleProfileRequest));
    }

    /**
     * Saves profile data based on the provided DefineProfileRequest.
     *
     * @param profileRequest the request containing profile data to be saved
     * @return ResponseEntity with appropriate status and message
     */
    @PostMapping
    public ResponseEntity<?> saveProfileData(@Valid @RequestBody DefineProfileRequest profileRequest) {
        LOGGER.info("Start of saveProfileData in VehiclePartsController");
        LOGGER.info("DefineProfileRequest received: {}", profileRequest);

        final String multipleRepairs = profileRequest.getMultipleRepairs();
        if (StringUtils.isBlank(multipleRepairs))
            return ResponseEntity.badRequest().body(null);

        try {
            if (StringUtils.equalsAnyIgnoreCase("Y", multipleRepairs)) {
                LOGGER.info("Saving profile data with multiple repairs enabled for selected Regions.");

                VehicleLineProfile vehicleLineProfile = vehiclePartsService.saveProfileData(profileRequest);
                List<VehicleLineProfileDTO> profileDetails = vehiclePartsService.getProfileDetails(vehicleLineProfile.getVernNumber(), vehicleLineProfile.getRevision(), vehicleLineProfile.getPopulationId());
                return ResponseEntity.status(HttpStatus.CREATED).body(profileDetails);
            } else if (StringUtils.equalsAnyIgnoreCase("N", multipleRepairs)) {
                LOGGER.info("Saving profile for all the regions");

                VehicleLineProfile vehicleLineProfile = vehiclePartsService.saveProfileDataForAllRegions(profileRequest);
                List<VehicleLineProfileDTO> profileDetails = vehiclePartsService.getProfileDetails(vehicleLineProfile.getVernNumber(), vehicleLineProfile.getRevision(), vehicleLineProfile.getPopulationId());
                return ResponseEntity.status(HttpStatus.CREATED).body(profileDetails);
            } else {
                LOGGER.info("WERS only profile save flow");
                vfdService.saveVFDProfileData(profileRequest);
                List<VehicleLineProfileDTO> profileDetails = vfdService.mapEntityToDTO(profileRequest.getPopulationId());
                return ResponseEntity.status(HttpStatus.CREATED).body(profileDetails);
            }
        } catch (GridException gridException) {
            final String message = gridException.getMessage();
            LOGGER.info("Exception in saveProfileData: {}", message);
            return ResponseEntity.status(gridException.getStatus()).body(gridException.getDescription());
        }
    }

    /**
     * Deletes profile data based on the provided profile ID.
     *
     * @param profileId the profile ID for which to delete profile data
     * @return ResponseEntity with appropriate status and message
     */
    @DeleteMapping("/{profileId}")
    public ResponseEntity<String> deleteProfileData(@PathVariable("profileId") String profileId) {
        LOGGER.info("Start of deleteProfileData in VehiclePartsController for profileId: {}", profileId);

        if (vehiclePartsService.deleteProfileData(profileId) > 0)
            return ResponseEntity.ok("Profile data deleted successfully for profileId: " + profileId);
        else
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to delete profile data for profileId: " + profileId);
    }

    /**
     * Updates profile data based on the provided DefineProfileRequest.
     *
     * @param profileRequest the request containing profile data to be updated
     * @return ResponseEntity containing updated profile details
     */
    @PutMapping
    public ResponseEntity<?> updateProfileData(@Valid @RequestBody DefineProfileRequest profileRequest) {
        LOGGER.info("Start of updateProfileData in VehiclePartsController");
        LOGGER.info("Update Profile request payload : {}", profileRequest);

        VehicleLineProfile vehicleLineProfile;
        final String multipleRepairs = profileRequest.getMultipleRepairs();
        LOGGER.info("multipleRepairs received: {}", multipleRepairs);
        try {
            if (StringUtils.equalsAnyIgnoreCase("Y", multipleRepairs)) {
                LOGGER.info("Updating profile data with multiple repairs enabled for selected Regions.");
                vehicleLineProfile = vehiclePartsService.updateProfileDataForSelectedRegions(profileRequest);
                List<VehicleLineProfileDTO> profileDetails = vehiclePartsService.getProfileDetails(vehicleLineProfile.getVernNumber(), vehicleLineProfile.getRevision(), vehicleLineProfile.getPopulationId());
                LOGGER.info("Update Profile response for Selected regions: {}", profileDetails);

                return ResponseEntity.status(HttpStatus.OK).body(profileDetails);
            } else if (StringUtils.equalsAnyIgnoreCase("N", multipleRepairs)) {
                LOGGER.info("Updating profile for all the regions");
                vehicleLineProfile = vehiclePartsService.updateProfileDataForAllRegions(profileRequest);
                List<VehicleLineProfileDTO> profileDetails = vehiclePartsService.getProfileDetails(vehicleLineProfile.getVernNumber(), vehicleLineProfile.getRevision(), vehicleLineProfile.getPopulationId());
                LOGGER.info("Update Profile response for All regions: {}", profileDetails);

                return ResponseEntity.status(HttpStatus.OK).body(profileDetails);
            } else {
                LOGGER.info("Update VFD profile");
                vfdService.updateProfileData(profileRequest);
                List<VehicleLineProfileDTO> vehicleLineProfileDTOS = vfdService.mapEntityToDTO((profileRequest.getPopulationId()));
                return ResponseEntity.ok(vehicleLineProfileDTOS);
            }
        } catch (GridException gridException) {
            LOGGER.error("Exception while updating profile data: {}", gridException.getMessage());
            return ResponseEntity.status(gridException.getStatus()).body(gridException.getMessage());
        }
    }


    /**
     * Matches VERN number for a given population ID.
     * Updates VERN number and revision in VehicleLineProfiles and resets CalculateParts.
     *
     * @param populationId the population ID
     * @return ResponseEntity with success message
     */
    @PutMapping("/matchVernNumber/{populationId}")
    public ResponseEntity<String> matchVernNumber(@PathVariable("populationId") final String populationId) {
        LOGGER.info("Start of matchVernNumber in VehiclePartsController for populationId: {}", populationId);
        String result = vehiclePartsService.matchVernNumber(populationId);
        LOGGER.info("End of matchVernNumber in VehiclePartsController for populationId: {}", populationId);
        return ResponseEntity.ok(result);
    }

    @PutMapping("/edit-profile")
    public ResponseEntity<VFDProfileEditResponse> editProfile(@RequestBody ProfileRequest profileRequest) {
        LOGGER.info("Start of editProfile in VehiclePartsController for profileId: {}", profileRequest);
        return ResponseEntity.ok(vehiclePartsService.editProfile(profileRequest));
    }

    @PutMapping("/reset-edit-profile")
    public void resetEditProfile(@RequestBody ProfileRequest profileRequest) {
        LOGGER.info("Start of resetEditProfile in VehiclePartsController for profileId: {}", profileRequest);
        vehiclePartsService.resetEditProfile(profileRequest);
    }
}