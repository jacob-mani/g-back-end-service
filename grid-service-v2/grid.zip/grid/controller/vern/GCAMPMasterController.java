package com.ford.grid.controller.vern;

import com.ford.grid.model.dto.response.AgencyInfo;
import com.ford.grid.model.dto.response.LeadRegionsResponse;
import com.ford.grid.model.dto.response.vern.GCAMPLeadRegionResponse;
import com.ford.grid.service.GRIDMasterService;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("api/master")
public class GCAMPMasterController {
    private static final Logger LOGGER = LoggerFactory.getLogger(GCAMPMasterController.class);
    private final GRIDMasterService gridMasterService;

    /**
     * API to get Lead Regions along with their agencies
     *
     * @return List of GCAMPLeadRegionResponse
     */
    @GetMapping("/lead-regions")
    public ResponseEntity<List<GCAMPLeadRegionResponse>> getLeadRegions() {
        LOGGER.info("Start of getLeadRegions method in GCAMPMasterController");

        List<LeadRegionsResponse> leadRegions = gridMasterService.getLeadRegions();
        List<GCAMPLeadRegionResponse> leadRegionResponses = leadRegions.stream().map(region ->
                GCAMPLeadRegionResponse.builder()
                        .key(region.getKey())
                        .value(region.getValue())
                        .agencies(region.getAgencies().stream().map(AgencyInfo::getValue).toList())
                        .build()
        ).toList();
        LOGGER.info("leadRegionResponses: {}", leadRegionResponses);
        LOGGER.info("End of getLeadRegions method in GCAMPMasterController");

        return ResponseEntity.ok(leadRegionResponses);
    }
}