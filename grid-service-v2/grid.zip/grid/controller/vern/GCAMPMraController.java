package com.ford.grid.controller.vern;

import com.ford.grid.common.SystemWideResponses;
import com.ford.grid.model.dto.request.MraDetailsRequest;
import com.ford.grid.model.dto.response.vern.MraDetailsResponse;
import com.ford.grid.service.impl.vern.VernResponseService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@RequestMapping(value = "api/mra", produces = MediaType.APPLICATION_JSON_VALUE)
public class GCAMPMraController {
    private static final Logger LOGGER = LoggerFactory.getLogger(GCAMPMraController.class);
    private final VernResponseService vernResponseService;
    /**
     * Endpoint to fetch MRA details for given FSA numbers.
     *
     * @param request the MRA details request containing fsaNos and optional vehicles
     * @return ResponseEntity containing MraDetailsResponse or 404 if no FSAs found
     */
    @PostMapping(value = "byFsa", consumes = MediaType.APPLICATION_JSON_VALUE)
    @SystemWideResponses
    @Operation(summary = "Get MRA Details", description = "Fetch MRA details for the given FSA numbers",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    description = "MRA details request with FSA numbers",
                    required = true,
                    content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                            schema = @Schema(implementation = MraDetailsRequest.class),
                            examples = @ExampleObject(name = "MRA Request",
                                    value = "{\"fsaNos\": [\"24S01\", \"24S02\"], \"vehicles\": [{\"modelYear\": 2024, \"brandName\": \"Ford\", \"vehicleLine\": \"F-150\"}]}"))),
            responses = {
                    @ApiResponse(responseCode = "200", description = "MRA details retrieved successfully",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = MraDetailsResponse.class)))
            })
    public ResponseEntity<MraDetailsResponse> getMraDetails(@Valid @RequestBody MraDetailsRequest request) {
        LOGGER.info("Received MRA details request for FSAs: {}", request.getFsaNos());
        MraDetailsResponse response = vernResponseService.getMraDetails(request);
        if (response == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        return ResponseEntity.ok(response);
    }
}
