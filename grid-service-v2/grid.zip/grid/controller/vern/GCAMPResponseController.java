package com.ford.grid.controller.vern;

import com.ford.grid.common.SystemWideResponses;
import com.ford.grid.exception.GridException;
import com.ford.grid.mapper.vern.VernObjectMapper;
import com.ford.grid.model.dto.request.vern.FSATypeResponseModel;
import com.ford.grid.model.dto.request.vern.LocalFsaModel;
import com.ford.grid.model.dto.request.vfd.VFDResponseModel;
import com.ford.grid.model.dto.response.SignedURLResponse;
import com.ford.grid.model.dto.response.vern.*;
import com.ford.grid.service.ISignedURLService;
import com.ford.grid.service.VernRequestService;
import com.ford.grid.service.impl.vern.VernMailService;
import com.ford.grid.service.impl.vern.VernRequestServiceImpl;
import com.ford.grid.service.impl.vern.VernResponseService;
import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.MapUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.Map;

import static com.ford.grid.constants.VERNConstants.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("api/gcamp/response")
public class GCAMPResponseController {
    private static final Logger LOGGER = LoggerFactory.getLogger(GCAMPResponseController.class);
    private final VernObjectMapper vernObjectMapper;
    private final VernMailService vernMailService;
    private final VernResponseService vernResponseService;
    private final ISignedURLService signedURLService;
    private final VernRequestService vernRequestService;

    /**
     * Endpoint to process VERN response details.
     *
     * @param responseModelDTO the VERN response model DTO
     * @return ResponseEntity containing GCAMPResponse
     */
    @PutMapping("vern")
    public ResponseEntity<GCAMPResponse> vernDetails(@RequestBody VernResponseModelDTO responseModelDTO) {
        LOGGER.info("Start of get vern details for the vern number:{}", responseModelDTO.getVernNumber());
        LOGGER.info("Received VERN response: {}", responseModelDTO);

        GCAMPResponse gcampResponse;
        try {
            final String vernNumber = responseModelDTO.getVernNumber();
            VernResponseModel vernResponseModel = vernObjectMapper.toVernResponseModel(responseModelDTO);
            gcampResponse = vernResponseService.processVERNResponse(vernResponseModel);

            //Notify ASO with VERN status and send email
            final int gridSequence = responseModelDTO.getGridSequence();
            String sequenceId;
            if (gridSequence < 10) {
                sequenceId = "00" + gridSequence;
            } else if (gridSequence < 100) {
                sequenceId = "0" + gridSequence;
            } else {
                sequenceId = String.valueOf(gridSequence);
            }
            final String issueNumber = responseModelDTO.getGridYearId() + "-" + sequenceId;
            LOGGER.info("Issue Number for VERN response email: {}", issueNumber);

            //Notify ASO with VERN status and send email
            Map<String, String> issueDetails = vernMailService.notifyASOWithVERNStatus(issueNumber, vernNumber);
            if (MapUtils.isNotEmpty(issueDetails)) {
                issueDetails.put(VERN_NUMBER, vernNumber);
                issueDetails.put(VERN_GLOBAL_FSA_NUMBER, String.valueOf(responseModelDTO.getGlobalFSANumber()));
                issueDetails.put(VERN_SUPPLEMENT_ID, responseModelDTO.getSupplementId());
            } else {
                issueDetails = Map.of(VERN_NUMBER, vernNumber, VERN_SUPPLEMENT_ID, responseModelDTO.getSupplementId(),
                        VERN_GLOBAL_FSA_NUMBER, String.valueOf(responseModelDTO.getGlobalFSANumber()));
            }
//            vernMailService.mailVernResponse(issueNumber, issueDetails);
//            vernResponseService.sendVernRefreshCompletionMailIfApplicable(vernResponseModel, gcampResponse, issueNumber, vernNumber);
              vernRequestService.sendVernExtractEmail(vernResponseModel);
        } catch (GridException gridException) {
            LOGGER.info("Error processing VERN response: {}", gridException.getMessage());
            gcampResponse = GCAMPResponse.builder().statusCode(String.valueOf(HttpStatus.OK.value()))
                    .statusDescription("VERN response processed in GRID").build();
        }
        return ResponseEntity.status(Integer.parseInt(gcampResponse.getStatusCode())).body(gcampResponse);
    }

    /**
     * Endpoint to process failed VERN response details.
     *
     * @param vernResponseModel the VERN response model
     * @return ResponseEntity containing GCAMPResponse
     */
    @PutMapping("failedVern")
    @SystemWideResponses
    @Operation(summary = "Failed VERN Response", description = "Process failed VERN response details")
    public ResponseEntity<GCAMPResponse> failedVernDetails(@RequestBody VernResponseModel vernResponseModel) {
        LOGGER.info("Received Failed VERN response: {}", vernResponseModel);

        GCAMPResponse gcampResponse = vernResponseService.processRemainingVERNNumber(vernResponseModel);
        return ResponseEntity.status(Integer.parseInt(gcampResponse.getStatusCode())).body(gcampResponse);
    }

    /**
     * Endpoint to update submitted flag for VERNs.
     *
     * @param vernResponseModel the VERN response model
     * @return ResponseEntity containing FailedResponse
     */
    @PutMapping("submittedVern")
    @SystemWideResponses
    @Operation(summary = "Process VERN response", description = "Process the VERN response details")
    public ResponseEntity<FailedResponse> submittedFlag(@RequestBody VernResponseModel vernResponseModel) {
        LOGGER.info("Received Submitted VERN request details: {}", vernResponseModel);

        FailedResponse failedResponse = vernResponseService.submittedFlagVERN(vernResponseModel);
        return ResponseEntity.status(Integer.parseInt(failedResponse.getStatus())).body(failedResponse);
    }

    /**
     * Endpoint to delete global FSA.
     *
     * @param vernResponseModel the VERN response model
     * @return ResponseEntity containing GCAMPResponse
     */
    @PutMapping("global/fsa/delete")
    @SystemWideResponses
    @Operation(summary = "Process VERN response for FSA delete", description = "Process the VERN response details for deleting global FSA")
    public ResponseEntity<GCAMPResponse> deleteGlobalFSA(@RequestBody VernResponseModel vernResponseModel) {
        LOGGER.info("Received Delete Global FSA request details: {}", vernResponseModel);

        GCAMPResponse gcampResponse = vernResponseService.deleteGlobalFSA(vernResponseModel);
        return ResponseEntity.status(Integer.parseInt(gcampResponse.getStatusCode())).body(gcampResponse);
    }

    @GetMapping("/getVinFileSignedUrl")
    @SystemWideResponses
    @Operation(summary = "Get VIN File Signed URL", description = "Get a signed URL for downloading a VIN file")
    public ResponseEntity<DownloadResponse> downloadSignedURL(@RequestParam String fileName) throws IOException {
        SignedURLResponse signedURLResponse = signedURLService.getFileByGcsFileName(fileName);
        DownloadResponse response = new DownloadResponse(signedURLResponse.getSignedUrl().toString()); // Fixed constructor issue
        return ResponseEntity.ok(response);
    }

    @PostMapping("local/fsa")
    public ResponseEntity<GCAMPResponse> createLocalFSA(@RequestBody LocalFsaModel fsaDetails) throws GridException {
        LOGGER.info("Received Create Local FSA request details: {}", fsaDetails);
        GCAMPResponse gcampResponse = vernResponseService.createLocalFSA(fsaDetails);
        return ResponseEntity.status(Integer.parseInt(gcampResponse.getStatusCode())).body(gcampResponse);
    }

    /**
     * Endpoint to delete local FSA.
     *
     * @param fsaDetails the local FSA model
     * @return ResponseEntity containing GCAMPResponse
     */
    @DeleteMapping("local/fsa")
    public ResponseEntity<GCAMPResponse> deleteLocalFSAForImplementation(@RequestBody LocalFsaModel fsaDetails) {
        LOGGER.info("Delete Local FSA request details: {}", fsaDetails);
        GCAMPResponse gcampResponse = vernResponseService.deleteLocalFSA(fsaDetails);
        return ResponseEntity.status(Integer.parseInt(gcampResponse.getStatusCode())).body(gcampResponse);
    }

    /**
     * GCAMP endpoint to update potential type for the Global FSA number
     *
     * @param fsaTypeDetails the local FSA model
     * @return ResponseEntity containing GCAMPResponse
     */
    @PostMapping("fsaType")
    public ResponseEntity<GCAMPResponse> updatePotentialType(@RequestBody FSATypeResponseModel fsaTypeDetails) {
        LOGGER.info("Update Local FSA request details: {}", fsaTypeDetails);
        GCAMPResponse gcampResponse = vernResponseService.updatePotentialType(fsaTypeDetails);
        return ResponseEntity.status(Integer.parseInt(gcampResponse.getStatusCode())).body(gcampResponse);
    }

    /**
     * Endpoint to process VFD response details.
     *
     * @param vfdResponse the VFD response model
     * @return ResponseEntity containing GCAMPResponse
     */
    @PutMapping("vfd")
    public ResponseEntity<GCAMPResponse> processVFDResponse(@RequestBody VFDResponseModel vfdResponse) {
        LOGGER.info("Start of processVFDResponse VFD response in GCAMPResponseController: {}", vfdResponse.getVernNumber());
        LOGGER.info("Received Process VFD response details: {}", vfdResponse);

        GCAMPResponse gcampResponse;
        try {
            gcampResponse = vernResponseService.processVFDResponse(vfdResponse);
        } catch (GridException e) {
            LOGGER.error("Error processing VFD response: {}", e.getMessage());
            gcampResponse = GCAMPResponse.builder().statusCode(String.valueOf(HttpStatus.OK.value()))
                    .statusDescription("Internal Server Error: " + e.getMessage()).build();
        }
        return ResponseEntity.status(Integer.parseInt(gcampResponse.getStatusCode())).body(gcampResponse);
    }
}