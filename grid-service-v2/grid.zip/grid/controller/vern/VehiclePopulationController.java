package com.ford.grid.controller.vern;

import com.ford.grid.common.SystemWideResponses;
import com.ford.grid.exception.GridException;
import com.ford.grid.model.dto.response.vern.SuspectVehiclePopulation;
import com.ford.grid.service.impl.vern.VernResponseService;
import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v2/vehicle-population")
public class VehiclePopulationController {
    private static final Logger LOGGER = LoggerFactory.getLogger(VehiclePopulationController.class);
    private final VernResponseService vernResponseService;

    /**
     * Get the count of VERN responses processed for a given VERN number and revision.
     *
     * @param vernNumber The VERN number to query.
     * @param revision   The revision number of the VERN.
     * @return ResponseEntity containing SuspectVehiclePopulation data or appropriate error status.
     */
    @GetMapping("{vernNumber}")
    @SystemWideResponses
    @Operation(summary = "Get VERN Count", description = "Get the count of VERN responses processed")
    public ResponseEntity<SuspectVehiclePopulation> getVernCount(@PathVariable("vernNumber") String vernNumber,
                                                                 @RequestParam(value = "revision", required = false, defaultValue = "0") int revision) {
        LOGGER.info("Start of getVernCount for VERN Number: {} and revision : {}", vernNumber, revision);

        try {
            if (revision == 0) {
                //When revision is not provided, fetch the latest revision from DB
                revision = vernResponseService.getLatestVernRevision(vernNumber);
                LOGGER.info("Get latest revision : {} for VERN Number: {}", revision, vernNumber);
            }
            return ResponseEntity.ok(vernResponseService.getVernCountByVernNumber(vernNumber, revision));
        } catch (GridException gridException) {
            LOGGER.error("GridException in getVernCount for VERN Number: {} and revision : {}. Error: {}", vernNumber, revision, gridException.getMessage());
            return ResponseEntity.status(gridException.getStatus()).build();
        }
    }
}