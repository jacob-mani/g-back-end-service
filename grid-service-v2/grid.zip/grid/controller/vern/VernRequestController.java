package com.ford.grid.controller.vern;

import com.ford.grid.common.SystemWideResponses;
import com.ford.grid.exception.GridException;
import com.ford.grid.model.dto.request.vern.GcampFRCApprovalRequest;
import com.ford.grid.model.dto.request.vern.GridRefreshRequest;
import com.ford.grid.model.dto.response.vern.GCAMPResponse;
import com.ford.grid.model.dto.response.vern.VernResponseModel;
import com.ford.grid.service.VernRequestService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v2/impl/vern")
@RequiredArgsConstructor
@Slf4j
public class VernRequestController {

    private final VernRequestService vernRequestService;

    @PostMapping("/submitToVern/{vernNumber}")
    @Operation(summary = "Submit Vern Request", description = "Submit a Vern request for processing")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public VernResponseModel submitVernRequest(@PathVariable String vernNumber) throws GridException {
        log.info("Vern request submission started for vernNumber- {}", vernNumber);
        VernResponseModel request = vernRequestService.submitVernRequest(vernNumber);
        log.info("Vern request submission ended for vernNumber- {}", vernNumber);
        return request;
    }


    @PostMapping("/refreshVern")
    @Operation(summary = "Refresh Vern Data", description = "Refresh Vern data from external system")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public GCAMPResponse refreshInStockRequest(@Valid @RequestBody GridRefreshRequest refreshRequest) throws GridException {
        log.info("Vern data refresh started for request- {}", refreshRequest.getVernNumber());
        GCAMPResponse response = vernRequestService.refreshInStockRequest(refreshRequest);
        log.info("Vern data refresh ended for request- {}", refreshRequest.getVernNumber());
        return response;
    }

    @PutMapping("/frcApproval")
    @Operation(summary = " Update FRC Approval information for population to gcamp", description = " Update FRC Approval information for population to gcamp")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public GCAMPResponse updateFRCApprovalToGcamp(@Valid @RequestBody GcampFRCApprovalRequest frcApprovalRequest) throws GridException {
        final int globalFSANumber = frcApprovalRequest.getGlobalFSANumber();

        GCAMPResponse response = vernRequestService.updateFRCApprovalToGcamp(frcApprovalRequest);
        log.info("Global FSA for FRC approval:{} and response:{}", globalFSANumber, response);
        log.info("End of update FSA approval in VernRequestController:{}", globalFSANumber);

        return response;
    }

    @PutMapping("/frcApproval/{issueNumber}/{populationId}")
    @Operation(summary = "Update FRC Approval information for population to gcamp", description = "Update FRC Approval information for population to gcamp")
    @SystemWideResponses
    @PreAuthorize("@gridAuthorizeService.isAuthorized('GRID:Checklist','update')")
    public GCAMPResponse updateFRCApprovalToGcamp(
            @PathVariable String issueNumber,
            @PathVariable String populationId,
            @Valid @RequestBody GcampFRCApprovalRequest frcApprovalRequest) throws GridException {
        log.info("FRC Approval update to GCAMP started for populationId- {}", populationId);
        GCAMPResponse response = vernRequestService.updateFRCApprovalToGcamp(issueNumber, populationId, frcApprovalRequest);
        log.info("Population id for FRC approval:{} and response:{}", populationId, response);
        log.info("FRC Approval update to GCAMP ended for populationId- {}", populationId);

        return response;
    }
}