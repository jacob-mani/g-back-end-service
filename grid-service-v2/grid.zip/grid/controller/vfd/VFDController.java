package com.ford.grid.controller.vfd;

import com.ford.grid.exception.GridException;
import com.ford.grid.model.dto.request.vehicleparts.*;
import com.ford.grid.model.dto.request.vfd.VFDProfileRequest;
import com.ford.grid.model.dto.request.vfd.VFDRequestDTO;
import com.ford.grid.model.dto.response.vehicleparts.VFDResponseStatus;
import com.ford.grid.service.VernRequestService;
import com.ford.grid.service.impl.vfd.VFDService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URL;
import java.util.List;
import java.util.Objects;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v2/vfd")
public class VFDController {
    private static final Logger LOGGER = LoggerFactory.getLogger(VFDController.class);
    private final VFDService vfdService;
    private final VernRequestService vernRequestService;

    /**
     * Endpoint to submit a VFD request to GCAMP based on the provided VFDRequestDTO.
     *
     * @param vfdRequestDTO the request DTO containing the necessary information for submitting the VFD request
     * @return ResponseEntity containing the result of the submission, or an error message if an exception occurs
     */
    @PostMapping("/submitToGCAMP")
    public ResponseEntity<?> submitToGCAMP(@Valid @RequestBody VFDRequestDTO vfdRequestDTO) {
        LOGGER.info("Start of submitToGCAMP in VFDController for VERN Number: {}", vfdRequestDTO.vernNumber());

        try {
            return ResponseEntity.ok(vernRequestService.submitVFDRequestToGCAMP(vfdRequestDTO));
        } catch (GridException gridException) {
            LOGGER.error("Exception occurred while processing VFD request: {}", gridException.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(gridException.getDescription());
        }
    }

    /**
     * Endpoint to retrieve the signed URL for downloading a VFD file based on the provided VERN number.
     *
     * @param populationId the Population number associated with the VFD file
     * @return ResponseEntity containing the signed URL if found, or a 404 Not Found status if not found
     */
    @GetMapping("/downloadVFD/{populationId}")
    public ResponseEntity<String> getVFDFilePathInGRIDStorage(@PathVariable final String populationId) {
        LOGGER.info("Start of getVFDFilePathInGRIDStorage in VFDController for VERN Number: {}", populationId);

        final URL vfdSignedURL = vfdService.getVFDSignedURL(populationId);
        if (Objects.nonNull(vfdSignedURL)) {
            LOGGER.info("End of getVFDFilePathInGRIDStorage in VFDController");
            return ResponseEntity.ok(vfdSignedURL.toString());
        } else {
            LOGGER.info("VFD Signed URL not found for VERN Number: {}", populationId);
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Retrieves WERS attributes based on the provided population ID and optional filter group code.
     *
     * @param populationId the population ID
     * @return ResponseEntity containing a list of WERSAttributeItemn
     */
    @GetMapping("/wers-attributes/{populationId}")
    public ResponseEntity<Page<List<WERSAttributeItem>>> getWERSAttributes(@PathVariable final String populationId, Pageable pageable) {
        LOGGER.info("Start of getWERSAttributes in VFDController for Population id: {} ", populationId);
        return ResponseEntity.ok(vfdService.getWersAttributes(populationId, pageable));
    }

    /**
     * Endpoint to retrieve the vehicle profile based on the provided VFDProfileRequest.
     *
     * @param vfdProfileRequest the request containing the necessary information to retrieve the vehicle profile
     * @return ResponseEntity containing a list of ProfileDetailKeyValue representing the vehicle profile details
     */
    @PostMapping("/vehicle-selection")
    public ResponseEntity<?> getVFDVehicleProfile(@RequestBody VFDProfileRequest vfdProfileRequest) {
        LOGGER.info("Start of getVehicleProfile in VehiclePartsController");

        VFDProfileResponse vfdProfileResponse = vfdService.getVFDVehicleProfile(vfdProfileRequest);
        LOGGER.info("VFD profile response: {}", vfdProfileResponse);
        LOGGER.info("End of getVehicleProfile in VehiclePartsController");

        return new ResponseEntity<>(vfdProfileResponse, HttpStatus.OK);
    }

    /**
     * Endpoint to retrieve the GCAMP submission status for a given population ID.
     *
     * @param populationId the population ID for which to retrieve the GCAMP submission status
     * @return ResponseEntity containing the VFDResponse status if found, or a 404 Not Found status if not found
     */
    @GetMapping("/status/{populationId}")
    public ResponseEntity<VFDResponseStatus> getVFDResponseStatus(@PathVariable final String populationId) {
        LOGGER.info("Start of getVFDResponseStatus in VFDController for Population id: {} ", populationId);
        return ResponseEntity.ok(vfdService.getVFDResponseStatus(populationId));
    }

    /**
     * Endpoint to retrieve the profile details for a given population ID.
     *
     * @param populationId the population ID for which to retrieve the profile details
     * @return ResponseEntity containing the VFDDropDownDetails if found, or a 404 Not Found status if not found
     */
    @GetMapping("/profile/{populationId}")
    public ResponseEntity<VFDDropDownDetails> getProfile(@PathVariable final String populationId) {
        LOGGER.info("Start of getProfile in VFDController for Population id: {} ", populationId);
        return ResponseEntity.ok(vfdService.getProfileDetails(populationId));
    }

    @PostMapping("/processVFD/{populationId}/{vernNumber}/{version}/{revision}")
    public void saveVFDPopulation(@PathVariable String populationId, @PathVariable String vernNumber,
                                  @PathVariable String version, @PathVariable String revision) throws GridException {
        LOGGER.info("Start of saveVFDPopulation in VFDController population ID : {}, vernNumber : {}, revision : {}", populationId, vernNumber, revision);

        vfdService.processVFDFile(populationId, vernNumber, Integer.parseInt(version), Integer.parseInt(revision));
        LOGGER.info("End of saveVFDPopulation for vern Number ID:{}", vernNumber);
    }


    @PutMapping("/edit-profile")
    public ResponseEntity<VFDProfileEditResponse> editVFDProfile(@RequestBody ProfileRequest profileRequest) {
        LOGGER.info("Start of editVFDProfile in VFDController");
        LOGGER.info("ProfileRequest received for editing VFD profile: {}", profileRequest);

        VFDProfileEditResponse response = vfdService.editVFDProfile(profileRequest);
        LOGGER.info("End of editVFDProfile in VFDController");
        return ResponseEntity.ok(response);
    }


    @PutMapping("/reset-edit-profile")
    public ResponseEntity<Void> resetEditVFDProfile(@RequestBody EditProfileRequest profileRequest) {
        LOGGER.info("Start of resetEditVFDProfile in VFDController");
        LOGGER.info("ProfileRequest received for resetting VFD profile: {}", profileRequest.getProfileName());
        vfdService.resetProfile(profileRequest);
        LOGGER.info("ProfileRequest Reset for VFD profile: {}", profileRequest.getProfileName());
        return ResponseEntity.ok().build();
    }
}