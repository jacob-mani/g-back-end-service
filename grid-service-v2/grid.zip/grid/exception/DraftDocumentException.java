package com.ford.grid.exception;

import lombok.Getter;
import org.springframework.http.HttpStatus;

/** Single custom exception for the generateDraftDocument API flow. */
@Getter
public class DraftDocumentException extends RuntimeException {

    private final HttpStatus status;
    private final String     description;
    private final String     userErrorTitle;
    private final String     userErrorMessage;
    private final String     userErrorGuidance;

    @Getter
    public enum ErrorCode {

        // 400 — Triggered when any required field is missing, a value fails validation,
        //        or an invalid argument is passed (covers all BAD_REQUEST scenarios)
        VALIDATION_FAILED(HttpStatus.BAD_REQUEST,
                "Missing or Invalid Information",
                "Complete all required Input fields before generating the draft",
                "Please review all required fields and ensure your inputs are complete and in the correct format. "
                        ),

        // 403 — Triggered when the caller does not have the required access permissions
        PERMISSION_DENIED(HttpStatus.FORBIDDEN,
                "Access Denied",
                "You do not have permission to perform this action.",
                "Your account does not have the required access to complete this request. "
                        + "Please check that you are logged in with the correct account. "
                        + "If you believe you should have access, please request the appropriate permissions."),

        // 404 — Triggered when no document template exists for the selected Region, Market, Brand,
        //        and document type combination (documentTemplateRepository returns empty list)
        NO_TEMPLATES_FOUND(HttpStatus.NOT_FOUND,
                "No Templates Found",
                "No document template was found for your selected options.",
                "Please check your Region, Market, Brand, and document type selections and try again."),

        // 404 — Triggered when:
        //        (1) Template file blob does not exist in storage (fetchGCPFileName)
        //        (2) Part 573 file blob does not exist in storage (fetchPart573Data → fetchGCPFileName)
        //        (3) Fact Sheet file name is blank or fact sheet not found (getFactSheetFromGCS)
        DOCUMENT_NOT_FOUND(HttpStatus.NOT_FOUND,
                "Document Not Found",
                "The requested document could not be found or fetched from the File Location.",
                "The document may have been moved, deleted or not yet saved. Please try again."),

        // 500 — Triggered when a file exists in storage but its content is empty or unreadable after download:
        //        (1) Template file bytes are null/empty (buildLLMRequests → fetchGCPFile)
        //        (2) Part 573 file bytes are null/empty (fetchPart573Data → fetchGCPFileName)
        //        (3) File bytes are null/empty during SharePoint upload (uploadGcsToSharepoint → fetchGCPFile)
        GCS_FILE_DOWNLOAD_FAILED(HttpStatus.INTERNAL_SERVER_ERROR,
                "File Retrieval Failed",
                "A required support file could not be retrieved from storage.",
                "The supporting file for draft generation may be missing, empty or damaged. Please try again after some time."),

        // 500 — Triggered when any Fact Sheet file cannot be loaded:
        //        covers both missing/incomplete records and unexpected retrieval failures (collectFactSheetData)
        FACT_SHEET_UNEXPECTED_ERROR(HttpStatus.INTERNAL_SERVER_ERROR,
                "Fact Sheet Unexpected Error",
                "The Fact Sheet information could not be loaded.",
                "The Fact Sheet may be temporarily unavailable or not accessible. "
                        + "If the Fact Sheet was recently updated, wait a moment before retrying."),

        // 500 — Triggered when the 14D safety recall document cannot be fetched or parsed
        //        (fetch14DDocumentJson — covers both retrieval failure and unreadable format)
        FOURTEEN_D_FETCH_ERROR(HttpStatus.INTERNAL_SERVER_ERROR,
                "Safety Recall Document Error",
                "The safety recall document could not be loaded or read.",
                "The safety recall document may be missing, inaccessible, or in an unreadable format. "
                        + "Please try again after some time."),

        // 500 — Triggered BEFORE document generation begins:
        //        SharePoint folder creation fails during the pre-fetch phase (buildSharePointFolderPath)
        SHAREPOINT_FOLDER_CREATION_FAILED(HttpStatus.INTERNAL_SERVER_ERROR,
                "Document Storage Not Ready",
                "The document could not be started because the storage folder was not ready.",
                "The storage folder must be set up before document generation can begin. Please try again."),

        // 500 — Triggered when NHTSA government submission details cannot be fetched
        //        (getLaunchGovernmentSubmission — document may still be generated without this data)
        GOVERNMENT_SUBMISSION_FETCH_FAILED(HttpStatus.INTERNAL_SERVER_ERROR,
                "Government Submission Fetch Failed",
                "The government submission details could not be loaded.",
                "Some government submission information is unavailable at the moment. The document may be generated without these details."),

        // 500 — Triggered when the document generation service (LLM) returns an error response
        //        or when one or more parallel LLM calls fail across multiple brands/templates
        //        (executeLLMCall — covers response errors, client errors, server errors, parallel execution failures)
        LLM_GENERATION_FAILED(HttpStatus.INTERNAL_SERVER_ERROR,
                "LLM Generation Failed",
                "The document generation service encountered an error.",
                "The document could not be generated at this time. Please try again."),

        // 500 — Triggered when a required data value is unexpectedly null during processing
        //        (NullPointerException caught in the outer catch block of getTemplateFileService)
        NULL_REFERENCE_ERROR(HttpStatus.INTERNAL_SERVER_ERROR,
                "Null Reference Error",
                "An unexpected error occurred while processing your request.",
                "Some required information appears to be missing. Please ensure all fields are filled in correctly and try again. "
                        + "Check that all related data records exist and are saved properly. "
                        + "If a linked record was recently deleted, it may need to be restored."),

        // 500 — Catch-all for any unhandled exception during the draft document generation flow
        //        (generic Exception caught in the outer catch block of getTemplateFileService)
        DOCUMENT_GENERATION_FAILED(HttpStatus.INTERNAL_SERVER_ERROR,
                "Document Generation Failed",
                "An unexpected error occurred while creating the document.",
                "Something went wrong while creating your document. Please try again. "
                        + "Try refreshing the page and re-entering your selections before retrying. "
                        + "Ensure all required information is available and complete before generating the document."),

        // 500 — Triggered when a request exceeds the allowed processing time
        //        (any operation in the flow that throws a timeout or socket timeout exception)
        TIMEOUT_ERROR(HttpStatus.INTERNAL_SERVER_ERROR,
                "Request Timed Out",
                "The request took too long and was not completed.",
                "Wait a few moments to allow the system to recover from the temporary delay. "
                        + "Return to the template configuration screen and review your settings. "
                        + "Attempt to generate the draft again, as most timeout issues are temporary and typically resolve on retry."),

        // 500 — Triggered when the service cannot reach an external system due to a network or internet issue
        //        (e.g. ConnectException, UnknownHostException, SocketException thrown during any outbound call)
        CONNECTION_ERROR(HttpStatus.INTERNAL_SERVER_ERROR,
                "Connection Failed",
                "Unable to connect to a required service. Please check your network connection.",
                "A network or internet issue prevented the request from completing. "
                        + "Please check your connection and try again. "
                        + "If the problem continues, the service you are trying to reach may be temporarily unavailable.");

        private final HttpStatus status;
        private final String userErrorTitle;
        private final String userErrorMessage;
        private final String userErrorGuidance;

        ErrorCode(HttpStatus status, String userErrorTitle, String userErrorMessage, String userErrorGuidance) {
            this.status            = status;
            this.userErrorTitle    = userErrorTitle;
            this.userErrorMessage  = userErrorMessage;
            this.userErrorGuidance = userErrorGuidance;
        }
    }

    public DraftDocumentException(HttpStatus status, String message, String description, ErrorCode errorCode) {
        this(status, message, description, errorCode, null);
    }

    public DraftDocumentException(HttpStatus status, String message, String description, ErrorCode errorCode, Throwable cause) {
        super(message, cause);
        this.status            = status;
        this.description       = description;
        this.userErrorTitle    = errorCode.getUserErrorTitle();
        this.userErrorMessage  = errorCode.getUserErrorMessage();
        this.userErrorGuidance = errorCode.getUserErrorGuidance();
    }
}
