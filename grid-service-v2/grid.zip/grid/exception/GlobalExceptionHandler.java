package com.ford.grid.exception;

import com.fasterxml.jackson.databind.exc.MismatchedInputException;
import com.ford.cloudnative.base.api.BaseBodyError;
import com.ford.cloudnative.base.api.StandardErrorResponse;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.ConstraintViolationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.NoHandlerFoundException;
import org.springframework.web.servlet.resource.NoResourceFoundException;

import java.util.HashMap;
import java.util.Map;

@Order(Ordered.HIGHEST_PRECEDENCE)
@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(GlobalExceptionHandler.class);
    private static final String FORUM_CUSTOM_VIEW_PATH = "/api/v2/customview/forumInvestigation";
    private static final String FORUM_CUSTOM_VIEW_DOWNLOAD_PATH = "/api/v2/customview/forumInvestigation/download";
    
    @ExceptionHandler(DraftDocumentException.class)
    public ResponseEntity<StandardErrorResponse> handleDraftDocumentException(DraftDocumentException e) {
        LOGGER.error("DraftDocumentException [status={}] " + "userErrorTitle='{}' | userErrorMessage='{}' | userErrorGuidance='{}' | " +
                        "rawMessage='{}' | rawDescription='{}'",
                e.getStatus(), e.getUserErrorTitle(), e.getUserErrorMessage(), e.getUserErrorGuidance(),
                e.getMessage(), e.getDescription());
        BaseBodyError baseBodyError = BaseBodyError.builder()
                .errorCode(String.valueOf(e.getStatus().value()))
                .message(e.getMessage())
                .attribute("error description", e.getDescription())
                .attribute("userErrorTitle",    e.getUserErrorTitle())
                .attribute("userErrorMessage",  e.getUserErrorMessage())
                .attribute("userErrorGuidance", e.getUserErrorGuidance())
                .build();
        return ResponseEntity.status(e.getStatus()).body(StandardErrorResponse.error(baseBodyError));
    }

    @ExceptionHandler(GridException.class)
    public ResponseEntity<StandardErrorResponse> handleGridException(GridException e) {
        HttpStatus status = e.getStatus() != null ? e.getStatus() : HttpStatus.INTERNAL_SERVER_ERROR;
        if (HttpStatus.BAD_REQUEST.equals(status)) {
            return handleGridBadRequestException(e, status);
        }
        if (HttpStatus.NOT_FOUND.equals(status)) {
            return handleGridNotFoundException(e, status);
        }
        if (HttpStatus.UNAUTHORIZED.equals(status)) {
            return handleGridUnauthorizedException(e, status);
        }
        LOGGER.error("Unhandled runtime exception {}", e.getLocalizedMessage());
        BaseBodyError baseBodyError = BaseBodyError.builder().errorCode(String.valueOf(status.value())).message(e.getMessage())
                .attribute("error description", e.getMessage())
                .build();
        return ResponseEntity.status(status).body(StandardErrorResponse.error(baseBodyError, status.value()));
    }

    private ResponseEntity<StandardErrorResponse> handleGridBadRequestException(GridException e, HttpStatus status) {
        LOGGER.error("Bad request exception: {}", e.getLocalizedMessage());
        BaseBodyError baseBodyError = BaseBodyError.builder()
                .errorCode(String.valueOf(status.value()))
                .message(e.getMessage())
                .attribute("error description", e.getDescription())
                .build();
        return ResponseEntity.status(status).body(StandardErrorResponse.error(baseBodyError, status.value()));
    }

    private ResponseEntity<StandardErrorResponse> handleGridNotFoundException(GridException e, HttpStatus status) {
        LOGGER.error("Resource not found: {}", e.getLocalizedMessage());
        BaseBodyError baseBodyError = BaseBodyError.builder()
                .errorCode(String.valueOf(status.value()))
                .message(e.getMessage())
                .attribute("error description", e.getDescription())
                .build();
        return ResponseEntity.status(status).body(StandardErrorResponse.error(baseBodyError, status.value()));
    }

    private ResponseEntity<StandardErrorResponse> handleGridUnauthorizedException(GridException e, HttpStatus status) {
        LOGGER.error("Unauthorized access: {}", e.getLocalizedMessage());
        BaseBodyError baseBodyError = BaseBodyError.builder()
                .errorCode(String.valueOf(status.value()))
                .message(e.getMessage())
                .attribute("error description", e.getDescription())
                .build();
        return ResponseEntity.status(status).body(StandardErrorResponse.error(baseBodyError, status.value()));
    }

    @ExceptionHandler(ConstraintViolationException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseEntity<StandardErrorResponse> handleConstraintViolationException(ConstraintViolationException e) {
        BaseBodyError baseBodyError = BaseBodyError.builder()
                .errorCode(String.valueOf(HttpStatus.BAD_REQUEST.value()))
                .message(e.getMessage())
                .attribute("error description", "Validation failed for one or more fields in the request.")
                .build();
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(StandardErrorResponse.error(baseBodyError, HttpStatus.BAD_REQUEST.value()));
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseEntity<StandardErrorResponse> handleHttpMessageNotReadableException(HttpMessageNotReadableException e) {
        BaseBodyError baseBodyError = BaseBodyError.builder()
                .errorCode(String.valueOf(HttpStatus.BAD_REQUEST.value()))
                .message(e.getMessage())
                .attribute("error description", "Error in the JSON request.")
                .build();
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(StandardErrorResponse.error(baseBodyError, HttpStatus.BAD_REQUEST.value()));
    }

    @ExceptionHandler(MismatchedInputException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseEntity<StandardErrorResponse> handleMismatchedInputException(MismatchedInputException e) {
        BaseBodyError baseBodyError = BaseBodyError.builder()
                .errorCode(String.valueOf(HttpStatus.BAD_REQUEST.value()))
                .message(e.getMessage())
                .attribute("error description", "JSON input does not match the expected structure.")
                .build();
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(StandardErrorResponse.error(baseBodyError, HttpStatus.BAD_REQUEST.value()));
    }

    @ExceptionHandler(value = MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseEntity<StandardErrorResponse> methodArgumentErrorHandler(MethodArgumentNotValidException methodArgumentNotValidException) {
        Map<String, String> errors = new HashMap<>();
        String message = methodArgumentNotValidException.getBindingResult().getFieldErrors().get(0).getDefaultMessage();
        methodArgumentNotValidException.getBindingResult().getFieldErrors().forEach(error -> {
            errors.put(error.getField(), error.getDefaultMessage());
        });
        errors.put("error description", "Validation failed for one or more fields in the request JSON.  ["+message+"]" );
        BaseBodyError baseBodyError = BaseBodyError.builder().errorCode(String.valueOf(HttpStatus.BAD_REQUEST.value()))
                .message(message)
                .attributes(errors)
                .build();
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(StandardErrorResponse.error(baseBodyError, HttpStatus.BAD_REQUEST.value()));
    }

    @ExceptionHandler(value = HttpMediaTypeNotSupportedException.class)
    @ResponseStatus(HttpStatus.UNSUPPORTED_MEDIA_TYPE)
    public ResponseEntity<StandardErrorResponse> httpMediaTypeNotSupportedExceptionHandler(HttpMediaTypeNotSupportedException e) {
        BaseBodyError baseBodyError = BaseBodyError.builder().errorCode(String.valueOf(HttpStatus.UNSUPPORTED_MEDIA_TYPE.value()))
                .message(e.getMessage())
                .attribute("error description", "The media type is not supported.")
                .build();
        return ResponseEntity.status(HttpStatus.UNSUPPORTED_MEDIA_TYPE).body(StandardErrorResponse.error(baseBodyError, HttpStatus.UNSUPPORTED_MEDIA_TYPE.value()));
    }

    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    @ResponseStatus(HttpStatus.METHOD_NOT_ALLOWED)
    public ResponseEntity<StandardErrorResponse> handleMethodNotSupportException(HttpRequestMethodNotSupportedException e) {
        BaseBodyError baseBodyError = BaseBodyError.builder().errorCode(String.valueOf(HttpStatus.METHOD_NOT_ALLOWED.value()))
                .message(e.getMessage())
                .attribute("error description", "The HTTP method is not supported for this endpoint.")
                .build();
        return ResponseEntity.status(HttpStatus.METHOD_NOT_ALLOWED).body(StandardErrorResponse.error(baseBodyError, HttpStatus.METHOD_NOT_ALLOWED.value()));
    }

    // Handles AccessDeniedException and returns 401
    @ExceptionHandler(AccessDeniedException.class)
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    public ResponseEntity<StandardErrorResponse> handleAccessDeniedException(AccessDeniedException e) {
        String message = e.getMessage() != null ? e.getMessage() : "Access is denied.";
        BaseBodyError baseBodyError = BaseBodyError.builder()
                .errorCode(String.valueOf(HttpStatus.UNAUTHORIZED.value()))
                .message(message)
                .attribute("error description", "You do not have permission to access this resource.")
                .build();
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                .body(StandardErrorResponse.error(baseBodyError, HttpStatus.UNAUTHORIZED.value()));
    }

    @ExceptionHandler(AuthenticationException.class)
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    public ResponseEntity<StandardErrorResponse> handleAuthenticationException(AuthenticationException e) {
        BaseBodyError baseBodyError = BaseBodyError.builder()
                .errorCode(String.valueOf(HttpStatus.UNAUTHORIZED.value()))
                .message("Authentication Failed: " + e.getMessage())
                .attribute("error description", "Authentication is required to access this resource.")
                .build();
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                .body(StandardErrorResponse.error(baseBodyError, HttpStatus.UNAUTHORIZED.value()));
    }

    @ExceptionHandler(NoHandlerFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ResponseEntity<StandardErrorResponse> handleNoHandlerFoundException(NoHandlerFoundException e) {
        BaseBodyError baseBodyError = BaseBodyError.builder()
                .errorCode(String.valueOf(HttpStatus.NOT_FOUND.value()))
                .message("Resource not found: " + e.getRequestURL())
                .attribute("error description", "The requested resource was not found on the server.")
                .build();
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body(StandardErrorResponse.error(baseBodyError, HttpStatus.NOT_FOUND.value()));
    }

    @ExceptionHandler(NoResourceFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ResponseEntity<StandardErrorResponse> handleNoResourceFoundException(NoResourceFoundException e) {
        BaseBodyError baseBodyError = BaseBodyError.builder()
                .errorCode(String.valueOf(HttpStatus.NOT_FOUND.value()))
                .message("Resource not found: " + e.getResourcePath())
                .attribute("error description", "The requested resource was not found on the server.")
                .build();
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body(StandardErrorResponse.error(baseBodyError, HttpStatus.NOT_FOUND.value()));
    }

    @ExceptionHandler(ServletException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseEntity<StandardErrorResponse> handleForumCustomViewServletException(ServletException e,
                                                                                       HttpServletRequest request) {
        if (isForumCustomViewOutOfMemory(request, e)) {
            LOGGER.error("Forum custom view request failed due to memory exhaustion - method={}, uri={}",
                    request != null ? request.getMethod() : null,
                    request != null ? request.getRequestURI() : null,
                    e);
            return buildForumCustomViewOutOfMemoryResponse();
        }
        return executionException(e);
    }

    @ExceptionHandler(RuntimeException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseEntity<StandardErrorResponse> runtimeException(RuntimeException e) {
        LOGGER.error("Unhandled runtime exception", e);
        BaseBodyError baseBodyError = BaseBodyError.builder().errorCode(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()))
                .message(e.getMessage())
                .attribute("error description", "An runtime error occurred on the server.")
                .build();
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(StandardErrorResponse.error(baseBodyError, HttpStatus.INTERNAL_SERVER_ERROR.value()));
    }

    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseEntity<StandardErrorResponse> executionException(Exception e) {
        LOGGER.error("Unhandled exception", e);
        BaseBodyError baseBodyError = BaseBodyError.builder().errorCode(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()))
                .message(e.getMessage())
                .attribute("error description", "An unexpected error occurred on the server.")
                .build();
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(StandardErrorResponse.error(baseBodyError, HttpStatus.INTERNAL_SERVER_ERROR.value()));
    }

    @ExceptionHandler(ResponseStatusException.class)
    public ResponseEntity<StandardErrorResponse> handleResponseStatusException(ResponseStatusException ex) {
        BaseBodyError baseBodyError = BaseBodyError.builder().errorCode(String.valueOf(ex.getStatusCode().value()))
                .message(ex.getReason() != null ? ex.getReason() : "An error occurred.")
                .attribute("error description", "ex.getStatusCode().value() - " + ex.getReason())
                .build();
        return ResponseEntity.status(ex.getStatusCode()).body(StandardErrorResponse.error(baseBodyError, ex.getStatusCode().value()));
    }


    private boolean isForumCustomViewOutOfMemory(HttpServletRequest request, Throwable throwable) {
        return isForumCustomViewRequest(request) && hasOutOfMemoryCause(throwable);
    }

    private boolean isForumCustomViewRequest(HttpServletRequest request) {
        if (request == null) {
            return false;
        }
        String requestUri = request.getRequestURI();
        return FORUM_CUSTOM_VIEW_PATH.equals(requestUri)
                || FORUM_CUSTOM_VIEW_DOWNLOAD_PATH.equals(requestUri);
    }

    private boolean hasOutOfMemoryCause(Throwable throwable) {
        Throwable current = throwable;
        while (current != null) {
            if (current instanceof OutOfMemoryError) {
                return true;
            }
            current = current.getCause();
        }
        return false;
    }

    private ResponseEntity<StandardErrorResponse> buildForumCustomViewOutOfMemoryResponse() {
        BaseBodyError baseBodyError = BaseBodyError.builder()
                .errorCode(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()))
                .message("Forum custom view request is too large to process.")
                .attribute("error description", "The forum custom view result exceeded available server memory. Narrow the filters, reduce selected columns, or export a smaller result set and try again.")
                .build();
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(StandardErrorResponse.error(baseBodyError));
    }


}
