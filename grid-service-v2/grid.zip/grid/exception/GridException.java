package com.ford.grid.exception;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.springframework.http.HttpStatus;

@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class GridException extends Exception {

    private HttpStatus status;
    private String message;
    private String description;

    public GridException(String message) {
        super(message);
        this.message = message;
    }

    public GridException(HttpStatus status, String message, String description, Throwable cause) {
        super(message, cause);
        this.status = status;
        this.message = message;
        this.description = description;
    }
}
