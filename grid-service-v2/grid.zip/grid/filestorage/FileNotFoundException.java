package com.ford.grid.filestorage;

import com.ford.cloudnative.base.app.web.exception.StandardError;
import org.springframework.http.HttpStatus;

@StandardError(status = HttpStatus.NOT_FOUND, messages = "File not found")
public class FileNotFoundException extends RuntimeException {
}
