package com.ford.grid.filestorage;

import com.ford.cloudnative.base.app.web.exception.StandardError;
import org.springframework.http.HttpStatus;
import lombok.extern.slf4j.Slf4j;
@StandardError(status = HttpStatus.INTERNAL_SERVER_ERROR, messages = "Error connecting to file storage")
@Slf4j
public class FileStorageConnectionException extends RuntimeException {

    public FileStorageConnectionException(String message) {
        super(message);
        log.error("File Storage Connection Exception: {}", message);
    }
}
