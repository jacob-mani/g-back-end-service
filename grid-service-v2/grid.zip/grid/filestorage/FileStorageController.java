package com.ford.grid.filestorage;

import com.ford.grid.filestorage.api.FilesResponse;
import com.ford.cloudnative.base.api.StandardErrorResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import jakarta.validation.Valid;
import java.util.List;

@Validated
@RestController
@RequestMapping(path = "/api/v1/files")
public class FileStorageController {

    private final FileStorageService service;

    @Autowired
    public FileStorageController(FileStorageService service) {
        this.service = service;
    }

    @Operation(summary = "Retrieves a list of files", description = "Returns a list of file names in storage")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(schema = @Schema(implementation =  FilesResponse.class))),
            @ApiResponse(description = "All Errors", content = @Content(schema = @Schema(implementation =  StandardErrorResponse.class)))
    })
    @GetMapping()
    public FilesResponse list() {
        List<String> fileNames = service.getAllFiles();

        if (fileNames.isEmpty())
            throw new FileNotFoundException();

        return FilesResponse.builder()
                .fileNames(fileNames)
                .build();
    }

    @Operation(summary = "Upload a file to storage", description = "Returns the status of the upload")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "File Uploaded"),
            @ApiResponse(description = "All Errors", content = @Content(schema = @Schema(implementation =  StandardErrorResponse.class)))
    })
    @PostMapping(consumes = "multipart/form-data")
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<String> upload(@Parameter(description = "Files to be uploaded",
            content = @Content(mediaType = MediaType.MULTIPART_FORM_DATA_VALUE))
                                             @RequestPart (value = "files", required = true) MultipartFile[] multipartFiles)  {

        service.uploadFile(multipartFiles);
        return new ResponseEntity<>("File(s) Uploaded to Cloud Storage", HttpStatus.CREATED);
    }

    @Operation(summary = "Downloads a file from storage", description = "Downloads the file for the name provided")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK"),
            @ApiResponse(description = "All Errors", content = @Content(schema = @Schema(implementation =  StandardErrorResponse.class)))
    })
    @GetMapping("/download/{fileName}")
    public ResponseEntity<Resource> download(@Parameter(description="File Name", schema = @Schema(description = "File Name",
            type = "string", minLength = 1, maxLength = 255, pattern = "[A-Za-z0-9_.,()*?!\\-\\s]")) @PathVariable @Valid String fileName) {

        byte[] resourceArray = service.downloadFile(fileName);

        HttpHeaders header = new HttpHeaders();
        header.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + fileName);
        header.add("Cache-Control", "no-cache, no-store, must-revalidate");
        header.add("Pragma", "no-cache");
        header.add("Expires", "0");

        if(resourceArray != null) {
            ByteArrayResource resource = new ByteArrayResource(resourceArray);
            return ResponseEntity.ok()
                    .headers(header)
                    .contentType(MediaType.APPLICATION_OCTET_STREAM)
                    .body(resource);
        }

        return ResponseEntity.notFound()
                .headers(header)
                .build();
    }

    @Operation(summary = "Delete File", description = "Deletes a file in storage for the given file name")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "No Content"),
            @ApiResponse(description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
    })
    @DeleteMapping("/{name}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@Parameter(description="File Name", schema = @Schema(description = "File Name", type = "string",
            minLength = 1, maxLength = 255, pattern = "[A-Za-z0-9_.]+")) @PathVariable @Valid String name) {

        var file = service.getFile(name);

        if (file.isEmpty())
            throw new FileNotFoundException();

        this.service.delete(name);
    }
}
