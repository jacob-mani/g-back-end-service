package com.ford.grid.filestorage;

import com.google.api.gax.paging.Page;
import com.google.auth.Credentials;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.storage.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Slf4j
@Service
public class FileStorageService {

    @Value("${spring.cloud.gcp.storage.project-id:}")
    private String storageProjectId;

    @Value("${spring.cloud.gcp.storage.bucket-name:}")
    private String storageBucketName;

    Storage storage;

    Bucket bucket = null;

    public Optional<FileObject> getFile(String fileName) {

        connectToCloudStorage();

        Blob fileBlob = this.storage.get(BlobId.of(this.storageBucketName, fileName));
        if (fileBlob == null) return Optional.empty();

        return Optional.ofNullable(FileObject
                .builder()
                .name(fileName)
                .bucket(this.storageBucketName)
                .fileContent(fileBlob.getContent() != null ?
                        new String(fileBlob.getContent(), StandardCharsets.UTF_8) : null)
                .build());
    }

    public List<String> getAllFiles() {
        List<String> fileNames = new ArrayList<>();
        connectToCloudStorage();

        Page<Blob> files = this.storage.list(this.storageBucketName);

        for (Blob file : files.iterateAll()) {
            fileNames.add(file.getName());
        }

        return fileNames;
    }

    public void uploadFile(MultipartFile[] files) {
        try {
            connectToCloudStorage();

            for (MultipartFile file : files) {
                if (file.isEmpty()) {
                    throw new FileUploadException("Failed to store empty file.");
                }
                BlobId blobId;
                if (file.getOriginalFilename() != null) {
                    blobId = BlobId.of(storageBucketName, file.getOriginalFilename());
                } else {
                    blobId = BlobId.of(storageBucketName, file.getName());
                }
                store(file, blobId);
            }

        } catch (Exception exception) {
            throw new FileUploadException(exception.getMessage());
        }
    }

    public void store(MultipartFile file, BlobId blobId) throws IOException {

        byte[] content = file.getBytes();
        BlobInfo blobInfo = BlobInfo.newBuilder(blobId).build();

        this.storage.createFrom(blobInfo, new ByteArrayInputStream(content));
    }

    public void delete(String fileName) {
        connectToCloudStorage();

        Blob blob = this.storage.get(this.storageBucketName, fileName);
        Storage.BlobSourceOption precondition =
                Storage.BlobSourceOption.generationMatch(blob.getGeneration());

        this.storage.delete(this.storageBucketName, fileName, precondition);
    }

    void connectToCloudStorage() {
        if (this.bucket != null) return;

        try {
            Credentials credentials = GoogleCredentials.getApplicationDefault();
            this.storage = StorageOptions.newBuilder()
                    .setCredentials(credentials)
                    .setProjectId(this.storageProjectId)
                    .build()
                    .getService();

            this.bucket = this.storage.get(this.storageBucketName);

        } catch (Exception exception) {
            throw new FileStorageConnectionException(exception.getMessage());
        }
    }

    public byte[] downloadFile(String fileName) {

        try {
            connectToCloudStorage();
            if (fileName == null || fileName.isEmpty()) {
                throw new FileNotFoundException();
            }
            return storage.readAllBytes(storageBucketName, fileName);

        } catch (Exception e) {
            throw new FileNotFoundException();
        }
    }
}
