package com.ford.grid.filestorage;

import com.ford.cloudnative.base.app.web.exception.StandardError;
import org.springframework.http.HttpStatus;
import lombok.extern.slf4j.Slf4j;


@StandardError(status = HttpStatus.INTERNAL_SERVER_ERROR, messages = "Error while creating file")
@Slf4j
public class FileUploadException extends RuntimeException {

    public FileUploadException(String message) {
        super(message);
        log.error("FileUploadException: {}", message);
    }
}
