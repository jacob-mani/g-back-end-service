package com.ford.grid.filestorage.api;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Cloud Storage Blob API")
public class FileApi {

    @NotNull
    @Size(min = 1, max = 255)
    @Pattern(regexp = "^[a-zA-Z0-9 .-]+$")
    @Schema(description = "Blob Name", example = "BlobName")
    private String name;

    @NotNull
    @Size(min = 1, max = 255)
    @Pattern(regexp = "^[a-zA-Z0-9 _.-]+$")
    @Schema(description = "Bucket name", example = "BucketName")
    private String bucket;

    @Size(min = 1)
    @Schema(description = "Blob Content", example = "This is the text contents of the Blob")
    String fileContent;
}
