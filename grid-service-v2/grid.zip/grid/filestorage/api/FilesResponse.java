package com.ford.grid.filestorage.api;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Pattern;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.constraints.Size;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FilesResponse {

    @Size(max = 250)
    @Schema(description = "List of File Names in the bucket")
    @Pattern(regexp = "[A-Za-z0-9_.,()*?!\\-\\s]")
    List<String> fileNames;
}
