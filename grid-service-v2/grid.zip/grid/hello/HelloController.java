package com.ford.grid.hello;

import com.ford.cloudnative.base.api.StandardErrorResponse;
import com.ford.grid.hello.api.HelloRequest;
import com.ford.grid.hello.api.HelloResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;

@Validated
@RefreshScope
@RestController
@RequestMapping(path = "/api/v1/hello")
@Tag(name = "hello", description = "The hello API")
public class HelloController {

	@Value("${hello.greeting.message}")
	String greetingMessage;

	@Operation(summary = "Get a Hello Message", description = "Greets with Hello Message")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "OK", content = @Content(schema = @Schema(implementation = HelloResponse.class))),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
	})
	@GetMapping
	public HelloResponse hello() {
		return HelloResponse.builder().greeting("Hello, ".concat(greetingMessage)).build();
	}

	@Operation(summary = "Post a Hello Message", description = "Greets with Hello Message for the given user")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "OK", content = @Content(schema = @Schema(implementation = HelloResponse.class))),
			@ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
	})
	@PostMapping
	public HelloResponse helloName(@Parameter(description="Hello Request to greet user") @RequestBody @Valid HelloRequest helloRequest) {
		return HelloResponse.builder()
				.greeting("Hello " + helloRequest.getFirstName() + " " + helloRequest.getLastName())
				.build();
	}
}
