package com.ford.grid.hello.api;

import com.ford.cloudnative.annotations.WhitelistRegexValidator;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Hello Response to greet")
public class HelloResponse {

	@NotNull
	@Size(min = 1, max = 255)
	@Pattern(regexp = "^.{1,255}$")
	@WhitelistRegexValidator(regex = "[A-Za-z0-9_.,()*?!\\-\\s]")
	@Schema(example = "Hello", description = "Greeting Message")
	String greeting;
}
