package com.ford.grid.mapper;

import com.ford.grid.model.dto.request.ContactGroupRequest;
import com.ford.grid.model.dto.response.ContactGroupResponse;
import com.ford.grid.model.entity.ContactGroup;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class AdminContactsMapper {

    @Autowired
    private ModelMapper modelMapper;

    public ContactGroup toEntity(ContactGroupRequest groupRequest) {
        return modelMapper.map(groupRequest, ContactGroup.class);
    }

    public ContactGroupResponse toDto(ContactGroup group) {
        return modelMapper.map(group, ContactGroupResponse.class);
    }

}
