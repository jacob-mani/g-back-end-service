package com.ford.grid.mapper;

import com.ford.grid.model.dto.request.AssignPartRequest;
import com.ford.grid.model.dto.response.AssignPartResponse;
import com.ford.grid.model.entity.VehicleParts;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class AssignPartsMapper {


    @Autowired
    private ModelMapper modelMapper;

    public VehicleParts toEntity(AssignPartRequest request) {
        return modelMapper.map(request, VehicleParts.class);
    }

    public AssignPartResponse toResponse(VehicleParts assignParts) {
        return modelMapper.map(assignParts, AssignPartResponse.class);
    }

    public AssignPartResponse toResponseFromRequest(AssignPartRequest request) {
        return modelMapper.map(request, AssignPartResponse.class);
    }
}
