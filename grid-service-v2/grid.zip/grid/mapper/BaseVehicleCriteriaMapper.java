package com.ford.grid.mapper;

import com.ford.grid.model.dto.request.BaseVehicleCriteriaRequest;
import com.ford.grid.model.dto.response.BaseVehicleCriteriaResponse;
import com.ford.grid.model.entity.BaseVehicleCriteria;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class BaseVehicleCriteriaMapper {

    @Autowired
    private ModelMapper modelMapper;

    public BaseVehicleCriteria toEntity(BaseVehicleCriteriaRequest request) {
        return modelMapper.map(request, BaseVehicleCriteria.class);
    }

    public BaseVehicleCriteriaRequest toDto(BaseVehicleCriteria baseVehicleCriteria) {
        return modelMapper.map(baseVehicleCriteria, BaseVehicleCriteriaRequest.class);
    }

    public List<BaseVehicleCriteriaRequest> toRequestDtoList(List<BaseVehicleCriteria> baseVehicleCriteriaList) {
        if (baseVehicleCriteriaList == null || baseVehicleCriteriaList.isEmpty()) {
            return List.of();
        }
        return baseVehicleCriteriaList.stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    public BaseVehicleCriteriaResponse toResponseDto(BaseVehicleCriteria baseVehicleCriteria) {
        return modelMapper.map(baseVehicleCriteria, BaseVehicleCriteriaResponse.class);
    }

    public List<BaseVehicleCriteriaResponse> toBaseVehicleCriteriaResponseList(List<BaseVehicleCriteria> contactsEntity) {
        if (contactsEntity == null) {
            return List.of(); // Return an empty list if the input is null
        }
        return contactsEntity.stream()
                .map(entity -> modelMapper.map(entity, BaseVehicleCriteriaResponse.class))
                .collect(Collectors.toList());
    }
}
