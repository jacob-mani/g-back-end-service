package com.ford.grid.mapper;

import com.ford.grid.model.dto.response.BuildAgendaResponse;
import com.ford.grid.model.entity.ViewReportsBuildAgenda;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class BuildAgendaMapper {

    private static final Logger logger = LoggerFactory.getLogger(BuildAgendaMapper.class);

    public BuildAgendaResponse toDto(ViewReportsBuildAgenda entity) {
        if (entity == null) {
            return null;
        }

        try {
            return BuildAgendaResponse.builder()
                    .issueNumber(entity.getIssueNumber())
                    .leadRegion(entity.getLeadRegion())
                    .segment(entity.getSegment())
                    .issueTitle(entity.getIssueTitle())
                    .issueDescription(entity.getIssueDescription())
                    .agendaType(entity.getAgendaType())
                    .forumType(entity.getAgendaType())
                    .meetingDate(entity.getMeetingDate())
                    .modelYear(entity.getModelYear())
                    .vehicleLine(entity.getVehicleLine())
                    .contacts(entity.getContacts())
                    .meetingStartTime(entity.getMeetingStartTime())
                    .toggleButton(entity.getToggleButton())
                    .duration(entity.getDuration())
                    .keyParticipants(entity.getKeyParticipants())
                    .startEndTime(entity.getStartEndTime())
                    .topics(entity.getTopics())
                    .agendaKeyParticipants(entity.getAgendaKeyParticipants())
                    .issuePhase(entity.getIssuePhase())
                    .issueRelatedItems(entity.getIssueRelatedItems())
                    .affectedRegions(entity.getAffectedRegions())
                    .awaitingNHTSAResponse(entity.isAwaitingNHTSAResponse())
                    .potentialActionType(entity.getPotentialActionType())
                    .includeDraftStatus(entity.isIncludeDraftStatus())
                    .includeFactSheet(entity.isIncludeFactSheet())
                    .nextFrcDate(entity.getNextFrcDate())
                    .compileAgenda(entity.getCompileAgenda())
                    .frcSource(entity.getFrcSource())
                    .xNumber(entity.getXNumber())
                    .timezoneValues(entity.getTimezoneValues())
                    .build();
        } catch (Exception e) {
            logger.error("ERROR mapping entity to DTO for issue: {}, agendaType: {}",
                    entity.getIssueNumber(), entity.getAgendaType(), e);
            throw new RuntimeException("Failed to map BuildAgenda entity for issue " + entity.getIssueNumber(), e);
        }
    }

    public List<BuildAgendaResponse> toDtoList(List<ViewReportsBuildAgenda> entities) {
        if (entities == null) {
            return null;
        }
        logger.info("Mapping {} entities to DTOs", entities.size());
        try {
            return entities.stream()
                    .map(this::toDto)
                    .collect(Collectors.toList());
        } catch (Exception e) {
            logger.error("ERROR in toDtoList while mapping entities", e);
            throw e;
        }
    }
}

