package com.ford.grid.mapper;

import com.ford.grid.model.dto.request.CustomViewRequest;
import com.ford.grid.model.dto.response.CustomViewResponse;
import com.ford.grid.model.entity.CustomView;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class CustomViewMapper {
    @Autowired
    private ModelMapper modelMapper;


    public CustomView toCustomViewEntity(CustomViewRequest customViewRequest) {
        return modelMapper.map(customViewRequest, CustomView.class);
    }

    /**
     * Maps mutable fields from {@code request} onto the existing {@code entity}.
     * {@code combinedFilterQuery} is computed separately (via {@code applyFiltersAndCombinedQuery})
     * and is not part of the request DTO, so it is preserved here to prevent ModelMapper
     * from overwriting it with {@code null}.
     */
    public void updateCustomViewEntity(CustomViewRequest request, CustomView entity) {
        String existingCombinedFilterQuery = entity.getCombinedFilterQuery();

        if (entity.getActiveFilters() != null) {
            entity.getActiveFilters().clear();
        }
        modelMapper.map(request, entity);

        if (existingCombinedFilterQuery != null) {
            entity.setCombinedFilterQuery(existingCombinedFilterQuery);
        }
    }

    public CustomViewResponse toCustomViewDto(CustomView entity) {
        return modelMapper.map(entity, CustomViewResponse.class);
    }

}
