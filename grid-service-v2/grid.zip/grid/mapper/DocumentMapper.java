package com.ford.grid.mapper;

import com.ford.grid.model.dto.response.DocumentResponse;
import com.ford.grid.model.dto.response.LocationsResponse;
import com.ford.grid.model.entity.DocumentView;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class DocumentMapper {

    @Autowired
    private ModelMapper modelMapper;

    public DocumentResponse toResponse(DocumentView entity) {
        if (entity == null) {
            return null;
        }
        return modelMapper.map(entity, DocumentResponse.class);
    }

    public List<DocumentResponse> toResponseList(List<DocumentView> entities) {
        if (entities == null) {
            return null;
        }

        return entities.stream()
            .map(this::toResponse)
            .collect(Collectors.toList());
    }

    public LocationsResponse.LocationInfo toLocationInfo(String location, long documentCount, String docLevel) {
        LocationsResponse.LocationInfo locationInfo = new LocationsResponse.LocationInfo();
        locationInfo.setLocation(location);
        locationInfo.setDocumentCount(documentCount);
        locationInfo.setDocLevel(docLevel);
        return locationInfo;
    }
}
