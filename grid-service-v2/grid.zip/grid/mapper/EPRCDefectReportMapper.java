package com.ford.grid.mapper;

import com.ford.grid.model.dto.request.EPRCDefectReportRequest;
import com.ford.grid.model.dto.response.EPRCDefectReportResponse;
import com.ford.grid.model.entity.EPRCDefectReport;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class EPRCDefectReportMapper {
    private final ModelMapper modelMapper;

    public EPRCDefectReport toEntity(EPRCDefectReportRequest defectReportRequest) {
        return modelMapper.map(defectReportRequest, EPRCDefectReport.class);
    }
    public EPRCDefectReportResponse toDto(EPRCDefectReport eprcDefectReport) {
        return modelMapper.map(eprcDefectReport, EPRCDefectReportResponse.class);
    }

}
