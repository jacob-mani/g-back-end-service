package com.ford.grid.mapper;

import com.ford.grid.model.dto.request.EPRCFactSheetRequest;
import com.ford.grid.model.dto.request.EPRCFactSheetSection;
import com.ford.grid.model.dto.response.EPRCFactSheetResponse;
import com.ford.grid.model.entity.EPRCFactSheet;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class EPRCFactSheetMapper {

    @Autowired
    private ModelMapper modelMapper;

    public EPRCFactSheet toEntity(EPRCFactSheetRequest eprcFactSheetRequest) {
        return modelMapper.map(eprcFactSheetRequest, EPRCFactSheet.class);
    }

    public EPRCFactSheetResponse toDto(EPRCFactSheet eprcFactSheet) {
        EPRCFactSheetResponse response = modelMapper.map(eprcFactSheet, EPRCFactSheetResponse.class);
        return response;
    }

}
