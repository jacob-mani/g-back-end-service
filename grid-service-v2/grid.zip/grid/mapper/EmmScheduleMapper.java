package com.ford.grid.mapper;

import com.ford.grid.model.dto.request.EmmScheduleRequest;
import com.ford.grid.model.dto.response.EmmScheduleResponse;
import com.ford.grid.model.entity.EmmSchedule;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class EmmScheduleMapper {

    private final ModelMapper modelMapper;

    public EmmSchedule toEntity(EmmScheduleRequest emmScheduleRequest) {
        return modelMapper.map(emmScheduleRequest, EmmSchedule.class);
    }

    public EmmScheduleResponse toDto(EmmSchedule emmSchedule) {
        return modelMapper.map(emmSchedule, EmmScheduleResponse.class);
    }
}
