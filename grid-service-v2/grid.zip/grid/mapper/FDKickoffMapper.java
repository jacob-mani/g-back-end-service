package com.ford.grid.mapper;

import com.ford.grid.model.dto.request.FDKickoffRequest;
import com.ford.grid.model.dto.response.FDKickoffResponse;
import com.ford.grid.model.entity.FDKickoff;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class FDKickoffMapper {
    private final ModelMapper modelMapper;

    public FDKickoff toEntity(FDKickoffRequest fdKickoffRequest) {
        return modelMapper.map(fdKickoffRequest, FDKickoff.class);
    }

    public FDKickoffResponse toResponse(FDKickoff fdKickoff) {
        return modelMapper.map(fdKickoff, FDKickoffResponse.class);
    }

}
