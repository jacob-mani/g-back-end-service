package com.ford.grid.mapper;

import com.ford.grid.model.dto.request.FrcApproversDto;
import com.ford.grid.model.dto.request.FrcContributorsDto;
import com.ford.grid.model.dto.request.FrcFactSheetFileDto;
import com.ford.grid.model.dto.request.FrcFactsheetRequest;
import com.ford.grid.model.dto.response.FrcFactSheetResponse;
import com.ford.grid.model.entity.ApproversList;
import com.ford.grid.model.entity.ContributorsList;
import com.ford.grid.model.entity.FrcFactSheetFile;
import com.ford.grid.model.entity.FrcFactsheet;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.Comparator;
import java.util.List;

@Component
public class FRCFactsheetMapper {

    @Autowired
    private ModelMapper modelMapper;

    public FrcFactSheetResponse toFrcFactSheetResponse(FrcFactsheet entity) {
        FrcFactSheetResponse response = modelMapper.map(entity, FrcFactSheetResponse.class);

        // Get the file with the highest fileVersion
        entity.getFrcFactSheetFile().stream()
                .max(Comparator.comparingInt(FrcFactSheetFile::getFileVersion))
                .ifPresent(lastFile -> {
                    response.setFactSheetFile(modelMapper.map(lastFile, FrcFactSheetFileDto.class));
                });

        return response;
    }

    public FrcFactsheet toFactSheetEntity(FrcFactsheetRequest request) {
        return modelMapper.map(request, FrcFactsheet.class);
    }


    public List<ContributorsList> toContributorEntity( List<FrcContributorsDto> contributorsList) {
       if(CollectionUtils.isEmpty(contributorsList)) {
              return null;
       }
        return contributorsList.stream()
                .map(contributorDto -> modelMapper.map(contributorDto, ContributorsList.class))
                .toList();
    }

    public List<ApproversList> toApproversListEntity(List<FrcApproversDto> approversList) {
        if(CollectionUtils.isEmpty(approversList)){
            return null;
        }
        return approversList.stream()
                .map(approverDto -> modelMapper.map(approverDto, ApproversList.class))
                .toList();
    }


    public ApproversList toApproversEntity(FrcApproversDto frcApproversDto) {
        if(frcApproversDto == null){
            return null;
        }
        return modelMapper.map(frcApproversDto, ApproversList.class);
    }

    public FrcFactSheetFileDto toFrcFactSheetFileDto(FrcFactSheetFile entity) {
        return modelMapper.map(entity, FrcFactSheetFileDto.class);
    }
}
