
package com.ford.grid.mapper;

import com.ford.grid.model.dto.request.FRCMemoRequest;
import com.ford.grid.model.dto.response.FRCMemoResponse;
import com.ford.grid.model.entity.FRCMemo;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class FRCMemoMapper {

    private final ModelMapper modelMapper;

    @Autowired
    public FRCMemoMapper(ModelMapper modelMapper) {
        this.modelMapper = modelMapper;
    }

    public FRCMemoResponse toDto(Optional<FRCMemo> entity) {
        return modelMapper.map(entity, FRCMemoResponse.class);
    }

    public FRCMemo toEntity(FRCMemoRequest request) {
        return modelMapper.map(request, FRCMemo.class);
    }

}

