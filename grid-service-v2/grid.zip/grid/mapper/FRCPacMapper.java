
package com.ford.grid.mapper;

import com.ford.grid.model.dto.request.FRCPacRequest;
import com.ford.grid.model.dto.response.FRCPacResponse;
import com.ford.grid.model.entity.FRCPac;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class FRCPacMapper {

    private final ModelMapper modelMapper;

    @Autowired
    public FRCPacMapper(ModelMapper modelMapper) {
        this.modelMapper = modelMapper;
    }

    public FRCPacResponse toDto(Optional<FRCPac> entity) {
        return modelMapper.map(entity, FRCPacResponse.class);
    }

    public FRCPac toEntity(FRCPacRequest request) {
        return modelMapper.map(request, FRCPac.class);
    }

}

