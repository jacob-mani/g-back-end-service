
package com.ford.grid.mapper;

import com.ford.grid.model.dto.request.FRCScheduleRequest;
import com.ford.grid.model.dto.response.FRCScheduleResponse;
import com.ford.grid.model.entity.FRCSchedule;
import com.ford.grid.model.entity.FrcAgenda;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class FRCScheduleMapper {

    private final ModelMapper modelMapper;

    @Autowired
    public FRCScheduleMapper(ModelMapper modelMapper) {
        this.modelMapper = modelMapper;
    }

    public FRCScheduleResponse toDto(Optional<FRCSchedule> entity) {
        return modelMapper.map(entity, FRCScheduleResponse.class);
    }

    public FRCSchedule toEntity(FRCScheduleRequest request) {
        return modelMapper.map(request, FRCSchedule.class);
    }

    public FrcAgenda toFrcAgenda(FRCScheduleRequest request) {
        return modelMapper.map(request, FrcAgenda.class);
    }
}

