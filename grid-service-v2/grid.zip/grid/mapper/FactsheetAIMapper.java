package com.ford.grid.mapper;

import com.ford.grid.model.dto.response.FactsheetAIResponse;
import com.ford.grid.model.entity.FactsheetAIEntity;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class FactsheetAIMapper {

    @Autowired
    private ModelMapper modelMapper;

    public FactsheetAIEntity toEntity(FactsheetAIResponse dto) {
        return modelMapper.map(dto, FactsheetAIEntity.class);
    }

    public FactsheetAIResponse toDto(FactsheetAIEntity entity) {
        return modelMapper.map(entity, FactsheetAIResponse.class);
    }
}
