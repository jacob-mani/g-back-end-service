package com.ford.grid.mapper;

import javax.annotation.PostConstruct;

import java.util.ArrayList;
import java.util.List;


import com.ford.grid.model.dto.request.*;
import com.ford.grid.model.dto.response.FdQuestionnaire6Response;
import com.ford.grid.model.dto.response.FdQuestionnaire10Response;
import com.ford.grid.model.entity.*;
import com.ford.grid.model.dto.request.FdQuestionnaire1Dto;
import com.ford.grid.model.dto.request.FdQuestionnaire2Dto;
import com.ford.grid.model.dto.request.FdQuestionnaire3Dto;
import com.ford.grid.model.dto.request.FdQuestionnaire4Dto;
import com.ford.grid.model.dto.request.FdQuestionnaire8Dto;
import com.ford.grid.model.dto.request.FdQuestionnaire9Dto;
import com.ford.grid.model.dto.request.FdQuestionnaire11Dto;
import com.ford.grid.model.dto.request.FdCorrectivePartDto;
import com.ford.grid.model.dto.request.FdQuestionnaire6Request;
import com.ford.grid.model.dto.request.FdQuestionnaire10Request;
import com.ford.grid.model.dto.response.FdQuestionnaire6Response;
import com.ford.grid.model.dto.response.FdQuestionnaire10Response;
import com.ford.grid.model.entity.FdQuestionnaire1;
import com.ford.grid.model.entity.FdQuestionnaire2;
import com.ford.grid.model.entity.FdQuestionnaire3;
import com.ford.grid.model.entity.FdQuestionnaire4;
import com.ford.grid.model.entity.FdQuestionnaire6;
import com.ford.grid.model.entity.FdQuestionnaire8;
import com.ford.grid.model.entity.FdQuestionnaire9;
import com.ford.grid.model.entity.FdQuestionnaire10;
import com.ford.grid.model.entity.FdQuestionnaire11;
import com.ford.grid.model.entity.FdCorrectivePart;
import com.ford.grid.model.entity.FdPartsPurge;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component
public class FdQuestionnaireMapper {

    @Autowired
    private ModelMapper modelMapper;

    @PostConstruct
    private void configureModelMapper() {
        modelMapper.getConfiguration()
                .setSkipNullEnabled(true)
                .setFieldMatchingEnabled(true);
    }

    public FdQuestionnaire1 toEntity(FdQuestionnaire1Dto fdQuestionnaire1Dto) {
        return modelMapper.map(fdQuestionnaire1Dto, FdQuestionnaire1.class);
    }

    public FdQuestionnaire1Dto toDto(FdQuestionnaire1 fdQuestionnaire1) {
        return modelMapper.map(fdQuestionnaire1, FdQuestionnaire1Dto.class);
    }

    public void toExistingEntity(FdQuestionnaire1Dto fdQuestionnaire1Dto, FdQuestionnaire1 fdQuestionnaire1) {
        modelMapper.map(fdQuestionnaire1Dto, fdQuestionnaire1);
    }

    public FdQuestionnaire2 toEntity(FdQuestionnaire2Dto dto) {
        return modelMapper.map(dto, FdQuestionnaire2.class);
    }

    public FdQuestionnaire2Dto toDto(FdQuestionnaire2 entity) {
        return modelMapper.map(entity, FdQuestionnaire2Dto.class);
    }

    public void toExistingEntity(FdQuestionnaire2Dto dto, FdQuestionnaire2 entity) {
        modelMapper.map(dto, entity);
    }

    public FdQuestionnaire8 toEntity(FdQuestionnaire8Dto fdQuestionnaire8Dto) {
        return modelMapper.map(fdQuestionnaire8Dto, FdQuestionnaire8.class);
    }

    public FdQuestionnaire8Dto toDto(FdQuestionnaire8 fdQuestionnaire8) {
        return modelMapper.map(fdQuestionnaire8, FdQuestionnaire8Dto.class);
    }

    public void toExistingEntity(FdQuestionnaire8Dto fdQuestionnaire8Dto, FdQuestionnaire8 fdQuestionnaire8) {
        modelMapper.map(fdQuestionnaire8Dto, fdQuestionnaire8);
    }

    public FdQuestionnaire4 toEntity(FdQuestionnaire4Dto dto) {
        return modelMapper.map(dto, FdQuestionnaire4.class);
    }

    public FdQuestionnaire4Dto toDto(FdQuestionnaire4 entity) {
        return modelMapper.map(entity, FdQuestionnaire4Dto.class);
    }

    public void toExistingEntity(FdQuestionnaire4Dto dto, FdQuestionnaire4 entity) {
        modelMapper.map(dto, entity);
    }

    public FdQuestionnaire3 toEntity(FdQuestionnaire3Dto fdQuestionnaire3Dto) {
        return modelMapper.map(fdQuestionnaire3Dto, FdQuestionnaire3.class);
    }

    public FdQuestionnaire3Dto toDto(FdQuestionnaire3 fdQuestionnaire3) {
        return modelMapper.map(fdQuestionnaire3, FdQuestionnaire3Dto.class);
    }

    public void toExistingEntity(FdQuestionnaire3Dto fdQuestionnaire3Dto, FdQuestionnaire3 fdQuestionnaire3) {
        modelMapper.map(fdQuestionnaire3Dto, fdQuestionnaire3);
    }

    public FdQuestionnaire11 toEntity(FdQuestionnaire11Dto fdQuestionnaire11Dto) {
        return modelMapper.map(fdQuestionnaire11Dto, FdQuestionnaire11.class);
    }

    public FdQuestionnaire11Dto toDto(FdQuestionnaire11 fdQuestionnaire11) {
        return modelMapper.map(fdQuestionnaire11, FdQuestionnaire11Dto.class);
    }

    public void toExistingEntity(FdQuestionnaire11Dto fdQuestionnaire11Dto, FdQuestionnaire11 fdQuestionnaire11) {
        modelMapper.map(fdQuestionnaire11Dto, fdQuestionnaire11);
    }

    public FdQuestionnaire10Request toRequest(FdQuestionnaire10 entity) {
        return modelMapper.map(entity, FdQuestionnaire10Request.class);
    }

    public FdQuestionnaire10 toEntity(FdQuestionnaire10Request dto) {
        return modelMapper.map(dto, FdQuestionnaire10.class);
    }

    public FdQuestionnaire10Response toDto(FdQuestionnaire10 entity) {
        return modelMapper.map(entity, FdQuestionnaire10Response.class);
    }

    public void toExistingEntity(FdQuestionnaire10Request dto, FdQuestionnaire10 entity) {
        modelMapper.map(dto, entity);
    }

    public FdQuestionnaire6Request toRequest(FdQuestionnaire6 entity) {
        return modelMapper.map(entity, FdQuestionnaire6Request.class);
    }

    public FdQuestionnaire6 toEntity(FdQuestionnaire6Request dto) {
        return modelMapper.map(dto, FdQuestionnaire6.class);
    }

    public FdQuestionnaire6Response toDto(FdQuestionnaire6 entity) {
        return modelMapper.map(entity, FdQuestionnaire6Response.class);
    }

    public void toExistingEntity(FdQuestionnaire6Request dto, FdQuestionnaire6 entity) {
        modelMapper.map(dto, entity);
    }
    public FdQuestionnaire7 toEntity(FdQuestionnaire7Dto fdQuestionnaire7Dto) {
        return modelMapper.map(fdQuestionnaire7Dto, FdQuestionnaire7.class);
    }

    public FdQuestionnaire7Dto toDto(FdQuestionnaire7 fdQuestionnaire7) {
        return modelMapper.map(fdQuestionnaire7, FdQuestionnaire7Dto.class);
    }

    public void toExistingEntity(FdQuestionnaire7Dto fdQuestionnaire7Dto, FdQuestionnaire7 fdQuestionnaire7) {
        modelMapper.map(fdQuestionnaire7Dto, fdQuestionnaire7);
    }

    public FdQuestionnaire9 toEntity(FdQuestionnaire9Dto fdQuestionnaire9Dto) {
        return modelMapper.map(fdQuestionnaire9Dto, FdQuestionnaire9.class);
    }

    public FdQuestionnaire9Dto toDto(FdQuestionnaire9 fdQuestionnaire9) {
        return modelMapper.map(fdQuestionnaire9, FdQuestionnaire9Dto.class);
    }

    public void toExistingEntity(FdQuestionnaire9Dto fdQuestionnaire9Dto, FdQuestionnaire9 fdQuestionnaire9) {
        modelMapper.map(fdQuestionnaire9Dto, fdQuestionnaire9);
    }

    public FdCorrectivePart toEntity(FdCorrectivePartDto dto) {
        if (dto == null) {
            return null;
        }
        FdCorrectivePart entity = new FdCorrectivePart();
        entity.setIssueNumber(dto.getIssueNumber());
        entity.setCorrectiveParts(toCorrectivePartList(dto.getCorrectiveParts()));
        return entity;
    }

    public FdCorrectivePartDto toDto(FdCorrectivePart entity) {
        FdCorrectivePartDto dto = new FdCorrectivePartDto();
        dto.setIssueNumber(entity.getIssueNumber());
        dto.setStatus(entity.getStatus());
        dto.setCreatedBy(entity.getCreatedBy());
        dto.setCreatedAt(entity.getCreatedAt());
        dto.setUpdatedBy(entity.getUpdatedBy());
        dto.setUpdatedAt(entity.getUpdatedAt());
        if (entity.getCorrectiveParts() != null) {
            List<CorrectivePartDto> partDtos = new ArrayList<>();
            for (CorrectivePart p : entity.getCorrectiveParts()) {
                CorrectivePartDto d = new CorrectivePartDto();
                d.setEngineeringPartNumber(p.getEngineeringPartNumber());
                d.setServicePartNumber(p.getServicePartNumber());
                d.setFinisCode(p.getFinisCode());
                d.setWersAlertNumber(p.getWersAlertNumber());
                d.setWersConcernNumber(p.getWersConcernNumber());
                d.setCorrectiveDate(p.getCorrectiveDate());
                partDtos.add(d);
            }
            dto.setCorrectiveParts(partDtos);
        }
        return dto;
    }

    public void toExistingEntity(FdCorrectivePartDto dto, FdCorrectivePart entity) {
        entity.setIssueNumber(dto.getIssueNumber());
        entity.setCorrectiveParts(toCorrectivePartList(dto.getCorrectiveParts()));
    }

    private List<CorrectivePart> toCorrectivePartList(List<CorrectivePartDto> dtos) {
        if (dtos == null) return new ArrayList<>();
        List<CorrectivePart> parts = new ArrayList<>();
        for (CorrectivePartDto d : dtos) {
            CorrectivePart p = new CorrectivePart();
            p.setEngineeringPartNumber(d.getEngineeringPartNumber());
            p.setServicePartNumber(d.getServicePartNumber());
            p.setFinisCode(d.getFinisCode());
            p.setWersAlertNumber(d.getWersAlertNumber());
            p.setWersConcernNumber(d.getWersConcernNumber());
            p.setCorrectiveDate(d.getCorrectiveDate());
            parts.add(p);
        }
        return parts;
    }
    public FdAffectedProgram toEntity(FdAffectedProgramDto dto) {
        return modelMapper.map(dto, FdAffectedProgram.class);
    }

    public FdAffectedProgramDto toDto(FdAffectedProgram entity) {
        return modelMapper.map(entity, FdAffectedProgramDto.class);
    }

    public void toExistingEntity(FdAffectedProgramDto dto, FdAffectedProgram entity) {
        modelMapper.map(dto, entity);
    }

    public FdPartsPurge toEntity(FdPartsPurgeDto dto) {

        FdPartsPurge entity = new FdPartsPurge();
        entity.setIssueNumber(dto.getIssueNumber());
        entity.setParts(toPurgePartList(dto.getParts()));
        return entity;
    }

    public FdPartsPurgeDto toDto(FdPartsPurge entity) {
        FdPartsPurgeDto dto = new FdPartsPurgeDto();
        dto.setIssueNumber(entity.getIssueNumber());
        dto.setStatus(entity.getStatus());
        dto.setCreatedBy(entity.getCreatedBy());
        dto.setCreatedAt(entity.getCreatedAt());
        dto.setUpdatedBy(entity.getUpdatedBy());
        dto.setUpdatedAt(entity.getUpdatedAt());
        if (entity.getParts() != null) {
            List<PurgePartDto> partDtos = new ArrayList<>();
            for (PurgePart p : entity.getParts()) {
                PurgePartDto d = new PurgePartDto();
                d.setEngineeringPartNumber(p.getEngineeringPartNumber());
                d.setServicePartNumber(p.getServicePartNumber());
                d.setFinisCode(p.getFinisCode());
                d.setPartName(p.getPartName());
                d.setPurgeStatus(p.getPurgeStatus());
                d.setCompletionDate(p.getCompletionDate());
                d.setLastUsedDate(p.getLastUsedDate());
                d.setComments(p.getComments());
                partDtos.add(d);
            }
            dto.setParts(partDtos);
        }
        return dto;
    }

    public void toExistingEntity(FdPartsPurgeDto dto, FdPartsPurge entity) {
        entity.setIssueNumber(dto.getIssueNumber());
        entity.setParts(toPurgePartList(dto.getParts()));
    }

    private List<PurgePart> toPurgePartList(List<PurgePartDto> dtos) {
        if (dtos == null) return new ArrayList<>();
        List<PurgePart> parts = new ArrayList<>();
        for (PurgePartDto d : dtos) {
            PurgePart p = new PurgePart();
            p.setEngineeringPartNumber(d.getEngineeringPartNumber());
            p.setServicePartNumber(d.getServicePartNumber());
            p.setFinisCode(d.getFinisCode());
            p.setPartName(d.getPartName());
            p.setPurgeStatus(d.getPurgeStatus());
            p.setCompletionDate(d.getCompletionDate());
            p.setLastUsedDate(d.getLastUsedDate());
            p.setComments(d.getComments());
            parts.add(p);
        }
        return parts;
    }

    public FdPartSummary toEntity(FdPartSummaryDto dto) {
        return modelMapper.map(dto, FdPartSummary.class);
    }

    public FdPartSummaryDto toDto(FdPartSummary entity) {
        return modelMapper.map(entity, FdPartSummaryDto.class);
    }

    public void toExistingEntity(FdPartSummaryDto dto, FdPartSummary entity) {
        modelMapper.map(dto, entity);
    }

    public FdMra toEntity(FdMraDto dto) {
        return modelMapper.map(dto, FdMra.class);
    }

    public FdMraDto toDto(FdMra entity) {
        return modelMapper.map(entity, FdMraDto.class);
    }

    public void toExistingEntity(FdMraDto dto, FdMra entity) {
        modelMapper.map(dto, entity);
    }


    // public List<Attachment> toAttachmentResponses(List<UploadResponse> uploadResponses) {
    //   List<Attachment> attachments = new ArrayList<>();
    //   for (int i = 0; i < uploadResponses.size(); i++) {
    //     UploadResponse response = uploadResponses.get(i);
    //     Attachment doc = modelMapper.map(response, Attachment.class);
    //     doc.setOrder(i + 1);
    //     doc.setUpdatedAt(LocalDateTime.now());
    //     attachments.add(doc);
    //   }
    //   return attachments;
    // }
}
