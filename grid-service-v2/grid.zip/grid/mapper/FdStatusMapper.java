package com.ford.grid.mapper;

import com.ford.grid.model.dto.request.FdStatusRequest;
import com.ford.grid.model.dto.response.FdStatusResponse;
import com.ford.grid.model.entity.FdStatus;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class FdStatusMapper {
    @Autowired
    private ModelMapper modelMapper;

    public FdStatus toEntity(FdStatusRequest request) {
        return modelMapper.map(request, FdStatus.class);
    }

    public FdStatusResponse toResponse(FdStatus fdStatus) {
        return modelMapper.map(fdStatus, FdStatusResponse.class);
    }
}