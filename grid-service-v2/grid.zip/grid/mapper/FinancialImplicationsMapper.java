package com.ford.grid.mapper;

import com.ford.grid.model.dto.request.FinancialImplicationsRequest;
import com.ford.grid.model.dto.response.FinancialImplicationsResponse;
import com.ford.grid.model.entity.FinancialImplications;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class FinancialImplicationsMapper {

    private final ModelMapper modelMapper;

    @Autowired
    public FinancialImplicationsMapper(ModelMapper modelMapper) {
        this.modelMapper = modelMapper;
    }

    public FinancialImplicationsResponse toDto(Optional<FinancialImplications> entity) {
        return modelMapper.map(entity, FinancialImplicationsResponse.class);
    }

    public FinancialImplications toEntity(FinancialImplicationsRequest request) {
        return modelMapper.map(request, FinancialImplications.class);
    }

}
