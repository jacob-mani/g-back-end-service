package com.ford.grid.mapper;

import com.ford.grid.model.dto.request.ForumConfirmRegulatoryImpactRequest;
import com.ford.grid.model.dto.response.ForumConfirmRegulatoryImpactResponse;
import com.ford.grid.model.entity.ForumConfirmRegulatoryImpact;
import lombok.AllArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@Component
@AllArgsConstructor
public class ForumConfirmRegulatoryImpactMapper {

    private final ModelMapper modelMapper;

    public ForumConfirmRegulatoryImpactResponse toForumConfirmRegulatoryImpactDto(ForumConfirmRegulatoryImpact forumConfirmRegulatoryImpact) {
        return modelMapper.map(forumConfirmRegulatoryImpact, ForumConfirmRegulatoryImpactResponse.class);
    }

    public ForumConfirmRegulatoryImpact toEntity(ForumConfirmRegulatoryImpactRequest request) {
        return modelMapper.map(request, ForumConfirmRegulatoryImpact.class);
    }
}
