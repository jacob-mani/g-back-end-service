package com.ford.grid.mapper;

import com.ford.grid.model.dto.request.FDKickoffRequest;
import com.ford.grid.model.dto.request.ForumCorrespondenceRequest;
import com.ford.grid.model.dto.response.ForumCorrespondenceResponse;
import com.ford.grid.model.entity.FDKickoff;
import com.ford.grid.model.entity.ForumCorrespondence;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

@Service
public class ForumCorrespondenceMapper {
    private final ModelMapper modelMapper;

    public ForumCorrespondenceMapper(ModelMapper modelMapper) {
        this.modelMapper = modelMapper;
    }

    public ForumCorrespondenceResponse toDto(ForumCorrespondence forumCorrespondence) {
        return modelMapper.map(forumCorrespondence, ForumCorrespondenceResponse.class);
    }

    public ForumCorrespondence toEntity(ForumCorrespondenceRequest forumCorrespondenceRequest) {
        return modelMapper.map(forumCorrespondenceRequest, ForumCorrespondence.class);
    }

    public void updateEntityForumCorresRequest(ForumCorrespondenceRequest forumCorrespondenceRequest, ForumCorrespondence entity) {
        modelMapper.map(forumCorrespondenceRequest, entity);
    }
}
