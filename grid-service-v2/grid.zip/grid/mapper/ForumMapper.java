package com.ford.grid.mapper;

import com.ford.grid.model.dto.request.ForumGovActionRequest;
import com.ford.grid.model.dto.request.GLSchForumAgeRequest;
import com.ford.grid.model.dto.request.SchForumAgeRequest;
import com.ford.grid.model.dto.response.GLSchForumAgeResponse;
import com.ford.grid.model.dto.response.SchForumAgeResponse;
import com.ford.grid.model.entity.ForumAgenda;
import com.ford.grid.model.entity.GlobalForumAgenda;
import com.ford.grid.model.entity.ForumGovAction;
import com.ford.grid.model.dto.response.ForumGovActionResponse;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component
public class ForumMapper {

    @Autowired
    private  ModelMapper modelMapper;


    public ForumAgenda toScheduleForumEntity(SchForumAgeRequest schForumAgeRequest) {
        return modelMapper.map(schForumAgeRequest, ForumAgenda.class);
    }

    public SchForumAgeResponse toScheduleForumDto(ForumAgenda model) {
        return modelMapper.map(model, SchForumAgeResponse.class);
    }

    public GlobalForumAgenda toGlobalAgendaModel(GLSchForumAgeRequest GLSchForumAgeRequest) {
        return modelMapper.map(GLSchForumAgeRequest, GlobalForumAgenda.class);
    }

    public GLSchForumAgeResponse toGlobalAgendaResponse(GlobalForumAgenda model) {
        return modelMapper.map(model, GLSchForumAgeResponse.class);
    }

    public ForumGovActionResponse toForumActionResponse(ForumGovAction forumAction) {
        return modelMapper.map(forumAction, ForumGovActionResponse.class);
    }

    public void updateEntitySchForum(SchForumAgeRequest schForumAgeRequest, ForumAgenda entity) {
        // Preserve the entity's DB identity and audit fields before mapping —
        // modelMapper would otherwise overwrite them with the request's values
        // (e.g. request id=null creates a duplicate; request id=X overwrites wrong doc).
        String existingId        = entity.getId();
        String existingCreatedBy = entity.getCreatedBy();
        java.time.LocalDateTime existingCreatedAt = entity.getCreatedAt();

        modelMapper.map(schForumAgeRequest, entity);

        // Restore preserved fields
        entity.setId(existingId);
        entity.setCreatedBy(existingCreatedBy);
        entity.setCreatedAt(existingCreatedAt);
    }

    public void updateEntityGlobalSchForum(GLSchForumAgeRequest globalRequest, GlobalForumAgenda entity) {
        modelMapper.map(globalRequest, entity);
    }

    public void updateEntityGlobAction(ForumGovActionRequest forumActionRequest, ForumGovAction entity) {
        modelMapper.map(forumActionRequest, entity);
    }
}
