package com.ford.grid.mapper;

import com.ford.grid.model.dto.request.ForumMinutesRequest;
import com.ford.grid.model.dto.response.ForumMinsEprcResponse;
import com.ford.grid.model.entity.ForumMinutes;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class ForumMinsEprcMapper {
    private final ModelMapper modelMapper;

    public ForumMinutes toEntity(ForumMinutesRequest forumMinsEprcRequest) {
        return modelMapper.map(forumMinsEprcRequest, ForumMinutes.class);
    }

    public ForumMinsEprcResponse toDto(ForumMinutes forumMinutes) {
        return modelMapper.map(forumMinutes, ForumMinsEprcResponse.class);
    }

    public void updateEntityFromRequest(ForumMinutesRequest request, ForumMinutes entity) {
        modelMapper.map(request, entity);
    }
}


