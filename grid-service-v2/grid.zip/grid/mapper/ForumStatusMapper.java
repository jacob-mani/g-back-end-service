package com.ford.grid.mapper;

import com.ford.grid.model.dto.request.ForumNoteApprovers;
import com.ford.grid.model.dto.request.ForumStatusRequest;
import com.ford.grid.model.dto.response.ForumStatusResponse;
import com.ford.grid.model.entity.ForumConclusion;
import com.ford.grid.model.entity.ForumStatus;
import com.ford.grid.model.entity.NoteApprovers;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ForumStatusMapper {
    @Autowired
    private ModelMapper modelMapper;

    public ForumConclusion toEntity(ForumStatusRequest request) {
        return modelMapper.map(request, ForumConclusion.class);
    }

    public ForumStatusRequest toRequestDto(ForumConclusion forumConclusion) {
        return modelMapper.map(forumConclusion, ForumStatusRequest.class);
    }

    public ForumStatus toEntityForumStatus(ForumStatusRequest request) {
        return modelMapper.map(request, ForumStatus.class);
    }

    public NoteApprovers setNoteApproverEntity(ForumNoteApprovers approver) {
        return modelMapper.map(approver, NoteApprovers.class);
    }

    public ForumNoteApprovers setNoteApproverDto(NoteApprovers approver) {
        return modelMapper.map(approver, ForumNoteApprovers.class);
    }

    public ForumStatusResponse toResponse(ForumStatus forumStatus) {
        ForumStatusResponse response = modelMapper.map(forumStatus, ForumStatusResponse.class);
        ForumConclusion conclusion = forumStatus.getForumConclusion();
        if (conclusion != null) {
            modelMapper.map(conclusion, response);
        }
        return response;
    }
}
