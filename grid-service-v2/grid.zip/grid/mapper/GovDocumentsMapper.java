package com.ford.grid.mapper;

import com.ford.grid.model.dto.request.FrcApproversDto;
import com.ford.grid.model.dto.request.Part573FileDto;
import com.ford.grid.model.dto.request.Part573Request;
import com.ford.grid.model.dto.response.DocResponse;
import com.ford.grid.model.dto.response.Part573Response;
import com.ford.grid.model.dto.response.TcDocResponse;
import com.ford.grid.model.entity.ApproversList;
import com.ford.grid.model.entity.GovDocuments;
import com.ford.grid.model.entity.Part573File;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class GovDocumentsMapper {

    private static final Logger LOGGER = LoggerFactory.getLogger(GovDocumentsMapper.class);

    // ─────────────────────────────────────────────
    // Request → Entity
    // ─────────────────────────────────────────────

    /**
     * Map Part573Request to GovDocuments entity (top-level fields only).
     * Part573File is built separately via mapPart573DetailFromRequest.
     */
    public GovDocuments toEntity(Part573Request request) {
        if (request == null) {
            return null;
        }
        GovDocuments entity = new GovDocuments();
        entity.setIssueNumber(request.getIssueNumber());
        entity.setImplId(request.getImplId());
        entity.setPopulationId(request.getPopulationId());
        entity.setIssueTitle(request.getIssueTitle());
        entity.setRegion(request.getRegion());
        entity.setDocFileName(request.getDocFileName());
        entity.setDocFileUrl(request.getDocFileUrl());
        // Audit
        entity.setCreatedBy(request.getCreatedBy());
        entity.setCreatedAt(request.getCreatedAt());
        entity.setUpdatedBy(request.getUpdatedBy());
        entity.setUpdatedAt(request.getUpdatedAt());
        return entity;
    }

    /**
     * Map FrcApproversDto → ApproversList entity (complete mapping).
     */
    public ApproversList toApproversEntity(FrcApproversDto dto) {
        if (dto == null) {
            return null;
        }
        ApproversList entity = new ApproversList();
        entity.setSequenceNo(dto.getSequenceNo());
        entity.setTitle(dto.getTitle());
        entity.setCdsid(dto.getCdsid());
        entity.setName(dto.getName());
        entity.setFixed(dto.getFixed());
        entity.setNotAvailable(dto.getNotAvailable());
        entity.setProcessStatus(dto.getProcessStatus());
        entity.setPendingFrom(dto.getPendingFrom());
        entity.setApprovedBy(dto.getApprovedBy());
        entity.setApprovedDate(dto.getApprovedDate());
        // Approval workflow fields
        entity.setApprovalDate(dto.getApprovalDate());
        entity.setApprovalAction(dto.getApprovalAction());
        entity.setComments(dto.getComments());
        return entity;
    }

    /**
     * Map list of FrcApproversDto → list of ApproversList entities.
     */
    public List<ApproversList> toApproversListEntity(List<FrcApproversDto> dtoList) {
        if (dtoList == null || dtoList.isEmpty()) {
            return null;
        }
        return dtoList.stream()
                .map(this::toApproversEntity)
                .collect(Collectors.toList());
    }

    /**
     * Map Part573FileDto → Part573File entity (complete mapping).
     */
    public Part573File toFileEntity(Part573FileDto dto) {
        if (dto == null) {
            return null;
        }
        Part573File file = new Part573File();
        file.setDocSubject(dto.getDocSubject());
        file.setDocTargetDate(dto.getDocTargetDate());
        // Approvers
        file.setApproversList(toApproversListEntity(dto.getApproversList()));
        file.setDraftReviewer(toApproversEntity(dto.getDraftReviewer()));
        file.setFinalReviewer(toApproversEntity(dto.getFinalReviewer()));
        // Concluded
        file.setConcluded(dto.isConcluded());
        file.setConcludedBy(dto.getConcludedBy());
        file.setConcludedDate(dto.getConcludedDate());
        // Approval status fields (preserve existing values if DTO fields are null)
        if (dto.getDraftReviewerStatus() != null) {
            file.setDraftReviewerStatus(dto.getDraftReviewerStatus());
        }
        if (dto.getApproverStatus() != null) {
            file.setApproverStatus(dto.getApproverStatus());
        }
        if (dto.getFinalReviewerStatus() != null) {
            file.setFinalReviewerStatus(dto.getFinalReviewerStatus());
        }
        if (dto.getApprovalStatus() != null) {
            file.setApprovalStatus(dto.getApprovalStatus());
        }
        // DocuSign fields
        file.setDocuSignEnvelopeId(dto.getDocuSignEnvelopeId());
        file.setDocuSignStatus(dto.getDocuSignStatus());
        file.setDocuSignFileName(dto.getDocuSignFileName());
        file.setDocuSignFileNameGCP(dto.getDocuSignFileNameGCP());
        file.setSignedDocumentUrl(dto.getSignedDocumentUrl());
        // Audit
        file.setCreatedBy(dto.getCreatedBy());
        file.setCreatedAt(dto.getCreatedAt());
        file.setUpdatedBy(dto.getUpdatedBy());
        file.setUpdatedAt(dto.getUpdatedAt());
        return file;
    }

    // ─────────────────────────────────────────────
    // Entity → DTO / Response
    // ─────────────────────────────────────────────

    /**
     * Map ApproversList entity → FrcApproversDto (complete mapping).
     */
    public FrcApproversDto toApproversDto(ApproversList entity) {
        if (entity == null) {
            return null;
        }
        FrcApproversDto dto = new FrcApproversDto();
        dto.setSequenceNo(entity.getSequenceNo());
        dto.setTitle(entity.getTitle());
        dto.setCdsid(entity.getCdsid());
        dto.setName(entity.getName());
        dto.setFixed(entity.getFixed());
        dto.setNotAvailable(entity.getNotAvailable());
        dto.setProcessStatus(entity.getProcessStatus());
        dto.setPendingFrom(entity.getPendingFrom());
        dto.setApprovedBy(entity.getApprovedBy());
        dto.setApprovedDate(entity.getApprovedDate());
        // Approval workflow fields
        dto.setApprovalDate(entity.getApprovalDate());
        dto.setApprovalAction(entity.getApprovalAction());
        dto.setComments(entity.getComments());
        return dto;
    }

    /**
     * Map Part573File entity → Part573FileDto (complete mapping).
     */
    public Part573FileDto toFileDto(Part573File file) {
        if (file == null) {
            return null;
        }
        Part573FileDto dto = new Part573FileDto();
        dto.setDocSubject(file.getDocSubject());
        dto.setDocTargetDate(file.getDocTargetDate());
        // Approvers
        if (file.getApproversList() != null) {
            dto.setApproversList(
                    file.getApproversList().stream()
                            .map(this::toApproversDto)
                            .collect(Collectors.toList())
            );
        }
        dto.setDraftReviewer(toApproversDto(file.getDraftReviewer()));
        dto.setFinalReviewer(toApproversDto(file.getFinalReviewer()));
        // Concluded
        dto.setConcluded(file.isConcluded());
        dto.setConcludedBy(file.getConcludedBy());
        dto.setConcludedDate(file.getConcludedDate());
        // Approval status fields
        dto.setDraftReviewerStatus(file.getDraftReviewerStatus());
        dto.setApproverStatus(file.getApproverStatus());
        dto.setFinalReviewerStatus(file.getFinalReviewerStatus());
        dto.setApprovalStatus(file.getApprovalStatus());
        // DocuSign fields
        dto.setDocuSignEnvelopeId(file.getDocuSignEnvelopeId());
        dto.setDocuSignStatus(file.getDocuSignStatus());
        dto.setDocuSignFileName(file.getDocuSignFileName());
        dto.setDocuSignFileNameGCP(file.getDocuSignFileNameGCP());
        dto.setSignedDocumentUrl(file.getSignedDocumentUrl());
        // Audit
        dto.setStatus(file.getStatus());
        dto.setCreatedBy(file.getCreatedBy());
        dto.setCreatedAt(file.getCreatedAt());
        dto.setUpdatedBy(file.getUpdatedBy());
        dto.setUpdatedAt(file.getUpdatedAt());
        return dto;
    }

    /**
     * Minimal DocResponse (used for simple operation results like upload, break-inheritance, etc.)
     */
    public DocResponse toDto(GovDocuments govDoc) {
        DocResponse response = new DocResponse();
        response.setFileName(govDoc.getDocFileName());
        response.setFileUrl(govDoc.getDocFileUrl());
        response.setStatusCode("200");
        response.setMessage("Success");
        response.setDocumentCreated(govDoc.getDocumentCreated());
        return response;
    }

    /**
     * Full Part573Response — used for create, get, and approval responses.
     */
    public Part573Response toPart573Response(GovDocuments govDoc) {
        if (govDoc == null) {
            return null;
        }
        LOGGER.debug("Mapping GovDocuments to Part573Response for issueNumber: {}", govDoc.getIssueNumber());

        Part573Response response = new Part573Response();
        response.setId(govDoc.getId());
        response.setIssueNumber(govDoc.getIssueNumber());
        response.setImplId(govDoc.getImplId());
        response.setPopulationId(govDoc.getPopulationId());
        response.setIssueTitle(govDoc.getIssueTitle());
        response.setRegion(govDoc.getRegion());
        response.setDocFileName(govDoc.getDocFileName());
        response.setDocFileUrl(govDoc.getDocFileUrl());
        response.setPotentialFsaName(govDoc.getPotentialFsaName());
        response.setDocumentCreated(govDoc.getDocumentCreated());
        // Audit
        response.setStatus(govDoc.getStatus());
        response.setCreatedBy(govDoc.getCreatedBy());
        response.setCreatedAt(govDoc.getCreatedAt());
        response.setUpdatedBy(govDoc.getUpdatedBy());
        response.setUpdatedAt(govDoc.getUpdatedAt());
        // Part573File
        if (govDoc.getPart573Files() != null) {
            response.setPart573Files(toFileDto(govDoc.getPart573Files()));
        } else {
            LOGGER.warn("No Part573File found for GovDocuments issueNumber: {}", govDoc.getIssueNumber());
        }
        response.setStatusCode("200");
        return response;
    }

    /**
     * Full TcDocResponse — used for create, get, and TC approval responses.
     */
    public TcDocResponse toTcDocResponse(GovDocuments govDoc) {
        if (govDoc == null) {
            return null;
        }
        LOGGER.debug("Mapping GovDocuments to TcDocResponse for issueNumber: {}", govDoc.getIssueNumber());

        TcDocResponse response = new TcDocResponse();
        response.setId(govDoc.getId());
        response.setIssueNumber(govDoc.getIssueNumber());
        response.setImplId(govDoc.getImplId());
        response.setPopulationId(govDoc.getPopulationId());
        response.setIssueTitle(govDoc.getIssueTitle());
        response.setRegion(govDoc.getRegion());
        response.setDocFileName(govDoc.getDocFileName());
        response.setDocFileUrl(govDoc.getDocFileUrl());
        response.setPotentialIssueType(govDoc.getPotentialIssueType());
        response.setDocumentCreated(govDoc.getDocumentCreated());
        // Audit
        response.setStatus(govDoc.getStatus());
        response.setCreatedBy(govDoc.getCreatedBy());
        response.setCreatedAt(govDoc.getCreatedAt());
        response.setUpdatedBy(govDoc.getUpdatedBy());
        response.setUpdatedAt(govDoc.getUpdatedAt());
        // Part573File
        if (govDoc.getPart573Files() != null) {
            response.setPart573Files(toFileDto(govDoc.getPart573Files()));
        } else {
            LOGGER.warn("No Part573File found for TC document issueNumber: {}", govDoc.getIssueNumber());
        }
        response.setStatusCode("200");
        return response;
    }
}
