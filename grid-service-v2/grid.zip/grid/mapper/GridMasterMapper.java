package com.ford.grid.mapper;

import com.ford.grid.model.dto.response.*;
import com.ford.grid.model.entity.*;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

@Service
public class GridMasterMapper {
    private final ModelMapper modelMapper;

    public GridMasterMapper(ModelMapper modelMapper) {
        this.modelMapper = modelMapper;
    }

    public IssueTypeMasterResponse toIssueTypeDto(IssueTypeMaster issueTypeMaster) {
        return modelMapper.map(issueTypeMaster, IssueTypeMasterResponse.class);
    }

    public VehiclePlantMappingResponse findByBrandIn(VehiclePlantMappingMaster vehiclePlantMappingMaster) {
        return modelMapper.map(vehiclePlantMappingMaster, VehiclePlantMappingResponse.class);
    }

    public NonWERSFilterGroupsResponse toFilterGroupResponse(NonWersFilterGroupsMaster nonWersFilterGroupsMaster) {
        return modelMapper.map(nonWersFilterGroupsMaster, NonWERSFilterGroupsResponse.class);
    }

    public ForumTypeResponse toForumTypeResponse(ForumTypeMaster forumTypeMaster) {
        return modelMapper.map(forumTypeMaster, ForumTypeResponse.class);
    }

    public AgendaTypeResponse toAgendaTypeResponse(AgendaTypeMaster agendaTypeMaster) {
        return modelMapper.map(agendaTypeMaster, AgendaTypeResponse.class);
    }

    public VehicleModelYearResponse toVehicleModelYearResponse(VehicleYearMaster vehicleYearMaster) {
        return modelMapper.map(vehicleYearMaster, VehicleModelYearResponse.class);
    }

    public CasualTypeResponse toCasualTyperResponse(CasualTypesMaster casualTypesMaster) {
        return modelMapper.map(casualTypesMaster, CasualTypeResponse.class);
    }

    public VehicleTypesResponse toVehicleTypesResponse(VehicleTypesMaster vehicleTypesMaster) {
        return modelMapper.map(vehicleTypesMaster, VehicleTypesResponse.class);
    }

    public LeadRegionsResponse toLeadRegionResponse(LeadRegionsMaster leadRegionsMaster) {
        return modelMapper.map(leadRegionsMaster, LeadRegionsResponse.class);
    }

    public BannerDetailsResponse toBannerDetailsResponse(BannerDetailMaster bannerDetailMaster) {
        return modelMapper.map(bannerDetailMaster, BannerDetailsResponse.class);
    }

    public SegmentsResponse toSegmentsResponse(SegmentsMaster segmentsMaster) {
        return modelMapper.map(segmentsMaster, SegmentsResponse.class);
    }

    public VehicleFeatureMappingResponse toVehicleFeatureMappingResponse(VehicleFeatureMappingMaster vehicleFeatureMappingMaster) {
        return modelMapper.map(vehicleFeatureMappingMaster, VehicleFeatureMappingResponse.class);
    }

    public FilterResponse toFileGroupsResponse(FilterMaster filterMaster) {
        return modelMapper.map(filterMaster, FilterResponse.class);
    }
}
