package com.ford.grid.mapper;

import com.ford.grid.model.dto.request.vern.GcampVernRequest;
import com.ford.grid.model.dto.request.vern.VernReviewRequest;
import com.ford.grid.model.dto.response.vern.GcampVernResponse;
import com.ford.grid.model.entity.vern.GridVernDetails;
import com.ford.grid.model.entity.vern.VernReview;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class GridVernMapper {

    @Autowired
    private ModelMapper modelMapper;


    public GridVernDetails toGridVernDetails(GcampVernRequest gcampVernRequest) {
        return modelMapper.map(gcampVernRequest, GridVernDetails.class);
    }


    public VernReview toGridVernReview(VernReviewRequest vernReviewRequest) {
        return modelMapper.map(vernReviewRequest, VernReview.class);
    }

    public VernReviewRequest toVernReviewRequest(VernReview vernReview) {
        return modelMapper.map(vernReview, VernReviewRequest.class);
    }

    public GcampVernRequest toGcampVernRequest(GridVernDetails gridVernDetails) {
        return modelMapper.map(gridVernDetails, GcampVernRequest.class);
    }

    public GcampVernResponse toGcampVernResponse(GridVernDetails gridVernDetails) {
        return modelMapper.map(gridVernDetails, GcampVernResponse.class);
    }
}
