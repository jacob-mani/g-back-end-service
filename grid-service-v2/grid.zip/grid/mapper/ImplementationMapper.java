package com.ford.grid.mapper;

import com.ford.grid.model.dto.request.PopulationAndImplementationDetail;
import com.ford.grid.model.dto.response.ImplementationResponse;
import com.ford.grid.model.dto.response.PopulationResponse;
import com.ford.grid.model.entity.IssueImplementation;
import com.ford.grid.model.entity.Population;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class ImplementationMapper {

    @Autowired
    private ModelMapper modelMapper;

    public ImplementationResponse toImplementationResponse(IssueImplementation implementation) {
        ImplementationResponse response =  modelMapper.map(implementation, ImplementationResponse.class);
        setSupplementFlag(response);
        return response;
    }

    private void setSupplementFlag(ImplementationResponse response) {
        List<PopulationResponse> populationResponse = response.getPopulations();
        if (populationResponse != null) {
            for (PopulationResponse p : populationResponse) {
                String populationId = p.getPopulationId();
                if (populationId != null) {
                    String[] ids = populationId.split("-");
                    int id = Integer.parseInt(ids[ids.length - 1]);
                    p.setIsSupplement(id != 0);
                }
            }
        }
    }


    public IssueImplementation populationDetailToIssueImplementation(IssueImplementation issueImplementation, PopulationAndImplementationDetail populationDetail) {
        if (issueImplementation == null || issueImplementation.getPopulations() == null) {
            return issueImplementation;
        }
        issueImplementation.setPotentialIssueType(populationDetail.getPotentialIssueType());
        for (Population p : issueImplementation.getPopulations()) {
            if (p.getPopulationId().equals(populationDetail.getPopulationId())) {
                p.setOtaIndicator(false);
                p.setPotentialFsaName(populationDetail.getPotentialFsaName());
                p.setStopShip(populationDetail.getStopShip());
                if(populationDetail.isManualPopulationDeleteUpdate()) {
                    p.setManualPopulation(false);
                    p.setDisableSupplementCreation(true);
                }
                p.setTaskOwner(populationDetail.getTaskOwner());
                p.setUpdatedAt(populationDetail.getUpdatedAt());
                p.setUpdatedBy(populationDetail.getUpdatedBy());
                // Add other fields as needed
            }
        }
        return issueImplementation;
    }

}
