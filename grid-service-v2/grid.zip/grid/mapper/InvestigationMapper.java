package com.ford.grid.mapper;

import com.ford.grid.model.dto.request.InvestigationAnalysisRequest;
import com.ford.grid.model.dto.response.InvestigationAnalysisResponse;
import com.ford.grid.model.entity.InvestigationAnalysis;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

@Service
public class InvestigationMapper {
    private final ModelMapper modelMapper;

    public InvestigationMapper(ModelMapper modelMapper) {
        this.modelMapper = modelMapper;
    }

    public InvestigationAnalysisResponse toInvestigationDto(InvestigationAnalysis investigationAnalysis) {
        return modelMapper.map(investigationAnalysis, InvestigationAnalysisResponse.class);
    }

    public InvestigationAnalysis toEntity(InvestigationAnalysisRequest investigationAnalysisRequest) {
        return modelMapper.map(investigationAnalysisRequest, InvestigationAnalysis.class);
    }

}
