package com.ford.grid.mapper;


import com.ford.grid.model.dto.response.InvestigationViewResponse;
import com.ford.grid.model.entity.InvestigationView;
import org.modelmapper.ModelMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class InvestigationViewMapper {
    private final ModelMapper modelMapper;

    public InvestigationViewResponse toDto(InvestigationView investigationView) {
        return modelMapper.map(investigationView, InvestigationViewResponse.class);
    }
}
