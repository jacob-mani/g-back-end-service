package com.ford.grid.mapper;

import com.ford.grid.model.dto.response.IssueContactsResponse;
import com.ford.grid.model.entity.IssueContacts;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;



@Component
public class IssueContactsMapper {

    @Autowired
    private ModelMapper modelMapper;

    public IssueContactsResponse mapToIssueContactsResponse(IssueContacts issueContacts) {

        IssueContactsResponse response = modelMapper.map(issueContacts, IssueContactsResponse.class);
        return response;
    }

    public IssueContactsResponse toResponseDto(IssueContacts issueContacts) {

        return modelMapper.map(issueContacts, IssueContactsResponse.class);
    }

}
