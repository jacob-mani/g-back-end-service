package com.ford.grid.mapper;

import com.ford.grid.model.dto.request.IssueFunctionRequest;
import com.ford.grid.model.entity.IssueFunction;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class IssueFunctionMapper {

    private final ModelMapper modelMapper;

    @Autowired
    public IssueFunctionMapper(ModelMapper modelMapper) {
        this.modelMapper = modelMapper;
    }

    public IssueFunction toEntity(IssueFunctionRequest request) {
        return modelMapper.map(request, IssueFunction.class);
    }

    public IssueFunctionRequest toDto(IssueFunction issueFunction) {
        return modelMapper.map(issueFunction, IssueFunctionRequest.class);
    }
}
