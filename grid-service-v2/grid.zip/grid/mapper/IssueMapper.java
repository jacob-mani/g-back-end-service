package com.ford.grid.mapper;

import com.ford.grid.model.dto.request.BaseVehicleCriteriaRequest;
import com.ford.grid.model.dto.request.RecallIssueRequest;
import com.ford.grid.model.dto.response.IssueResponse;
import com.ford.grid.model.dto.response.SuggestedIssueResponse;
import com.ford.grid.model.entity.BaseVehicleCriteria;
import com.ford.grid.model.entity.RecallIssue;
import com.ford.grid.util.RecallIssueUtil;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class IssueMapper {

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private RecallIssueUtil recallIssueUtil;

    public RecallIssue toEntity(RecallIssueRequest recallIssueRequest) {
        return modelMapper.map(recallIssueRequest, RecallIssue.class);
    }

    public IssueResponse toDto(RecallIssue recallIssue) {
        return modelMapper.map(recallIssue, IssueResponse.class);
    }

    public IssueResponse toResponseDto(RecallIssue recallIssue, List<BaseVehicleCriteria> baseVehicleCriteriaList, String createdByName) {
        IssueResponse issueResponse = modelMapper.map(recallIssue, IssueResponse.class);
        List<BaseVehicleCriteriaRequest> criteriaRequests = baseVehicleCriteriaList.stream()
                .map(criteria -> modelMapper.map(criteria, BaseVehicleCriteriaRequest.class))
                .collect(Collectors.toList());

        issueResponse.setBaseVehicleCriteria(criteriaRequests);
        // Set the created by name
        issueResponse.setCreatedByName(createdByName);

        return issueResponse;
    }

    public SuggestedIssueResponse toSuggestedIssueResponse(RecallIssue recallIssue, List<BaseVehicleCriteria> baseVehicleCriteriaList) {
        SuggestedIssueResponse suggestedIssueResponse = modelMapper.map(recallIssue, SuggestedIssueResponse.class);
        String affectedVehicles = recallIssueUtil.getAffectedVehiclesString(baseVehicleCriteriaList);
        suggestedIssueResponse.setAffectedVehicles(affectedVehicles);
        return suggestedIssueResponse;
    }
}
