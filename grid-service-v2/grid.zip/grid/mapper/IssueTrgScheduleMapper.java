package com.ford.grid.mapper;

import com.ford.grid.model.dto.request.IssueTrgScheduleRequest;
import com.ford.grid.model.dto.response.IssueTrgScheduleResponse;
import com.ford.grid.model.entity.IssueTrgSchedule;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class IssueTrgScheduleMapper {

    private final ModelMapper modelMapper;

    public IssueTrgSchedule toEntity(IssueTrgScheduleRequest request) {
        return modelMapper.map(request, IssueTrgSchedule.class);
    }

    public IssueTrgScheduleResponse toDto(IssueTrgSchedule entity) {
        if (entity == null) {
            return null;
        }
        return modelMapper.map(entity, IssueTrgScheduleResponse.class);
    }
}

