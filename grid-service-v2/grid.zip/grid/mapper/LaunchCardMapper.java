package com.ford.grid.mapper;

import com.ford.grid.model.dto.request.LaunchCardRequest;
import com.ford.grid.model.dto.response.LaunchCardResponse;
import com.ford.grid.model.entity.LaunchCard;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class LaunchCardMapper {
    @Autowired
    private ModelMapper modelMapper;


    public LaunchCard toLaunchCardEntity(LaunchCardRequest launchCardRequest) {
        return modelMapper.map(launchCardRequest, LaunchCard.class);
    }

    public void updateLaunchCardEntity(LaunchCardRequest launchCardRequest, LaunchCard entity) {
        if (entity.getReimbursements() != null) {
            entity.getReimbursements().clear();
        }
        modelMapper.map(launchCardRequest, entity);
    }

    public LaunchCardResponse toLaunchCardDto(LaunchCard model) {
        return modelMapper.map(model, LaunchCardResponse.class);
    }
}
