package com.ford.grid.mapper;

import com.ford.grid.model.dto.request.LaunchGovernmentSubmissionRequest;
import com.ford.grid.model.dto.response.LaunchGovernmentSubmissionResponse;
import com.ford.grid.model.entity.LaunchGovernmentSubmission;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class LaunchGovernmentSubmissionMapper {
    private final ModelMapper modelMapper;

    public LaunchGovernmentSubmissionResponse toDto(LaunchGovernmentSubmission entity) {
        return modelMapper.map(entity, LaunchGovernmentSubmissionResponse.class);
    }

    public LaunchGovernmentSubmission toEntity(LaunchGovernmentSubmissionRequest request) {
        return modelMapper.map(request, LaunchGovernmentSubmission.class);
    }

    public void updateEntityFromRequest(LaunchGovernmentSubmissionRequest request, LaunchGovernmentSubmission entity) {
        modelMapper.map(request, entity);
    }
}
