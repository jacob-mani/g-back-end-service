package com.ford.grid.mapper;

import com.ford.grid.model.dto.request.FRCPacRequest;
import com.ford.grid.model.dto.request.LaunchRegionCommunicationRequest;
import com.ford.grid.model.dto.response.FRCPacResponse;
import com.ford.grid.model.dto.response.LaunchRegionCommunicationResponse;
import com.ford.grid.model.entity.FRCPac;
import com.ford.grid.model.entity.LaunchRegionCommunication;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
@RequiredArgsConstructor
public class LaunchRegionCommunicationMapper {

    private final ModelMapper modelMapper;

    public LaunchRegionCommunicationResponse toDto(Optional<LaunchRegionCommunication> entity) {
        return modelMapper.map(entity, LaunchRegionCommunicationResponse.class);
    }

    public LaunchRegionCommunication toEntity(LaunchRegionCommunicationRequest request) {
        return modelMapper.map(request, LaunchRegionCommunication.class);
    }

    public void updateEntityFromRequest(LaunchRegionCommunicationRequest request, LaunchRegionCommunication entity) {
        modelMapper.map(request, entity);
    }
}
