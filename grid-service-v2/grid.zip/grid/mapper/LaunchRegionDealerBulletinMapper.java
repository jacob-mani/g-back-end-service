package com.ford.grid.mapper;

import com.ford.grid.model.dto.request.LaunchRegionDealerBulletinRequest;
import com.ford.grid.model.dto.response.LaunchRegionDealerBulletinResponse;
import com.ford.grid.model.entity.LaunchRegionDealerBulletin;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class LaunchRegionDealerBulletinMapper {

    private final ModelMapper modelMapper;

    @Autowired
    public LaunchRegionDealerBulletinMapper(ModelMapper modelMapper) {
        this.modelMapper = modelMapper;
    }

    public LaunchRegionDealerBulletinResponse toDto(LaunchRegionDealerBulletin entity) {
        return modelMapper.map(entity, LaunchRegionDealerBulletinResponse.class);
    }

    public LaunchRegionDealerBulletin toEntity(LaunchRegionDealerBulletinRequest request) {
        return modelMapper.map(request, LaunchRegionDealerBulletin.class);
    }

    public void updateEntityFromRequest(LaunchRegionDealerBulletinRequest request, LaunchRegionDealerBulletin entity) {
        if (request == null || entity == null) {
            return;
        }

        // Map all updatable fields from the request onto the existing entity
        modelMapper.map(request, entity);

        // Ensure notification types are updated explicitly - replace the entire list when provided
        if (request.getNotificationType() != null) {
            entity.setNotificationType(request.getNotificationType());
        }
    }
}