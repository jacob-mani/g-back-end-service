package com.ford.grid.mapper;

import com.ford.grid.model.dto.request.LaunchRegionOwnerNotificationRequest;
import com.ford.grid.model.dto.response.LaunchRegionOwnerNotificationResponse;
import com.ford.grid.model.entity.LaunchRegionOwnerNotification;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class LaunchRegionOwnerNotificationMapper {

    private final ModelMapper modelMapper;

    @Autowired
    public LaunchRegionOwnerNotificationMapper(ModelMapper modelMapper) {
        this.modelMapper = modelMapper;
    }

    public LaunchRegionOwnerNotificationResponse toDto(LaunchRegionOwnerNotification entity) {
        return modelMapper.map(entity, LaunchRegionOwnerNotificationResponse.class);
    }

    public LaunchRegionOwnerNotification toEntity(LaunchRegionOwnerNotificationRequest request) {
        return modelMapper.map(request, LaunchRegionOwnerNotification.class);
    }

    public void updateEntityFromRequest(LaunchRegionOwnerNotificationRequest request, LaunchRegionOwnerNotification entity) {
        if (request == null || entity == null) {
            return;
        }

        // Map all updatable fields from the request onto the existing entity
        modelMapper.map(request, entity);

        // Ensure notification types are updated explicitly - replace the entire list when provided
        if (request.getNotificationType() != null) {
            entity.setNotificationType(request.getNotificationType());

            // Handle mail trackings for each notification type
            for (int i = 0; i < entity.getNotificationType().size() && i < request.getNotificationType().size(); i++) {
                var entityNotificationType = entity.getNotificationType().get(i);
                var requestNotificationType = request.getNotificationType().get(i);

                if (requestNotificationType.getMailTrackings() == null) {
                    // If request has null mail trackings, clear all existing mail trackings
                    if (entityNotificationType.getMailTrackings() != null) {
                        entityNotificationType.getMailTrackings().clear();
                    }
                } else {
                    // If request has mail trackings array (even if empty), replace existing with request data
                    entityNotificationType.setMailTrackings(requestNotificationType.getMailTrackings());
                }
            }
        }
    }
}

