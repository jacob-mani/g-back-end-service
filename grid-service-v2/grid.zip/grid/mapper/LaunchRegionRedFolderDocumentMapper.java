package com.ford.grid.mapper;

import com.ford.grid.model.dto.request.LaunchRegionRedFolderDocumentRequest;
import com.ford.grid.model.dto.response.LaunchRegionRedFolderDocumentResponse;
import com.ford.grid.model.entity.LaunchRegionRedFolderDocument;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
@RequiredArgsConstructor
public class LaunchRegionRedFolderDocumentMapper {

    private final ModelMapper modelMapper;

    public LaunchRegionRedFolderDocumentResponse toDto(Optional<LaunchRegionRedFolderDocument> launchRegionRedFolderDocument) {
        return modelMapper.map(launchRegionRedFolderDocument, LaunchRegionRedFolderDocumentResponse.class);
    }

    public LaunchRegionRedFolderDocument toEntity(LaunchRegionRedFolderDocumentRequest request) {
        return modelMapper.map(request, LaunchRegionRedFolderDocument.class);
    }

    public void updateEntityFromRequest(LaunchRegionRedFolderDocumentRequest request, LaunchRegionRedFolderDocument entity) {
        modelMapper.map(request, entity);
    }
}