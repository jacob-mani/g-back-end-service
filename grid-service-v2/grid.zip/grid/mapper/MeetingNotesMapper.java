package com.ford.grid.mapper;

import com.ford.grid.model.dto.response.meetingnotes.MeetingNotesResponse;
import com.ford.grid.model.dto.response.meetingnotes.MeetingNotesWithPopulationResponse;
import com.ford.grid.model.entity.meetingnotes.MeetingNotes;
import com.ford.grid.model.entity.meetingnotes.MeetingNotesWithPopulation;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class MeetingNotesMapper {
    private final ModelMapper modelMapper;

    public MeetingNotesResponse toMeetingNotesResponse(MeetingNotes meetingNotes) {
        return modelMapper.map(meetingNotes, MeetingNotesResponse.class);
    }

    public MeetingNotesWithPopulationResponse toMeetingNotesWithPopulationResponse(MeetingNotesWithPopulation meetingNotes) {
        return modelMapper.map(meetingNotes, MeetingNotesWithPopulationResponse.class);
    }
}