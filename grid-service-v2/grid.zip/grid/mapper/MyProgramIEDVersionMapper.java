package com.ford.grid.mapper;

import com.ford.grid.model.entity.MyProgramBucketModel;
import com.ford.grid.model.entity.SoftwareMyPgmIedVersion;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class MyProgramIEDVersionMapper {

    private final ModelMapper modelMapper;

    public MyProgramIEDVersionMapper(ModelMapper modelMapper) {
        this.modelMapper = modelMapper;
    }

    /**
     * Creates a deep copy of SoftwareMyPgmIedVersion with incremented version
     *
     * @param source The source SoftwareMyPgmIedVersion to copy from
     * @return A new SoftwareMyPgmIedVersion with incremented IED version
     */
    public SoftwareMyPgmIedVersion createNewVersion(SoftwareMyPgmIedVersion source) {
        if (source == null) {
            return null;
        }

        SoftwareMyPgmIedVersion newVersion = modelMapper.map(source, SoftwareMyPgmIedVersion.class);
        newVersion.setIedVersion(source.getIedVersion() + 1);

        // Deep copy of bucket list to avoid reference sharing
        if (source.getMyProgramBucketModelList() != null) {
            List<MyProgramBucketModel> copiedBuckets = source.getMyProgramBucketModelList().stream()
                    .map(bucket -> modelMapper.map(bucket, MyProgramBucketModel.class))
                    .collect(Collectors.toList());
            newVersion.setMyProgramBucketModelList(copiedBuckets);
        }

        return newVersion;
    }
}
