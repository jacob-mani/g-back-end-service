package com.ford.grid.mapper;

import com.ford.grid.model.dto.request.Part573AIUpdateRequest;
import com.ford.grid.model.dto.response.Part573AIResponse;
import com.ford.grid.model.entity.Part573AIEntity;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Part573AIMapper {

    @Autowired
    private ModelMapper modelMapper;

    /**
     * Convert Response DTO to Entity (used when saving LLM response)
     */
    public Part573AIEntity toEntity(Part573AIResponse dto) {
        return modelMapper.map(dto, Part573AIEntity.class);
    }

    /**
     * Convert Entity to Response DTO
     */
    public Part573AIResponse toResponse(Part573AIEntity entity) {
        return modelMapper.map(entity, Part573AIResponse.class);
    }

    /**
     * Convert Update Request to Entity
     */
    public Part573AIEntity toEntityFromRequest(Part573AIUpdateRequest request) {
        Part573AIEntity entity = new Part573AIEntity();
        entity.setIssueNumber(request.getIssueNumber());
        entity.setImplId(request.getImplId());
        entity.setPopulationId(request.getPopulationId());

        if (request.getAiData() != null) {
            Part573AIUpdateRequest.AiData aiData = request.getAiData();
            entity.setDescriptiveInfoOutput(aiData.getConcernDescriptionOutput());
            entity.setSafetyRiskDescriptionOutput(aiData.getSafetyRiskDescriptionOutput());
            entity.setCauseDescriptionOutput(aiData.getCauseDescriptionOutput());
            entity.setWarningOutput(aiData.getWarningOutput());
            entity.setFmvssOutput(aiData.getFmvssOutput());
            entity.setChronologyOutput(aiData.getChronologyOutput());
            entity.setPetitionForNoncompliance(aiData.getPetitionForNoncompliance());
            entity.setDescribeSafetyRisk(aiData.getDescribeSafetyRisk());
            entity.setDescribeDefect(aiData.getDescribeDefect());
            entity.setDescribeRecallSchedule(aiData.getDescribeRecallSchedule());
            entity.setRemedyComponentDistinctionOutput(aiData.getRemedyComponentDistinctionOutput());
            entity.setRemedyProgramOutput(aiData.getRemedyProgramOutput());
            entity.setShortConcernSummary(aiData.getShortConcernSummary());
        }
        return entity;
    }

    /**
     * Update existing entity from request
     */
    public void updateEntityFromRequest(Part573AIUpdateRequest request, Part573AIEntity entity) {
        if (request == null || entity == null) {
            return;
        }

        entity.setImplId(request.getImplId());
        entity.setPopulationId(request.getPopulationId());

        if (request.getAiData() != null) {
            Part573AIUpdateRequest.AiData aiData = request.getAiData();
            entity.setDescriptiveInfoOutput(aiData.getConcernDescriptionOutput());
            entity.setSafetyRiskDescriptionOutput(aiData.getSafetyRiskDescriptionOutput());
            entity.setCauseDescriptionOutput(aiData.getCauseDescriptionOutput());
            entity.setWarningOutput(aiData.getWarningOutput());
            entity.setFmvssOutput(aiData.getFmvssOutput());
            entity.setChronologyOutput(aiData.getChronologyOutput());
            entity.setPetitionForNoncompliance(aiData.getPetitionForNoncompliance());
            entity.setDescribeSafetyRisk(aiData.getDescribeSafetyRisk());
            entity.setDescribeDefect(aiData.getDescribeDefect());
            entity.setDescribeRecallSchedule(aiData.getDescribeRecallSchedule());
            entity.setRemedyComponentDistinctionOutput(aiData.getRemedyComponentDistinctionOutput());
            entity.setRemedyProgramOutput(aiData.getRemedyProgramOutput());
            entity.setShortConcernSummary(aiData.getShortConcernSummary());
        }
    }
}
