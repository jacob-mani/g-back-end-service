package com.ford.grid.mapper;

import com.ford.grid.model.dto.request.PreAuthParts;
import com.ford.grid.model.dto.response.PreAuthPartsResponse;
import com.ford.grid.model.entity.PreAuthTabMiddle;
import com.ford.grid.model.dto.request.*;
import com.ford.grid.model.dto.response.*;
import com.ford.grid.model.entity.*;
import com.ford.grid.model.dto.response.PreAuthTabMiddleResponse;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class PreAuthImplMapper {
    private final ModelMapper modelMapper;

    public PreAuthImpl toEntity(PreAuthImplRequest preAuthImplRequest) {
        return modelMapper.map(preAuthImplRequest, PreAuthImpl.class);
    }

    public PreAuthImplResponse toDto(PreAuthImpl preAuthimpl) {
        return modelMapper.map(preAuthimpl, PreAuthImplResponse.class);
    }

    public void updateEntityFromRequest(PreAuthImplRequest request, PreAuthImpl entity) {
        modelMapper.map(request, entity);
    }

    public PreAuthTab1 toEntity(PreAuthTab1Request request) {
        return modelMapper.map(request, PreAuthTab1.class);
    }

    public PreAuthTab1Response toDto(PreAuthTab1 entity) {
        return modelMapper.map(entity, PreAuthTab1Response.class);
    }

    public void updateEntityFromRequest(PreAuthTab1Request request, PreAuthTab1 entity) {
        modelMapper.map(request, entity);
    }

    public PreAuthTab6 toEntity(PreAuthTab6Request request) {
        return modelMapper.map(request, PreAuthTab6.class);
    }

    public PreAuthTab6Response toDto(PreAuthTab6 entity) {
        return modelMapper.map(entity, PreAuthTab6Response.class);
    }

    public void updateEntityFromRequest(PreAuthTab6Request request, PreAuthTab6 entity) {
        modelMapper.map(request, entity);
    }

    public PreAuthTabMiddleResponse toDtoMiddle (PreAuthTabMiddle entity) {
        return modelMapper.map(entity, PreAuthTabMiddleResponse.class);
    }

    public PreAuthTabMiddle toEntity(PreAuthTabMiddleRequest request) {
        return modelMapper.map(request, PreAuthTabMiddle.class);
    }

    public void updateEntityFromRequest(PreAuthTabMiddleRequest request, PreAuthTabMiddle entity) {
        modelMapper.map(request, entity);
    }

    public PreAuthTab7 toEntity(PreAuthTab7Request request) {
        return modelMapper.map(request, PreAuthTab7.class);
    }

    public PreAuthTab7Response toDto(PreAuthTab7 entity) {
        return modelMapper.map(entity, PreAuthTab7Response.class);
    }

    public void updateEntityFromRequest(PreAuthTab7Request request, PreAuthTab7 entity) {
        modelMapper.map(request, entity);
    }

    public PreAuthTab5 toEntity(PreAuthTab5Request request) {
        return modelMapper.map(request, PreAuthTab5.class);
    }

    public PreAuthTab5Response toDto(PreAuthTab5 entity) {
        PreAuthTab5Response response = modelMapper.map(entity, PreAuthTab5Response.class);
        response.setCombinedList(toPartsResponseList(entity.getCombinedList()));
        response.setConfirmedList(toPartsResponseList(entity.getConfirmedList()));
        return response;
    }

    private List<PreAuthPartsResponse> toPartsResponseList(List<PreAuthParts> parts) {
        if (parts == null || parts.isEmpty()) return Collections.emptyList();
        return parts.stream().map(this::toPartsResponse).collect(Collectors.toList());
    }

    /**
     * Maps a single PreAuthParts to PreAuthPartsResponse using the custom getters.
     * The custom getters on PreAuthParts delegate to the @DBRef PartMaster when
     * the part reference is set, so engineeringPartNumber, servicePartNumber,
     * finisCode and partName are correctly resolved from the PartMaster document.
     */
    private PreAuthPartsResponse toPartsResponse(PreAuthParts parts) {
        PreAuthPartsResponse response = new PreAuthPartsResponse();
        response.setEngineeringPartNumber(parts.getEngineeringPartNumber());
        response.setServicePartNumber(parts.getServicePartNumber());
        response.setFinisCode(parts.getFinisCode());
        response.setPartName(parts.getPartName());
        response.setLaunchQuantity(parts.getLaunchQuantity());
        response.setTotalQuantity(parts.getTotalQuantity());
        response.setCost(parts.getCost());
        response.setPreAuthReason(parts.getPreAuthReason());
        response.setPreAuthAmount(parts.getPreAuthAmount());
        response.setAuthorizedAmount(parts.getAuthorizedAmount());
        response.setGrandTotal(parts.getGrandTotal());
        return response;
    }

    public void updateEntityFromRequest(PreAuthTab5Request request, PreAuthTab5 entity) {
        modelMapper.map(request, entity);
    }
}


