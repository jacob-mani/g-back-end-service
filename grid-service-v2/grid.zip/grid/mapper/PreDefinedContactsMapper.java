package com.ford.grid.mapper;

import com.ford.grid.model.dto.response.PreDefinedContactsResponse;
import com.ford.grid.model.entity.PreDefinedContacts;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class PreDefinedContactsMapper {

    @Autowired
    private ModelMapper modelMapper;

    public PreDefinedContactsResponse toResponseDto(PreDefinedContacts contactsEntity) {

        return modelMapper.map(contactsEntity, PreDefinedContactsResponse.class);
    }


}
