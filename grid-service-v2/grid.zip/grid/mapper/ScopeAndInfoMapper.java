package com.ford.grid.mapper;

import com.ford.grid.model.dto.request.ScopeAndInfoRequest;
import com.ford.grid.model.dto.response.ScopeAndInfoResponse;
import com.ford.grid.model.entity.ScopeAndInfo;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@Component
public class ScopeAndInfoMapper {

    private final ModelMapper modelMapper;

    public ScopeAndInfoMapper(ModelMapper modelMapper) {
        this.modelMapper = modelMapper;
    }

    public ScopeAndInfoResponse toScopeAndInfoDto(ScopeAndInfo scopeAndInfo) {
        return modelMapper.map(scopeAndInfo, ScopeAndInfoResponse.class);
    }

    public void updateEntityFromRequest(ScopeAndInfoRequest request, ScopeAndInfo entity) {
        if (entity.getAssemblyPlants() != null) {
            entity.getAssemblyPlants().clear();
        }
        if (entity.getStopShips() != null) {
            entity.getStopShips().clear();
        }
        if (entity.getAttachments() != null) {
            entity.getAttachments().clear();
        }
        modelMapper.map(request, entity);
    }

    public void toScopeAndInfoDto(ScopeAndInfo scopeAndInfo, ScopeAndInfoResponse response) {
        modelMapper.map(scopeAndInfo, response);
    }
}

