package com.ford.grid.mapper;

import com.ford.grid.model.dto.request.ProgramFsaMappingRequest;
import com.ford.grid.model.dto.request.SoftwarePartsFsaRequest;
import com.ford.grid.model.dto.response.SoftwareFsaMyPgmGvmsResponse;
import com.ford.grid.model.dto.response.SoftwareFsaSavePartsResponse;
import com.ford.grid.model.entity.SoftwareFsaMyPgmGvms;
import com.ford.grid.model.entity.SoftwareFsaSaveParts;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class SoftwarePartsMapper {

    private final ModelMapper modelMapper;

    public SoftwarePartsMapper(ModelMapper modelMapper) {
        this.modelMapper = modelMapper;
    }


    public List<SoftwareFsaMyPgmGvmsResponse> programFsaMappingToProgramFsaMappingDto(List<SoftwareFsaMyPgmGvms> programFsaMappingList) {
        return mapList(programFsaMappingList, SoftwareFsaMyPgmGvmsResponse.class);
    }
    private <S, T> List<T> mapList(List<S> source, Class<T> targetClass) {
        return source
                .stream()
                .map(element -> modelMapper.map(element, targetClass))
                .collect(Collectors.toList());
    }
    public List<SoftwareFsaMyPgmGvms> programFsaMappingDtoToProgramFsaMapping(List<ProgramFsaMappingRequest> programFsaMappingRequest) {
        return mapList(programFsaMappingRequest, SoftwareFsaMyPgmGvms.class);
    }

    public List<SoftwareFsaSaveParts> mapSoftwarePartsDtoToModel(List<SoftwarePartsFsaRequest> softwarePartsFsaRequest) {
        return mapList(softwarePartsFsaRequest, SoftwareFsaSaveParts.class);
    }

    public SoftwareFsaSavePartsResponse toSoftwarePartsFsaResponse(SoftwareFsaSaveParts model) {
        return modelMapper.map(model, SoftwareFsaSavePartsResponse.class);
    }
}
