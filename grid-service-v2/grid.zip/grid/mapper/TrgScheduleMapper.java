package com.ford.grid.mapper;

import com.ford.grid.model.dto.request.TrgScheduleRequest;
import com.ford.grid.model.dto.response.TrgScheduleResponse;
import com.ford.grid.model.entity.TrgSchedule;
import lombok.AllArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class TrgScheduleMapper {

    private final ModelMapper modelMapper;

    public TrgSchedule toEntity (TrgScheduleRequest trgScheduleRequest) {
        return modelMapper.map(trgScheduleRequest, TrgSchedule.class);
    }

    public TrgScheduleResponse toDto(TrgSchedule trgSchedule) {
        return modelMapper.map(trgSchedule, TrgScheduleResponse.class);
    }
}
