package com.ford.grid.mapper.vern;

import com.ford.grid.model.dto.response.vern.VernCount;
import com.ford.grid.model.dto.response.vern.VernResponseModel;
import com.ford.grid.model.dto.response.vern.VernResponseModelDTO;
import com.ford.grid.model.entity.vern.VernCountDAO;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class VernObjectMapper {
    private final ModelMapper modelMapper;

    public VernResponseModel toVernResponseModel(VernResponseModelDTO responseModelDTO) {
        return modelMapper.map(responseModelDTO, VernResponseModel.class);
    }

    public VernCount toVernCount(VernCountDAO vernCountDAO) {
        return modelMapper.map(vernCountDAO, VernCount.class);
    }
}