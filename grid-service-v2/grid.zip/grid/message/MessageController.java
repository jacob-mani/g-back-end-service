package com.ford.grid.message;

import com.ford.cloudnative.base.api.StandardErrorResponse;
import com.ford.grid.message.api.MessageRequest;
import com.ford.grid.message.api.MessageResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;

@Validated
@RestController
@RequestMapping(path = "/api/v1/messages")
@Tag(name = "message", description = "The message API")
public class MessageController {

    private final MessageService messageService;
    private final MessageMapper mapper;

    @Autowired
    public MessageController(MessageService messageService, MessageMapper mapper) {
        this.messageService = messageService;
        this.mapper = mapper;
    }

    @Operation(summary = "Send a Message", description = "Sends a Message by posting in the PubSub Topic")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(schema = @Schema(implementation = MessageResponse.class))),
            @ApiResponse(responseCode = "default", description = "All Errors", content = @Content(schema = @Schema(implementation = StandardErrorResponse.class)))
    })
    @PostMapping
    @ResponseStatus(HttpStatus.OK)
    public MessageResponse sendMessage(
            @Parameter(description="Send a Message") @RequestBody @Valid  MessageRequest messageRequest) {
        String messageStatus = "Failed";

        var message = this.mapper.toMessage(messageRequest);

        if (messageService.sendMessage(message)) {
            messageStatus = "Success";
        }

        return MessageResponse.builder().ackMessage(messageStatus).build();
    }

}
