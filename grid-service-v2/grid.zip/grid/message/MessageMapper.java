package com.ford.grid.message;

import org.springframework.stereotype.Component;

import com.ford.grid.message.api.MessageRequest;

@Component
public class MessageMapper {

	public Message toMessage(MessageRequest messageRequest) {
		return Message.builder()
				.message(messageRequest.getMessage())
				.build();
	}
}
