package com.ford.grid.message;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.stream.function.StreamBridge;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MessageService {

    private StreamBridge streamBridge;

    @Autowired
    public MessageService(StreamBridge streamBridge) {
        this.streamBridge = streamBridge;
    }

    @Value("${spring.cloud.stream.bindings.output.destination:}")
    String messageOutputTopic;

    public boolean sendMessage(Message request) {
        log.info("Sending message: " + request.toString());

        return streamBridge.send(messageOutputTopic, request);
    }
}
