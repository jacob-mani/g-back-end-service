package com.ford.grid.message.api;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Message Request to send a message")
public class MessageRequest {

    @NotNull
    @Size(min = 1, max = 255)
    @Pattern(regexp = "^[a-zA-Z0-9 .-]+$")
    @Schema(example = "Hello World", description = "Message Greeting")
    String message;
}
