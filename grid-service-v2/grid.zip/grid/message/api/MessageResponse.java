package com.ford.grid.message.api;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Response to greeting message")
public class MessageResponse {

	@NotNull
	@Size(min = 1, max = 10)
	@Pattern(regexp = "^.{1,255}$")
	@Schema(example= "OK", description = "Acknowledgement Message")
	String ackMessage;
}

