package com.ford.grid.model.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "agenda_issues_sort")
public class AgendaIssuesSort {

    private ObjectId _id;

    @NotBlank(message = "Meeting Type must not be null or blank")
    private String agendaType;

    @NotBlank(message = "Meeting Date must not be null or blank")
    private String agendaDate;

    @NotNull(message = "Region must not be null")
    private String agendaRegn;

    @NotBlank(message = "User must not be null or blank")
    private String agendaUser;

    @NotBlank(message = "Issues must not be null or blank")
    private String agendaIssues;

    private Date agendaTime;

    @NotNull(message = "Cust Descriptions must not be null ")
    private String customDesc;

    private String segment;

}