package com.ford.grid.model.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "ECU and DID by Part Number base")
public class BaseDidMapping {
    @NotNull
    @Pattern(regexp = "^[a-zA-Z0-9]{1,10}$")
    @Schema(example = "14C302", description = "Part number base")
    String partBase;

    @NotNull
    @Pattern(regexp = "^[a-zA-Z0-9]{1,3}$")
    @Schema(example = "7D0", description = "Ecu node ID")
    String ecuNodeID;

    @NotNull
    @Pattern(regexp = "^[a-zA-Z0-9]{1,4}$")
    @Schema(example = "F16E", description = "DID by part number base")
    String partDID;

    @NotNull
    @Pattern(regexp = "^[0-9]{1,4}$")
    @Schema(example = "F16E", description = "Status code")
    String statusCode;

    @NotNull
    @Pattern(regexp = "^[a-zA-Z0-9]{1,100}$")
    @Schema(example = "F16E", description = "status message")
    String statusMessage;

    @Override()
    public String toString() {
        return "{" +
                "partBase:'" + partBase + '\'' +
                ", ecuNodeID:'" + ecuNodeID + '\'' +
                ", partDID:'" + partDID + '\'' +
                ", statusCode:'" + statusCode + '\'' +
                ", statusMessage:'" + statusMessage + '\'' +
                '}';
    }
}
