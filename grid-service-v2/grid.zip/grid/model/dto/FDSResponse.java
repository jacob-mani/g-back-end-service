package com.ford.grid.model.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class FDSResponse {

    @JsonProperty("@odata.context")
    private String odataContext;

    @JsonProperty("value")
    private List<FDSUser> value;
}
