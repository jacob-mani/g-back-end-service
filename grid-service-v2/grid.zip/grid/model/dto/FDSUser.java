package com.ford.grid.model.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class FDSUser {

    @JsonProperty("id")
    private String id;

    @JsonProperty("userPrincipalName")
    private String userPrincipalName;

    @JsonProperty("displayName")
    private String displayName;

    @JsonProperty("surname")
    private String surname;

    @JsonProperty("givenName")
    private String givenName;

    @JsonProperty("mail")
    private String mail;

    @JsonProperty("businessPhones")
    private List<String> businessPhones;

    @JsonProperty("jobTitle")
    private String jobTitle;
}
