package com.ford.grid.model.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Schema(description = "FSA Model year program code Bucket with list of Part numbers")
public class FsaPartDetail {

    String fsaId;
    List<ModelYearProgramBucket> myPgmBuckets;

}
