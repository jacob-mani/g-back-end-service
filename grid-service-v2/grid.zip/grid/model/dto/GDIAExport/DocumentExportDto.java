package com.ford.grid.model.dto.GDIAExport;

import com.ford.grid.model.entity.DocumentMatView;
import lombok.Data;

/**
 * Export DTO for view_by_documents_mat.
 * All fields are present with defaults — ensures consistent JSON schema regardless of null data.
 */
@Data
public class DocumentExportDto {

    private String issueNumber = "";
    private String implId = "";
    private String populationId = "";
    private String populationType = "";
    private String populationFsaName = "";
    private String location = "";
    private String section = "";
    private String documentId = "";
    private String documentName = "";
    private String uploadedUser = "";
    private String uploadedLocalDate = "";
    private String nameInGCP = "";
    private String documentUrl = "";
    private String notificationType = "";
    private String fsaNo = "";
    private String region = "";
    private String leadRegion = "";
    private String affectedRegion = "";
    private String issueTitle = "";

    public static DocumentExportDto from(DocumentMatView e) {
        DocumentExportDto dto = new DocumentExportDto();
        if (e == null) return dto;
        dto.issueNumber = nvl(e.getIssueNumber());
        dto.implId = nvl(e.getImplId());
        dto.populationId = nvl(e.getPopulationId());
        dto.populationType = nvl(e.getPopulationType());
        dto.populationFsaName = nvl(e.getPopulationFsaName());
        dto.location = nvl(e.getLocation());
        dto.section = nvl(e.getSection());
        dto.documentId = nvl(e.getDocumentId());
        dto.documentName = nvl(e.getDocumentName());
        dto.uploadedUser = nvl(e.getUploadedUser());
        dto.uploadedLocalDate = nvl(e.getUploadedLocalDate());
        dto.nameInGCP = nvl(e.getNameInGCP());
        dto.documentUrl = nvl(e.getDocumentUrl());
        dto.notificationType = nvl(e.getNotificationType());
        dto.fsaNo = nvl(e.getFsaNo());
        dto.region = nvl(e.getRegion());
        dto.leadRegion = nvl(e.getLeadRegion());
        dto.affectedRegion = nvl(e.getAffectedRegion());
        dto.issueTitle = nvl(e.getIssueTitle());
        return dto;
    }

    private static String nvl(String s) { return s != null ? s : ""; }
}

