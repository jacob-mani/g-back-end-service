package com.ford.grid.model.dto.GDIAExport;

import com.ford.grid.model.entity.ForumInvestigationMatView;
import lombok.Data;

/**
 * Export DTO for view_by_forum_mat.
 * All fields are String with "" default — ensures consistent JSON schema with no nulls.
 * Entity fields are typed as Object; we convert everything safely via toString().
 */
@Data
public class ForumExportDto {

    // ── Issue ─────────────────────────────────────────────────────────────────
    private String issueNumber = "";
    private String issueTitle = "";
    private String issueOpenDate = "";
    private String issueDescription = "";

    // ── Region / Vehicle ──────────────────────────────────────────────────────
    private String leadRegion = "";
    private String affectedRegion = "";
    private String affectedVehicleLine = "";
    private String affectedModelYear = "";
    private String affectedBrand = "";
    private String assemblyPlants = "";
    private String makeModelModelYear = "";

    // ── Forum overview ────────────────────────────────────────────────────────
    private String forum = "";
    private String isForumGov = "";
    private String govAgency = "";
    private String govInitAssignment = "";
    private String govInitDueDate = "";
    private String govRecentAssignment = "";
    private String govRecentDueDate = "";
    private String govDueDates = "";
    private String forumStatus = "";
    private String forumOpenDate = "";
    private String forumMeetingDates = "";
    private String forumRecentMeetingDate = "";
    private String forumReOpenedDates = "";
    private String forumPostFsaMonitor = "";
    private String forumNoOfDaysInOpen = "";
    private String forumIntialReOpenDate = "";
    private String forumRecentReOpenDate = "";
    private String forumReOpenedCount = "";
    private String forumMeetingsCount = "";
    private String forumConcludedDate = "";
    private String forumConcludedToFsa = "";
    private String forumConcludedToFsaNo = "";

    // ── Global forum ──────────────────────────────────────────────────────────
    private String globalForumOpenDate = "";
    private String globalForumMeetingDates = "";
    private String globalForumRecentMeetingDate = "";
    private String globalForumNoOfMeetings = "";

    // ── FSAM ──────────────────────────────────────────────────────────────────
    private String fsamFlag = "";
    private String fsamStatus = "";

    // ── Meeting notes ─────────────────────────────────────────────────────────
    private String recentMeetingNotesTitle = "";
    private String recentMeetingNotes = "";
    private String recentMeetingNotesAuthor = "";
    private String recentMeetingNotesDate = "";

    // ── CCRG fields ───────────────────────────────────────────────────────────
    private String preAuthKickOff = "";
    private String ccrgInitFindings = "";
    private String ccrgVoqAnalysis = "";
    private String ccrgWarrantyAnalysis = "";
    private String ccrgHighSeverityFieldReports = "";
    private String ccrgConnectedVehicleData = "";
    private String ccrgFootPrintAnalysis = "";
    private String ccrgProjections = "";
    private String ccrgReliabilityAnalysis = "";
    private String ccrgFieldReport = "";
    private String ccrgComponentTesting = "";
    private String ccrgSubSystemTesting = "";
    private String ccrgVehicleTesting = "";
    private String ccrgQualitySystemData = "";
    private String ccrgRootCause = "";
    private String ccrgContainmentAct = "";
    private String ccrgCustomerExp = "";
    private String ccrgSafetyImpact = "";
    private String ccrgWarningIndicators = "";
    private String ccrgTesting = "";
    private String ccrgNoRiskReason = "";
    private String ccrgClosureFsa = "";
    private String ccrgApproxGlobalVol = "";

    public static ForumExportDto from(ForumInvestigationMatView e) {
        ForumExportDto dto = new ForumExportDto();
        if (e == null) return dto;

        dto.issueNumber = nvl(e.getIssueNumber());
        dto.issueTitle = nvl(e.getIssueTitle());
        dto.issueOpenDate = nvl(e.getIssueOpenDate());
        dto.issueDescription = nvl(e.getIssueDescription());

        dto.leadRegion = nvl(e.getLeadRegion());
        dto.affectedRegion = nvl(e.getAffectedRegion());
        dto.affectedVehicleLine = nvl(e.getAffectedVehicleLine());
        dto.affectedModelYear = nvl(e.getAffectedModelYear());
        dto.affectedBrand = nvl(e.getAffectedBrand());
        dto.assemblyPlants = nvl(e.getAssemblyPlants());
        dto.makeModelModelYear = nvl(e.getMakeModelModelYear());

        dto.forum = nvl(e.getForum());
        dto.isForumGov = nvl(e.getIsForumGov());
        dto.govAgency = nvl(e.getGovAgency());
        dto.govInitAssignment = nvl(e.getGovInitAssignment());
        dto.govInitDueDate = nvl(e.getGovInitDueDate());
        dto.govRecentAssignment = nvl(e.getGovRecentAssignment());
        dto.govRecentDueDate = nvl(e.getGovRecentDueDate());
        dto.govDueDates = nvl(e.getGovDueDates());
        dto.forumStatus = nvl(e.getForumStatus());
        dto.forumOpenDate = nvl(e.getForumOpenDate());
        dto.forumMeetingDates = nvl(e.getForumMeetingDates());
        dto.forumRecentMeetingDate = nvl(e.getForumRecentMeetingDate());
        dto.forumReOpenedDates = nvl(e.getForumReOpenedDates());
        dto.forumPostFsaMonitor = nvl(e.getForumPostFsaMonitor());
        dto.forumNoOfDaysInOpen = nvl(e.getForumNoOfDaysInOpen());
        dto.forumIntialReOpenDate = nvl(e.getForumIntialReOpenDate());
        dto.forumRecentReOpenDate = nvl(e.getForumRecentReOpenDate());
        dto.forumReOpenedCount = nvl(e.getForumReOpenedCount());
        dto.forumMeetingsCount = nvl(e.getForumMeetingsCount());
        dto.forumConcludedDate = nvl(e.getForumConcludedDate());
        dto.forumConcludedToFsa = nvl(e.getForumConcludedToFsa());
        dto.forumConcludedToFsaNo = nvl(e.getForumConcludedToFsaNo());

        dto.globalForumOpenDate = nvl(e.getGlobalForumOpenDate());
        dto.globalForumMeetingDates = nvl(e.getGlobalForumMeetingDates());
        dto.globalForumRecentMeetingDate = nvl(e.getGlobalForumRecentMeetingDate());
        dto.globalForumNoOfMeetings = nvl(e.getGlobalForumNoOfMeetings());

        dto.fsamFlag = nvl(e.getFsamFlag());
        dto.fsamStatus = nvl(e.getFsamStatus());

        dto.recentMeetingNotesTitle = nvl(e.getRecentMeetingNotesTitle());
        dto.recentMeetingNotes = nvl(e.getRecentMeetingNotes());
        dto.recentMeetingNotesAuthor = nvl(e.getRecentMeetingNotesAuthor());
        dto.recentMeetingNotesDate = nvl(e.getRecentMeetingNotesDate());

        dto.preAuthKickOff = nvl(e.getPreAuthKickOff());
        dto.ccrgInitFindings = nvl(e.getCcrgInitFindings());
        dto.ccrgVoqAnalysis = nvl(e.getCcrgVoqAnalysis());
        dto.ccrgWarrantyAnalysis = nvl(e.getCcrgWarrantyAnalysis());
        dto.ccrgHighSeverityFieldReports = nvl(e.getCcrgHighSeverityFieldReports());
        dto.ccrgConnectedVehicleData = nvl(e.getCcrgConnectedVehicleData());
        dto.ccrgFootPrintAnalysis = nvl(e.getCcrgFootPrintAnalysis());
        dto.ccrgProjections = nvl(e.getCcrgProjections());
        dto.ccrgReliabilityAnalysis = nvl(e.getCcrgReliabilityAnalysis());
        dto.ccrgFieldReport = nvl(e.getCcrgFieldReport());
        dto.ccrgComponentTesting = nvl(e.getCcrgComponentTesting());
        dto.ccrgSubSystemTesting = nvl(e.getCcrgSubSystemTesting());
        dto.ccrgVehicleTesting = nvl(e.getCcrgVehicleTesting());
        dto.ccrgQualitySystemData = nvl(e.getCcrgQualitySystemData());
        dto.ccrgRootCause = nvl(e.getCcrgRootCause());
        dto.ccrgContainmentAct = nvl(e.getCcrgContainmentAct());
        dto.ccrgCustomerExp = nvl(e.getCcrgCustomerExp());
        dto.ccrgSafetyImpact = nvl(e.getCcrgSafetyImpact());
        dto.ccrgWarningIndicators = nvl(e.getCcrgWarningIndicators());
        dto.ccrgTesting = nvl(e.getCcrgTesting());
        dto.ccrgNoRiskReason = nvl(e.getCcrgNoRiskReason());
        dto.ccrgClosureFsa = nvl(e.getCcrgClosureFsa());
        dto.ccrgApproxGlobalVol = nvl(e.getCcrgApproxGlobalVol());

        return dto;
    }

    /** Safely converts any Object field to String, returns "" for null. */
    private static String nvl(Object o) {
        return o != null ? o.toString() : "";
    }
}

