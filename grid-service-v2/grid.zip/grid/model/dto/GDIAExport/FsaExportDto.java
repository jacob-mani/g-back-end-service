package com.ford.grid.model.dto.GDIAExport;

import com.ford.grid.model.entity.FsaMatView;
import lombok.Data;

import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

/**
 * Export DTO for view_by_fsa_mat.
 * All fields are String with "" default — ensures consistent JSON schema with no nulls.
 */
@Data
public class FsaExportDto {

    private String issueNumber = "";
    private String implId = "";
    private String populationId = "";
    private String populationType = "";
    private String potentialFsaName = "";
    private String potentialFsaType = "";
    private String fsaNumber = "";
    private String fsaStatus = "";
    private String globalFsaNumber = "";
    private String stopshipNumber = "";
    private String vernNumber = "";
    private String frcDate = "";
    private String issueTitle = "";
    private String issueDescription = "";
    private String issueOpenDate = "";
    private String leadRegion = "";
    private String labourCost = "";
    private String materialCost = "";
    private String overallEstimatedCost = "";
    private String impactedRegion = "";
    private String impactedModelYear = "";
    private String impactedVehicleLines = "";
    private String impactedBrand = "";
    private String makeModelModelYear = "";
    private String totalSoldUnits = "";
    private String totalUnsoldUnits = "";
    private String totalUnits = "";
    private String govtSubmissionLaunchActivity = "";
    private String dealerBulletinLaunchActivity = "";
    private String ownerNotificationLaunchActivity = "";
    private String partAvailabilityLaunchActivity = "";
    private String impactedRegionsCompletedLaunchActivity = "";
    //private String impactedRegionsDidNotCompleteLaunchActivity = "";

    public static FsaExportDto from(FsaMatView e) {
        FsaExportDto dto = new FsaExportDto();
        if (e == null) return dto;
        dto.issueNumber = nvl(e.getIssueNumber());
        dto.implId = nvl(e.getImplId());
        dto.populationId = nvl(e.getPopulationId());
        dto.populationType = nvl(e.getPopulationType());
        dto.potentialFsaName = nvl(e.getPotentialFsaName());
        dto.potentialFsaType = nvl(e.getPotentialFsaType());
        dto.fsaNumber = nvl(e.getFsaNumber());
        dto.fsaStatus = nvl(e.getFsaStatus());
        dto.globalFsaNumber = nvlNum(e.getGlobalFsaNumber());
        dto.stopshipNumber = nvl(e.getStopshipNumber());
        dto.vernNumber = nvl(e.getVernNumber());
        dto.frcDate = nvlDate(e.getFrcDate());
        dto.issueTitle = nvl(e.getIssueTitle());
        dto.issueDescription = nvl(e.getIssueDescription());
        dto.issueOpenDate = nvlDate(e.getIssueOpenDate());
        dto.leadRegion = nvl(e.getLeadRegion());
        dto.labourCost = nvlNum(e.getLabourCost());
        dto.materialCost = nvlNum(e.getMaterialCost());
        dto.overallEstimatedCost = nvlNum(e.getOverallEstimatedCost());
        dto.impactedRegion = nvlList(e.getImpactedRegion());
        dto.impactedModelYear = nvlNumList(e.getImpactedModelYear());
        dto.impactedVehicleLines = nvlList(e.getImpactedVehicleLines());
        dto.impactedBrand = nvlList(e.getImpactedBrand());
        dto.makeModelModelYear = nvlList(e.getMakeModelModelYear());
        dto.totalSoldUnits = nvlNum(e.getTotalSoldUnits());
        dto.totalUnsoldUnits = nvlNum(e.getTotalUnsoldUnits());
        dto.totalUnits = nvlNum(e.getTotalUnits());
        dto.govtSubmissionLaunchActivity = nvl(e.getGovtSubmissionLaunchActivity());
        dto.dealerBulletinLaunchActivity = nvl(e.getDealerBulletinLaunchActivity());
        dto.ownerNotificationLaunchActivity = nvl(e.getOwnerNotificationLaunchActivity());
        dto.partAvailabilityLaunchActivity = nvl(e.getPartAvailabilityLaunchActivity());
        dto.impactedRegionsCompletedLaunchActivity = nvl(e.getImpactedRegionsCompletedLaunchActivity());
        // dto.impactedRegionsDidNotCompleteLaunchActivity = nvlList(e.getImpactedRegionsDidNotCompleteLaunchActivity());
        return dto;
    }

    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private static String nvl(String s) { return s != null ? s : ""; }
    private static String nvlNum(Number n) { return n != null ? n.toString() : ""; }
    private static String nvlDate(Date d) {
        if (d == null) return "";
        return d.toInstant().atZone(ZoneId.systemDefault()).toLocalDate().format(DATE_FMT);
    }
    private static String nvlList(List<?> l) {
        if (l == null || l.isEmpty()) return "";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < l.size(); i++) {
            if (i > 0) sb.append(", ");
            Object item = l.get(i);
            if (item instanceof Date d) {
                sb.append(d.toInstant().atZone(ZoneId.systemDefault()).toLocalDate().format(DATE_FMT));
            } else {
                sb.append(item != null ? item.toString() : "");
            }
        }
        return sb.toString();
    }
    private static String nvlNumList(List<? extends Number> l) {
        if (l == null || l.isEmpty()) return "";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < l.size(); i++) {
            if (i > 0) sb.append(", ");
            sb.append(l.get(i) != null ? l.get(i).toString() : "");
        }
        return sb.toString();
    }
}
