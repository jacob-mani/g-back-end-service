package com.ford.grid.model.dto.GDIAExport;

import com.ford.grid.model.entity.HwPartsMatView;
import lombok.Data;

import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;

/**
 * Export DTO for view_by_hwParts_mat.
 * All fields are String with "" default — ensures consistent JSON schema with no nulls.
 */
@Data
public class HwPartsExportDto {

    // ── Issue & Implementation ───────────────────────────────────────────
    private String issueNumber = "";
    private String issueTitle = "";
    private String implId = "";
    private String populationId = "";
    private String populationType = "";
    private String potentialFsaName = "";
    private String potentialIssueType = "";
    private String fsaNumber = "";

    // ── Region ───────────────────────────────────────────────────────────
    private String leadRegion = "";
    private String affectedRegion = "";
    private String psnlRegion = "";

    // ── Contacts ──────────────────────────────────────────────────────────
    private String implementationLead = "";
    private String fcsdPurchaseLead = "";
    private String pslSupplyChain = "";
    private String sta = "";

    // ── PreAuth ───────────────────────────────────────────────────────────
    private String preAuthApprovedBy = "";
    private String preAuthApprovedDate = "";
    private String preAuthRequestedBy = "";
    private String preAuthRequestedDate = "";

    // ── PSNL signoff & SCM ────────────────────────────────────────────────
    private String pslSignoffDate = "";
    private String scmPurchasingRating = "";
    private String programType = "";
    private String confirmedBy = "";
    private String confirmedOn = "";

    // ── Vehicle totals ────────────────────────────────────────────────────
    private String totalVehicleUnits = "";
    private String totalVehicleSold = "";
    private String totalVehicleUnsold = "";

    // ── Market ───────────────────────────────────────────────────────────
    private String market = "";

    // ── Part identification ───────────────────────────────────────────────
    private String engineeringPartNumber = "";
    private String servicePartNumber = "";
    private String finisCode = "";
    private String partName = "";

    // ── Part flags ────────────────────────────────────────────────────────
    private String partType = "";
    private String partStatus = "";
    private String relatedDamagedPart = "";
    private String oneTimePart = "";
    private String causalPart = "";

    // ── Part quantities ───────────────────────────────────────────────────
    private String totalQuantity = "";
    private String launchQuantity = "";
    private String partQtySold = "";
    private String partQtyUnsold = "";
    private String partQtyTotal = "";

    // ── Country-level PSNL fields ─────────────────────────────────────────
    private String partOk = "";
    private String netInStockQuantity = "";
    private String oneTimePartQty = "";
    private String orderQuantity = "";
    private String overallPartsAvailableStatusComments = "";
    private String partComment = "";
    private String partStatusDetail = "";
    private String partsPrice = "";
    private String eta = "";
    private String targetDate = "";
    private String actualDate = "";

    // ── Supplier & Critical Part ──────────────────────────────────────────
    private String criticalPart = "";
    private String supplierCode = "";
    private String supplierName = "";


    public static HwPartsExportDto from(HwPartsMatView e) {
        HwPartsExportDto dto = new HwPartsExportDto();
        if (e == null) return dto;

        dto.issueNumber = nvl(e.getIssueNumber());
        dto.issueTitle = nvl(e.getIssueTitle());
        dto.implId = nvl(e.getImplId());
        dto.populationId = nvl(e.getPopulationId());
        dto.populationType = nvl(e.getPopulationType());
        dto.potentialFsaName = nvl(e.getPotentialFsaName());
        dto.potentialIssueType = nvl(e.getPotentialIssueType());
        dto.fsaNumber = nvl(e.getFsaNumber());

        dto.leadRegion = nvl(e.getLeadRegion());
        dto.affectedRegion = nvl(e.getAffectedRegion());
        dto.psnlRegion = nvl(e.getPsnlRegion());

        dto.implementationLead = nvl(e.getImplementationLead());
        dto.fcsdPurchaseLead = nvl(e.getFcsdPurchaseLead());
        dto.pslSupplyChain = nvl(e.getPslSupplyChain());
        dto.sta = nvl(e.getSta());

        dto.preAuthApprovedBy = nvl(e.getPreAuthApprovedBy());
        dto.preAuthApprovedDate = nvlDate(e.getPreAuthApprovedDate());
        dto.preAuthRequestedBy = nvl(e.getPreAuthRequestedBy());
        dto.preAuthRequestedDate = nvlDate(e.getPreAuthRequestedDate());

        dto.pslSignoffDate = nvlDate(e.getPslSignoffDate());
        dto.scmPurchasingRating = nvl(e.getScmPurchasingRating());
        dto.programType = nvl(e.getProgramType());
        dto.confirmedBy = nvl(e.getConfirmedBy());
        dto.confirmedOn = nvlDate(e.getConfirmedOn());

        dto.totalVehicleUnits = nvlNum(e.getTotalVehicleUnits());
        dto.totalVehicleSold = nvlNum(e.getTotalVehicleSold());
        dto.totalVehicleUnsold = nvlNum(e.getTotalVehicleUnsold());

        dto.market = nvl(e.getMarket());

        dto.engineeringPartNumber = nvl(e.getEngineeringPartNumber());
        dto.servicePartNumber = nvl(e.getServicePartNumber());
        dto.finisCode = nvl(e.getFinisCode());
        dto.partName = nvl(e.getPartName());

        dto.partType = nvl(e.getPartType());
        dto.partStatus = nvl(e.getPartStatus());
        dto.relatedDamagedPart = nvl(e.getRelatedDamagedPart());
        dto.oneTimePart = nvl(e.getOneTimePart());
        dto.causalPart = nvl(e.getCausalPart());

        dto.totalQuantity = nvlNum(e.getTotalQuantity());
        dto.launchQuantity = nvlNum(e.getLaunchQuantity());
        dto.partQtySold = nvlNum(e.getPartQtySold());
        dto.partQtyUnsold = nvlNum(e.getPartQtyUnsold());
        dto.partQtyTotal = nvlNum(e.getPartQtyTotal());

        dto.partOk = nvl(e.getPartOk());
        dto.netInStockQuantity = nvlNum(e.getNetInStockQuantity());
        dto.oneTimePartQty = nvlNum(e.getOneTimePartQty());
        dto.orderQuantity = nvlNum(e.getOrderQuantity());
        dto.overallPartsAvailableStatusComments = nvl(e.getOverallPartsAvailableStatusComments());
        dto.partComment = nvl(e.getPartComment());
        dto.partStatusDetail = nvl(e.getPartStatusDetail());
        dto.partsPrice = e.getPartsPrice() != null ? e.getPartsPrice().toString() : "";
        dto.eta = nvl(e.getEta());
        dto.targetDate = nvl(e.getTargetDate());
        dto.actualDate = nvlDate(e.getActualDate());

        dto.criticalPart = nvl(e.getCriticalPart());
        dto.supplierCode = nvl(e.getSupplierCode());
        dto.supplierName = nvl(e.getSupplierName());

        return dto;
    }

    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private static String nvl(String s) { return s != null ? s : ""; }
    private static String nvlNum(Number n) { return n != null ? n.toString() : ""; }
    private static String nvlDate(Date d) {
        if (d == null) return "";
        return d.toInstant().atZone(ZoneId.systemDefault()).toLocalDate().format(DATE_FMT);
    }
}
