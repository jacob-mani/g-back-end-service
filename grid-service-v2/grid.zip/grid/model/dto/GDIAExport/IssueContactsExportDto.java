package com.ford.grid.model.dto.GDIAExport;

import com.ford.grid.model.entity.GdiaViewByIssueContactsDocument;
import com.ford.grid.model.entity.IssueContactEntry;
import com.ford.grid.model.entity.IssueContactsMatView;
import com.ford.grid.model.entity.IssueCustomContactEntry;
import com.ford.grid.model.entity.IssueSubGroupEntry;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

/**
 * Export DTO for view_by_issue_contacts.
 * All fields (including nested objects) are String with "" default — zero nulls in JSON.
 */
@Data
public class IssueContactsExportDto {

    private String issueNumber = "";
    private String affectedRegions = "";
    private List<ContactExportDto> contacts = new ArrayList<>();
    private List<CustomContactExportDto> customContacts = new ArrayList<>();
    private List<SubGroupExportDto> subGroups = new ArrayList<>();

    // ── Nested DTOs ───────────────────────────────────────────────────────────

    @Data
    public static class ContactExportDto {
        private String id = "";
        private String label = "";
        private String name = "";
        private String cdsid = "";

        public static ContactExportDto from(IssueContactEntry c) {
            ContactExportDto dto = new ContactExportDto();
            if (c == null) return dto;
            dto.id = nvl(c.getId());
            dto.label = nvl(c.getLabel());
            dto.name = nvl(c.getName());
            dto.cdsid = nvl(c.getCdsid());
            return dto;
        }
    }

    @Data
    public static class CustomContactExportDto {
        private String id = "";
        private String groupId = "";
        private String groupName = "";
        private String label = "";
        private String name = "";
        private String cdsid = "";

        public static CustomContactExportDto from(IssueCustomContactEntry c) {
            CustomContactExportDto dto = new CustomContactExportDto();
            if (c == null) return dto;
            dto.id = nvl(c.getId());
            dto.groupId = nvl(c.getGroupId());
            dto.groupName = nvl(c.getGroupName());
            dto.label = nvl(c.getLabel());
            dto.name = nvl(c.getName());
            dto.cdsid = nvl(c.getCdsid());
            return dto;
        }
    }

    @Data
    public static class SubGroupContactExportDto {
        private String id = "";
        private String label = "";
        private String name = "";
        private String cdsid = "";

        public static SubGroupContactExportDto from(IssueContactEntry c) {
            SubGroupContactExportDto dto = new SubGroupContactExportDto();
            if (c == null) return dto;
            dto.id = nvl(c.getId());
            dto.label = nvl(c.getLabel());
            dto.name = nvl(c.getName());
            dto.cdsid = nvl(c.getCdsid());
            return dto;
        }
    }

    @Data
    public static class SubGroupDetailExportDto {
        private String subGroupName = "";
        private List<SubGroupContactExportDto> contacts = new ArrayList<>();

        public static SubGroupDetailExportDto from(IssueSubGroupEntry.IssueSubGroupDetailEntry d) {
            SubGroupDetailExportDto dto = new SubGroupDetailExportDto();
            if (d == null) return dto;
            dto.subGroupName = nvl(d.getSubGroupName());
            if (d.getContacts() != null) {
                for (IssueContactEntry c : d.getContacts()) {
                    dto.contacts.add(SubGroupContactExportDto.from(c));
                }
            }
            return dto;
        }
    }

    @Data
    public static class SubGroupExportDto {
        private String groupId = "";
        private String groupName = "";
        private List<SubGroupDetailExportDto> subGroupDetails = new ArrayList<>();

        public static SubGroupExportDto from(IssueSubGroupEntry sg) {
            SubGroupExportDto dto = new SubGroupExportDto();
            if (sg == null) return dto;
            dto.groupId = nvl(sg.getGroupId());
            dto.groupName = nvl(sg.getGroupName());
            if (sg.getSubGroupDetails() != null) {
                for (IssueSubGroupEntry.IssueSubGroupDetailEntry d : sg.getSubGroupDetails()) {
                    dto.subGroupDetails.add(SubGroupDetailExportDto.from(d));
                }
            }
            return dto;
        }
    }

    // ── Root mappers ──────────────────────────────────────────────────────────

    public static IssueContactsExportDto from(GdiaViewByIssueContactsDocument e) {
        return mapFromFields(e == null ? null : e.getIssueNumber(),
                e == null ? null : e.getAffectedRegions(),
                e == null ? null : e.getContacts(),
                e == null ? null : e.getCustomContacts(),
                e == null ? null : e.getSubGroups());
    }

    public static IssueContactsExportDto from(IssueContactsMatView e) {
        return mapFromFields(e == null ? null : e.getIssueNumber(),
                e == null ? null : e.getAffectedRegions(),
                e == null ? null : e.getContacts(),
                e == null ? null : e.getCustomContacts(),
                e == null ? null : e.getSubGroups());
    }

    private static IssueContactsExportDto mapFromFields(
            String issueNumber, String affectedRegions,
            List<IssueContactEntry> contacts,
            List<IssueCustomContactEntry> customContacts,
            List<IssueSubGroupEntry> subGroups) {
        IssueContactsExportDto dto = new IssueContactsExportDto();
        dto.issueNumber = nvl(issueNumber);
        dto.affectedRegions = nvl(affectedRegions);
        if (contacts != null) {
            for (IssueContactEntry c : contacts) {
                dto.contacts.add(ContactExportDto.from(c));
            }
        }
        if (customContacts != null) {
            for (IssueCustomContactEntry c : customContacts) {
                dto.customContacts.add(CustomContactExportDto.from(c));
            }
        }
        if (subGroups != null) {
            for (IssueSubGroupEntry sg : subGroups) {
                dto.subGroups.add(SubGroupExportDto.from(sg));
            }
        }
        return dto;
    }

    private static String nvl(String s) { return s != null ? s : ""; }
}
