package com.ford.grid.model.dto.GDIAExport;

import com.ford.grid.model.entity.customviews.IssueMaterialView;
import com.google.gson.annotations.SerializedName;
import lombok.Data;

import java.util.Collections;
import java.util.List;

/**
 * Export DTO for view_by_issue_mat.
 * All fields are String with "" default — ensures consistent JSON schema with no nulls.
 */
@Data
public class IssueExportDto {

    // ── Issue identifiers ─────────────────────────────────────────────────
    private String issueNumber = "";
    private String issueTitle = "";
    private String issueDescription = "";
    private String issueOpenDate = "";
    private String issueCreationDate = "";
    private String issueCreatedBy = "";
    private String leadRegion = "";
    private String relatedItems = "";
    private String segment = "";
    private String issueCurrentPhase = "";
    private String patientZeroDate = "";

    // ── Dates ─────────────────────────────────────────────────────────────
    private String icaDate = "";
    private String pcaDate = "";

    // ── Impact ────────────────────────────────────────────────────────────
    private String affectedRegions = "";
    private String affectedVehicleLine = "";
    private String affectedModelYear = "";
    private String affectedBrand = "";
    private String makeModelModelYear = "";
    private String assemblyPlants = "";
    private String causalType = "";
    private String causalFunction = "";
    private String causalTypeOther = "";
    private String functionOther = "";
    private String commodity = "";
    private String stopship = "";
    private String govtInvestigation = "";
    private String forums = "";

    // ── CCRG Forum ────────────────────────────────────────────────────────
    private String ccrgOpenDate = "";
    private String ccrgForumStatus = "";
    private String ccrgNoOfDaysInOpen = "";
    private String ccrgNoOfDaysInMonitor = "";
    private String ccrgConcludedDate = "";

    // ── CSF Forum ─────────────────────────────────────────────────────────
    private String csfOpenDate = "";
    private String csfForumStatus = "";
    private String csfNoOfDaysInOpen = "";
    private String csfNoOfDaysInMonitor = "";
    private String csfConcludedDate = "";

    // ── EPRC Forum ────────────────────────────────────────────────────────
    private String eprcOpenDate = "";
    private String eprcForumStatus = "";
    private String eprcNoOfDaysInOpen = "";
    private String eprcNoOfDaysInMonitor = "";
    private String eprcConcludedDate = "";

    // ── PIR Forum ─────────────────────────────────────────────────────────
    private String pirOpenDate = "";
    private String pirForumStatus = "";
    private String pirNoOfDaysInOpen = "";
    private String pirNoOfDaysInMonitor = "";
    private String pirConcludedDate = "";

    // ── Gov Forum / 14D ───────────────────────────────────────────────────
    private String govForumKickOff = "";
    @SerializedName("DOpenDate14")
    private String dOpenDate14 = "";
    @SerializedName("DCloseDate14")
    private String dCloseDate14 = "";
    @SerializedName("DCloseBy14")
    private String dCloseBy14 = "";
    @SerializedName("DMeetingDates14")
    private String dMeetingDates14 = "";
    @SerializedName("DRecentMeetingDate14")
    private String dRecentMeetingDate14 = "";
    @SerializedName("DRecentMeetingNotesDate14")
    private String dRecentMeetingNotesDate14 = "";
    @SerializedName("DRecentMeetingNotesTitle14")
    private String dRecentMeetingNotesTitle14 = "";
    @SerializedName("DRecentMeetingNotes14")
    private String dRecentMeetingNotes14 = "";

    // ── FD Status ─────────────────────────────────────────────────────────
    private String fd1Status = "";
    private String fd1UpdatedDate = "";
    private String fd1UpdatedBy = "";
    private String fd2Status = "";
    private String fd2UpdatedDate = "";
    private String fd2UpdatedBy = "";
    private String fd3Status = "";
    private String fd3UpdatedDate = "";
    private String fd3UpdatedBy = "";
    private String fd4Status = "";
    private String fd4UpdatedDate = "";
    private String fd4UpdatedBy = "";
    private String fd6Status = "";
    private String fd6UpdatedDate = "";
    private String fd6UpdatedBy = "";
    private String fd7Status = "";
    private String fd7UpdatedDate = "";
    private String fd7UpdatedBy = "";
    private String fd8Status = "";
    private String fd8UpdatedDate = "";
    private String fd8UpdatedBy = "";
    private String fd11Status = "";
    private String fd11UpdatedDate = "";
    private String fd11UpdatedBy = "";
    private String fdStatus = "";
    @SerializedName("14DAge")
    private String fdAge = "";

    // ── EMM TRG ───────────────────────────────────────────────────────────
    private String emmTrgOpenDate = "";
    private String emmTrgMeetingDates = "";
    private String emmTrgRecentMeetingDate = "";

    // ── TRG ───────────────────────────────────────────────────────────────
    private String trgOpenDate = "";
    private String trgMeetingDates = "";
    private String trgRecentMeetingDate = "";
    private String trgMeetingType = "";
    private String trgRecentMeetingType = "";
    private String trgRecentMeetingTitle = "";
    private String trgRecentCcrgTeam = "";
    private String trgRecentDuration = "";
    private String trgRecentMeetingNotesDate = "";
    private String trgRecentMeetingNotesTitle = "";
    private String trgRecentMeetingNotes = "";

    // ── Transient Notes ───────────────────────────────────────────────────
    private String transientNotesAso = "";
    private String transientNotesCsf = "";
    private String transientNotesEprc = "";
    private String transientNotesCcm = "";
    private String transientNotesCce = "";
    private String transientNotesOgc = "";
    private String transientNotesPsl = "";
    private String transientNotesFcsdSeo = "";
    private String transientNotesFcsdRsp = "";
    private String transientNotesFcsdScm = "";
    private String transientNotesFcsdPurchasing = "";
    private String transientNotesExecutiveSummaryNotes = "";

    // ── First Meeting Dates ───────────────────────────────────────────────
    private String ccrgFirstMeetingDate = "";
    private String csfFirstMeetingDate = "";
    private String eprcFirstMeetingDate = "";
    private String pirFirstMeetingDate = "";

    // ── Days Metrics ──────────────────────────────────────────────────────
    private String noOfDaysCcrgTo14D = "";
    private String noOfDaysCsfTo14D = "";
    private String noOfDaysEprcTo14D = "";
    private String noOfDaysPirTo14D = "";
    private String noOfDaysCcrgToTrg = "";
    private String noOfDaysCsfToTrg = "";
    private String noOfDaysEprcToTrg = "";
    private String noOfDays14DToTrg = "";

    // ── FSA ───────────────────────────────────────────────────────────────
    private List<String> fsaNumber = Collections.emptyList();

    // ── TRG Creation / RC / PRA Dates ─────────────────────────────────────
    private String trgCreationDate = "";
    private String rcDate = "";
    private String praDate = "";

    public static IssueExportDto from(IssueMaterialView e) {
        IssueExportDto dto = new IssueExportDto();
        if (e == null) return dto;

        dto.issueNumber = nvl(e.getIssueNumber());
        dto.issueTitle = nvl(e.getIssueTitle());
        dto.issueDescription = nvl(e.getIssueDescription());
        dto.issueOpenDate = nvl(e.getIssueOpenDate());
        dto.issueCreationDate = nvl(e.getIssueCreationDate());
        dto.issueCreatedBy = nvl(e.getIssueCreatedBy());
        dto.leadRegion = nvl(e.getLeadRegion());
        dto.relatedItems = nvl(e.getRelatedItems());
        dto.segment = nvl(e.getSegment());
        dto.issueCurrentPhase = nvl(e.getIssueCurrentPhase());
        dto.patientZeroDate = nvl(e.getPatientZeroDate());

        dto.icaDate = nvl(e.getIcaDate());
        dto.pcaDate = nvl(e.getPcaDate());

        dto.affectedRegions = nvl(e.getAffectedRegions());
        dto.affectedVehicleLine = nvl(e.getAffectedVehicleLine());
        dto.affectedModelYear = nvl(e.getAffectedModelYear());
        dto.affectedBrand = nvl(e.getAffectedBrand());
        dto.makeModelModelYear = nvl(e.getMakeModelModelYear());
        dto.assemblyPlants = nvl(e.getAssemblyPlants());
        dto.causalType = nvl(e.getCausalType());
        dto.causalFunction = nvl(e.getCausalFunction());
        dto.causalTypeOther = nvl(e.getCausalTypeOther());
        dto.functionOther = nvl(e.getFunctionOther());
        dto.commodity = nvl(e.getCommodity());
        dto.stopship = nvl(e.getStopship());
        dto.govtInvestigation = nvl(e.getGovtInvestigation());
        dto.forums = nvl(e.getForums());

        dto.ccrgOpenDate = nvl(e.getCcrgOpenDate());
        dto.ccrgForumStatus = nvl(e.getCcrgForumStatus());
        dto.ccrgNoOfDaysInOpen = nvl(e.getCcrgNoOfDaysInOpen());
        dto.ccrgNoOfDaysInMonitor = nvl(e.getCcrgNoOfDaysInMonitor());
        dto.ccrgConcludedDate = nvl(e.getCcrgConcludedDate());

        dto.csfOpenDate = nvl(e.getCsfOpenDate());
        dto.csfForumStatus = nvl(e.getCsfForumStatus());
        dto.csfNoOfDaysInOpen = nvl(e.getCsfNoOfDaysInOpen());
        dto.csfNoOfDaysInMonitor = nvl(e.getCsfNoOfDaysInMonitor());
        dto.csfConcludedDate = nvl(e.getCsfConcludedDate());

        dto.eprcOpenDate = nvl(e.getEprcOpenDate());
        dto.eprcForumStatus = nvl(e.getEprcForumStatus());
        dto.eprcNoOfDaysInOpen = nvl(e.getEprcNoOfDaysInOpen());
        dto.eprcNoOfDaysInMonitor = nvl(e.getEprcNoOfDaysInMonitor());
        dto.eprcConcludedDate = nvl(e.getEprcConcludedDate());

        dto.pirOpenDate = nvl(e.getPirOpenDate());
        dto.pirForumStatus = nvl(e.getPirForumStatus());
        dto.pirNoOfDaysInOpen = nvl(e.getPirNoOfDaysInOpen());
        dto.pirNoOfDaysInMonitor = nvl(e.getPirNoOfDaysInMonitor());
        dto.pirConcludedDate = nvl(e.getPirConcludedDate());

        dto.govForumKickOff = nvl(e.getGovForumKickOff());
        dto.dOpenDate14 = nvl(e.getDOpenDate14());
        dto.dCloseDate14 = nvl(e.getDCloseDate14());
        dto.dCloseBy14 = nvl(e.getDCloseBy14());
        dto.dMeetingDates14 = nvl(e.getDMeetingDates14());
        dto.dRecentMeetingDate14 = nvl(e.getDRecentMeetingDate14());
        dto.dRecentMeetingNotesDate14 = nvl(e.getDRecentMeetingNotesDate14());
        dto.dRecentMeetingNotesTitle14 = nvl(e.getDRecentMeetingNotesTitle14());
        dto.dRecentMeetingNotes14 = nvl(e.getDRecentMeetingNotes14());

        dto.fd1Status = nvl(e.getFd1Status());
        dto.fd1UpdatedDate = nvl(e.getFd1UpdatedDate());
        dto.fd1UpdatedBy = nvl(e.getFd1UpdatedBy());
        dto.fd2Status = nvl(e.getFd2Status());
        dto.fd2UpdatedDate = nvl(e.getFd2UpdatedDate());
        dto.fd2UpdatedBy = nvl(e.getFd2UpdatedBy());
        dto.fd3Status = nvl(e.getFd3Status());
        dto.fd3UpdatedDate = nvl(e.getFd3UpdatedDate());
        dto.fd3UpdatedBy = nvl(e.getFd3UpdatedBy());
        dto.fd4Status = nvl(e.getFd4Status());
        dto.fd4UpdatedDate = nvl(e.getFd4UpdatedDate());
        dto.fd4UpdatedBy = nvl(e.getFd4UpdatedBy());
        dto.fd6Status = nvl(e.getFd6Status());
        dto.fd6UpdatedDate = nvl(e.getFd6UpdatedDate());
        dto.fd6UpdatedBy = nvl(e.getFd6UpdatedBy());
        dto.fd7Status = nvl(e.getFd7Status());
        dto.fd7UpdatedDate = nvl(e.getFd7UpdatedDate());
        dto.fd7UpdatedBy = nvl(e.getFd7UpdatedBy());
        dto.fd8Status = nvl(e.getFd8Status());
        dto.fd8UpdatedDate = nvl(e.getFd8UpdatedDate());
        dto.fd8UpdatedBy = nvl(e.getFd8UpdatedBy());
        dto.fd11Status = nvl(e.getFd11Status());
        dto.fd11UpdatedDate = nvl(e.getFd11UpdatedDate());
        dto.fd11UpdatedBy = nvl(e.getFd11UpdatedBy());
        dto.fdStatus = nvl(e.getFdStatus());
        dto.fdAge = nvl(e.getFdAge());

        dto.emmTrgOpenDate = nvl(e.getEmmTrgOpenDate());
        dto.emmTrgMeetingDates = nvl(e.getEmmTrgMeetingDates());
        dto.emmTrgRecentMeetingDate = nvl(e.getEmmTrgRecentMeetingDate());

        dto.trgOpenDate = nvl(e.getTrgOpenDate());
        dto.trgMeetingDates = nvl(e.getTrgMeetingDates());
        dto.trgRecentMeetingDate = nvl(e.getTrgRecentMeetingDate());
        dto.trgMeetingType = nvl(e.getTrgMeetingType());
        dto.trgRecentMeetingType = nvl(e.getTrgRecentMeetingType());
        dto.trgRecentMeetingTitle = nvl(e.getTrgRecentMeetingTitle());
        dto.trgRecentCcrgTeam = nvl(e.getTrgRecentCcrgTeam());
        dto.trgRecentDuration = nvl(e.getTrgRecentDuration());
        dto.trgRecentMeetingNotesDate = nvl(e.getTrgRecentMeetingNotesDate());
        dto.trgRecentMeetingNotesTitle = nvl(e.getTrgRecentMeetingNotesTitle());
        dto.trgRecentMeetingNotes = nvl(e.getTrgRecentMeetingNotes());

        dto.transientNotesAso = nvl(e.getTransientNotesAso());
        dto.transientNotesCsf = nvl(e.getTransientNotesCsf());
        dto.transientNotesEprc = nvl(e.getTransientNotesEprc());
        dto.transientNotesCcm = nvl(e.getTransientNotesCcm());
        dto.transientNotesCce = nvl(e.getTransientNotesCce());
        dto.transientNotesOgc = nvl(e.getTransientNotesOgc());
        dto.transientNotesPsl = nvl(e.getTransientNotesPsl());
        dto.transientNotesFcsdSeo = nvl(e.getTransientNotesFcsdSeo());
        dto.transientNotesFcsdRsp = nvl(e.getTransientNotesFcsdRsp());
        dto.transientNotesFcsdScm = nvl(e.getTransientNotesFcsdScm());
        dto.transientNotesFcsdPurchasing = nvl(e.getTransientNotesFcsdPurchasing());
        dto.transientNotesExecutiveSummaryNotes = nvl(e.getTransientNotesExecutiveSummaryNotes());

        dto.ccrgFirstMeetingDate = nvl(e.getCcrgFirstMeetingDate());
        dto.csfFirstMeetingDate = nvl(e.getCsfFirstMeetingDate());
        dto.eprcFirstMeetingDate = nvl(e.getEprcFirstMeetingDate());
        dto.pirFirstMeetingDate = nvl(e.getPirFirstMeetingDate());

        dto.noOfDaysCcrgTo14D = nvl(e.getNoOfDaysCcrgTo14D());
        dto.noOfDaysCsfTo14D = nvl(e.getNoOfDaysCsfTo14D());
        dto.noOfDaysEprcTo14D = nvl(e.getNoOfDaysEprcTo14D());
        dto.noOfDaysPirTo14D = nvl(e.getNoOfDaysPirTo14D());
        dto.noOfDaysCcrgToTrg = nvl(e.getNoOfDaysCcrgToTrg());
        dto.noOfDaysCsfToTrg = nvl(e.getNoOfDaysCsfToTrg());
        dto.noOfDaysEprcToTrg = nvl(e.getNoOfDaysEprcToTrg());
        dto.noOfDays14DToTrg = nvl(e.getNoOfDays14DToTrg());

        dto.fsaNumber = e.getFsaNumber();

        dto.trgCreationDate = nvl(e.getTrgCreationDate());
        dto.rcDate = nvl(e.getRcDate());
        dto.praDate = nvl(e.getPraDate());

        return dto;
    }

    private static String nvl(String s) { return s != null ? s : ""; }
}

