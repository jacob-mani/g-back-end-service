package com.ford.grid.model.dto.GDIAExport;

import com.ford.grid.model.entity.LaunchMatView;
import lombok.Data;

import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;

/**
 * Export DTO for view_by_launch_mat.
 * All fields are String with "" default — ensures consistent JSON schema with no nulls.
 */
@Data
public class LaunchExportDto {

    private String issueNumber = "";
    private String implId = "";
    private String fsaNumber = "";
    private String globalFsa = "";
    private String populationId = "";
    private String populationType = "";
    private String potentialFsaName = "";
    private String potentialFsaType = "";
    private String issueTitle = "";
    private String issueDescription = "";
    private String issueOpenDate = "";
    private String leadRegion = "";
    private String impactedRegion = "";
    private String submissionType = "";
    private String notificationType = "";
    private String referenceNo = "";
    private String nhtsaVin = "";
    private String fordVin = "";
    private String marketsApplicable = "";
    private String repairDetails = "";
    private String recTargetDate = "";
    private String revisedTargetDate = "";
    private String actualNotificationDate = "";
    private String reasonForDelay = "";
    private String govtSubLaunchActivityStatus = "";
    private String ownerNotifLaunchActivityStatus = "";
    private String dealerBullLaunchActivityStatus = "";
    private String govtSubLaunchActivity = "";
    private String ownerNotifLaunchActivity = "";
    private String dealerBulletLaunchActivity = "";
    private String regionalLaunchActivityStatus = "";

    public static LaunchExportDto from(LaunchMatView e) {
        LaunchExportDto dto = new LaunchExportDto();
        if (e == null) return dto;
        dto.issueNumber = nvl(e.getIssueNumber());
        dto.implId = nvl(e.getImplId());
        dto.fsaNumber = nvl(e.getFsaNumber());
        dto.globalFsa = nvlNum(e.getGlobalFsa());
        dto.populationId = nvl(e.getPopulationId());
        dto.populationType = nvl(e.getPopulationType());
        dto.potentialFsaName = nvl(e.getPotentialFsaName());
        dto.potentialFsaType = nvl(e.getPotentialFsaType());
        dto.issueTitle = nvl(e.getIssueTitle());
        dto.issueDescription = nvl(e.getIssueDescription());
        dto.issueOpenDate = nvlDate(e.getIssueOpenDate());
        dto.leadRegion = nvl(e.getLeadRegion());
        dto.impactedRegion = nvl(e.getImpactedRegion());
        dto.submissionType = nvl(e.getSubmissionType());
        dto.notificationType = nvl(e.getNotificationType());
        dto.referenceNo = nvl(e.getReferenceNo());
        dto.nhtsaVin = nvl(e.getNhtsaVin());
        dto.fordVin = nvl(e.getFordVin());
        dto.marketsApplicable = nvl(e.getMarketsApplicable());
        dto.repairDetails = nvl(e.getRepairDetails());
        dto.recTargetDate = nvlDate(e.getRecTargetDate());
        dto.revisedTargetDate = nvlDate(e.getRevisedTargetDate());
        dto.actualNotificationDate = nvlDate(e.getActualNotificationDate());
        dto.reasonForDelay = nvl(e.getReasonForDelay());
        dto.govtSubLaunchActivityStatus = nvl(e.getGovtSubLaunchActivityStatus());
        dto.ownerNotifLaunchActivityStatus = nvl(e.getOwnerNotifLaunchActivityStatus());
        dto.dealerBullLaunchActivityStatus = nvl(e.getDealerBullLaunchActivityStatus());
        dto.govtSubLaunchActivity = nvl(e.getGovtSubLaunchActivity());
        dto.ownerNotifLaunchActivity = nvl(e.getOwnerNotifLaunchActivity());
        dto.dealerBulletLaunchActivity = nvl(e.getDealerBulletLaunchActivity());
        dto.regionalLaunchActivityStatus = nvl(e.getRegionalLaunchActivityStatus());
        return dto;
    }

    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private static String nvl(String s) { return s != null ? s : ""; }
    private static String nvlNum(Number n) { return n != null ? n.toString() : ""; }
    private static String nvlDate(Date d) {
        if (d == null) return "";
        return d.toInstant().atZone(ZoneId.systemDefault()).toLocalDate().format(DATE_FMT);
    }
}
