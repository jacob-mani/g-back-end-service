package com.ford.grid.model.dto.GDIAExport;

import com.ford.grid.model.entity.PopulationMatView;
import lombok.Data;

import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

/**
 * Export DTO for view_by_population_mat.
 * All fields are String with "" default — ensures consistent JSON schema with no nulls.
 */
@Data
public class PopulationExportDto {

    private String issueNumber = "";
    private String implId = "";
    private String fsaNumber = "";
    private String globalFsa = "";
    private String populationId = "";
    private String populationType = "";
    private String potentialFsaName = "";
    private String potentialFsaType = "";
    private String issueTitle = "";
    private String issueDescription = "";
    private String issueOpenDate = "";
    private String leadRegion = "";
    private String impactedRegion = "";
    private String impactedMarket = "";
    private String impactedVehicleLine = "";
    private String makeModelModelYear = "";
    private String fd9Status = "";
    private String fd9UpdatedDate = "";
    private String fd9UpdatedBy = "";
    private String fd10Status = "";
    private String fd10UpdatedDate = "";
    private String fd10UpdatedBy = "";
    private String trgInitMeetingDate = "";
    private String trgRecentMeetingDate = "";
    private String trgRecentMeetingType = "";
    private String trgRecentMeetingUrgency = "";
    private String trgRecentMeetingTitle = "";
    private String trgRecentCcrgTeam = "";
    private String trgRecentDuration = "";
    private String trgRecentCriticalParticipantSupp = "";
    private String trgRecentOtherParticipants = "";
    private String trgRecentScheduledStatus = "";
    private String trgMeetingDates = "";
    private String trgCreationDate = "";
    private String noOfDaysCcrgToTrg = "";
    private String noOfDaysCsfToTrg = "";
    private String noOfDaysEprcToTrg = "";
    private String noOfDays14DToTrg = "";
    private String noOfDays14DToFrc = "";
    private String noOfDaysTrgToFrc = "";
    private String frcFactSheetTargetDate = "";
    private String frcFactSheetRecentDraftCompDate = "";
    private String frcFactSheetRecentRevCompDate = "";
    private String frcInitMeetingDate = "";
    private String frcRecentMeetingDate = "";
    private String frcMeetingDates = "";
    private String frcRecentApprRegion = "";
    private String frcRecentDealBulletinTiming = "";
    private String frcRecentDraftTitle = "";
    private String frcRecentApprovalSentToGCAMP = "";
    private String frcMemoInitMeetingDate = "";
    private String frcMemoRecentMeetingDate = "";
    private String frcMemoMeetingDates = "";
    private String trgRecentMeetingNotesDate = "";
    private String trgRecentMeetingNotesTitle = "";
    private String trgRecentMeetingNotes = "";
    private String frcRecentMeetingNotesDate = "";
    private String frcRecentMeetingNotesTitle = "";
    private String frcRecentMeetingNotes = "";
    private String vernNoWithRev = "";
    private String soldUnits = "";
    private String unSoldUnits = "";
    private String totalUnits = "";
    private String vernStatus = "";

    public static PopulationExportDto from(PopulationMatView e) {
        PopulationExportDto dto = new PopulationExportDto();
        if (e == null) return dto;
        dto.issueNumber = nvl(e.getIssueNumber());
        dto.implId = nvl(e.getImplId());
        dto.fsaNumber = nvl(e.getFsaNumber());
        dto.globalFsa = nvlNum(e.getGlobalFsa());
        dto.populationId = nvl(e.getPopulationId());
        dto.populationType = nvl(e.getPopulationType());
        dto.potentialFsaName = nvl(e.getPotentialFsaName());
        dto.potentialFsaType = nvl(e.getPotentialFsaType());
        dto.issueTitle = nvl(e.getIssueTitle());
        dto.issueDescription = nvl(e.getIssueDescription());
        dto.issueOpenDate = nvlDate(e.getIssueOpenDate());
        dto.leadRegion = nvl(e.getLeadRegion());
        dto.impactedRegion = nvl(e.getImpactedRegion());
        dto.impactedMarket = nvl(e.getImpactedMarket());
        dto.impactedVehicleLine = nvl(e.getImpactedVehicleLine());
        dto.makeModelModelYear = nvl(e.getMakeModelModelYear());
        dto.fd9Status = nvl(e.getFd9Status());
        dto.fd9UpdatedDate = nvlDate(e.getFd9UpdatedDate());
        dto.fd9UpdatedBy = nvl(e.getFd9UpdatedBy());
        dto.fd10Status = nvl(e.getFd10Status());
        dto.fd10UpdatedDate = nvlDate(e.getFd10UpdatedDate());
        dto.fd10UpdatedBy = nvl(e.getFd10UpdatedBy());
        dto.trgInitMeetingDate = nvlDate(e.getTrgInitMeetingDate());
        dto.trgRecentMeetingDate = nvlDate(e.getTrgRecentMeetingDate());
        dto.trgRecentMeetingType = nvl(e.getTrgRecentMeetingType());
        dto.trgRecentMeetingUrgency = nvl(e.getTrgRecentMeetingUrgency());
        dto.trgRecentMeetingTitle = nvl(e.getTrgRecentMeetingTitle());
        dto.trgRecentCcrgTeam = nvl(e.getTrgRecentCcrgTeam());
        dto.trgRecentDuration = nvl(e.getTrgRecentDuration());
        dto.trgRecentCriticalParticipantSupp = nvl(e.getTrgRecentCriticalParticipantSupp());
        dto.trgRecentOtherParticipants = nvl(e.getTrgRecentOtherParticipants());
        dto.trgRecentScheduledStatus = nvl(e.getTrgRecentScheduledStatus());
        dto.trgMeetingDates = nvlDateList(e.getTrgMeetingDates());
        dto.trgCreationDate = nvlDate(e.getTrgCreationDate());
        dto.noOfDaysCcrgToTrg = nvlNum(e.getNoOfDaysCcrgToTrg());
        dto.noOfDaysCsfToTrg = nvlNum(e.getNoOfDaysCsfToTrg());
        dto.noOfDaysEprcToTrg = nvlNum(e.getNoOfDaysEprcToTrg());
        dto.noOfDays14DToTrg = nvlNum(e.getNoOfDays14DToTrg());
        dto.noOfDays14DToFrc = nvlNum(e.getNoOfDays14DToFrc());
        dto.noOfDaysTrgToFrc = nvlNum(e.getNoOfDaysTrgToFrc());
        dto.frcFactSheetTargetDate = nvlDate(e.getFrcFactSheetTargetDate());
        dto.frcFactSheetRecentDraftCompDate = nvlDate(e.getFrcFactSheetRecentDraftCompDate());
        dto.frcFactSheetRecentRevCompDate = nvlDate(e.getFrcFactSheetRecentRevCompDate());
        dto.frcInitMeetingDate = nvlDate(e.getFrcInitMeetingDate());
        dto.frcRecentMeetingDate = nvlDate(e.getFrcRecentMeetingDate());
        dto.frcMeetingDates = nvlDateList(e.getFrcMeetingDates());
        dto.frcRecentApprRegion = nvl(e.getFrcRecentApprRegion());
        dto.frcRecentDealBulletinTiming = nvl(e.getFrcRecentDealBulletinTiming());
        dto.frcRecentDraftTitle = nvl(e.getFrcRecentDraftTitle());
        dto.frcRecentApprovalSentToGCAMP = nvl(e.getFrcRecentApprovalSentToGCAMP());
        dto.frcMemoInitMeetingDate = nvlDate(e.getFrcMemoInitMeetingDate());
        dto.frcMemoRecentMeetingDate = nvlDate(e.getFrcMemoRecentMeetingDate());
        dto.frcMemoMeetingDates = nvlDateList(e.getFrcMemoMeetingDates());
        dto.trgRecentMeetingNotesDate = nvl(e.getTrgRecentMeetingNotesDate());
        dto.trgRecentMeetingNotesTitle = nvl(e.getTrgRecentMeetingNotesTitle());
        dto.trgRecentMeetingNotes = nvl(e.getTrgRecentMeetingNotes());
        dto.frcRecentMeetingNotesDate = nvl(e.getFrcRecentMeetingNotesDate());
        dto.frcRecentMeetingNotesTitle = nvl(e.getFrcRecentMeetingNotesTitle());
        dto.frcRecentMeetingNotes = nvl(e.getFrcRecentMeetingNotes());
        dto.vernNoWithRev = nvl(e.getVernNoWithRev());
        dto.soldUnits = nvlNum(e.getSoldUnits());
        dto.unSoldUnits = nvlNum(e.getUnSoldUnits());
        dto.totalUnits = nvlNum(e.getTotalUnits());
        dto.vernStatus = nvl(e.getVernStatus());
        return dto;
    }

    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private static String nvl(String s) { return s != null ? s : ""; }
    private static String nvlNum(Number n) { return n != null ? n.toString() : ""; }
    private static String nvlDate(Date d) {
        if (d == null) return "";
        return d.toInstant().atZone(ZoneId.systemDefault()).toLocalDate().format(DATE_FMT);
    }
    private static String nvlDateList(List<Date> l) {
        if (l == null || l.isEmpty()) return "";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < l.size(); i++) {
            if (i > 0) sb.append(", ");
            Date d = l.get(i);
            sb.append(d != null ? d.toInstant().atZone(ZoneId.systemDefault()).toLocalDate().format(DATE_FMT) : "");
        }
        return sb.toString();
    }
}
