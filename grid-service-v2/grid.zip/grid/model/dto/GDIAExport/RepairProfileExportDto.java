package com.ford.grid.model.dto.GDIAExport;

import com.ford.grid.model.entity.RepairProfileMatView;
import lombok.Data;

/**
 * Export DTO for view_by_repairProfile_mat.
 * All fields are String with "" default — ensures consistent JSON schema with no nulls.
 */
@Data
public class RepairProfileExportDto {

    private String issueNumber = "";
    private String issueTitle = "";
    private String implId = "";
    private String fsaNumber = "";
    private String globalFsa = "";
    private String populationId = "";
    private String populationType = "";
    private String potentialFsaType = "";
    private String potentialFsaName = "";
    private String affectedRegion = "";
    private String leadRegion = "";
    private String region = "";
    private String vernNumber = "";
    private String vernRevision = "";
    private String profileName = "";
    private String multiRepairs = "";
    private String labourHour = "";
    private String remedyExplanation = "";
    private String profileVehicleLine = "";
    private String profileMarket = "";
    private String impactedVehicleCount = "";
    private String soldUio = "";
    private String soldResponseRate = "";
    private String soldLaunchQuantity = "";
    private String unSoldUio = "";
    private String unSoldResponseRate = "";
    private String unSoldLaunchQuantity = "";
    private String relatedDamagedPart = "";
    private String oneTimePart = "";
    private String causalPart = "";
    private String partStatus = "";
    private String partType = "";
    private String partProfileId = "";
    private String qtyPerRepair = "";
    private String partReplaceRate = "";
    private String engineeringPartNumber = "";
    private String servicePartNumber = "";
    private String finisCode = "";
    private String partName = "";
    private String noPartsNeeded = "";
    private String profileWersValue1 = "";
    private String profileWersValue2 = "";
    private String profileWersValue3 = "";
    private String profileWersValue4 = "";
    private String profileWersValue5 = "";
    private String profileWersValue6 = "";
    private String profileWersValue7 = "";
    private String profileWersValue8 = "";
    private String profileWersValue9 = "";
    private String profileWersValue10 = "";
    private String profileWersAttribute1 = "";
    private String profileWersAttribute2 = "";
    private String profileWersAttribute3 = "";
    private String profileWersAttribute4 = "";
    private String profileWersAttribute5 = "";
    private String profileWersAttribute6 = "";
    private String profileWersAttribute7 = "";
    private String profileWersAttribute8 = "";
    private String profileWersAttribute9 = "";
    private String profileWersAttribute10 = "";

    public static RepairProfileExportDto from(RepairProfileMatView e) {
        RepairProfileExportDto dto = new RepairProfileExportDto();
        if (e == null) return dto;
        dto.issueNumber = nvl(e.getIssueNumber());
        dto.issueTitle = nvl(e.getIssueTitle());
        dto.implId = nvl(e.getImplId());
        dto.fsaNumber = nvl(e.getFsaNumber());
        dto.globalFsa = nvlNum(e.getGlobalFsa());
        dto.populationId = nvl(e.getPopulationId());
        dto.populationType = nvl(e.getPopulationType());
        dto.potentialFsaType = nvl(e.getPotentialFsaType());
        dto.potentialFsaName = nvl(e.getPotentialFsaName());
        dto.affectedRegion = nvl(e.getAffectedRegion());
        dto.leadRegion = nvl(e.getLeadRegion());
        dto.region = nvl(e.getRegion());
        dto.vernNumber = nvl(e.getVernNumber());
        dto.vernRevision = nvlNum(e.getVernRevision());
        dto.profileName = nvl(e.getProfileName());
        dto.multiRepairs = nvl(e.getMultiRepairs());
        dto.labourHour = nvlNum(e.getLabourHour());
        dto.remedyExplanation = nvl(e.getRemedyExplanation());
        dto.profileVehicleLine = nvl(e.getProfileVehicleLine());
        dto.profileMarket = nvl(e.getProfileMarket());
        dto.impactedVehicleCount = nvl(e.getImpactedVehicleCount());
        dto.soldUio = nvl(e.getSoldUio());
        dto.soldResponseRate = nvl(e.getSoldResponseRate());
        dto.soldLaunchQuantity = nvl(e.getSoldLaunchQuantity());
        dto.unSoldUio = nvl(e.getUnSoldUio());
        dto.unSoldResponseRate = nvl(e.getUnSoldResponseRate());
        dto.unSoldLaunchQuantity = nvl(e.getUnSoldLaunchQuantity());
        dto.relatedDamagedPart = nvl(e.getRelatedDamagedPart());
        dto.oneTimePart = nvl(e.getOneTimePart());
        dto.causalPart = nvl(e.getCausalPart());
        dto.partStatus = nvl(e.getPartStatus());
        dto.partType = nvl(e.getPartType());
        dto.partProfileId = nvl(e.getPartProfileId());
        dto.qtyPerRepair = nvl(e.getQtyPerRepair());
        dto.partReplaceRate = nvl(e.getPartReplaceRate());
        dto.engineeringPartNumber = nvl(e.getEngineeringPartNumber());
        dto.servicePartNumber = nvl(e.getServicePartNumber());
        dto.finisCode = nvl(e.getFinisCode());
        dto.partName = nvl(e.getPartName());
        dto.noPartsNeeded = nvl(e.getNoPartsNeeded());
        dto.profileWersValue1 = nvl(e.getProfileWersValue1());
        dto.profileWersValue2 = nvl(e.getProfileWersValue2());
        dto.profileWersValue3 = nvl(e.getProfileWersValue3());
        dto.profileWersValue4 = nvl(e.getProfileWersValue4());
        dto.profileWersValue5 = nvl(e.getProfileWersValue5());
        dto.profileWersValue6 = nvl(e.getProfileWersValue6());
        dto.profileWersValue7 = nvl(e.getProfileWersValue7());
        dto.profileWersValue8 = nvl(e.getProfileWersValue8());
        dto.profileWersValue9 = nvl(e.getProfileWersValue9());
        dto.profileWersValue10 = nvl(e.getProfileWersValue10());
        dto.profileWersAttribute1 = nvl(e.getProfileWersAttribute1());
        dto.profileWersAttribute2 = nvl(e.getProfileWersAttribute2());
        dto.profileWersAttribute3 = nvl(e.getProfileWersAttribute3());
        dto.profileWersAttribute4 = nvl(e.getProfileWersAttribute4());
        dto.profileWersAttribute5 = nvl(e.getProfileWersAttribute5());
        dto.profileWersAttribute6 = nvl(e.getProfileWersAttribute6());
        dto.profileWersAttribute7 = nvl(e.getProfileWersAttribute7());
        dto.profileWersAttribute8 = nvl(e.getProfileWersAttribute8());
        dto.profileWersAttribute9 = nvl(e.getProfileWersAttribute9());
        dto.profileWersAttribute10 = nvl(e.getProfileWersAttribute10());
        return dto;
    }

    private static String nvl(String s) { return s != null ? s : ""; }
    private static String nvlNum(Number n) { return n != null ? n.toString() : ""; }
}
