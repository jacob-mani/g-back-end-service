package com.ford.grid.model.dto.GDIAExport;

import com.ford.grid.model.entity.SwPartsMatView;
import lombok.Data;

import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

/**
 * Export DTO for view_by_swParts_mat.
 * All fields are String with "" default — ensures consistent JSON schema with no nulls.
 */
@Data
public class SwPartsExportDto {

    // ── Issue / Implementation identifiers ───────────────────────────────
    private String issueNumber = "";
    private String implId = "";
    private String populationId = "";
    private String populationType = "";
    private String fsaNumber = "";
    private String globalFsa = "";
    private String fsaType = "";
    private String isManualPopulation = "";

    // ── IED version details ───────────────────────────────────────────────
    private String iedVersionNumber = "";
    private String iedPublishedDate = "";
    private String iedPublishedBy = "";

    // ── Vehicle / Program ─────────────────────────────────────────────────
    private String modelYear = "";
    private String programCode = "";

    // ── Flags ─────────────────────────────────────────────────────────────
    private String vinExcludeFlag = "";
    private String softwareOnlyFlag = "";
    private String includeSoftwareFlag = "";
    private String configFlag = "";
    private String replacedInd = "";

    // ── Config / Parts ────────────────────────────────────────────────────
    private String configNodes = "";
    private String wersNoticeNo = "";
    private String engPartNo = "";
    private String engPartName = "";
    private String engPartNode = "";
    private String engPartDid = "";

    public static SwPartsExportDto from(SwPartsMatView e) {
        SwPartsExportDto dto = new SwPartsExportDto();
        if (e == null) return dto;

        dto.issueNumber = nvl(e.getIssueNumber());
        dto.implId = nvl(e.getImplId());
        dto.populationId = nvl(e.getPopulationId());
        dto.populationType = nvl(e.getPopulationType());
        dto.fsaNumber = nvl(e.getFsaNumber());
        dto.globalFsa = nvlNum(e.getGlobalFsa());
        dto.fsaType = nvl(e.getFsaType());
        dto.isManualPopulation = nvl(e.getIsManualPopulation());

        dto.iedVersionNumber = nvl(e.getIedVersionNumber());
        dto.iedPublishedDate = nvlDate(e.getIedPublishedDate());
        dto.iedPublishedBy = nvl(e.getIedPublishedBy());

        dto.modelYear = nvl(e.getModelYear());
        dto.programCode = nvl(e.getProgramCode());

        dto.vinExcludeFlag = nvl(e.getVinExcludeFlag());
        dto.softwareOnlyFlag = nvl(e.getSoftwareOnlyFlag());
        dto.includeSoftwareFlag = nvl(e.getIncludeSoftwareFlag());
        dto.configFlag = nvl(e.getConfigFlag());
        dto.replacedInd = nvl(e.getReplacedInd());

        dto.configNodes = nvlList(e.getConfigNodes());
        dto.wersNoticeNo = nvl(e.getWersNoticeNo());
        dto.engPartNo = nvl(e.getEngPartNo());
        dto.engPartName = nvl(e.getEngPartName());
        dto.engPartNode = nvl(e.getEngPartNode());
        dto.engPartDid = nvl(e.getEngPartDid());

        return dto;
    }

    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private static String nvl(String s) { return s != null ? s : ""; }
    private static String nvlNum(Number n) { return n != null ? n.toString() : ""; }
    private static String nvlDate(Date d) {
        if (d == null) return "";
        return d.toInstant().atZone(ZoneId.systemDefault()).toLocalDate().format(DATE_FMT);
    }
    private static String nvlList(List<String> list) {
        if (list == null || list.isEmpty()) return "";
        return String.join(", ", list);
    }
}



