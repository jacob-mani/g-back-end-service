package com.ford.grid.model.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class GetFactSheetAndPartListDTO {

    private String factSheetFileName;
    private String factSheetGCPName;
    @Builder.Default
    private String factSheetStatus = "Not_Available";
    private String partListFileName;
    private String partListGCPFilePath;
    private String partListSPPath;
    @Builder.Default
    private String partListStatus = "Not_Available";
    private List<GetFactSheetListDTO> factSheetList;
}
