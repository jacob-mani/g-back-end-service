package com.ford.grid.model.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class GetFactSheetListDTO {

    private String factSheetFileName;
    private String factSheetGCPName;
    private byte[] factSheetFile;
}

