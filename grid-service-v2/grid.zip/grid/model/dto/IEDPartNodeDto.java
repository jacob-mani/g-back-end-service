package com.ford.grid.model.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class IEDPartNodeDto {
    private String partNumber;
    private String partBase;
    private String ecuNodeId;
    private String partDid;

}
