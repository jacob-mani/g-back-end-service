package com.ford.grid.model.dto;

import lombok.Builder;
import lombok.Data;
import org.springframework.core.io.InputStreamSource;
import org.thymeleaf.context.Context;
import org.thymeleaf.util.ListUtils;

import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

@Data
@Builder
public class MailRequest {
    private String sender;
    private List<String> recipients;
    private List<String> cc;
    private List<String> bcc;
    private String subject;
    private Context context;
    private String notificationType;
    private String notificationName;
    private String mailTemplateName;
    private Map<String, InputStreamSource> attachments;
    private String htmlBody;

    // When true, this operational email bypasses the per-issue disableEmails mute and is always sent.
    private boolean forceSend;

    public List<String> getMail() {
        if (!ListUtils.isEmpty(getCc()))
            return Stream.of(getRecipients(), getCc()).flatMap(List::stream).distinct().toList();

        return getRecipients();
    }
}