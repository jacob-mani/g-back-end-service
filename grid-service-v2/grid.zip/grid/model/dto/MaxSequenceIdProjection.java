package com.ford.grid.model.dto;

import lombok.Data;

@Data
public class MaxSequenceIdProjection {
    private Integer maxSequenceId;
}
