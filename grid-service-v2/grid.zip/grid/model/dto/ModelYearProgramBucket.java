package com.ford.grid.model.dto;

import com.ford.grid.model.entity.IEDWersNoticeNumberPartNumber;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ModelYearProgramBucket {
    String modelYear;

    @NotNull
    @Pattern(regexp = "^[a-zA-Z0-9_]*$")
    @Schema(example = "CX483N", description = "Program Code")
    String programCode;

    List<IEDWersNoticeNumberPartNumber> wersNoticeNumberPartNumbers;

    boolean vinExclude;
    Boolean ota;
    List<String> configNodes;
}
