package com.ford.grid.model.dto;

import com.ford.grid.model.entity.AffectedRegion;
import com.ford.grid.model.entity.Contacts;
import lombok.Data;

import java.util.List;

/**
 * DTO for open issue data fetched directly from collections (no MongoDB view dependency).
 * Used by BuildAgendaDirectServiceImpl for open items section in PDF export.
 */
@Data
public class OpenIssueData {
    private String issueNumber;
    private String issueTitle;
    private String issueDescription;
    private String issuePhase;
    private String issueRelatedItems;
    private String leadRegion;
    private String segment;
    private String duration;
    private String agendaType;
    private String objective;
    private String monitorStatus;
    private String monitorComebackDate;
    private String potentialActionType;
    private boolean awaitingNHTSAResponse;
    private List<Contacts> keyParticipants;
    private List<AffectedRegion> affectedRegions;
}

