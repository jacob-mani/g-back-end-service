package com.ford.grid.model.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class AccessTokenFrcFactsheetRequest {
    private String grant_type;
    private String client_id;
    private String client_secret;
    private String resource;
}