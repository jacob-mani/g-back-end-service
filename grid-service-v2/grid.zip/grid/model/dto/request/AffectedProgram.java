package com.ford.grid.model.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AffectedProgram {

    private String plantName;
    private String vehicleProgram;
    private String variant;
    private String remarks;

}
