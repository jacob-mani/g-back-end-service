package com.ford.grid.model.dto.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * Data model representing a single row in the GRID Report Word document table.
 * Contains issue details including concern, dates, age, and status information.
 *
 * @author GRID Team
 * @version 2.0
 * @since 2026-03-27
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AgendaRowData {

    /**
     * The concern or issue description text.
     * Example: "N BIW - TestCCRG"
     */
    private String concern;

    /**
     * The unique issue number identifier.
     * Example: "26-109", "26-095"
     */
    private String issueNumber;

    /**
     * The date when the issue was opened, formatted for display.
     * Format: "Mar. 06, 2026"
     */
    private String dateOpen;

    /**
     * The age of the issue in days since it was opened.
     * Example: 21, 31, 35, 71
     */
    private int age;

    /**
     * The current phase of the issue.
     * Example: "14D(CCRG)", "FRC(CCRG)", "Investigation (CCRG)"
     */
    private String phase;

    /**
     * The FRC (Forum Review Committee) status or region-specific status.
     * Example: "Scheduled", "Pending", "Approved"
     */
    private String frcStatus;

    /**
     * The affected volume information with region and count.
     * Example: "SA_(242)", "IMG_(88349)", "EU_(1265)"
     */
    private String affectedVolume;

    /**
     * Key contact names associated with this issue.
     * Multiple contacts separated by line breaks or commas.
     * Example: "John Doe\nJane Smith" or "John Doe, Jane Smith"
     */
    private String keyContacts;

    /**
     * Scheduled meetings with dates.
     * Example: "› Prior CCRG on Mar 18 2026\n› Scheduled TRG on Mar 20 2026"
     */
    private String meetings;

    /**
     * Detailed meeting notes and discussions.
     * Example: "Discussed action items. Next steps approved."
     */
    private String meetingNotes;
}

