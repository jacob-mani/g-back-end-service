package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AgendaTopics {

    @Schema(example = "UH033")
    @JsonProperty("title")
    // @Size(min = 0, max = Integer.MAX_VALUE, message = "")
    // @Pattern(regexp = "^.{1,255}$", message = "")
    private String title;

    @Schema(example = "UH033")
    @JsonProperty("activity")
    // @Size(min = 0, max = Integer.MAX_VALUE, message = "")
    // @Pattern(regexp = "^.{1,255}$", message = "")
    private String activity;
}
