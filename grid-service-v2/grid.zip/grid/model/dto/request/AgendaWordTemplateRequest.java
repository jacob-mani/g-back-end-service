package com.ford.grid.model.dto.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Request model for generating GRID 2.0 Word document reports.
 * Contains all necessary data for creating an "Index of Contents" table
 * with customizable title, forum type, region, and row data.
 *
 * <p>Example Usage:</p>
 * <pre>
 * AgendaWordTemplateRequest request = AgendaWordTemplateRequest.builder()
 *     .reportTitle("GRID REPORT")
 *     .reportSubTitle("Large SUV, Truck and Commercial")
 *     .forumType("CCRG")
 *     .region("NA")
 *     .meetingDate("March 27, 2026")
 *     .rows(agendaRowDataList)
 *     .includeWatermark(true)
 *     .watermarkText("CONFIDENTIAL")
 *     .build();
 * </pre>
 *
 * @author GRID Team
 * @version 2.0
 * @since 2026-03-27
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AgendaWordTemplateRequest {

    /**
     * The main report title displayed at the top of the document.
     * Typically "GRID REPORT".
     * Font: 24pt, centered, dark gray.
     */
    private String reportTitle;

    /**
     * The report subtitle displayed below the main title in parentheses.
     * Example: "Large SUV, Truck and Commercial"
     * Font: 14pt, centered, dark gray.
     */
    private String reportSubTitle;

    /**
     * The forum type for the report.
     * Values: "CCRG", "CSF", "EPRC", "GOVERNMENT"
     * Used in table title: "Index of Contents - {forumType}"
     */
    private String forumType;

    /**
     * The lead region for the report.
     * Example: "NA", "EU", "SA", "IMG"
     */
    private String region;

    /**
     * The meeting date for the report.
     * Example: "March 27, 2026"
     */
    private String meetingDate;

    /**
     * List of data rows to be rendered in the document table.
     * Each row represents an issue with concern, dates, age, and status.
     */
    private List<AgendaRowData> rows;

    /**
     * Flag indicating whether to include a watermark on the document.
     * Default: false
     */
    private boolean includeWatermark;

    /**
     * The text to display as a watermark if includeWatermark is true.
     * Example: "CONFIDENTIAL", "DRAFT"
     */
    private String watermarkText;
}

