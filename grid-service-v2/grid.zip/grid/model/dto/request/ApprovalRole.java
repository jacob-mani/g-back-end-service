package com.ford.grid.model.dto.request;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public enum ApprovalRole {
    LEAD_INVESTIGATOR("ASO Lead Investigator"),
    INVESTIGATION_MANAGER("ASO Investigation Manager"),
    CCRG_CHAIR("CCRG Chair"),
    CCRG_ATTORNEY("CCRG Attorney"),
    ASSISTANT_DIRECTOR("ASO Assistant Director"),
    REVIEW_COMPLETED("Review Completed");

    private final String title;

    ApprovalRole(String title) {
        this.title = title;
    }

    public String getTitle() { return title; }

    /**
     * Check if this role is a mid-chain approver (positions 2, 3, 4, 5)
     * These can be used in any combination (1, 2, 3, or all 4)
     */
    public boolean isMidChainApprover() {
        return this == INVESTIGATION_MANAGER ||
               this == CCRG_CHAIR ||
               this == CCRG_ATTORNEY ||
               this == ASSISTANT_DIRECTOR;
    }

    /**
     * Check if this is the draft reviewer (position 1)
     */
    public boolean isDraftReviewer() {
        return this == LEAD_INVESTIGATOR;
    }

    /**
     * Check if this is the final reviewer (position 6)
     */
    public boolean isFinalReviewer() {
        return this == REVIEW_COMPLETED;
    }

    /**
     * Get all mid-chain approver roles
     * These can be combined in any way (1, 2, 3, or all 4 approvers)
     */
    public static List<ApprovalRole> getMidChainApprovers() {
        return Arrays.asList(
            INVESTIGATION_MANAGER,
            CCRG_CHAIR,
            CCRG_ATTORNEY,
            ASSISTANT_DIRECTOR
        );
    }

    /**
     * Get all mid-chain approver titles
     */
    public static List<String> getMidChainApproverTitles() {
        return getMidChainApprovers().stream()
                .map(ApprovalRole::getTitle)
                .collect(Collectors.toList());
    }

    /**
     * Find role by title
     */
    public static ApprovalRole fromTitle(String title) {
        for (ApprovalRole role : values()) {
            if (role.title.equals(title)) {
                return role;
            }
        }
        return null;
    }

    /**
     * Check if a title belongs to a mid-chain approver
     */
    public static boolean isMidChainApproverTitle(String title) {
        ApprovalRole role = fromTitle(title);
        return role != null && role.isMidChainApprover();
    }
}
