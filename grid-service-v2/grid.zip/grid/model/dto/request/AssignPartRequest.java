package com.ford.grid.model.dto.request;

import com.ford.grid.model.entity.Audit;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

@EqualsAndHashCode(callSuper = false)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AssignPartRequest extends Audit {
    private String id;
    @NotBlank
    private String issueNumber;
    @NotBlank
    private String implId;
    @NotBlank
    private String populationId;
    @NotEmpty
    private List<String> profiles;
    private boolean noPartsNeeded;
    private String engineeringPartNumber;
    private String servicePartNumber;
    private String finisCode;
    private String partName;
    private boolean relatedDamagedPart;
    private boolean causalPart;
    private boolean oneTimePart;
    private BigDecimal partReplaceRate = BigDecimal.valueOf(100);
    private BigDecimal qtyPerRepair = BigDecimal.ONE;
    private String partStatus;
    private String partType;

    // Part description — conditionally mandatory (only when noPartsNeeded=false, validated in service layer
    // alongside engineeringPartNumber/servicePartNumber/partName which follow the same pattern)
    private String partDesc;

    private String partDecision;
}
