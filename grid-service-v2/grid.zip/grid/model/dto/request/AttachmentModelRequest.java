package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.Audit;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
public class AttachmentModelRequest  extends Audit {
    @Schema(example = "UH033")
    @JsonProperty("name")
    private String name;
    @Schema(example = "UH033")
    @JsonProperty("desc")
    private String desc;
    @Schema(example = "UH033")
    @JsonProperty("url")
    private String url;
}

