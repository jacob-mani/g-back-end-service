package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.*;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.LocalDate;
import java.util.List;

@Data
@EqualsAndHashCode(callSuper = false)
public class BaseVehicleCriteriaRequest extends Audit {
    @Schema(maxLength = 100, pattern = "^[a-zA-Z0-9_\\-]+$", example = "BVC-001")
    private String id;

    @JsonProperty("modelYear")
    @NotBlank(message = "Model Year must not be null or blank")
    @ArraySchema(maxItems = 50, schema = @Schema(type = "integer", minimum = "1900", maximum = "2100", example = "2024"))
    private List<Integer> modelYear;

    @JsonProperty("brand")
    @NotBlank(message = "Brand title must not be null or blank")
    @Schema(maxLength = 100, pattern = "^[a-zA-Z0-9_\\-\\s]+$", example = "Ford")
    private String brand;

    @JsonProperty("vehicleLine")
    @NotBlank(message = "VehicleLine must not be null or blank")
    @Schema(maxLength = 100, pattern = "^[a-zA-Z0-9_\\-\\s]+$", example = "Explorer")
    private String vehicleLine;

    @JsonProperty("vehicleLineOther")
    @Schema(maxLength = 200, pattern = "^[a-zA-Z0-9_\\-\\s]*$", example = "Other vehicle line")
    private String vehicleLineOther;

    @JsonProperty("plant")
    @ArraySchema(maxItems = 50, schema = @Schema(type = "string", maxLength = 100, pattern = "^[a-zA-Z0-9_\\-\\s]+$", example = "DEARBORN"))
    private List<String> plant;

    @JsonProperty("productionDateFrom")
    private LocalDate productionDateFrom;

    @JsonProperty("productionDateTo")
    private LocalDate productionDateTo;

    @JsonProperty("wers")
    @ArraySchema(maxItems = 100)
    private List<Wers> wers;

    @JsonProperty("vehicleCodes")
    @ArraySchema(maxItems = 100)
    private List<VehicleCode> vehicleCodes;

    @JsonProperty("marketRegions")
    private MarketRegion marketRegions;

    @JsonProperty("software")
    @ArraySchema(maxItems = 100)
    private List<SoftwareCriteria> software;

    @JsonProperty("issueNumber")
    @Schema(maxLength = 50, pattern = "^[a-zA-Z0-9_\\-]*$", example = "ISS-2024-001")
    private String issueNumber;
}
