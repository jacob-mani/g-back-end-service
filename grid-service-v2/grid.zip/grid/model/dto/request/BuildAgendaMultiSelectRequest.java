package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class BuildAgendaMultiSelectRequest {

    @Schema(example = "[\"ccrg\", \"csf\", \"eprc\"]", description = "List of agenda types to fetch. Only ccrg, csf, eprc are allowed together.")
    @JsonProperty("agendaType")
    @NotEmpty(message = "agendaType must not be empty")
    private List<@NotBlank(message = "agendaType entries must not be blank or null") String> agendaType;

    @Schema(example = "2026-03-18", description = "Meeting date in yyyy-MM-dd format")
    @JsonProperty("meetingDate")
    @NotNull(message = "meetingDate must not be null")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    @JsonDeserialize(using = LocalDateDeserializer.class)
    private LocalDate meetingDate;

    @Schema(example = "NA", description = "Lead region (e.g. NA, EU, AP). Not required for global types (gccrg, gcsf, geprc).")
    @JsonProperty("leadRegion")
    private String leadRegion;

    @Schema(example = "0", description = "Page number (0-based)", defaultValue = "0")
    @JsonProperty("page")
    private int page = 0;

    @Schema(example = "10", description = "Page size", defaultValue = "10")
    @JsonProperty("size")
    private int size = 10;

    @Schema(example = "issueNumber", description = "Field to sort by", defaultValue = "issueNumber")
    @JsonProperty("sortBy")
    private String sortBy = "issueNumber";

    @Schema(example = "DESC", description = "Sort direction: ASC or DESC", defaultValue = "DESC")
    @JsonProperty("direction")
    private String direction = "DESC";
}
