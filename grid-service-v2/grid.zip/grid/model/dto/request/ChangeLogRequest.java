package com.ford.grid.model.dto.request;

import com.ford.grid.constants.CardLocation;
import com.ford.grid.constants.UserAction;
import com.ford.grid.model.entity.changelog.ChangeInformation;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class ChangeLogRequest {
    @NotBlank
    private String issueNumber;
    @NotNull
    private CardLocation cardLocation;
    private String description;
    private UserAction action;
    private List<ChangeInformation> changes;
    private String userCdsId;
}