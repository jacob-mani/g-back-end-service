package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Data
@NoArgsConstructor
public class ClearNotificationsByDateRequest {
    @JsonFormat(pattern = "yyyy-MM-dd")
    @NotNull(message = "targetDate is required")
    private LocalDate targetDate;
    private List<String> categories;
    private String dateField;
    private Boolean allUsers;

    public ClearNotificationsByDateRequest(LocalDate targetDate, List<String> categories, String dateField) {
        this(targetDate, categories, dateField, Boolean.FALSE);
    }

    public ClearNotificationsByDateRequest(LocalDate targetDate,
                                           List<String> categories,
                                           String dateField,
                                           Boolean allUsers) {
        this.targetDate = targetDate;
        this.categories = categories;
        this.dateField = dateField;
        this.allUsers = allUsers;
    }
}

