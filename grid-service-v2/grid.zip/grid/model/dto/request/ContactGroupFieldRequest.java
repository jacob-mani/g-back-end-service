package com.ford.grid.model.dto.request;

import lombok.Data;

@Data
public class ContactGroupFieldRequest {
    private String groupId;
    private String label;
}
