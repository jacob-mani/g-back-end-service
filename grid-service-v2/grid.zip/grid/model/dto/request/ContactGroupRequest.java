package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.Audit;
import com.ford.grid.model.entity.FieldIds;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

@Data
@EqualsAndHashCode(callSuper = false)
public class ContactGroupRequest extends Audit {
    @Schema(example = "UH033")
    private String id;
    @Schema(example = "UH033")
    @JsonProperty("groupId")
    @NotBlank(message = "ContactGroup Id must not be null or blank")
    private String groupId;

    @Schema(example = "UH033")
    @JsonProperty("groupName")
    @NotBlank(message = "ContactGroup Name must not be null or blank")
    private String groupName;

    @Schema(example = "UH033")
    @JsonProperty("fieldIds")
    @NotBlank(message = "Field Ids must not be null or blank")
    private List<FieldIds> fieldIds;
}
