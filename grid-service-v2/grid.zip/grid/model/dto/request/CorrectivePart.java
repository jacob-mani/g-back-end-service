package com.ford.grid.model.dto.request;

import com.ford.grid.model.entity.PartMaster;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.DBRef;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CorrectivePart {

    @DBRef
    private PartMaster part;

    private String engineeringPartNumber;
    private String servicePartNumber;
    private String finisCode;

    // Not in PartMaster — persisted directly
    private String wersAlertNumber;
    private String wersConcernNumber;

    private LocalDate correctiveDate;

    public String getEngineeringPartNumber() {
        return part != null ? part.getEngineeringPartNumber() : engineeringPartNumber;
    }

    public String getServicePartNumber() {
        return part != null ? part.getServicePartNumber() : servicePartNumber;
    }

    public String getFinisCode() {
        return part != null ? part.getFinisCode() : finisCode;
    }
}
