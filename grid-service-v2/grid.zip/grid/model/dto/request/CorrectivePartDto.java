package com.ford.grid.model.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CorrectivePartDto {
    @NotBlank(message = "Engineering Part Number must not be null or blank")
    private String engineeringPartNumber;
    private String servicePartNumber;
    private String finisCode;
    private String wersAlertNumber;
    private String wersConcernNumber;
    private LocalDate correctiveDate;
}

