package com.ford.grid.model.dto.request;

import lombok.Data;

import java.time.LocalDate;

/**
 * Request DTO for country-level part detail editable fields.
 * Only contains fields that UI should send.
 * partOkUpdatedBy and partOkUpdatedDate are auto-set by backend.
 */
@Data
public class CountryPartDetailRequest {

    private String name;
    private boolean partOk;
    private String partComment;
    private LocalDate etaActualDate;
    private String etaTargetQuarter;
}

