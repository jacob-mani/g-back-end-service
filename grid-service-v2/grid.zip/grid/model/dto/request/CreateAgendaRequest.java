package com.ford.grid.model.dto.request;


import com.ford.grid.model.entity.AffectedRegion;
import com.ford.grid.model.entity.Audit;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CreateAgendaRequest extends Audit {

    private String id;
    private List<String> agendaType;
    private LocalDate meetingDate;
    private String leadRegion;
    private String meetingStartTime;
    private String meetingEndTime;
    private String segment;
    private String toggleButton;
    private List<IssueList> issues;
    private List<AgendaTopics> topics;
    //global agenda types
    private List<AffectedRegion> affectedRegions;
    //frc
    private String compileAgenda;
    private boolean includeFactSheet;
    private boolean includeDraftStatus;
    private String nextFrcDate;
    private String timezoneValues;


}

