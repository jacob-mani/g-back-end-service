package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.Audit;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class CreateImplementationRequest extends Audit {

    @Schema(example = "25-001")
    @JsonProperty("issueNumber")
    @NotBlank(message = "Issue number must not be null or blank")
    private String issueNumber;

    @Schema(example = "25-001-1")
    @JsonProperty("implId")
    private String implId;

    @Schema(example = "UH033")
    @JsonProperty("potentialFsaName")
    @NotBlank(message = "Potential FSA Name must not be null or blank")
    private String potentialFsaName;

    @Schema(example = "UH033")
    @JsonProperty("potentialIssueType")
    private String potentialIssueType;

    @Schema(example = "true")
    @JsonProperty("otaIndicator")
    @NotNull(message = "otaIndicator must not be null")
    private Boolean otaIndicator;

    @Schema(example = "true")
    @JsonProperty("isSupplement")
    @NotNull(message = "isSupplement must not be null")
    private Boolean isSupplement;
}
