package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.Audit;
import com.ford.grid.model.entity.SelectedFilter;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CustomViewRequest extends Audit {

    @Schema(example = "507f1f77bcf86cd799439011")
    private String id;

    @Schema(example = "tjamalmo")
    private String cdsId;

    @Schema(example = "My FSA View")
    private String customViewName;

    @Schema(example = "fsa")
    private String viewType; // issue | fsa

    @Schema(example = "true")
    private boolean myIssues;

    @JsonProperty("activeFilters")
    private List<SelectedFilter> activeFilters;

    @JsonProperty("activeColumns")
    @Schema(example = "fsaNo")
    private List<String> activeColumns;

    @JsonProperty("activeContactColumn")
    private List<String> activeContactColumn;

    @JsonProperty("orderColumn")
    private List<String> orderColumn;
}