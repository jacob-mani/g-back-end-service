package com.ford.grid.model.dto.request;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import lombok.Data;


@XmlAccessorType(XmlAccessType.FIELD)
@Data
public class DataArea {

    @XmlElement(name = "WersResponse")
    private WersNoticeJobResponse wersNoticeJobResponse;

}