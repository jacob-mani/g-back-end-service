package com.ford.grid.model.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DataReadlinessRequest {

    private String issueNumber;
    private String implId;
    private String populationId;
    private String region;
}

