package com.ford.grid.model.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class DefectReportRecommendations {
    private String question;
    private String content;
    private String yesorNoDefault;
    private String completedDate;
    //Q8
    private String driveabilityAffected;
    private String milIllumination;
    private String soundOrVisual;
    private String otherReasons;
    //Q10
    private String selectOption;
}

