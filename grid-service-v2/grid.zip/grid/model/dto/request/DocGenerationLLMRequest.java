package com.ford.grid.model.dto.request;

import com.ford.grid.model.dto.GetFactSheetListDTO;
import com.ford.grid.model.dto.response.JiraPartsBomResponse;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DocGenerationLLMRequest {

    private String issueNumber;
    private String implId;
    private String populationId;
    private String fsaNumber;
    private String brandName;
    private String market;
    private String region;
    private String potentialType;
    private String notificationType;
    private String templateFileName;
    private byte[] templates;
    private String factSheetFileName;
    private byte[] factSheetDocument;
    private String part573FileName;
    private byte[] part573Document;
    private String json14DData;
    private Map<String,String> nhtsaAgency;
    private JiraPartsBomResponse jiraPartsBom;
    private List<GetFactSheetListDTO> factSheetList;
    private String communicationGoal;
}

