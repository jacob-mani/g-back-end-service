package com.ford.grid.model.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class DocTemplateRequest {
    private String region;
    private String market;
    private List<String> brandName;
    private String communicationGoal;
    private String templatePair;
    private String potentialType;
    private String fsaNumber;
    private String issueNumber;
    private String implId;
    private String populationId;
}

