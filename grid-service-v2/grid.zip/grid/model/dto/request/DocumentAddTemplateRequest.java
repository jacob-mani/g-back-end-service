package com.ford.grid.model.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.Date;

/**
 * Represents the details of a single document template entry,
 * matching the structure stored in the document_templates collection.
 *
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Single template metadata entry for ARC collaboration template upload", additionalProperties = Schema.AdditionalPropertiesValue.FALSE)
public class DocumentAddTemplateRequest {

    @Schema(maxLength = 150, pattern = "^[a-zA-Z0-9_\\-\\s]+$", example = "Advanced Notice")
    private String communicationGoal;

    @Schema(maxLength = 150, pattern = "^[a-zA-Z0-9_\\-\\s]+$", example = "Advanced Notice")
    private String notificationType;

    @Schema(example = "1", minimum = "1", maximum = "999")
    private Integer pair;

    @Schema(maxLength = 255, pattern = "^[^<>\\\"|?*]+$", example = "26S18_Safety_NA_USA_Ford_Advance_Notice_v1.docx")
    private String fileName;

    @Schema(maxLength = 2000, pattern = "^[^<>\\\"|?*]+$", example = "ARC/ComplianceRecalls/NorthAmerica/UnitedStates/Ford/Dealer_Bulletin/26S18_Safety_NA_USA_Ford_Advance_Notice_v1.docx")
    private String filePath;

    @Schema(maxLength = 2048, pattern = "^https://[\\w.-]+(?:/[\\w\\-./%]*)?$", example = "https://storage.googleapis.com/grid-dev-docs/ARC/test/ComplianceRecalls/NorthAmerica/UnitedStates/Ford/Dealer_Bulletin/26S18_Safety_NA_USA_Ford_Advance_Notice_v1.docx")
    private String signedURL;

    @Schema(maxLength = 255, pattern = "^[^<>\\\"|?*]+$", example = "26S18_Safety_NA_USA_Ford_Advance_Notice.docx")
    private String displayName;

    @Schema(maxLength = 20, example = "v1.2", pattern = "^v[0-9]+\\.[0-9]+$")
    private String version;

    @Schema(example = "2026-08-21T07:56:02.785+00:00")
    private Date updatedAt;

    @Schema(example = "2026-08-21T07:56:02.785+00:00")
    private Date createdAt;

    @Schema(maxLength = 20, pattern = "^[a-zA-Z0-9]*$", example = "BD21")
    private String updatedBy;

    @Schema(maxLength = 20, pattern = "^[a-zA-Z0-9]*$", example = "BD21")
    private String createdBy;

    @Schema(example = "ACTIVE", allowableValues = {"ACTIVE", "INACTIVE"})
    private String status;
}

