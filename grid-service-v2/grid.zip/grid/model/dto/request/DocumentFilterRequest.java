package com.ford.grid.model.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DocumentFilterRequest {

    @NotNull(message = "Issue number is required")
    private String issueNumber;

    private List<String> locations; // Filter by locations (optional)

    private String docLevel; // ISSUE, FD, FORUM, IMPL, LAUNCH (optional)

    @Min(value = 0, message = "Page number must be >= 0")
    private int page = 0;

    @Min(value = 1, message = "Page size must be >= 1")
    @Max(value = 100, message = "Page size must be <= 100")
    private int size = 20;

    private String sortBy = "uploadedTime"; // Default sort field

    private String sortDirection = "DESC"; // ASC or DESC
}
