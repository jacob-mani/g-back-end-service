package com.ford.grid.model.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.web.multipart.MultipartFile;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DraftDocumentRequest {

    @NotBlank(message = "issueNumber is required")
    private String issueNumber;
    private String implId;
    private String populationId;
    @NotBlank(message = "fsaNumber is required")
    private String fsaNumber;
    private String brand;
    private String region;
    private String market;
    private String fileName;
    private String notificationType;
    private Integer responseStatus;
    private String errorMessage;
    private MultipartFile file;
    private String communicationGoal;
}
