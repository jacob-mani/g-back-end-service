package com.ford.grid.model.dto.request;

import com.ford.grid.model.entity.Audit;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;
@Data
@EqualsAndHashCode(callSuper = false)
public class EPRCDefectReportRequest extends Audit {
    @Schema(example = "UH033")
    private String issueNumber;
    @Schema(example = "UH033")
    private List<EPRCPartRegulation> part85;
    @Schema(example = "UH033")
    private List<EPRCPartRegulation> part1068;
}
