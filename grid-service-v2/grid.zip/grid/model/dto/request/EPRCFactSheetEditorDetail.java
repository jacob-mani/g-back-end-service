package com.ford.grid.model.dto.request;

import com.ford.grid.model.entity.Attachment;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EPRCFactSheetEditorDetail {
    private String question;
    private String content;
    private List<Attachment> attachments;
    private String lastUpdatedBy;
    private LocalDateTime lastUpdatedAt;
}
