package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.Audit;
import com.ford.grid.model.entity.EPRCFactSheetApprovedContact;
import com.ford.grid.model.entity.EprcFactSheetSubmissionStatus;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class EPRCFactSheetRequest extends Audit {

    @Schema(example = "UH033")
    @JsonProperty("issueNumber")
    @NotNull(message = "Issue number must not be null or blank")
    private String issueNumber;

    @Schema(example = "UH033")
    @JsonProperty("region")
    private String region;

    @Schema(example = "UH033")
    @JsonProperty("factSheetSections")
    private List<EPRCFactSheetSection> factSheetSections;

    @Schema(example = "UH033")
    @JsonProperty("eprcfactsheetstatus")
    @NotBlank(message = "EPRC Factsheet status must not be null or blank")
    private String eprcfactsheetstatus;

    @Schema(example = "UH033")
    @JsonProperty("leadSignOff")
    private EPRCFactSheetSignOff leadSignOff;

    @Schema(example = "UH033")
    @JsonProperty("supportSignOffs")
    private List<EPRCFactSheetSignOff> supportSignOffs;

    @Schema(example = "UH033")
    @JsonProperty("eprcFactSheetApprovedContacts")
    private List<EPRCFactSheetApprovedContact> eprcFactSheetApprovedContacts;

    @Schema(example = "UH033")
    @JsonProperty("factSheetStatus")
    private List<EprcFactSheetSubmissionStatus> factSheetStatus;

    @Schema(example = "UH033")
    @JsonProperty("submittedInfoSent")
    private boolean submittedInfoSent;

    @Schema(example = "UH033")
    @JsonProperty("regionBasedMailCdsId")
    private String regionBasedMailCdsId;
}

