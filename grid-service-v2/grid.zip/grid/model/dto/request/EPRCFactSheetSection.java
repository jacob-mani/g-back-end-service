package com.ford.grid.model.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EPRCFactSheetSection {
    private EPRCFactSheetSectionOne factSheetSectionsOne;
    private EPRCFactSheetSectionTwo factSheetSectionsTwo;
}
