package com.ford.grid.model.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EPRCFactSheetSectionOne {

    private String title;
    private String titleHighlighted;
    private String subTitle;
    private EPRCFactSheetEditorDetail concernDescription;
    private EPRCFactSheetEditorDetail vehiclesAffected;
    private EPRCFactSheetEditorDetail causesOfConcernAndRootCause;
    private EPRCFactSheetEditorDetail marketsAffected;
    private EPRCFactSheetEditorDetail unitsShippedByVehicleLine;
    private EPRCFactSheetEditorDetail unitsConcernByVehicleLine;
    private EPRCFactSheetEditorDetail correctiveActionsInProduction;
    private EPRCFactSheetEditorDetail correctiveActionsInService;
    private EPRCFactSheetEditorDetail preventProblemRecurrence;
}
