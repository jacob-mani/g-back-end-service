package com.ford.grid.model.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EPRCFactSheetSectionTwo {
    private String title;
    private String titleHighlighted;
    private String subTitle;
    private EPRCFactSheetEditorDetail emissionConcern;
    private EPRCFactSheetEditorDetail greenhouseGasEmissions;
    private EPRCFactSheetEditorDetail onBoardDiagnosticSystemCompliance;
    private EPRCFactSheetEditorDetail vehicleEnvComplianceRequirements;
    private EPRCFactSheetEditorDetail driverAwareness;
    private EPRCFactSheetEditorDetail emissionsRelatedComponentDurability;
}
