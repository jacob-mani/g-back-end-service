package com.ford.grid.model.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EPRCFactSheetSignOffUserDetail {

    private String name;
    private String cdsid;
    private String activity;
    private String sign;
    private LocalDate date;


}
