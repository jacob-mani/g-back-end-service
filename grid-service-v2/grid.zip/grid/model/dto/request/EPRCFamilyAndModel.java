package com.ford.grid.model.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EPRCFamilyAndModel {
    @Schema(example = "UH033")
    @NotBlank(message = "familyName must not be null or blank")
    private String familyName;
    @NotBlank(message = "Model Year must not be null or blank")
    private String modelYear;
    @Schema(example = "UH033")
    @NotBlank(message = "salesArea must not be null or blank")
    private String salesArea;
    private Date defectStartDate;
    private Date defectEndDate;
    private int totalProductionVolume;
    @Schema(example = "UH033")
    @NotBlank(message = "potentialNumberAffected must not be null or blank")
    private String potentialNumberAffected;
    @Schema(example = "UH033")
    @NotBlank(message = "actualNumberIdentified must not be null or blank")
    private String actualNumberIdentified;

}
