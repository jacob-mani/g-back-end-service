package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class EPRCPartRegulation {

    @Schema(example = "UH033")
    @NotBlank(message = "applicationRegulation must not be null or blank")
    private String applicationRegulation;
    @Schema(example = "UH033")
    @NotBlank(message = "industry must not be null or blank")
    private String industry;
    @Schema(example = "UH033")
    @NotBlank(message = "defectCategory must not be null or blank")
    private String defectCategory;
    @Schema(example = "UH033")
    @NotBlank(message = "manufacturerReportName must not be null or blank")
    private String manufacturerReportName;
    @Schema(example = "UH033")
    private String manufacturerReportIdentifier;
    @Schema(example = "UH033")
    private String edir;
    @Schema(example = "UH033")
    private String epaDefectReport;
    @Schema(example = "UH033")
    private Date vhAndCDirectorDelegate;
    @Schema(example = "UH033")
    private Date vhAndCDirectorDelegateApproval;
    @Schema(example = "UH033")
    private Date defectReportCirculationApproval;
    @Schema(example = "UH033")
    private String dueDateToEpa;
    @Schema(example = "UH033")
    private Date actualSubmissionToEpa;
    @Schema(example = "UH033")
    @NotBlank(message = "defectDescription must not be null or blank")
    private String defectDescription;
    @Schema(example = "UH033")
    @NotBlank(message = "emissionsImpact must not be null or blank")
    private String emissionsImpact;
    @Schema(example = "UH033")
    @NotBlank(message = "planForAddressing must not be null or blank")
    private String planForAddressing;
    @Schema(example = "UH033")
    @NotBlank(message = "drivabilityProblems must not be null or blank")
    private String drivabilityProblems;
    @NotNull(message = "emissionDataAvailable must not be null or blank")
    private boolean emissionDataAvailable;
    private boolean defectCause;
    @Schema(example = "UH033")
    @NotNull(message = "defectIdentificationSource must not be null or blank")
    private List<String> defectIdentificationSource;
    @Schema(example = "UH033")
    @NotNull(message = "plants must not be null or blank")
    private List<String> plants;
    @Schema(example = "UH033")
    private String comments;
    @Schema(example = "UH033")
    private String basePartNumber;
    @Schema(example = "UH033")
    private Date asoApprovalDate;
    @Schema(example = "UH033")
    private Date ogcApprovalDate;
    @Schema(example = "UH033")
    private Date pdApprovalDate;
    @Schema(example = "UH033")
    private String asoStatus;
    @Schema(example = "UH033")
    private String ogcStatus;
    @Schema(example = "UH033")
    private String pdStatus;
    private List<EPRCFamilyAndModel> familyAndModels;


}
