package com.ford.grid.model.dto.request;

import com.ford.grid.model.entity.Attachment;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Data
public class EmmAgenda {

    private int sequenceId;
    private String agendaId;
    private String emmTrType;
    private String emmType;
    private String leadRegion;
    private String grid;
    private String ccrgChair;
    private String ccrgChairCdsid;
    private String cce;
    private String cceCdsid;
    private String requiredSupportCdsid;
    private String meetingTitle;
    private String objectiveDesiredOutcome;
    private String requiredSupport;
    private String emmCcDistribution;
    private LocalDateTime earliestDate;
    private LocalDateTime latestDate;
    private Integer lengthMinutes;
    private String notes;
    private String regParticipation;
    private String imgParticipation;
    private List<LocalDate> meetingDates;
    private LocalDate emmScheduledDate;
    private String emmStatus;
    private Boolean followUp;
    private LocalDate followUpDate;
    private List<Attachment> attachments;

    // Agenda-level audit fields
    private String createdBy;
    private LocalDateTime createdAt;
    private String updatedBy;
    private LocalDateTime updatedAt;

    // Resolved display names (populated by GET API via LDAP lookup)
    private String createdByName;
    private String updatedByName;
}

