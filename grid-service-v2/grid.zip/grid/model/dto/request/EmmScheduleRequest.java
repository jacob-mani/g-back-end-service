package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.Audit;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

@Data
@EqualsAndHashCode(callSuper = false)
public class EmmScheduleRequest extends Audit {

    @Schema(example = "SCH12345")
    private String id;

    @Schema(example = "ISSUE-2024-001")
    @JsonProperty("issueNumber")
    private String issueNumber;

    @JsonProperty("emmSchedule")
    private List<EmmAgenda> emmSchedule;

    @Schema(example = "[\"file1.pdf\", \"file2.docx\"]")
    @JsonProperty("deletedAttachments")
    private List<String> deletedAttachments;
}
