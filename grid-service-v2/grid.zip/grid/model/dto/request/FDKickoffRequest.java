package com.ford.grid.model.dto.request;

import com.ford.grid.model.entity.Attachment;
import com.ford.grid.model.entity.Audit;
import com.ford.grid.model.entity.Contacts;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.LocalDate;
import java.util.List;

@Data
@EqualsAndHashCode(callSuper = false)
public class FDKickoffRequest extends Audit {

    private String id;
    private String issueNumber;
    private LocalDate fdKickOffDate;
    private List<LocalDate> meetingDate;
    private String xnumber;
    private String forumType;
    private List<Integer> causalTypes;
    private String causalTypeOther;
    private List<Integer> function;
    private String functionOther;
    private List<Contacts> contacts;
    private String region;
    private Boolean isSupportNeed;
    private List<Attachment> attachments;
    private List<String> deletedAttachments;

}
