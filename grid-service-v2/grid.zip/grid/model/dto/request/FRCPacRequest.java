package com.ford.grid.model.dto.request;


import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.Attachment;
import com.ford.grid.model.entity.Audit;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class FRCPacRequest extends Audit {
    @Schema(example = "UH033")
    private String id;
    @Schema(example = "25-001")
    private String issueNumber;
    @Schema(example = "UH033")
    private String implId;
    @Schema(example = "UH033")
    private String populationId;
    @Schema(example = "UH033")
    private List<Attachment> attachments;
    @Schema(example = "[\"file1.pdf\", \"file2.docx\"]")
    @JsonProperty("deletedAttachments")
    private List<String> deletedAttachments;
}