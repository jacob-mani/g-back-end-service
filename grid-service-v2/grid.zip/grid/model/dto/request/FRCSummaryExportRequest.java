package com.ford.grid.model.dto.request;

import com.ford.grid.model.entity.FRCSummaryResponse;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FRCSummaryExportRequest {

	private String createdBy;
	private String region;
	private String frcDate;
	private String fromDate;
	private String toDate;
	private List<FRCSummaryResponse> frcSummaryBOs;
	private Map<String,Boolean> exportColumns;
}