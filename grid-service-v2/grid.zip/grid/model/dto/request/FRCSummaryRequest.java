package com.ford.grid.model.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FRCSummaryRequest {
    private String frcDate;
    private String leadRegion;
    private String fromDate;
    private String toDate;
    private String affectedRegion;
    private String memoFilterFlag;
    private String programType;
}
