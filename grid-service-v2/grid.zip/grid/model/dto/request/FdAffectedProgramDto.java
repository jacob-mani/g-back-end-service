package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.Audit;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

@EqualsAndHashCode(callSuper = false)
@Data
public class FdAffectedProgramDto extends Audit {
    @JsonProperty("issueNumber")
    @NotBlank(message = "Issue Number must not be null or blank")
    private String issueNumber;

    private List<AffectedProgram> affectedPrograms;
}
