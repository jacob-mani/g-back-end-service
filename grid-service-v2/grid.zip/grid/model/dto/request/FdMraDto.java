package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.Audit;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;
import java.util.Map;

@EqualsAndHashCode(callSuper = false)
@Data
public class FdMraDto extends Audit {
    @JsonProperty("issueNumber")
    @NotBlank(message = "Issue Number must not be null or blank")
    private String issueNumber;
    @JsonProperty("implId")
    @NotBlank(message = "Impl ID must not be null or blank")
    private String implId;
    private String mraIncluded;
    private String delivery;
    private String rental;
    private String rentalFundedBy;
    private Map<String, String> programDuration;
    private List<MRACategorization> mraCategorization;
}
