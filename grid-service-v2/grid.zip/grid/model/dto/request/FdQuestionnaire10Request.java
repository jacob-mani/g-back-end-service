package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.Audit;
import com.ford.grid.model.entity.EditorDetail;
import com.ford.grid.model.entity.PopulationDetail10;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Data
@EqualsAndHashCode(callSuper = false)
@JsonIgnoreProperties(ignoreUnknown = true)
public class FdQuestionnaire10Request extends Audit {

    @JsonProperty("issueNumber")
    @NotBlank(message = "Issue Number must not be null or blank")
    private String issueNumber;

    @JsonProperty("title")
    @NotBlank(message = "Title must not be null or blank")
    private String title;

    @JsonProperty("fdStatus")
    private String fdStatus;

    @JsonProperty("implId")
    private String implId;

    /**
     * Per-population FD10 content keyed by populationId.
     * Frontend sends e.g.:
     * {
     *   "populationDetails": {
     *     "26-052-1": { "softwareSignOff": {...}, "softwareUpdate": "No", "calibrationMapped": "No", "vin2Part": {...} },
     *     "26-052-2": { "softwareSignOff": {...}, "softwareUpdate": "Yes", ... }
     *   }
     * }
     * Each population's 10A / 10B(1) / 10B(2) / 10C sections are stored independently.
     */
    @JsonProperty("populationDetails")
    private Map<String, PopulationDetail10> populationDetails = new HashMap<>();

    @Schema(description = "List of GCS file names to be deleted", example = "[\"file1.pdf\", \"file2.docx\"]")
    @JsonProperty("deletedAttachments")
    private List<String> deletedAttachments;

    // ── Deprecated flat fields kept for backward-compatibility ──────────
    /** @deprecated Use populationDetails map instead. */
    @Deprecated
    @JsonProperty("softwareSignOff")
    private EditorDetail softwareSignOff;

    /** @deprecated Use populationDetails map instead. */
    @Deprecated
    @JsonProperty("softwareUpdate")
    private String softwareUpdate;

    /** @deprecated Use populationDetails map instead. */
    @Deprecated
    @JsonProperty("calibrationMapped")
    private String calibrationMapped;

    /** @deprecated Use populationDetails map instead. */
    @Deprecated
    @JsonProperty("vin2Part")
    private EditorDetail vin2Part;
}
