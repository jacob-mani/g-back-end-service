package com.ford.grid.model.dto.request;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.Audit;
import com.ford.grid.model.entity.UserDetails;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class FdQuestionnaire11Dto extends Audit {
    @JsonProperty("issueNumber")
    @NotBlank(message = "Issue Number must not be null or blank")
    private String issueNumber;
    @JsonProperty("title")
    @NotBlank(message = "Title must not be null or blank")
    private String title;
    @JsonProperty("fdStatus")
    @NotBlank(message = "FdStatus must not be null or blank")
    private String fdStatus;
    @JsonProperty("conditionType")
    @NotBlank(message = "conditionType must not be null or blank")
    private String conditionType;
    @JsonProperty("mfdSiteCode")
    private String mfdSiteCode;
    @JsonProperty("buyer")
    private List<UserDetails> buyer;
    @JsonProperty("fieldEnggIds")
    private List<UserDetails> fieldEnggIds;
    @JsonProperty("supplierDetail")
    private SupplierDetail supplierDetail;
}
