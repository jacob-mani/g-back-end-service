package com.ford.grid.model.dto.request;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.*;
import com.ford.grid.model.dto.response.BaseVehicleCriteriaResponse;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class FdQuestionnaire1Dto extends Audit {

  @JsonProperty("issueNumber")
  @NotBlank(message = "Issue Number must not be null or blank")
  private String issueNumber;
  @JsonProperty("title")
  @NotBlank(message = "Title must not be null or blank")
  private String title; // Heading of the questionnaire
  @JsonProperty("fdStatus")
  private String fdStatus;
  @JsonProperty("kdUnitsAffected")
  private String kdUnitsAffected;
  @JsonProperty("problemDesc")
  private EditorDetail problemDesc;
  @JsonProperty("concernDiscovered")
  private EditorDetail concernDiscovered;
  @JsonProperty("corporateProduct")
  private EditorDetail corporateProduct;
  @JsonProperty("componentInfo")
  private ComponentInfo componentInfo;
  @JsonProperty("markets")
  private List<Market> markets;

  @Schema(description = "List of GCS file names to be deleted", example = "[\"file1.pdf\", \"file2.docx\"]")
  @JsonProperty("deletedAttachments")
  private List<String> deletedAttachments;

  private List<BaseVehicleCriteriaResponse> baseVehicleCriteria;

  private List<AffectedRegion> affectedRegions;

}
