package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.Audit;
import com.ford.grid.model.entity.EditorDetail;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.LocalDate;
import java.util.List;

@Data
@EqualsAndHashCode(callSuper = false)
public class FdQuestionnaire2Dto extends Audit {

    @Schema(example = "ISSUE-2025-01")
    @JsonProperty("issueNumber")
    @NotBlank(message = "Issue Number must not be null or blank")
    private String issueNumber;

    @JsonProperty("title")
    @NotBlank(message = "Title must not be null or blank")
    private String title;

    @Schema(example = "Open")
    @JsonProperty("fdStatus")
    private String fdStatus;

    @Schema(example = "High")
    @JsonProperty("specificRC")
    private EditorDetail specificRC;

    @Schema(example = "Medium")
    @JsonProperty("detectionRC")
    private EditorDetail detectionRC;

    @Schema(example = "Low")
    @JsonProperty("systemicRC")
    private EditorDetail systemicRC;

    @Schema(example = "Preliminary assessment details here")
    @JsonProperty("preliminaryAssessment")
    private EditorDetail preliminaryAssessment;

    @Schema(example = "2025-09-15")
    @JsonProperty("rcDate")
    private LocalDate rcDate;

    @Schema(example = "2025-09-15")
    @JsonProperty("praDate")
    private LocalDate praDate;

    @Schema(description = "List of GCS file names to be deleted", example = "[\"file1.pdf\", \"file2.docx\"]")
    @JsonProperty("deletedAttachments")
    private List<String> deletedAttachments;
}
