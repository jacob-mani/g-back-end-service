package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.Audit;
import com.ford.grid.model.entity.EditorDetail;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class FdQuestionnaire3Dto extends Audit {

  @JsonProperty("issueNumber")
  @NotBlank(message = "Issue Number must not be null or blank")
  private String issueNumber;
  @JsonProperty("title")
  @NotBlank(message = "Title must not be null or blank")
  private String title; // Heading of the questionnaire
  @JsonProperty("fdStatus")
  private String fdStatus;

  @JsonProperty("labTest")
  private EditorDetail labTest;
  @JsonProperty("vehicleTest")
  private EditorDetail vehicleTest;
  @JsonProperty("supplierReport")
  private EditorDetail supplierReport;
  @JsonProperty("qualityIndicator")
  private EditorDetail qualityIndicator;
  @JsonProperty("fieldReport")
  private EditorDetail fieldReport;
  @JsonProperty("partSale")
  private EditorDetail partSale;
  @JsonProperty("accidentsAttributed")
  private EditorDetail accidentsAttributed;

}
