package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.Audit;
import com.ford.grid.model.entity.EditorDetail;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.LocalDate;

@Data
@EqualsAndHashCode(callSuper = false)
public class FdQuestionnaire4Dto extends Audit {

    @JsonProperty("issueNumber")
    @NotBlank(message = "Issue Number must not be null or blank")
    private String issueNumber;
    @JsonProperty("title")
    @NotBlank(message = "Title must not be null or blank")
    private String title;
    @JsonProperty("fdStatus")
    private String fdStatus;
    @JsonProperty("interimCA")
    private EditorDetail interimCA;
    @JsonProperty("icaDate")
    private LocalDate icaDate;
    @JsonProperty("permanentCA")
    private EditorDetail permanentCA;
    @JsonProperty("pcaDate")
    private LocalDate pcaDate;
    @JsonProperty("potentiallyAffected")
    private EditorDetail potentiallyAffected;
    @JsonProperty("effectiveness")
    private EditorDetail effectiveness;
    @JsonProperty("batchIssue")
    private String batchIssue;
    @JsonProperty("componentBatchIssue")
    private EditorDetail componentBatchIssue;
}
