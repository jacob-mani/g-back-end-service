package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.Audit;
import com.ford.grid.model.entity.EditorDetail;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.HashMap;
import java.util.Map;

@Data
@EqualsAndHashCode(callSuper = false)
public class FdQuestionnaire6Request extends Audit {
    @JsonProperty("issueNumber")
    @NotBlank(message = "Issue Number must not be null or blank")
    private String issueNumber;
    @JsonProperty("fdStatus")
    private String fdStatus;
    @JsonProperty("title")
    private String title;

    /**
     * Per-population 6B content keyed by populationId.
     * Frontend sends e.g.: { "populationDeterminations": { "26-052-1-0": { ... }, "26-052-2-0": { ... } } }
     */
    @JsonProperty("populationDeterminations")
    private Map<String, EditorDetail> populationDeterminations = new HashMap<>();

    /**
     * @deprecated Use populationDeterminations map instead.
     * Kept for backward-compatibility with older frontend/API clients.
     */
    @Deprecated
    @JsonProperty("populationDetermination")
    private EditorDetail populationDetermination;
}
