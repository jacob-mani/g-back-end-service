package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.Audit;
import com.ford.grid.model.entity.EditorDetail;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

@Data
@EqualsAndHashCode(callSuper = false)
public class FdQuestionnaire7Dto extends Audit {
    @JsonProperty("issueNumber")
    @NotBlank(message = "Issue Number must not be null or blank")
    private String issueNumber;
    @JsonProperty("title")
    @NotBlank(message = "Title must not be null or blank")
    private String title; // Heading of the questionnaire
    @JsonProperty("fdStatus")
    private String fdStatus;
    @JsonProperty("partsPurge")
    private EditorDetail partsPurge;
    @Schema(description = "List of GCS file names to be deleted", example = "[\"file1.pdf\", \"file2.docx\"]")
    @JsonProperty("deletedAttachments")
    private List<String> deletedAttachments;
}
