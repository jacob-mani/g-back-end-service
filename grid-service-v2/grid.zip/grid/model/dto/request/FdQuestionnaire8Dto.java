package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.Audit;
import com.ford.grid.model.entity.EditorDetail;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class FdQuestionnaire8Dto extends Audit {
    @JsonProperty("issueNumber")
    @NotBlank(message = "Issue Number must not be null or blank")
    private String issueNumber;
    @JsonProperty("title")
    @NotBlank(message = "Title must not be null or blank")
    private String title; // Heading of the questionnaire
    @JsonProperty("fdStatus")
    private String fdStatus;
    @JsonProperty("status")
    private String status;
    @JsonProperty("vehicleOperationEffect")
    private EditorDetail vehicleOperationEffect;
    @JsonProperty("warnings")
    private EditorDetail warnings;
    @JsonProperty("regulatoryImpact")
    private EditorDetail regulatoryImpact;
    @JsonProperty("regulatorInfluenced")
    private String regulatorInfluenced;
    @JsonProperty("defectPercentage")
    private Double defectPercentage;
}
