package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.Audit;
import com.ford.grid.model.entity.EditorDetail;
import com.ford.grid.model.entity.UserDetails;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;
@EqualsAndHashCode(callSuper = false)
@Data
public class FdQuestionnaire9Dto extends Audit {

    @JsonProperty("issueNumber")
    @NotBlank(message = "Issue Number must not be null or blank")
    private String issueNumber;
    @JsonProperty("title")
    @NotBlank(message = "Title must not be null or blank")
    private String title;
    @Schema(example = "Open")
    @JsonProperty("fdStatus")
    @NotBlank(message = "fdStatus must not be null or blank")
    private String fdStatus;
    @JsonProperty("implId")
    @NotBlank(message = "implId must not be null or blank")
    private String implId;
    //private String fSADisplay//from car6
    @JsonProperty("repairEffectiveness")
    private EditorDetail repairEffectiveness;
    @JsonProperty("multipleModel")
    private String multipleModel;
    @JsonProperty("prdEnggVerified")
    private EditorDetail prdEnggVerified;
    @JsonProperty("hasPrdEnggVerified")
    private String hasPrdEnggVerified;
    @JsonProperty("inspectionRequired")
    private EditorDetail inspectionRequired;
    @JsonProperty("hasInspectionRequired")
    private String hasInspectionRequired;
    @JsonProperty("techInstruction")
    private EditorDetail techInstruction;
    @JsonProperty("performedPrior")
    private String performedPrior;
    @JsonProperty("hasFinalRepair")
    private String hasFinalRepair;
    @JsonProperty("finalRepair")
    private EditorDetail finalRepair;
    @JsonProperty("serviceTrial")
    private EditorDetail serviceTrial;
    @JsonProperty("hasPowerTool")
    private String hasPowerTool;
    @JsonProperty("powerTool")
    private EditorDetail powerTool;
    @JsonProperty("fixItRight")
    private EditorDetail fixItRight;
    @JsonProperty("invertedDelta")
    private String invertedDelta;
    @JsonProperty("standardRepair")
    private EditorDetail standardRepair;
    @JsonProperty("hasStandardRepair")
    private String hasStandardRepair;
    @JsonProperty("serviceCount")
    private EditorDetail serviceCount;
    @JsonProperty("hasOtherPart")
    private String hasOtherPart;
    @JsonProperty("otherPart")
    private EditorDetail otherPart;
    @JsonProperty("pdEnggIds")
    private List<UserDetails> pdEnggIds;
    @JsonProperty("comments")
    private String comments;
    @JsonProperty("emissionChange")
    private EditorDetail emissionChange;
    @JsonProperty("hasEmissionChange")
    private String hasEmissionChange;
    @JsonProperty("correctionEffect")
    private EditorDetail correctionEffect;
    @JsonProperty("hasCorrectionEffect")
    private String hasCorrectionEffect;
    @JsonProperty("custConcernCode")
    private String custConcernCode;
    @JsonProperty("conditionCode")
    private String conditionCode;
    @JsonProperty("casualPartNumber")
    private String casualPartNumber;
    @JsonProperty("claimsNA")
    private Boolean claimsNA;
    @JsonProperty("hasCurrentUsage")
    private String hasCurrentUsage;
    @JsonProperty("currentUsage")
    private EditorDetail currentUsage;
    @JsonProperty("repairedExclusion")
    private EditorDetail repairedExclusion;
    @JsonProperty("hasRepairedExclusion")
    private String hasRepairedExclusion;
    @Schema(description = "List of GCS file names to be deleted", example = "[\"file1.pdf\", \"file2.docx\"]")
    @JsonProperty("deletedAttachments")
    private List<String> deletedAttachments;
    @JsonProperty("remedyStatus")
    private String remedyStatus;
    @JsonProperty("repairClassification")
    private String repairClassification;
    @JsonProperty("otaCapableForRepair")
    private EditorDetail otaCapableForRepair;
    @JsonProperty("hasOtaCapableForRepair")
    private String hasOtaCapableForRepair;
    @JsonProperty("otaProposedForRepair")
    private EditorDetail otaProposedForRepair;
    @JsonProperty("hasOtaProposedForRepair")
    private String hasOtaProposedForRepair;

}
