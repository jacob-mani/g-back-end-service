package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.Audit;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class FdStatusRequest extends Audit {

    private String id;
    @Schema(example = "UH033")
    @JsonProperty("issueNumber")
    @NotNull(message = "Issue number must not be null")
    private String issueNumber;

    @Schema(example = "1")
    @JsonProperty("fdStatus")
    @NotNull(message = "Fd status must not be null")
    private String fdStatus;

    @Schema(description = "Conclude date", example = "2023-10-31")
    @JsonProperty("concludeDate")
    private LocalDate concludeDate;

    @Schema(description = "Is reopened")
    @JsonProperty("isReopenRequest")
    private Boolean isReopenRequest;

    @Schema(description = "Reopen date", example = "2023-11-15")
    @JsonProperty("reopenDate")
    private LocalDate reopenDate;
}
