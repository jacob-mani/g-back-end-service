package com.ford.grid.model.dto.request;

import com.ford.grid.model.entity.FrcFactSheetFile;
import com.ford.grid.model.entity.fdr.FdrFactSheetDocument;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class FdrActionRequest {

    @NotBlank
    private String fsaNumber;
    @NotBlank
    private String issueNumber;
    private String reasonForFieldAct;
    private String approxRecallDt;
    private String descOfRemedy;
    private FdrFactSheetDocument selectedFactSheet;
}
