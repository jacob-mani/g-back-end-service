package com.ford.grid.model.dto.request;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.ford.grid.model.dto.request.vern.ProductionDateByPlant;
import com.ford.grid.model.entity.*;
import com.ford.grid.model.entity.fdr.FdrFactSheetDocument;
import com.ford.grid.model.entity.fdr.NHTSAnotice;
import lombok.Data;

@Data
public class FdrModel {

    private boolean waitingForSubmit;

    private boolean waitingForReview;

    private boolean reviewCompleted;

    private String issueNumber;

    private String subject;

    private String title;

    private String manufacturer;

    private String vehicleLine;

    private String similarVehicles;

    private String assemblyPlant;

    private String fsa;

    private String reasonForFsa;

    private String descriptionOfRemedy;

    private String approxRecallDt;

    private List<Map<String, Object>> vehicles;

    private List<VehicleCriteriaModel> baseVehicleCriterias;

    private String lastTRGDate;

    private String nextTRGDate;

    private List<Contacts> concernTeam;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    @JsonDeserialize(using = LocalDateDeserializer.class)
    @JsonSerialize(using = LocalDateSerializer.class)
    private LocalDate fdKickOffDate;

    private String kickOff14dDate;

    private String frcDate;

    private String make;

    private String model;

    private String fdrStatus;

    private NHTSAnotice nhtsaNotice;

    List<FdrFactSheetDocument> frcFactSheetDocuments;

    FdrFactSheetDocument selectedFactSheet;

    List<String> vehicleCritria;

    String typeOfAction;

    private List<ProductionDateByPlant> productionDateByPlantList;

    Integer vehicleCount;

    List<String> markets;


}

