package com.ford.grid.model.dto.request;

import com.ford.grid.model.entity.Attachment;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
public class FeedbackRequest {

    private String feedbackType;
    private String areaAffected;
    private String feedbackTitle;
    private String feedbackDescription;
    private String responseUrgency;
    private List<Attachment> images;
    private String cdsId;
    private String comments;
    private String assigneeName;
}


