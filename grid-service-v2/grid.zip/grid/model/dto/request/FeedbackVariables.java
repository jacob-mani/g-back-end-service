package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FeedbackVariables {

    @JsonProperty("application_lookup")
    private String applicationLookup;

    @JsonProperty("request_category")
    private String requestCategory;

    @JsonProperty("summary")
    private String summary;

    @JsonProperty("description")
    private String description;

    @JsonProperty("requested_for")
    private String requestedFor;
}

