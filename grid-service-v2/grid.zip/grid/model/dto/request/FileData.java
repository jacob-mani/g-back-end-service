package com.ford.grid.model.dto.request;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@AllArgsConstructor
@Builder
public class FileData {
    private String originalFileName;
    private String desiredGCSFileName;
    private String contentType;
    private byte[] content;
}