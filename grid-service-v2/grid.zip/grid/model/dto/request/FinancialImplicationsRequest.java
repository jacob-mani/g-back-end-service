package com.ford.grid.model.dto.request;


import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.Attachment;
import com.ford.grid.model.entity.Audit;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class FinancialImplicationsRequest extends Audit {

    @Schema(example = "UH033")
    private String id;
    @Schema(example = "25-001")
    @JsonProperty("issueNumber")
    @NotBlank(message = "Issue number must not be null or blank")
    private String issueNumber;
    @Schema(example = "25-001-1")
    @JsonProperty("implId")
    @NotBlank(message = "implId must not be null or blank")
    private String implId;
    @JsonProperty("populationId")
    @NotBlank(message = "populationId must not be null or blank")
    private String populationId;
    //private Integer totalVehicleVolume;
    @JsonProperty("materialTotalCost")
    private BigDecimal materialTotalCost;
    @JsonProperty("laborTotalCost")
    private BigDecimal laborTotalCost;
    @JsonProperty("estimatedTotalCost")
    private BigDecimal estimatedTotalCost;
    @JsonProperty("additionalNotes")
    private String additionalNotes;
    @Schema(example = "UH033")
    @JsonProperty("attachments")
    private List<Attachment> attachments;
    @Schema(example = "true")
    @JsonProperty("costNotApplicable")
    @NotNull(message = "costNotApplicable must not be null")
    private boolean costNotApplicable;
    @Schema(example = "true")
    @JsonProperty("additionalNotesNotApplicable")
    @NotNull(message = "additionalNotesNotApplicable must not be null")
    private boolean additionalNotesNotApplicable;
    @Schema(example = "[\"file1.pdf\", \"file2.docx\"]")
    @JsonProperty("deletedAttachments")
    private List<String> deletedAttachments;

}