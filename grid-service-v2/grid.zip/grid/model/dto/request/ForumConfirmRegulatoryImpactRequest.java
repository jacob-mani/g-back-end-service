package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.Attachment;
import com.ford.grid.model.entity.Audit;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

@Data
@EqualsAndHashCode(callSuper = false)
public class ForumConfirmRegulatoryImpactRequest extends Audit {

    @Schema(example = "507f1f77bcf86cd799439011")
    private String id;

    @Schema(example = "ISS-2024-001")
    @JsonProperty("issueNumber")
    @NotBlank(message = "Issue number must not be null or blank")
    private String issueNumber;

    @Schema(example = "[\"REG-1001\", \"REG-1002\"]")
    @JsonProperty("regulationNumber")
    private List<String> regulationNumber;

    @Schema(example = "Technical Forum")
    @JsonProperty("forumType")
    @NotBlank(message = "Forum type must not be null or blank")
    private String forumType;

    @Schema(example = "EPA")
    @JsonProperty("agency")
    private String agency;

    @Schema(example = "UH033")
    @JsonProperty("attachments")
    private List<Attachment> attachments;

    @Schema(example = "[\"file1.pdf\", \"file2.docx\"]")
    @JsonProperty("deletedAttachments")
    private List<String> deletedAttachments;
}
