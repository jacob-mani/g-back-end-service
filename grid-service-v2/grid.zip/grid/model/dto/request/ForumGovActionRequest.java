package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.Assignment;
import com.ford.grid.model.entity.Audit;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.data.mongodb.core.index.Indexed;

import java.util.List;

@Data
@EqualsAndHashCode(callSuper = false)
public class ForumGovActionRequest extends Audit {

    @Schema(example = "UH033")
    private String id;

    @Schema(example = "UH033")
    @JsonProperty("issueNumber")
    @Indexed(unique = true)
    @NotBlank(message = "Issue number must not be null or blank")
    private String issueNumber;

    @Schema(example = "Technical Forum")
    @JsonProperty("forumType")
    @NotBlank(message = "Forum type must not be null or blank")
    private String forumType;

    @Schema(example = "EPA")
    @JsonProperty("agency")
    private String agency;

    @Schema(description = "List of assignments")
    @JsonProperty("assignments")
    private List<Assignment> assignments;

}
