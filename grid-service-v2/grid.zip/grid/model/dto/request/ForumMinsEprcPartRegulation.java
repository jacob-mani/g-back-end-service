package com.ford.grid.model.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class ForumMinsEprcPartRegulation {

    private DefectReportRecommendations potentialDefectDesign;
    private DefectReportRecommendations potentialDefectDeviceSystem;
    private DefectReportRecommendations potentialAffectAnyParameter;
    private DefectReportRecommendations potentialOneMoreEmissionRelated;
    private DefectReportRecommendations otherQuestionsYes;
    private DefectReportRecommendations defectInvolveMoreVehiclesEngines;
    private DefectReportRecommendations answersYesToQuestions5AND6;
    //8
    private DefectReportRecommendations customerNotification;
    private DefectReportRecommendations failureThatAffects;
    //10
    private DefectReportRecommendations provideJustification;
    private DefectReportRecommendations approvedFSAThatRepairs;
    private DefectReportRecommendations technicalReviewProcess;
    private DefectReportRecommendations recommendInitiationDPAC;
    private DefectReportRecommendations presentCurrentProduction;

}
