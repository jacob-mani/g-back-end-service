package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.Audit;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class ForumMinutesRequest extends Audit {
    @JsonProperty("issueNumber")
    @NotBlank(message = "Issue Number must not be null or blank")
    private String issueNumber;
    private String eprcOpenedDate;
    private String dateRevisited;
    private String regulation;
    private ForumMinsEprcPartRegulation part85;
    private ForumMinsEprcPartRegulation part1068;
}