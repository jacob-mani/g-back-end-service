package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ForumNoteApprovers {

    @Schema(description = "Reviewer title", example = "Manager")
    @JsonProperty("title")
    private String title;

    @JsonProperty("titleName")
    private String titleName;

    @Schema(description = "Reviewer CDSID", example = "jdoe1")
    @JsonProperty("cdsid")
    private String cdsid;

    @Schema(description = "Reviewer name", example = "John Doe")
    @JsonProperty("name")
    private String name;

    @Schema(description = "Process status", example = "Completed")
    @JsonProperty("processStatus")
    private String processStatus;  //Completed , Approved with edit, Rejected.

    @Schema(description = "Approved by", example = "jdoe1")
    @JsonProperty("approvedBy")
    private String approvedBy;

    @Schema(description = "Rejected To", example = "asmith2")
    @JsonProperty("sendTo")
    private String sendTo;

    @Schema(description = "Sent To Title", example = "asmith2")
    @JsonProperty("sendToTitle")
    private String sendToTitle;

    @Schema(description = "Process date")
    @JsonProperty("pendingFrom")
    private LocalDate pendingFrom;

    @Schema(description = "ApprovedDate")
    @JsonProperty("approvedDate")
    private LocalDate approvedDate;

    @Schema(description = "Pending days count", example = "5")
    @JsonProperty("pendingDaysCount")
    private Integer pendingDaysCount;

    @Schema(description = "Is current reviewer", example = "true")
    @JsonProperty("isCurrentReviewer")
    private Boolean isCurrentReviewer;

}
