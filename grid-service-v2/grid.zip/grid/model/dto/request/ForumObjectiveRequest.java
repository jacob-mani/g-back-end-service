package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.time.LocalDate;

@Data
public class ForumObjectiveRequest {
    @Schema(example = "UH033")
    @JsonProperty("objectiveText")
    private String objectiveText;
    @Schema(example = "UH033")
    @JsonProperty("meetingDate")
    private LocalDate meetingDate;

}
