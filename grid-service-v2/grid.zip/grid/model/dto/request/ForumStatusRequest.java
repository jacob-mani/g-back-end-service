package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.Audit;
import com.ford.grid.model.entity.Contacts;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class ForumStatusRequest extends Audit {
    private String id;
    @Schema(example = "UH033")
    @JsonProperty("issueNumber")
    @NotNull(message = "Issue number must not be null")
    private String issueNumber;
    @Schema(example = "1")
    @JsonProperty("forumStatus")
    @NotNull(message = "Forum status must not be null")
    private String forumStatus;
    @Schema(example = "1")
    @JsonProperty("forumType")
    @NotNull(message = "Forum type must not be null")
    private String forumType;
    @Schema(example = "Agency Name")
    @JsonProperty("agency")
    private String agency;
    @Schema(example = "Monitor Reason")
    @JsonProperty("monitorReason")
    private String monitorReason;
    @Schema(description = "Monitor comeback date",example = "2023-10-31")
    @JsonProperty("monitorComebackDate")
    private LocalDate monitorComebackDate;
    @Schema(example = "Monitor Responsible")
    @JsonProperty("monitorResponsible")
    private Contacts monitorResponsible;
    @Schema(example = "true")
    @JsonProperty("isConcludeFSA")
    private Boolean isConcludeFSA;
    @Schema(description = "Is forum concluded")
    @JsonProperty("isForumConcluded")
    private Boolean isForumConcluded;
    @Schema(description = "Forum to conclude with", example = "CCRG")
    @JsonProperty("concludeWithForum")
    private String concludeWithForum;
    @Schema(description = "Forum open date for the target forum", example = "2026-08-19")
    @JsonProperty("forumOpenDate")
    private LocalDate forumOpenDate;
    @Schema(description = "Forum segment", example = "6")
    @JsonProperty("segment")
    private String forumSegment;
    @Schema(example = "FSA123")
    @JsonProperty("fsaNumber")
    private String fsaNumber;
    @Schema(description = "Conclude date", example = "2023-10-31")
    @JsonProperty("concludeDate")
    private LocalDate concludeDate;
    @Schema(description = "Is note reviewed")
    @JsonProperty("isNoteReviewed")
    private Boolean isNoteReviewed;
    @Schema(description = "Notes Pending sub-status selected by the user (Notes Pending or Pending Regulator Alignment), kept even if forumStatus itself becomes Concluded in the same save", example = "Pending Regulator Alignment")
    @JsonProperty("notesPendingStatus")
    private String notesPendingStatus;
    @Schema(description = "List of note reviewers")
    @JsonProperty("notesApprovers")
    private List<ForumNoteApprovers> notesApprovers;
    @Schema(description = "Is reopened")
    @JsonProperty("isReopenRequest")
    private Boolean isReopenRequest;
    @Schema(example = "true")
    @JsonProperty("isTsb")
    private Boolean isTsb;
    @Schema(example = "TSB123")
    @JsonProperty("tsb")
    private String tsb;
    @Schema(example = "true")
    @JsonProperty("isSsm")
    private Boolean isSsm;
    @Schema(example = "SSM123")
    @JsonProperty("ssm")
    private String ssm;
    @Schema(description = "Is post monitor")
    @JsonProperty("isPostMonitor")
    private Boolean isPostMonitor;
    @Schema(description = "Post monitor date", example = "2023-10-31")
    @JsonProperty("postMonitorDate")
    private LocalDate postMonitorDate;
    @Schema(description = "Days open", example = "15")
    @JsonProperty("daysOpen")
    private Integer daysOpen;
    @Schema(description = "Additional comments")
    @JsonProperty("additionalComments")
    private String additionalComments;
    @Schema(description = "Reopen date", example = "2023-11-15")
    @JsonProperty("reopenDate")
    private LocalDate reopenDate;
    @Schema(description = "Draft Reviewed", example = "true")
    @JsonProperty("isDraftReviewed")
    private Boolean isDraftReviewed;
}
