package com.ford.grid.model.dto.request;

import com.ford.grid.model.entity.Attachment;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.time.LocalDate;
import java.util.List;

@Data
public class FrcAgendaDto {
    @Schema(example = "1")
    private int sequenceId;
    @Schema(example = "AGD12345")
    private String agendaId;
    @Schema(example = "2024-06-30")
    private LocalDate frcMeetingDate;
    @Schema(example = "NA")
    private String frcApprovedRegion;
    @Schema(example = "attachment1, attachment2")
    private List<Attachment> attachments;
    @Schema(example = "s")
    private String potentialFsaType;
    @Schema(example = "UH033")
    private String draftFsaTitle;
    @Schema(example = "UH033")
    private String selectedTiming;
}
