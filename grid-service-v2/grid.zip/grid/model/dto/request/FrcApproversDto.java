package com.ford.grid.model.dto.request;

import com.ford.grid.model.entity.Contacts;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FrcApproversDto {
    private int sequenceNo;
    private String title;
    private String cdsid;
    private String name;
    private Boolean fixed;
    private Boolean notAvailable;
    private String processStatus;
    private String pendingFrom;
    private String approvedBy;
    private LocalDate approvedDate;
    private boolean currentApprover = false;
    private List<String> approverTitles;
    private List<Contacts> approversDetails;

    // Approval workflow fields
    private LocalDateTime approvalDate;
    private String approvalAction;
    private String comments;
}
