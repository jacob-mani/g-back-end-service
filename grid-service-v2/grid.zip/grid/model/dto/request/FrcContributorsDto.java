package com.ford.grid.model.dto.request;

import lombok.Data;

@Data
public class FrcContributorsDto {
    private int sequenceNo;
    private String cdsid;
    private String name;
    private Boolean newContact;
    private String access;
}
