package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import org.springframework.data.mongodb.core.index.Indexed;

import java.time.LocalDate;
import java.util.List;

@Data
public class FrcFactSheetApprovalRequest {

    @Schema(example = "UH033")
    @JsonProperty("issueNumber")
    @Indexed(unique = true)
    @NotBlank(message = "Issue number must not be null or blank")
    private String issueNumber;

    @Schema(example = "UH033")
    @JsonProperty("implId")
    @NotNull(message = "Implementation Id must not be null")
    private String implId;

    @Schema(example = "UH033")
    @JsonProperty("populationId")
    @NotNull(message = "Population Id must not be null")
    private String populationId;

    @JsonProperty("draftReviewer")
    private FrcApproversDto draftReviewer;

    @JsonProperty("finalReviewer")
    private FrcApproversDto finalReviewer;

    @JsonProperty("approversList")
    private List<FrcApproversDto> approversList;

    @JsonProperty("factSheetStatus")
    private String factSheetStatus;

    @JsonProperty("approvalNotRequired")
    private boolean approvalNotRequired = false;

    private boolean isConcluded = false;
    private String concludedBy;
    private LocalDate concludedDate;

    @JsonProperty("rootCauseManagerComments")
    private String rootCauseManagerComments;
}
