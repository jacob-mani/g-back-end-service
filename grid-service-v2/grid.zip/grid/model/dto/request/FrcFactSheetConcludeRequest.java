package com.ford.grid.model.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FrcFactSheetConcludeRequest {

    @NotBlank(message = "Population ID is required")
    private String populationId;

    @NotNull(message = "File version is required")
    private Integer fileVersion;

    @NotBlank(message = "Concluded by is required")
    private String concludedBy;

    @NotNull(message = "Concluded date is required")
    private LocalDate concludedDate;
}
