package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.Audit;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.LocalDate;
import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
public class FrcFactSheetFileDto extends Audit {

    @NotBlank(message = "File Version must not be null or blank")
    @Schema(example = "1")
    @JsonProperty("fileVersion")
    private int fileVersion;

    @Schema(example = "UH033")
    @JsonProperty("frcSubject")
    @NotBlank(message = "Frc Subject must not be null or blank")
    private String frcSubject;

    @Schema(example = "UH033")
    @JsonProperty("factSheetTargetDate")
    @NotBlank(message = "FactSheet Target Date must not be null or blank")
    private LocalDate factSheetTargetDate;

    @Schema(example = "UH033")
    @JsonProperty("contributorsList")
    @NotBlank(message = "contributors List must not be null or blank")
    private List<FrcContributorsDto> contributorsList;

    @Schema(example = "UH033")
    @JsonProperty("approversList")
    private  List<FrcApproversDto> approversList;

    @Schema(example = "UH033")
    @JsonProperty("factSheetFileName")
    //NotBlank(message = "FactSheet FileName must not be null or blank")
    private String factSheetFileName;

    @Schema(example = "UH033")
    @JsonProperty("factSheetFileUrl")
    //@NotBlank(message = "FactSheet FileUrl must not be null or blank")
    private String factSheetFileUrl;

    @JsonProperty("draftReviewer")
    private FrcApproversDto draftReviewer;

    @JsonProperty("finalReviewer")
    private FrcApproversDto finalReviewer;

    @JsonProperty("approvalNotRequired")
    private boolean approvalNotRequired = false;

    private boolean isConcludeRequired;
    private boolean isConcluded;
    private String concludedBy;
    private LocalDate concludedDate;

    @JsonProperty("rootCauseManagerComments")
    private String rootCauseManagerComments;
}
