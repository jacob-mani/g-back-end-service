package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

import java.util.List;

@Data
public class FrcFactsheetChangePermissionRequest {

    @Schema(example = "26-125 Fact Sheet Draft -26-125-1-0-20260618170845-V1.docx", description = "File name")
    @JsonProperty("fileName")
    @NotBlank(message = "File name must not be null or blank")
    private String fileName;

    @Schema(example = "[\"zdunlap\"]", description = "List of CDS IDs of the users")
    @JsonProperty("cdsId")
    @NotEmpty(message = "CDS ID list must not be null or empty")
    private List<String> cdsId;

    @Schema(example = "read", description = "Permission type to remove")
    @JsonProperty("removeType")
    private String removeType;

    @Schema(example = "edit", description = "Permission type to add")
    @JsonProperty("addType")
    @NotBlank(message = "Add type must not be null or blank")
    private String addType;

    @Schema(example = "26-125-1-0", description = "Population ID")
    @JsonProperty("populationId")
    @NotBlank(message = "Population ID must not be null or blank")
    private String populationId;
}
