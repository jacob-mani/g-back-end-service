package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class FrcFactsheetDownloadRequest {

    @Schema(example = "25-444", description = "Issue Number")
    @JsonProperty("issueNumber")
    @NotBlank(message = "Issue number must not be null or blank")
    private String issueNumber;

    @Schema(example = "IMPL001", description = "Implementation ID")
    @JsonProperty("implId")
    @NotBlank(message = "Implementation ID must not be null or blank")
    private String implId;

    @Schema(example = "POP001", description = "Population ID")
    @JsonProperty("populationId")
    @NotBlank(message = "Population ID must not be null or blank")
    private String populationId;

    @Schema(example = "26-013 Fact Sheet Draft -3.docx", description = "File name to download")
    @JsonProperty("fileName")
    @NotBlank(message = "File name must not be null or blank")
    private String fileName;

    @Schema(example = "false", description = "Whether to download draft version (true) or final version (false)")
    @JsonProperty("draft")
    @NotNull(message = "Draft flag must not be null")
    private Boolean draft;
}

