package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.Audit;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.data.mongodb.core.index.Indexed;


import java.time.LocalDate;

@Data
@EqualsAndHashCode(callSuper = false)
public class FrcFactsheetRequest extends Audit {

    @Schema(example = "UH033")
    private String id;

    @Schema(example = "UH033")
    @JsonProperty("issueNumber")
    @Indexed(unique = true)
    @NotBlank(message = "Issue number must not be null or blank")
    private String issueNumber;

    @Schema(example = "UH033")
    @JsonProperty("implId")
    @NotNull(message = "Implementation Id must not be null")
    private String implId;

    @Schema(example = "UH033")
    @JsonProperty("populationId")
    @NotNull(message = "Population Id must not be null")
    private String populationId;
    private FrcFactSheetFileDto factSheetFile;
    @JsonProperty("isAmendment")
    private boolean isAmendment;
    @JsonProperty("isMemo")
    private boolean isMemo;
    private String factSheetStatus;
    private LocalDate concludedDate;
    private String concludedBy;

    @JsonProperty("isAiDataFlag")
    private boolean aiDataFlag;
}
