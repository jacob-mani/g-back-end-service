package com.ford.grid.model.dto.request;

import lombok.Data;

@Data
public class FsamPreserveRequest {
    private String  issueNumber;  // key — matches live issue
    private String  forumType;    // retained for composite key lookup
    private String  agency;       // retained for composite key lookup
    private Integer position;     // 1-based row index from UI (first row = 1)
}
