package com.ford.grid.model.dto.request;

import lombok.Data;

import java.util.List;

@Data
public class FsamPreviewRequest {
    private String       leadRegion;              // single region — "NA", "EU" etc.
    private String       viewType;                // "ccrgView" / "csfView" / "eprcView" / "govtView"
    private String       cdsid;                   // user identity — used to restore their own saved order
    private List<String> selectCCList;            // optional — filter by forum chair name
    private int          page;                    // 0-based page index (0 = first page)
    private int          pageSize;
    private List<SelectedIssue> selectedIssues;   // composite key — issueNumber + forumType
}
