package com.ford.grid.model.dto.request;

import lombok.Data;

@Data
public class FsamSearchRequest {

    private String leadRegion;

    private String searchKey;

    private int page;

    private int pageSize;
}
