package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.Audit;
import com.ford.grid.model.entity.ForumGlobalObjective;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;
@EqualsAndHashCode(callSuper = true)
@Data
public class GLSchForumAgeRequest extends Audit {
    @Schema(example = "UH033")

    @JsonProperty("id")
    private String id;

    @Schema(example = "UH033")
   @JsonProperty("forumType")
    private String forumType;
    @Schema(example = "UH033")
    @JsonProperty("agency")
    private String agency;
    @Schema(example = "UH033")
    @JsonProperty("issueNumber")
    private String issueNumber;
    @Schema(example = "UH033")

    @JsonProperty ("forumObjective")
    private List<ForumGlobalObjective> forumGlobalObjectives;
}
