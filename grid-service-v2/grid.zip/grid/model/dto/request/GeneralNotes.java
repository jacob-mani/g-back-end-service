package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.ford.grid.serializer.LowerCaseDeserializer;
import com.ford.grid.serializer.ToLowerCase;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Field;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class GeneralNotes {
    @ToLowerCase
    @JsonDeserialize(using = LowerCaseDeserializer.class)
    private String role;
    @ToLowerCase
    @JsonDeserialize(using = LowerCaseDeserializer.class)
    private String title;
    private String notes;
    @JsonProperty("isCardBeingEdited")
    private boolean isCardBeingEdited;
    @JsonProperty("currentlyEditedBy")
    private String currentlyEditedBy;
    @JsonProperty("isNoteActive")
    @Field("isNoteActive")
    private boolean isNoteActive = true;
    private String workLoad;
}