package com.ford.grid.model.dto.request;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import lombok.Data;


@XmlRootElement(name = "GetPartsForGridNotice")
@XmlAccessorType(XmlAccessType.FIELD)
@Data
public class GetPartsViaNoticeConcernPart {

    @XmlElement(name = "DataArea")
    private DataArea dataArea;

}
