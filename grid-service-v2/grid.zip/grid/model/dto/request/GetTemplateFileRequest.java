package com.ford.grid.model.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class GetTemplateFileRequest {

    private String issueNumber;
    private String implId;
    private String populationId;
    private String fsaNumber;
    private List<String> brand;
    private String region;
    private String market;
    private String potentialType;
    private String communicationGoal;
    private String templatePair;
    private String cdsId;
    private String status;
}

