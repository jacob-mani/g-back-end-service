package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class GovDocDownloadRequest {

    @Schema(example = "25-888", description = "Issue Number")
    @JsonProperty("issueNumber")
    @NotBlank(message = "Issue number must not be null or blank")
    private String issueNumber;

    @Schema(example = "IMPL001", description = "Implementation ID")
    @JsonProperty("implId")
    @NotBlank(message = "Implementation ID must not be null or blank")
    private String implId;

    @Schema(example = "POP001", description = "Population ID")
    @JsonProperty("populationId")
    @NotBlank(message = "Population ID must not be null or blank")
    private String populationId;

    @Schema(example = "true", description = "Whether to download as draft version")
    @JsonProperty("draft")
    @NotNull(message = "Draft flag must not be null")
    private Boolean draft;
}

