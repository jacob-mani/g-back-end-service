package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.IEDMyPgmBucket;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Schema(description = "FSA Model year program code Bucket with list of Part numbers")
@Valid
public class IEDFsaBucketPartNumbersRequest {

    @JsonProperty("fsaId")
    @Schema(example = "UH033")
    private String fsaId;

    @JsonProperty("myPgmBuckets")
    @Schema(example = "[{\"modelYear\":\"2022\",\"programCode\":\"CX483N\",\"wersNoticeNumberPartNumbers\":[{\"wersNoticeNumber\":\"AELEE13036479154\",\"addPartNumbers\":[\"M1BT-14C302-BD\",\"M1BT-14C302-BD\"],\"deletePartNumbers\":[\"M1BT-14C303-BD\",\"M1BT-14C303-BD\"]}]}]",
            description = "collection of model year program code Bucket with list of Part numbers")
    List<IEDMyPgmBucket> myPgmBuckets;
}
