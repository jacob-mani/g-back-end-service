package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.Attachment;
import com.ford.grid.model.entity.Audit;
import com.ford.grid.model.entity.ClosureNotesComments;
import com.ford.grid.model.entity.ProblemCategory;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class InvestigationAnalysisRequest extends Audit {

    @Schema(example = "507f1f77bcf86cd799439011")
    private String id;

    @Schema(example = "UH033")
    private String issueNumber;

    @Schema(example = "UH033")
    private List<Attachment> attachments;

    @Schema(example = "UH033")
    private String forumType;

    @Schema(example = "UH033")
    private String status;

    @Schema(example = "UH033")
    private String agency;

    @Schema(example = "UH033")
    private ProblemCategory problemCategory;

    @Schema(example = "[\"file1.pdf\", \"file2.docx\"]")
    @JsonProperty("deletedAttachments")
    private List<String> deletedAttachments;

    @Schema(example = "2023-12-01")
    @JsonProperty("patientZeroDate")
    private LocalDate patientZeroDate;

    @Schema(example = "UH033")
    @JsonProperty("chronologyComments")
    private List<ClosureNotesComments> chronologyComments;

    @Schema(example = "UH033")
    @JsonProperty("meetingNotesIds")
    private List<Integer> meetingNotesIds;

    @Schema(example = "UH033")
    @JsonProperty("isClosureNote")
    private Boolean isClosureNote;

    @Schema(example = "UH033")
    @JsonProperty("closureNoteLastUpdatedBy")
    private String closureNoteLastUpdatedBy;

    @Schema(example = "UH033")
    @JsonProperty("closureNoteLastUpdatedDate")
    private LocalDate closureNoteLastUpdatedDate;


}