package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.*;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

@Data
@Builder
@EqualsAndHashCode(callSuper = false)
public class IssueContactsRequest extends Audit {

    @Schema(example = "UH033")
    private String id;

    @Schema(example = "UH033")
    @JsonProperty("issueNumber")
    @NotBlank(message = "IssueNumber must not be null or blank")
    private String issueNumber;

    @Schema(example = "UH033")
    @JsonProperty("region")
    @NotBlank(message = "Region must not be null or blank")
    private String region;

    @Schema(example = "UH033")
    @JsonProperty("segment")
    @NotBlank(message = "Segment must not be null or blank")
    private String segment;

    @Schema(example = "UH033")
    @JsonProperty("forum")
    @NotBlank(message = "Forum must not be null or blank")
    private String forum;

    @Schema(example = "UH033")
    @JsonProperty("groupId")
    @NotBlank(message = "groupId must not be null or blank")
    private String groupId;

    @Schema(example = "UH033")
    @JsonProperty("contacts")
    private List<Contacts> contacts;

    @Schema(example = "UH033")
    @JsonProperty("customContacts")
    private List<CustomContacts> customContacts;

    @JsonProperty("subGroupDetails")
    private List<SubGroupDetail> subGroupDetails;
}
