package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class IssueFunctionRequest {

    @Schema(example = "UH033")
    private String id;

    @Schema(example = "UH033")
    @JsonProperty("key")
    private String key;

    @Schema(example = "UH033")
    @JsonProperty("value")
    private String value;
}
