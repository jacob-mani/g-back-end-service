package com.ford.grid.model.dto.request;

import com.ford.grid.model.entity.Contacts;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class IssueList {

    private String issueNumber;
    private String issueDescription;
    private String duration;
    private String startEndTime;
    private List<Contacts> keyParticipants;
    private List<Contacts> contacts;
    private boolean awaitingNHTSAResponse;
    private String potentialActionType;
    private String xNumber;
    private String agendaType;
    private String timezoneValues;
}
