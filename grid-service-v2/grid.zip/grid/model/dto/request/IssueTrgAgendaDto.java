package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.Attachment;
import com.ford.grid.model.entity.RegionsRecommended;
import com.ford.grid.model.entity.TrgRecommendation;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Data
public class IssueTrgAgendaDto {
    @Schema(example = "1")
    private int sequenceId;
    @Schema(example = "AGD12345")
    private String agendaId;
    @Schema(example = "Technical")
    private String trgType;
    @Schema(example = "2025-09-25")
    private LocalDate meetingDate;
    private String trgMeetingType;
    @Schema(example = "Engine safety discussion")
    private String topicDescription;
    @Schema(description = "Duration of the meeting", example = "2 hours")
    private String duration;
    @Schema(example = "CCRG Team A")
    private String ccrgTeam;
    @Schema(example = "Scheduled")
    private String trgStatus;
    @Schema(example = "Notes here")
    private String notes;
    @Schema(example = "true")
    @JsonProperty("followUp")
    private Boolean followUp;
    @Schema(example = "2025-10-10")
    @JsonProperty("followUpDate")
    private LocalDate followUpDate;
    @Schema(description = "TRG recommendations list (one entry per population)")
    private List<TrgRecommendation> trgRecommendations;
    private List<RegionsRecommended> regionsRecommended;
    @Schema(example = "2025-09-20")
    @JsonProperty("earliestDate")
    private LocalDate earlyDate;
    @Schema(example = "2025-09-30")
    private LocalDate latestDate;
    @Schema(example = "Task Owner Name")
    private String taskOwner;
    private String purposeOfTrg;
    private String trgMeetingUrgency;
    private String meetingTitle;
    private String otherParticipants;
    private LocalDate trgScheduledDate;
    @Schema(description = "Attachment details")
    private List<Attachment> attachments;

    // Contact fields
    @Schema(example = "John Doe")
    private String asoEngineer;
    @Schema(example = "JDOE1")
    private String asoEngineerCdsid;
    @Schema(example = "Jane Smith")
    private String ccmContact;
    @Schema(example = "JSMITH")
    private String ccmContactCdsid;
    @Schema(example = "Bob Wilson")
    private String cceContact;
    @Schema(example = "BWILSON")
    private String cceContactCdsid;
    @Schema(example = "Alice Brown")
    private String responsibleDirector;
    @Schema(example = "ABROWN")
    private String responsibleDirectorCdsid;
    @Schema(example = "Charlie Davis")
    private String dri;
    @Schema(example = "CDAVIS")
    private String driCdsid;
    @Schema(example = "David Lee")
    private String trgPresenter;
    @Schema(example = "DLEE")
    private String trgPresenterCdsid;
    @Schema(example = "Eve Martin")
    private String criticalParticipantSupport;
    @Schema(example = "EMARTIN")
    private String criticalParticipantSupportCdsid;

    // Participation fields
    @Schema(description = "Regional participation list", example = "[\"NA\", \"EU\"]")
    private List<String> regionalParticipation;
    @Schema(example = "Yes")
    private String imgParticipation;

    // Population identifiers — e.g. ["25-183-1-0", "25-185-1-1"]
    @Schema(description = "List of population IDs associated with this TRG agenda", example = "[\"25-183-1-0\", \"25-185-1-1\"]")
    private List<String> populationList;

    // Agenda-level audit fields
    @Schema(description = "User who created this agenda item", example = "JDOE1")
    private String createdBy;
    @Schema(description = "Timestamp when this agenda item was created")
    private LocalDateTime createdAt;
    @Schema(description = "User who last updated this agenda item", example = "JSMITH")
    private String updatedBy;
    @Schema(description = "Timestamp when this agenda item was last updated")
    private LocalDateTime updatedAt;

    // Resolved display names (populated by GET API via LDAP lookup)
    @Schema(description = "Display name of the creator", example = "John Doe")
    private String createdByName;
    @Schema(description = "Display name of the last updater", example = "Jane Smith")
    private String updatedByName;
}

