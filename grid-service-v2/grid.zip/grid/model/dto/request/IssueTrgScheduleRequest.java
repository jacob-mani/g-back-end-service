package com.ford.grid.model.dto.request;

import com.ford.grid.model.entity.Audit;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;

@Data
@EqualsAndHashCode(callSuper = false)
public class IssueTrgScheduleRequest extends Audit {
    @Schema(example = "507f1f77bcf86cd799439011")
    private String id;

    @Schema(example = "24-001")
    @NotBlank
    private String issueNumber;

    @Schema(description = "List of TRG agenda items at issue level")
    @Valid
    private List<IssueTrgAgendaDto> trgSchedule;

    @Schema(description = "List of deleted attachment GCS file names")
    private List<String> deletedAttachments;
}

