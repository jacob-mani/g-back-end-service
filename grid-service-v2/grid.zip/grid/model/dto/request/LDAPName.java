package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class LDAPName {

    @JsonProperty("cdsid")
    private String cdsId;
    private String firstName;
    private String lastName;
    private String displayName;

}

