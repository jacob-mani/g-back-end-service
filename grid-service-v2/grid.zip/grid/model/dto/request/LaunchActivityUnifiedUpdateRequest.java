package com.ford.grid.model.dto.request;

import com.ford.grid.model.entity.Audit;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.LastModifiedDate;

import java.time.LocalDateTime;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LaunchActivityUnifiedUpdateRequest {
    private String populationId;
    private String regionId;

    // Region-level statuses
    private String govtSubmissionStatus;
    private String dealerBulletinStatus;
    private String ownerNotificationStatus;

    // Editorial Supplement statuses
    private List<EditorialSupplementStatus> editorialSupplementStatuses;
    private String updatedBy;
    @LastModifiedDate
    private LocalDateTime updatedAt;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class EditorialSupplementStatus {
        private String notificationTypeId;
        private String collectionType;
        private String status;
    }
}
