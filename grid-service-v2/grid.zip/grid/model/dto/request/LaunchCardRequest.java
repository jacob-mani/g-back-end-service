package com.ford.grid.model.dto.request;

import com.ford.grid.constants.ImplementationRating;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.*;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Builder
@Data
public class LaunchCardRequest extends Audit {

    @Schema(example = "507f1f77bcf86cd799439011")
    private String id;

    @Schema(example = "UH033")
    private String issueNumber;

    @Schema(example = "UH033")
    private String implId;

    @Schema(example = "UH033")
    private String populationId;

    @JsonProperty("implementationRating")
    private ImplementationRating implementationRating;

    @Schema(example = "UH033")
    private String rationale;

    @JsonProperty("attachments")
    @Schema(example = "UH033")
    private List<Attachment> attachments;

    @JsonProperty("deletedAttachments")
    @Schema(example = "[\"file1.pdf\", \"file2.docx\"]")
    private List<String> deletedAttachments;

    @JsonProperty("reimbursements")
    private List<Reimbursement> reimbursements;
}