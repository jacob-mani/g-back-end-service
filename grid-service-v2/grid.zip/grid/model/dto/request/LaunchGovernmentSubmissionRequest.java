package com.ford.grid.model.dto.request;

import com.ford.grid.model.entity.Audit;
import com.ford.grid.model.entity.GovSubNotificationType;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

@Data
@EqualsAndHashCode(callSuper = false)
public class LaunchGovernmentSubmissionRequest extends Audit {
    private String id;
    private String issueNumber;
    private String implId;
    private String populationId;
    private String regionId;
    private String regionStatus;
    private List<GovSubNotificationType> govSubNotificationTypes;
}
