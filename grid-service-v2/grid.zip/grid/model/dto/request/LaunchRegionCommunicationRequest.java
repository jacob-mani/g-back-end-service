package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.Attachment;
import com.ford.grid.model.entity.Audit;
import com.ford.grid.model.entity.RegionCommunication;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

@Data
@EqualsAndHashCode(callSuper = false)
public class LaunchRegionCommunicationRequest extends Audit {
    @Schema(example = "UH033")
    private String id;
    @Schema(example = "25-001")
    private String issueNumber;
    @Schema(example = "UH033")
    private String implId;
    @Schema(example = "UH033")
    private String populationId;
    @Schema(example = "UH033")
    private List<Attachment> attachments;
    @Schema(example = "[\"file1.pdf\", \"file2.docx\"]")
    @JsonProperty("deletedAttachments")
    private List<String> deletedAttachments;
    private Boolean communicationApplicable;

}
