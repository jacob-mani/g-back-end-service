package com.ford.grid.model.dto.request;

import com.ford.grid.model.entity.Audit;
import com.ford.grid.model.entity.LaunchOwnerNotificationType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LaunchRegionOwnerNotificationRequest extends Audit {
    private String id;
    private String issueNumber;
    private String implId;
    private String populationId;
    private String regionId;
    private String regionStatus;
    private List<LaunchOwnerNotificationType> notificationType;
}

