package com.ford.grid.model.dto.request;

import com.ford.grid.model.entity.Audit;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@EqualsAndHashCode(callSuper = false)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class MRACategorization extends Audit {

    private String vehicle;
    private String repair;
    private String inspection;

}
