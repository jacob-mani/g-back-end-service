package com.ford.grid.model.dto.request;

import com.ford.grid.model.entity.MarketMailTracking;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MarketMailTrackingRequest {
    private String populationId;
    private String regionId;
    private String notificationTypeId;
    private List<MarketMailTracking> mailTrackings;
    private String updatedBy;
}

