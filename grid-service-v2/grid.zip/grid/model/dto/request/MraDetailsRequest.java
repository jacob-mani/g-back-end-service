package com.ford.grid.model.dto.request;

import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Request to fetch MRA details by FSA numbers", additionalProperties = Schema.AdditionalPropertiesValue.FALSE)
public class MraDetailsRequest {

    @NotEmpty(message = "fsaNos must not be empty")
    @Size(min = 1, max = 100, message = "fsaNos must contain between 1 and 100 items")
    @ArraySchema(maxItems = 100, minItems = 1, schema = @Schema(description = "FSA number", example = "24S01", pattern = "^[A-Za-z0-9\\-]{1,20}$", maxLength = 20, minLength = 1))
    private List<@Size(min = 1, max = 20, message = "Each FSA number must be between 1 and 20 characters")
                 @Pattern(regexp = "^[A-Za-z0-9\\-]{1,20}$", message = "FSA number format is invalid") String> fsaNos;

    @Valid
    @Size(max = 500, message = "vehicles list must not exceed 500 items")
    @ArraySchema(maxItems = 500, schema = @Schema(implementation = MraVehicleRequest.class))
    private List<MraVehicleRequest> vehicles;
}