package com.ford.grid.model.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Vehicle filter for MRA details lookup", additionalProperties = Schema.AdditionalPropertiesValue.FALSE)
public class MraVehicleRequest {

    @Min(value = 1900, message = "modelYear must be at least 1900")
    @Max(value = 2100, message = "modelYear must not exceed 2100")
    @Schema(description = "Model year of the vehicle", example = "2024", minimum = "1900", maximum = "2100")
    private Integer modelYear;

    @Size(max = 50, message = "brandName must not exceed 50 characters")
    @Pattern(regexp = "^[A-Za-z0-9\\s\\-]{0,50}$", message = "brandName contains invalid characters")
    @Schema(description = "Brand name of the vehicle", example = "Ford", maxLength = 50, pattern = "^[A-Za-z0-9\\s\\-]{0,50}$")
    private String brandName;

    @Size(max = 100, message = "vehicleLine must not exceed 100 characters")
    @Pattern(regexp = "^[A-Za-z0-9\\s\\-/]{0,100}$", message = "vehicleLine contains invalid characters")
    @Schema(description = "Vehicle line name", example = "F-150", maxLength = 100, pattern = "^[A-Za-z0-9\\s\\-/]{0,100}$")
    private String vehicleLine;
}