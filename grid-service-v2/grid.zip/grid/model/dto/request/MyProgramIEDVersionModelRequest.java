package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.Audit;
import com.ford.grid.model.entity.MyProgramBucketModel;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Builder
@Data
public class MyProgramIEDVersionModelRequest extends Audit {
    @Schema(example = "507f1f77bcf86cd799439011")
    private String id;

    @Schema(example = "UH033")
    private String issueNumber;

    @Schema(example = "UH033")
    private String implId;

    @Schema(example = "UH033")
    private String fsa;

    @Schema(example = "1")
    @JsonProperty("iedVersion")
    private Integer iedVersion;

    @Schema(description = "List of My Program Bucket Models")
    @JsonProperty("myProgramBucketModelList")
    private List<MyProgramBucketModel> myProgramBucketModelList;
}
