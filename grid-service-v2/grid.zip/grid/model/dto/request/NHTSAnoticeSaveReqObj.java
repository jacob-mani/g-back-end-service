package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import com.ford.grid.model.entity.fdr.NHTSAnotice;
import lombok.Data;

@Data
public class NHTSAnoticeSaveReqObj {


    @JsonProperty("fdrModel")
    private FdrModel fdrModel;


    @JsonProperty("nhtsaNotice")
    private NHTSAnotice nhtsaNotice;

}
