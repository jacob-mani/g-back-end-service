package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.fdr.FdrAssemblyPlantNhtsaInfo;
import com.ford.grid.model.entity.fdr.FdrNoticeMakeModelInfo;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

@Data
public class NhtsaNoticeRequest {

    @JsonProperty("issueNumber")
    private String issueNumber;

    @JsonProperty("fsaNumber")
    private String fsaNumber;

    @JsonProperty("globalDirectorASO")
    private String globalDirectorASO;

    @JsonProperty("noticeDate")
    private LocalDateTime noticeDate;

    @JsonProperty("directorNHTSA")
    private String directorNHTSA;

    @JsonProperty("toName")
    private String toName;

    @JsonProperty("region")
    private String region;

    @JsonProperty("manufacturer")
    private String manufacturer;

    @JsonProperty("typeOfAction")
    private String typeOfAction;

    @JsonProperty("subject")
    private String subject;

    @JsonProperty("fdrNoticeMakeModelInfo")
    private List<FdrNoticeMakeModelInfo> fdrNoticeMakeModelInfo;

    @JsonProperty("fdrAssemblyPlantNhtsaInfo")
    private List<FdrAssemblyPlantNhtsaInfo> fdrAssemblyPlantNhtsaInfo;

    @JsonProperty("otherLimitingfactor")
    private String otherLimitingfactor;

    @JsonProperty("similarVehicles")
    private String similarVehicles;

    @JsonProperty("vehiclesAffected")
    private Integer vehiclesAffected;

    @JsonProperty("markets")
    private List<String> markets;

    @JsonProperty("estimatedPercentOfAffVechicles")
    private String estimatedPercentOfAffVechicles;

    @JsonProperty("noOfReportsOfTheCondition")
    private String noOfReportsOfTheCondition;

    @JsonProperty("descriptionOfRemedy")
    private String descriptionOfRemedy;

    @JsonProperty("approxRecallStartDate")
    private String approxRecallStartDate;

    @JsonProperty("reasonForFSA")
    private String reasonForFSA;
}
