package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Notification {
    private String notificationId;
    private String notificationType;
    private String notificationName;
    @JsonProperty("isEmail")
    private boolean isEmail;
    @JsonProperty("isWeb")
    private boolean isWeb;
    @JsonProperty("isLive")
    private boolean isLive;
    @JsonProperty("isTo")
    private boolean isTo;
    @JsonProperty("isCC")
    private boolean isCC;
}