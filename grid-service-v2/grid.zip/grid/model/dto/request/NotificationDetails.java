package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class NotificationDetails {
    // Original fields from database
    private String notificationId;
    private String issNum;
    private String issTtl;
    private String leadReg;
    private String notfnTyp;
    private String notfnTxt;
    private String notfnDtl;
    private Date notfnRecv;

    // Additional fields from database
    private String extraInfo;
    private String multiIndex;
    private String notfnRead;
    private String notfnCleared;
    private String notfnComeBack;
    private String eventDate;
    private List<String> notificationContacts;
    private String newUserCdsId;
    private String role;
    private String reason;
    @JsonProperty("accessRequestedBY")
    private String accessRequestedBy;
}