package com.ford.grid.model.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@AllArgsConstructor
@RequiredArgsConstructor
public class NotificationPreferencesRequest {
    private String cdsId;
    private String notificationType;
    private String notificationName;
    private boolean emailApplicable;
    private boolean webApplicable;
    private boolean liveApplicable;
    private boolean toApplicable;
    private boolean ccApplicable;
}