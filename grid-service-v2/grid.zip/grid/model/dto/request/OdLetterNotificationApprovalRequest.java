package com.ford.grid.model.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OdLetterNotificationApprovalRequest {
    private String issueNumber;
    private String userId;
    private String collabId;
    private String status;
    private String implId;
    private String populationId;
    private String[] brand;
    private String region;
    private Boolean urgency;
    private String title;
    private String actionBy;
    private String actionByRole;
}
