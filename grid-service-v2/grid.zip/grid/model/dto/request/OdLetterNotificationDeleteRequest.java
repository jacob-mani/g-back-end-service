package com.ford.grid.model.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OdLetterNotificationDeleteRequest {

        private String issueNumber;
        private String fsaNumber;
        private String fsaType;
        private String region;
        private String implId;
        private String populationId;
        private String brand;
        private String docGenStage;
    }

