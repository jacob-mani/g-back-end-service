package com.ford.grid.model.dto.request;

import com.ford.grid.model.entity.OdLetterCollab;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OdLetterNotificationUpsertRequest {
    private String issueNumber;
    private String implId;
    private String populationId;
    private String brand;
    private String region;
    private String campaignName;
    private String fsaNumber;
    private String createdBy;
    private List<OdLetterCollab> collabs;
    private String screenName;
    private String subject;
    private String docGenStage;
    private String updatedBy;
    private Date updatedAt;
}
