package com.ford.grid.model.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Unified payload for OD reviewer remove/reassign action.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class OdLetterReviewerActionRequest {
    private String actionType;
    private String issueNumber;
    private String region;
    private String collabId;
    private String oldCdsid;
    private String oldRole;
    private String implId;
    private String populationId;
    private String[] brand;
    private List<OdLetterReviewerContactRequest> customContacts;
    private String actionBy;
    private String fsaNumber;
}

