package com.ford.grid.model.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * New reviewer details from UI for REASSIGN actions.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class OdLetterReviewerContactRequest {
    private String id;
    private String name;
    private String cdsid;
    private String role;
    private String group;
}

