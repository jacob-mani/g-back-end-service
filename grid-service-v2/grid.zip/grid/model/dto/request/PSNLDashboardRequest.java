package com.ford.grid.model.dto.request;

import lombok.Data;

import java.util.List;

@Data
public class PSNLDashboardRequest {

    // Optional filters - Multi-select support
    private List<String> region;
    private List<String> supplyChainContact; // Search by supply chain CDSID or name
    private List<String> potentialIssueType;
    private List<String> purchaseLead; // Search by purchase lead CDSID or name

    private Boolean hasFsaNumber; // true = has FSA number, false = no FSA number, null = both

    private String programType; //nonApproved/ approved/ launch

    // General search across multiple fields (engineeringPartNumber, servicePartNumber, finisCode, etc.)
    private String search;

    // Pagination
    private int page = 0;
    private int size = 20;

    // Sorting
    private String sortBy = "populationId";
    private String sortDirection = "ASC";
}



