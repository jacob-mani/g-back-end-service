package com.ford.grid.model.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

import java.time.LocalDate;
import java.util.List;

/**
 * Request DTO for saving/updating PSNL part details.
 * partMasterId is the primary lookup key — backend resolves PartMaster by id.
 * Key fields (populationId, region, partMasterId) are required.
 */
@Data
public class PSNLPartDetailRequest {

    @NotBlank(message = "issueNumber is required")
    private String issueNumber;

    @NotBlank(message = "populationId is required")
    private String populationId;

    @NotBlank(message = "region is required")
    private String region;

    @NotBlank(message = "partMasterId is required")
    private String partMasterId;

    // Who is making this change (CDSID) and when
    private String updatedBy;
    private LocalDate updatedOn;

    // Non-editable fields (sent by UI for display, not persisted — resolved from PartMaster)
    private String engineeringPartNumber;
    private String servicePartNumber;
    private String finisCode;
    private String partName;
    private String criticalPartLaunchStrategy;
    private Boolean relatedDamagedPart;

    // Checkbox fields (null defaults to false)
    private Boolean partOk;
    private Boolean criticalPart;

    // Dropdown/boolean fields (nullable — user can clear selection)
    private Boolean kitRequired;
    private Boolean partsPrice;

    // String fields (null or "" = user cleared)
    private String pdc;
    private String purchasingSupportRequired;
    private String supplierCode;
    private String supplierName;
    private String freightMethod;
    private String stockStatus;
    private String partComment;

    // Numeric fields (null = user cleared)
    private Double forecast;
    private Double leadTimeMonth;
    private Double netInStockQuantity;
    private Double orderQuantity;

    // ETA fields — UI sends either an actual date or a target quarter (e.g. "2024,Q1"), not both
    private LocalDate etaActualDate;
    private String etaTargetQuarter;

    // Country-level editable details (partOk, partComment, eta per country)
    private List<CountryPartDetailRequest> countryQuantityDetails;
}



