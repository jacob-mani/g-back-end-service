package com.ford.grid.model.dto.request;

import com.ford.grid.model.dto.response.ContactDTO;
import com.ford.grid.model.dto.response.vehicleparts.PSNLMeetingNoteDTO;
import com.ford.grid.model.dto.response.vehicleparts.PSNLRegionInfoDTO;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PSNLShowDetailsUpdateRequest {

    @NotBlank
    private String populationId;

    @NotBlank
    private String issueNumber;

    @NotBlank
    private String region;

    /**
     * List of contacts. Only entries with isModified = true will be updated in issue_contacts.
     * Each ContactDTO has id (title), cdsid, name, label, and isModified flag.
     */
    private List<ContactDTO> contacts;

    /**
     * Region info fields. Always updated irrespective of values (including null).
     * Read-only fields (allPartOk, partOkUpdatedDate, partOkUpdatedBy) are ignored.
     */
    private PSNLRegionInfoDTO regionInfo;

    /**
     * Meeting notes (scm, purchasing). Only entries with isModified = true will be saved.
     * Saved as regionandfsa transient notes. Only processed if FSA number exists for the population.
     */
    private List<PSNLMeetingNoteDTO> meetingNotes;

    private String updatedBy;
}


