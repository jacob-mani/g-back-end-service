package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class Part573AIRequest {

    @NotBlank(message = "Issue number is required")
    @JsonProperty("issueNumber")
    private String issueNumber;

    @NotBlank(message = "Implementation ID is required")
    @JsonProperty("implId")
    private String implId;

    @NotBlank(message = "Implementation title is required")
    @JsonProperty("implTitle")
    private String implTitle;

    @NotBlank(message = "Issue type is required")
    @JsonProperty("issueType")
    private String issueType;

    @NotBlank(message = "Population ID is required")
    @JsonProperty("populationId")
    private String populationId;

    @JsonProperty("aiDataFlag")
    private boolean aiDataFlag;
}
