package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.Audit;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Part573AIUpdateRequest extends Audit {

    @JsonProperty("issueNumber")
    private String issueNumber;

    @JsonProperty("implId")
    private String implId;

    @JsonProperty("populationId")
    private String populationId;

    @JsonProperty("aiData")
    private AiData aiData;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class AiData {

        @JsonProperty("descriptive_info_output")
        @JsonAlias("concern_description_output")
        private String concernDescriptionOutput;

        @JsonProperty("safety_risk_description_output")
        private String safetyRiskDescriptionOutput;

        @JsonProperty("cause_description_output")
        private String causeDescriptionOutput;

        @JsonProperty("warning_output")
        private String warningOutput;

        @JsonProperty("chronology_output")
        private String chronologyOutput;

        @JsonProperty("fmvss_output")
        private String fmvssOutput;

        @JsonProperty("petition_for_noncompliance")
        private String petitionForNoncompliance;

        @JsonProperty("describe_safety_risk")
        private String describeSafetyRisk;

        @JsonProperty("describe_defect")
        private String describeDefect;

        @JsonProperty("describe_recall_schedule")
        private String describeRecallSchedule;

        @JsonProperty("remedy_component_distinction_output")
        private String remedyComponentDistinctionOutput;

        @JsonProperty("remedy_program_output")
        private String remedyProgramOutput;

        @JsonProperty("short_concern_summary")
        private String shortConcernSummary;
    }
}

