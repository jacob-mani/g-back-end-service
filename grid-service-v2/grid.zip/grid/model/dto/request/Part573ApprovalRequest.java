package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Part573ApprovalRequest {
    @NotBlank(message = "Issue number is required")
    private String issueNumber;

    @NotBlank(message = "Implementation ID is required")
    private String implId;

    @NotBlank(message = "Population ID is required")
    private String populationId;

    private String issueTitle;
    private String region;

    @JsonProperty("draftReviewer")
    private FrcApproversDto draftReviewer;

    @JsonProperty("finalReviewer")
    private FrcApproversDto finalReviewer;

    @JsonProperty("approversList")
    private List<FrcApproversDto> approversList;

    @JsonProperty("docStatus")
    private String status;

    @JsonProperty("approvalNotRequired")
    private boolean approvalNotRequired = false;
    private boolean isConcluded = false;
    private String concludedBy;

    @JsonProperty("concludedDate")
    private LocalDate concludedDate;
}

