package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.Audit;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
public class Part573FileDto extends Audit {

    @Schema(example = "UH033")
    @JsonProperty("docSubject")
    private String docSubject;

    @Schema(example = "2024-12-31")
    @JsonProperty("docTargetDate")
    private LocalDate docTargetDate;

    @Schema(example = "UH033")
    @JsonProperty("approversList")
    private List<FrcApproversDto> approversList;

    @JsonProperty("draftReviewer")
    private FrcApproversDto draftReviewer;

    @JsonProperty("finalReviewer")
    private FrcApproversDto finalReviewer;

    @Schema(example = "Missing vehicle VIN numbers and incorrect FSA")
    @JsonProperty("rejectionComments")
    private String rejectionComments;

    // Concluded fields
    @JsonProperty("concluded")
    private boolean concluded;

    @JsonProperty("concludedBy")
    private String concludedBy;

    @JsonProperty("concludedDate")
    private LocalDateTime concludedDate;

    // Approval status tracking fields
    @JsonProperty("draftReviewerStatus")
    private String draftReviewerStatus;

    @JsonProperty("approverStatus")
    private String approverStatus;

    @JsonProperty("finalReviewerStatus")
    private String finalReviewerStatus;

    @JsonProperty("approvalStatus")
    private String approvalStatus;

    // DocuSign fields
    @JsonProperty("docuSignEnvelopeId")
    private String docuSignEnvelopeId;

    @JsonProperty("docuSignStatus")
    private String docuSignStatus;

    @com.fasterxml.jackson.annotation.JsonIgnore
    private String docuSignFileName;

    @com.fasterxml.jackson.annotation.JsonIgnore
    private String docuSignFileNameGCP;

    @com.fasterxml.jackson.annotation.JsonIgnore
    private String signedDocumentUrl;
}

