package com.ford.grid.model.dto.request;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Part573StatusRequest {
    private String id;

    private String issueNumber;
    private String implId;
    private String populationId;
    private Integer currentStatus;
    private Integer draftReviewerStatus;
    private Integer finalReviewerStatus;
    private String statusLabel;
    private Boolean allApproved;
    private Boolean concluded;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private String updatedBy;
}

