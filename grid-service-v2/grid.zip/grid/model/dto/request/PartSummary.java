package com.ford.grid.model.dto.request;

import com.ford.grid.model.entity.Audit;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@EqualsAndHashCode(callSuper = false)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PartSummary extends Audit {

    private String enggPartNumber;
    private String servicePartNumber;
    private String finisNumber;
    private String partName;
    private String partType;
    private Integer qtyPerRepair;
    private Integer totalQuantity;
    private Integer launchQuantity;
    private String concernNo;
    private String wersNoticeNo;
    private String swadNo;
    private Boolean isMisc;
}
