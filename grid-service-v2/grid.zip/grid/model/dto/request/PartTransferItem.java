package com.ford.grid.model.dto.request;

import com.ford.grid.model.entity.CountryTransferDetail;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

import java.util.List;

/**
 * A single part with its countries for a transfer request.
 * partMasterId is the primary lookup key — backend resolves PartMaster by id.
 */
@Data
public class PartTransferItem {

    @NotBlank(message = "partMasterId is required")
    private String partMasterId;

    // Part info sent by UI for display/error messages
    private String engineeringPartNumber;
    private String servicePartNumber;
    private String finisCode;
    private String partName;

    @NotEmpty(message = "countries is required")
    private List<CountryTransferDetail> countries;
}
