package com.ford.grid.model.dto.request;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.time.LocalDate;
import java.util.List;

/**
 * Request DTO for creating part transfer requests.
 * Supports multiple parts, each with multiple countries.
 * Service creates one document per country per part.
 */
@Data
public class PartTransferRequestDTO {

    @NotBlank(message = "populationId is required")
    private String populationId;

    @NotBlank(message = "issueNumber is required")
    private String issueNumber;

    @NotBlank(message = "sourceRegion is required")
    private String sourceRegion;

    @NotBlank(message = "targetRegion is required")
    private String targetRegion;

    @NotEmpty(message = "parts is required")
    @Valid
    private List<PartTransferItem> parts;

    @NotBlank(message = "requestedBy is required")
    private String requestedBy;


    @NotNull(message = "requestedDate is required")
    private LocalDate requestedDate;

    private String comments;
}

