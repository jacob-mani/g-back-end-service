package com.ford.grid.model.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

import java.util.List;

/**
 * Request DTO for undoing part transfer requests.
 * Accepts multiple transferIds to undo single or multiple countries at once.
 */
@Data
public class PartTransferUndoRequest {

    @NotBlank(message = "populationId is required")
    private String populationId;

    @NotBlank(message = "issueNumber is required")
    private String issueNumber;

    @NotBlank(message = "updatedBy is required")
    private String updatedBy;

    @NotEmpty(message = "transferIds is required")
    private List<String> transferIds;
}


