package com.ford.grid.model.dto.request;

import com.ford.grid.model.entity.Audit;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = false)
public class PdfBasicDetailRequest extends Audit {
    private String issueNumber;
    private String   printedBy;
    private String  status;
    private String  xnumber;
    private String  fsaNumber;
    private String  frcDate;
    private String currentDirUsers;
    private String affectedVehicle;
    private String disabledCards;
}
