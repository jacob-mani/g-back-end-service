package com.ford.grid.model.dto.request;


import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.Audit;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class PopulationAndImplementationDetail extends Audit {

    @Schema(example = "25-001")
    @JsonProperty("issueNumber")
    @NotBlank(message = "Issue number must not be null or blank")
    private String issueNumber;

    @Schema(example = "25-001-1")
    @JsonProperty("implId")
    @NotBlank(message = "Implementation ID must not be null or blank")
    private String implId;

    @Schema(example = "25-001-1-0")
    @JsonProperty("populationId")
    @NotBlank(message = "Population ID must not be null or blank")
    private String populationId;

    @Schema(example = "Safety")
    @JsonProperty("potentialIssueType")
    @NotBlank(message = "potential issue must not be null or blank")
    private String potentialIssueType;

    @Schema(example = "12345")
    @JsonProperty("globalFsa")
    private Integer globalFsa;//Global Fsa Number

    @Schema(example = "25S01")
    @JsonProperty("fsaNumber")
    private String fsaNumber;

    @Schema(example = "Potential Safety Issue")
    @JsonProperty("potentialFsaName")
    @NotBlank(message = "Potential FSA name must not be null or blank")
    private String potentialFsaName;

    @Schema(example = "true")
    @JsonProperty("otaIndicator")
//    @NotNull(message = "OTA Indicator must not be null")
    private Boolean otaIndicator;

    @Schema(example = "[\"12EB23\",\"34HT78\"]")
    @JsonProperty("stopShip")
    @NotEmpty(message = "Stop ship list must not be null or empty")
    private List<String> stopShip;

    @Schema(example = "John Doe")
    @JsonProperty("taskOwner")
    private String taskOwner;

    @Schema(example = "true")
    @JsonProperty("vernExtractReviewRequired")
    private Boolean vernExtractReviewRequired;

    @Schema(example = "25-001-1-0-V01")
    @JsonProperty("vernNumber")
    private String vernNumber;

    @Schema(example = "true")
    @JsonProperty("manualPopulationDeleteUpdate")
    private boolean manualPopulationDeleteUpdate = false;
}
