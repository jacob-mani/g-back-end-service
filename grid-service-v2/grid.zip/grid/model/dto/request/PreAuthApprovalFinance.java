package com.ford.grid.model.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PreAuthApprovalFinance {


    List<LDAPName> sendTo;
    List<LDAPName> sendCC;
    String emailBody;
    boolean mailSent;
    boolean send;
    boolean sendExtract;
    boolean sendParts;
    String populationFile;
    String partRequirementFile;
    boolean completed;
    LocalDate completionDate;
    //String updatedBy;

}

