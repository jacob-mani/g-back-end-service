package com.ford.grid.model.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PreAuthCalculateParts {

    String reqCalcParts;
    String reqCalcPartsMsg;
    //@Min(0)
    Double totalCost;
    //@Min(0)
    Double launchCost;
    List<PreAuthParts> combinedList;
    List<PreAuthParts> confirmedList;
    boolean completed;
    //String updatedBy;
    LocalDate completionDate;
}

