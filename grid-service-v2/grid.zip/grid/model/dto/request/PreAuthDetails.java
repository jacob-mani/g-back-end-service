package com.ford.grid.model.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PreAuthDetails {

    //Analyst requestedBy;
    LocalDate requestedOn;
    //Analyst approvedBy;
    LocalDate approvedOn;
    LocalDate completionDate;
    //Analyst concurrenceBy;
    LocalDate concurrenceOn;
    boolean notify;
    boolean completed;
    //String updatedBy;
}

