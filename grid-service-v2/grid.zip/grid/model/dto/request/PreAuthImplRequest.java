package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.Audit;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = false)
@Data
public class PreAuthImplRequest extends Audit {
    @JsonProperty("issueNumber")
    @NotBlank(message = "Issue Number must not be null or blank")
    private String issueNumber;
    private String forumType;
    private PreAuthRequestExtn preAuthRequest;
    private PreAuthPopulationExtn preAuthPopulation;
    private PreAuthRepairProcedure preAuthRepairProcedure;
    private PreAuthPartsRequirement preAuthPartsRequirement;
    private PreAuthCalculateParts preAuthCalculateParts;
    private PreAuthApprovalFinance preAuthApprovalFinance;
    private PreAuthDetails preAuthDetails;
}
