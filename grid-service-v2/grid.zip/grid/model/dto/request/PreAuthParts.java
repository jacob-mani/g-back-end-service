package com.ford.grid.model.dto.request;

import com.ford.grid.model.entity.PartMaster;
import jakarta.validation.constraints.Min;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.DBRef;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PreAuthParts {

    String engineeringPartNumber;
    String servicePartNumber;
    String finisCode;
    String partName;
    @DBRef
    private PartMaster part;
    Double launchQuantity;
    @Min(0)
    Double totalQuantity;
    @Min(0)
    Double cost;
    String preAuthReason;
    @Min(0)
    Double preAuthAmount;
    @Min(0)
    Double authorizedAmount;
    @Min(0)
    Double grandTotal;

    public String getEngineeringPartNumber() {
        return part != null ? part.getEngineeringPartNumber() : engineeringPartNumber;
    }

    public String getServicePartNumber() {
        return part != null ? part.getServicePartNumber() : servicePartNumber;
    }

    public String getFinisCode() {
        return part != null ? part.getFinisCode() : finisCode;
    }

    public String getPartName() {
        return part != null ? part.getPartName() : partName;
    }


}
