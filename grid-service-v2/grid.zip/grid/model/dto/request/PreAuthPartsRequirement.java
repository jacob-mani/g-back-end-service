package com.ford.grid.model.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PreAuthPartsRequirement {

    String population;
    String reqPopulationMsg;
    String reqPopulation;
    String reqAnotherPopulationMsg;
    String reqAnotherPopulation;
    boolean isNa;
    boolean completed;
    //LocalDate completionDate;--getfrom audit
    //String updatedBy;--get from audit

}

