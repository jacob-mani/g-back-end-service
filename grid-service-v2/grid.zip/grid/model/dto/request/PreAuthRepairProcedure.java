package com.ford.grid.model.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PreAuthRepairProcedure {

    String reqProfile;
    String requestProfileMsg;
    boolean completed;
    boolean notApplicable;
    List<VehicleProfileModel> repairProcedures;
    LocalDate completionDate;
    //String updatedBy;

}

