package com.ford.grid.model.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PreAuthRequestExtn {

    List<String> preAuthType;
    String reason;
    //Analyst requestedBy;--get from audit
    boolean completed;
    //LocalDate completionDate;--get from audit

}

