package com.ford.grid.model.dto.request;

import com.ford.grid.model.entity.Audit;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.LocalDate;
import java.util.List;

@EqualsAndHashCode(callSuper = false)
@Data
public class PreAuthTab5Request extends Audit {
    private String issueNumber;
    private String forumType;
    private String reqCalcParts;
    private String reqCalcPartsMsg;
    private Double totalCost;
    private Double launchCost;
    List<PreAuthParts> combinedList;
    List<PreAuthParts> confirmedList;
    private boolean completed;
    private LocalDate completionDate;

}
