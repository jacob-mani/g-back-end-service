package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.Audit;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.LocalDate;
import java.util.List;

@EqualsAndHashCode(callSuper = false)
@Data
public class PreAuthTab6Request extends Audit {
    @JsonProperty("issueNumber")
    @NotBlank(message = "Issue Number must not be null or blank")
    private String issueNumber;
    private String forumType;
    private List<LDAPName> sendTo;
    private List<LDAPName> sendCC;
    private String emailBody;
    private boolean mailSent;
    private boolean send;
    private boolean sendExtract;
    private boolean sendParts;
    private String populationFile;
    private String partRequirementFile;
    private String populationFileSignedUrl;
    private String partRequirementFileSignedUrl;
    private boolean completed;
    private List<String> deletedAttachments;
    private LocalDate completionDate;
}

