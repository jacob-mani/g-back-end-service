package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.Audit;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.LocalDate;

@EqualsAndHashCode(callSuper = false)
@Data
public class PreAuthTab7Request extends Audit {
    @JsonProperty("issueNumber")
    @NotBlank(message = "Issue Number must not be null or blank")
    private String issueNumber;
    private String forumType;
    private String requestedBy;
    private LocalDate requestedOn;
    private String approvedBy;
    private LocalDate approvedOn;
    private LocalDate completionDate;
    private String concurrenceBy;
    private LocalDate concurrenceOn;
    private boolean notify;
    private boolean completed;

}

