package com.ford.grid.model.dto.request;

import com.ford.grid.model.entity.Audit;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

@Data
@EqualsAndHashCode(callSuper = false)
public class PreAuthTabMiddleRequest extends Audit {
    private String issueNumber;
    private String forumType;
    private int type; // e.g., "Pre-Auth Tab 2 or 3 or 4"
    private String populationId;
    private boolean populationRequired;
    private boolean notApplicable;
    private String notes;
//    private List<LDAPName> sendTo;
//    private List<LDAPName> sendCC;
}
