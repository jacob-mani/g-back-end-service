package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.Audit;
import com.ford.grid.model.entity.Contacts;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

@Data
@EqualsAndHashCode(callSuper = false)
public class PreDefinedContactsRequest extends Audit{

    @Schema(example = "UH033")
    private String id;
    @Schema(example = "UH033")
    @JsonProperty("region")
    @NotBlank(message = "Region must not be null or blank")
    private String region;

    @Schema(example = "UH033")
    @JsonProperty("segment")
    @NotBlank(message = "Segment must not be null or blank")
    private String segment;

    @Schema(example = "UH033")
    @JsonProperty("contacts")
    @NotBlank(message = "Contacts must not be null or blank")
    private  List<Contacts> contacts;

    @Schema(example = "UH033")
    @JsonProperty("groupId")
    @NotBlank(message = "groupId must not be null or blank")
    private String groupId;

}
