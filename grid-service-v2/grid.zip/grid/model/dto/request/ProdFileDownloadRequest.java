package com.ford.grid.model.dto.request;

import lombok.Data;

import java.util.List;

/**
 * Request DTO for downloading files from prod GCP bucket and optionally uploading to lower environment.
 */
@Data
public class ProdFileDownloadRequest {

    /**
     * List of GCS file names to download from prod bucket.
     */
    private List<String> gcsFileNames;

    /**
     * Local folder path to save downloaded files.
     * Default: ./prod-downloads
     */
    private String downloadFolder = "./prod-downloads";

    /**
     * Prod API authentication token (Bearer token).
     * Required for accessing prod signed URL API.
     */
    private String prodToken;

    /**
     * Flag to upload downloaded files to lower environment GCP bucket.
     * Default: false
     */
    private boolean uploadToLowerEnv = false;

    /**
     * Optional: Custom GCS folder prefix for uploaded files.
     * If not provided, files will be uploaded with their original names.
     */
    private String uploadFolderPrefix;

    /**
     * Preprod API authentication token (Bearer token).
     * Required when uploadToLowerEnv is true. Used to get signed URL from preprod API for uploading files.
     */
    private String preprodToken;

    /**
     * Target environment for upload: "preprod", "qa", or "dev".
     * Default: "preprod"
     */
    private String targetEnv = "preprod";
}

