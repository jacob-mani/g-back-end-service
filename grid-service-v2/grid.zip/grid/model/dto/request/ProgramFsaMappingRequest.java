package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.Audit;
import com.ford.grid.model.entity.NodeAddress;
import com.ford.grid.model.entity.PartsData;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;


import java.util.List;

@Data
@Builder
@EqualsAndHashCode(callSuper = false)
public class ProgramFsaMappingRequest extends Audit {
    @JsonProperty("id")
    private String id;

    @JsonProperty("issueNumber")
    private String issueNumber;

    @JsonProperty("implId")
    private String implId;

    @JsonProperty("populationId")
    private String populationId;

    @JsonProperty("localFsa")
    private String localFsa;

    @JsonProperty("globalFsa")
    private String globalFsa;

    @JsonProperty("programCode")
    private String programCode;

    @JsonProperty("modelYear")
    private String modelYear;

    @JsonProperty("nodeAddress")
    private List<NodeAddress> nodeAddress;

    @JsonProperty("isSoftwareParts")
    private Boolean isSoftwareParts;

    @JsonProperty("isConfiguration")
    private Boolean isConfiguration;

    @JsonProperty("isVINexclude")
    private Boolean isVINexclude;

    @JsonProperty("isOta")
    private Boolean isOta;

    @JsonProperty("isSubmitted")
    private Boolean isSubmitted;

    @JsonProperty("partsData")
    private List<PartsData> partsData;

}
