package com.ford.grid.model.dto.request;

import com.ford.grid.model.entity.PartMaster;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.DBRef;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PurgePart {

    @DBRef
    private PartMaster part;

    private String engineeringPartNumber;
    private String servicePartNumber;
    private String finisCode;
    private String partName;

    private String purgeStatus;
    private LocalDate completionDate;
    private LocalDate lastUsedDate;
    private String comments;

    public String getEngineeringPartNumber() {
        return part != null ? part.getEngineeringPartNumber() : engineeringPartNumber;
    }

    public String getServicePartNumber() {
        return part != null ? part.getServicePartNumber() : servicePartNumber;
    }

    public String getFinisCode() {
        return part != null ? part.getFinisCode() : finisCode;
    }

    public String getPartName() {
        return part != null ? part.getPartName() : partName;
    }
}
