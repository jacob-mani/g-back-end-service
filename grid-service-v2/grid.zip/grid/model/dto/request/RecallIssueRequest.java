package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.Attachment;
import com.ford.grid.model.entity.Audit;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.LocalDate;
import java.util.List;

@Data
@EqualsAndHashCode(callSuper = false)
public class RecallIssueRequest extends Audit {

    @Schema(example = "UH033")
    private String id;

    @Schema(example = "UH033")
    @JsonProperty("issueNumber")
    private String issueNumber;

    @Schema(example = "UH033")
    @JsonProperty("openedDate")
    @NotNull(message = "Issue open date must not be null")
    private LocalDate openedDate;

    @Schema(example = "UH033")
    @JsonProperty("issueTitle")
    @NotBlank(message = "Issue title must not be null or blank")
    private String issueTitle;

    @Schema(example = "UH033")
    @JsonProperty("issueDescription")
    @NotBlank(message = "Issue description must not be null or blank")
    @Size(max = 5000, message = "Description cannot exceed 5000 characters")
    private String issueDescription;

    @Schema(example = "UH033")
    @JsonProperty("issuePhase")
    @NotBlank(message = "Phase must not be null or blank")
    private String issuePhase;

    @Schema(example = "UH033")
    @JsonProperty("issueType")
    private String issueType;

    @Schema(example = "UH033")
    @JsonProperty("leadRegion")
    @NotBlank(message = "Region must not be null or blank")
    private String leadRegion;

    @Schema(example = "UH033")
    @JsonProperty("segment")
    @NotBlank(message = "Segment must not be null or blank")
    private String segment;

    @Schema(example = "UH033")
    @JsonProperty("forumType")
    @NotBlank(message = "Forum type must not be null or blank")
    private String forumType;

    @Schema(example = "UH033")
    @JsonProperty("forumOpenDate")
    @NotNull(message = "Forum open date must not be null")
    private LocalDate forumOpenDate;

    @Schema(example = "UH033")
    @JsonProperty("issueRelatedItems")
    private String issueRelatedItems;

    @Schema(example = "UH033")
    @JsonProperty("isMyIssueDisplay")
    private Boolean isMyIssueDisplay;

    @Schema(example = "UH033")
    @JsonProperty("causalTypes")
    @NotEmpty(message = "Causal Types must not be null or empty")
    private List<Integer> causalTypes;

    @Schema(example = "UH033")
    @JsonProperty("causalTypeOther")
    private String causalTypeOther;

    @Schema(example = "1")
    @JsonProperty("function")
    private List<Integer> function;

    @Schema(example = "Other function details")
    @JsonProperty("functionOther")
    private String functionOther;

    @Schema(example = "UH033")
    @JsonProperty("disableEmails")
    private Boolean disableEmails;

    @Schema(example = "UH033")
    @JsonProperty("baseVehicleCriteria")
    private List<BaseVehicleCriteriaRequest> baseVehicleCriteria;

    @Schema(example = "UH033")
    @JsonProperty("imagesToDelete")
    private List<String> imagesToDelete;

    @Schema(example = "UH033")
    @JsonProperty("images")
    private List<Attachment> images;

    @Schema(example = "UH033")
    @JsonProperty("agency")
    private String agency;

    @JsonProperty("alertId")
    private String alertId;

    @JsonProperty("proIds")
    private List<String> proIds;

    @JsonProperty("relatedAlertIds")
    private List<String> relatedAlertIds;

    @JsonProperty("issueCreatedSystem")
    private String issueCreatedSystem;
}
