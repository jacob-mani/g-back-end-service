package com.ford.grid.model.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RemoveExpiredNotificationReq {
    private String category;
    private String type;
    private String issNum;
    private List<String> contactsList;
    private String detailContains;
}

