package com.ford.grid.model.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ReorderTabRequest {

    @Valid
    @NotEmpty(message = "tabs list must not be empty")
    @Schema(description = "Ordered list of tab entries with their new columnIndex values")
    private List<TabOrderEntry> tabs;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class TabOrderEntry {

        @NotBlank(message = "Tab id must not be blank")
        @Schema(example = "507f1f77bcf86cd799439011", description = "Custom view document _id")
        private String id;

        @NotNull(message = "columnIndex is required")
        @Schema(example = "4", description = "New columnIndex position for this tab")
        private Integer columnIndex;
    }
}
