package com.ford.grid.model.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

import java.util.List;

/**
 * Request DTO for saving TRG Recommendations on issue-level TRG schedule agenda items.
 *
 * <p>Structure:
 * <ul>
 *   <li>{@code issueNumber} + {@code updatedBy} at the top level</li>
 *   <li>{@code trgRecommendationsList} — array of recommendation entries, each matched to an agenda by {@code sequenceId}</li>
 * </ul>
 */
@Data
public class SaveTrgRecommendationRequest {

    @Schema(description = "Issue number", example = "25-521")
    @NotBlank
    private String issueNumber;

    @Schema(description = "User performing the save", example = "JDOE1")
    private String updatedBy;

    @Schema(description = "List of TRG recommendation entries to save")
    @NotEmpty
    @Valid
    private List<TrgRecommendationEntry> trgRecommendationsList;

    /**
     * A single TRG Recommendation entry to be added to the agenda item
     * identified by {@code sequenceId}.
     */
    @Data
    public static class TrgRecommendationEntry {

        @Schema(description = "Sequence ID of the agenda item in trgSchedule[]", example = "1")
        private Integer sequenceId;

        @Schema(description = "Program type", example = "Recall")
        private String programType;

        @Schema(description = "Population ID — links recommendation to a specific population",
                example = "25-521-3-0")
        private String populationId;

        @Schema(description = "Meeting title", example = "Safety TRG - Q3 Review")
        private String meetingTitle;

        @Schema(description = "Potential FSA Name (passed from UI, stored for reference)",
                example = "Initial")
        private String potentialFsaName;

        @Schema(description = "Comments / recommendation details",
                example = "Recommend field action for affected population")
        private String comments;

        @Schema(description = "Regions list", example = "[\"NA\", \"EU\"]")
        private List<String> regions;
    }
}
