package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.Attachment;
import com.ford.grid.model.entity.Audit;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.LocalDate;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Builder
@Data
public class SchForumAgeRequest extends Audit {
    @Schema(example = "UH033")
    @JsonProperty("id")
    private String id;
    @Schema(example = "UH033")
    @JsonProperty("fsamStatus")
    private List<String> fsamStatus;
    @Schema(example = "UH033")
    @JsonProperty("meetingDate")
    private List<LocalDate> meetingDate;
    @Schema(example = "UH033")
    @JsonProperty("addToFSAM")
    private boolean addToFSAM;
    @Schema(example = "UH033")
    @JsonProperty("forumType")
    private String forumType;
    @Schema(example = "UH033")
    @JsonProperty("agency")
    private String agency;
    @Schema(example = "UH033")
    @JsonProperty("issueNumber")
    private String issueNumber;
    @Schema(example = "UH033")
    @JsonProperty("attachments")
    private List<Attachment> attachments;
    @Schema(example = "[\"file1.pdf\", \"file2.docx\"]")
    @JsonProperty("deletedAttachments")
    private List<String> deletedAttachments;

}
