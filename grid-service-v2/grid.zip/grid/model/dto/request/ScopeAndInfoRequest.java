package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.*;
import com.ford.it.entity.validation.NotBlank;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class ScopeAndInfoRequest extends Audit {

    @Schema(example = "ISSUE-12345")
    @JsonProperty("issueNumber")
    private String issueNumber;

    @Schema(example = "engine")
    @JsonProperty("commodity")
    private String commodity;

    @JsonProperty("leadVehicleEngineeringActivity")
    private String leadVehicleEngineeringActivity;

    @Schema(example = "Private")
    @JsonProperty("sourceType")
    @NotBlank(message = "sourceType is mandatory")
    private String sourceType;

    @JsonProperty("isGovInvestigationRequired")
    private boolean isGovInvestigationRequired;

    @Schema(example = "2025-09-15")
    @JsonProperty("govFollowupDate")
    private LocalDate govFollowupDate;

    @Schema(example = "US")
    @JsonProperty("reportingMarket")
    private String reportingMarket;

    @JsonProperty("attachments")
    private List<Attachment> attachments;

    @JsonProperty("causalPartName")
    private String causalPartName;

    @JsonProperty("causalPartNumber")
    private String causalPartNumber;

    @JsonProperty("keyDates")
    private KeyDates keyDates;

    @JsonProperty("causalTypes")
    @NotEmpty(message = "causalTypes cannot be empty")
    private List<Integer> causalTypes;

    @JsonProperty("causalTypeOther")
    private String causalTypeOther;

    @JsonProperty("function")
    @NotEmpty(message = "function cannot be empty")
    private List<Integer> function;

    @JsonProperty("functionOther")
    private String functionOther;

    @JsonProperty("stopShips")
    private List<StopShip> stopShips;

    @JsonProperty("comment")
    private String comment;

    @JsonProperty("affectedRegions")
    private List<AffectedRegion> affectedRegions;

    @JsonProperty("assemblyPlants")
    private List<String> assemblyPlants;
}
