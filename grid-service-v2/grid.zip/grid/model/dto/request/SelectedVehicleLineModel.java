package com.ford.grid.model.dto.request;

import jakarta.validation.constraints.Min;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SelectedVehicleLineModel {

    String partName;
    @Min(0)
    Double quantity;
    @Min(0)
    Double takeRate;
}

