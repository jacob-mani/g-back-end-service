package com.ford.grid.model.dto.request;

import lombok.Data;


@Data
public class ShareCustomViewRequest {
    private String senderId;
    private String receiverId;
    private String customViewName;
}


