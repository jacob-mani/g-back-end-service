package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.dto.BaseDidMapping;
import com.ford.grid.model.entity.Audit;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Builder
@Data
@JsonInclude(JsonInclude.Include.ALWAYS)
public class SoftwarePartsFsaRequest extends Audit {
    @Schema(example = "507f1f77bcf86cd799439011")
    private String id;

    @JsonProperty("issueNumber")
    @Schema(example = "UH033")
    private String issueNumber;

    @JsonProperty("implId")
    @Schema(example = "UH033")
    private String implId;


    @JsonProperty("noticeNo")
    @Schema(example = "UH033")
    private String noticeNo;

    @JsonProperty("partNo")
    @Schema(example = "UH033")
    private String partNo;

    @JsonProperty("partName")
    @Schema(example = "UH033")
    private String partName;

    @JsonProperty("partType")
    @Schema(example = "UH033")
    private String partType;

    @JsonProperty("partBase")
    @Schema(example = "UH033")
    private String partBase;

    @JsonProperty("partPrefix")
    @Schema(example = "UH033")
    private String partPrefix;

    @JsonProperty("partSuffix")
    @Schema(example = "UH033")
    private String partSuffix;


    @JsonProperty("myPgmFsaId")
    @Schema(example = "UH033")
    private List<String> myPgmFsaId;

    private BaseDidMapping baseDidMapping;

}
