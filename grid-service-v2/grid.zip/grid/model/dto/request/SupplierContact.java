package com.ford.grid.model.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SupplierContact {

    private String desc;
    private String addr1;
    private String addr2;
    private String city;
    private String state;
    private String zipCode;
    private String country;
    private String firstName;
    private String lastName;
    private String position;
    private String phone;
    private String email;

}
