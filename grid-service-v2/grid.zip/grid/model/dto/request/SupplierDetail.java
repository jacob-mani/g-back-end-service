package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.Attachment;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SupplierDetail {

    private String title;
    private List<SupplierContact> contacts;
    private List<Attachment> attachments;
    private List<String> tags;
    @JsonProperty("isNotApplicable")
    private boolean isNotApplicable;

}
