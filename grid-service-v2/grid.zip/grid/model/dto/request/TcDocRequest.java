package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.Audit;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.data.mongodb.core.index.Indexed;

import java.time.LocalDate;

@Data
@EqualsAndHashCode(callSuper = false)
public class TcDocRequest extends Audit {
    @Schema(example = "UH033")
    private String id;

    @Schema(example = "UH033")
    @JsonProperty("issueNumber")
    @Indexed(unique = true)
    @NotBlank(message = "Issue number must not be null or blank")
    private String issueNumber;

    @Schema(example = "UH033")
    @JsonProperty("implId")
    @NotNull(message = "Implementation Id date must not be null")
    private String implId;

    @Schema(example = "UH033")
    @JsonProperty("populationId")
    @NotNull(message = "Population Id date must not be null")
    private String populationId;

    @Schema(example = "UH033")
    @JsonProperty("issueTitle")
    @NotBlank(message = "Issue Title must not be null or blank")
    private String issueTitle;

    @Schema(example = "UH033")
    @JsonProperty("region")
    @NotBlank(message = "region must not be null or blank")
    private String region;

    @Schema(example = "UH033")
    @JsonProperty("docTargetDate")
    @NotNull(message = "FactSheet Target Date must not be null")
    private LocalDate docTargetDate;


    @Schema(example = "UH033")
    @JsonProperty("factSheetFileName")
    //NotBlank(message = "FactSheet FileName must not be null or blank")
    private String factSheetFileName;

    @Schema(example = "UH033")
    @JsonProperty("factSheetFileUrl")
    //@NotBlank(message = "FactSheet FileUrl must not be null or blank")
    private String factSheetFileUrl;

    @JsonProperty("docFile")
    private Part573FileDto docFile;
}
