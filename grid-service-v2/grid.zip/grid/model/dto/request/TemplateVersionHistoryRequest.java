package com.ford.grid.model.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Request payload for retrieving the version history of a specific template classification.
 * All fields are used together to identify the exact template entry within
 * the {@code document_templates} collection.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TemplateVersionHistoryRequest {
    @NotBlank(message = "region is required")
    private String region;
    @NotBlank(message = "market is required")
    private String market;
    @NotBlank(message = "potentialType is required")
    private String potentialType;
    /** Matches against {@code brandType[].brandName} in the document_templates collection (case-insensitive). */
    @NotEmpty(message = "brandType is required and must have at least one value")
    private List<String> brandType;
    /** Matches against {@code brandType[].templates[].communicationGoal} (case-insensitive). */
    @NotBlank(message = "templateType is required")
    private String templateType;
}
