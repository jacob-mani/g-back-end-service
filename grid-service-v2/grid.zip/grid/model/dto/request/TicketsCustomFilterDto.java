package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.annotation.Nullable;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TicketsCustomFilterDto {

    @Nullable
    @Size(min = 0, max = 200, message = "category length should not exceed 200.")
    @Pattern(regexp = "^[-a-zA-Z0-9_ ]*$", message = "Invalid category")
    @Schema(example = "feedbackType")
    @JsonProperty("category")
    private String category;

    @Nullable
    @Size(min = 0, max = 200, message = "condition length should not exceed 200.")
    @Pattern(regexp = "^[-a-zA-Z0-9_ ]*$", message = "Invalid condition")
    @Schema(example = "Is")
    @JsonProperty("condition")
    private String condition;

    @Schema(example = "[\"Bug\", \"Suggestion\"]")
    @JsonProperty("criteria")
    private List<String> criteria;
}

