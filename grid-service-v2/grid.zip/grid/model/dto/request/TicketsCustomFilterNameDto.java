package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.annotation.Nullable;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TicketsCustomFilterNameDto {

    @Nullable
    @Size(min = 0, max = 200, message = "filterName length should not exceed 200.")
    @Pattern(regexp = "^[-a-zA-Z0-9.{}\\[\\]`<>'':=*!@^%$;+,#&()\\\\/_ ]*$", message = "Invalid filterName")
    @Schema(example = "My Bugs")
    @JsonProperty("filterName")
    private String filterName;

    @Schema(description = "List of filter criteria for this named filter")
    @JsonProperty("customFilterNames")
    private List<TicketsCustomFilterDto> customFilterNames;
}

