package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.Attachment;
import com.ford.grid.model.entity.RegionsRecommended;
import com.ford.grid.model.entity.TrgRecommendation;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.time.LocalDate;
import java.util.List;

@Data
public class TrgAgendaDto {
    @Schema(example = "1")
    private int sequenceId;
    @Schema(example = "AGD12345")
    private String agendaId;
    @Schema(example = "Technical")
    private String trgType;
    @Schema(example = "2025-09-25")
    private LocalDate meetingDate;
    private String trgMeetingType;
    @Schema(example = "Engine safety discussion")
    private String topicDescription;
    @Schema(description = "Duration of the meeting in a human-readable format, such as '2 hours' or '90 minutes'.", example = "2 hours")
    private String duration;
    @Schema(example = "CCRG Team A")
    private String ccrgTeam;
    private String ccmContact;
    @JsonProperty("ccmContactCdsid")
    private String ccmCdsId;
    private String cceContact;
    @JsonProperty("cceContactCdsid")
    private String cceCdsId;
    private String asoEngineer;
    @JsonProperty("asoEngineerCdsid")
    private String asoCdsId;
    private String dri;
    @JsonProperty("driCdsid")
    private String driCdsId;
    private String responsibleDirector;
    @JsonProperty("responsibleDirectorCdsid")
    private String responsibleDirectorCdsId;
    private String criticalParticipantSupport;
    @JsonProperty("cpsCdsid")
    private String cpsCdsId;
    private String trgPresenter;
    @JsonProperty("trgPresenterCdsid")
    private String trgPresenterCdsId;
    @Schema(example = "[\"NA\", \"EU\", \"APAC\"]")
    private List<String> regionalParticipation;
    @Schema(example = "IMG1")
    private String imgParticipation;
    @Schema(example = "Scheduled")
    private String trgStatus;
    @Schema(example = "Need to finalize slides")
    private String notes;
    @Schema(example = "true")
    @JsonProperty("followUp")
    private Boolean followUp;
    @Schema(example = "2025-10-10")
    @JsonProperty("followUpDate")
    private LocalDate followUpDate;
    @Schema(description = "TRG recommendations details")
    private List<TrgRecommendation> trgRecommendations;
    private List<RegionsRecommended> regionsRecommended;
    @Schema(example = "2025-09-20")
    @JsonProperty("earliestDate")
    private LocalDate earlyDate;
    @Schema(example = "2025-09-30")
    private LocalDate latestDate;
    @Schema(example = "Task Owner Name")
    private String taskOwner;
    private String purposeOfTrg;
    private List<String> populationDescriptions;
    private String trgMeetingUrgency;
    private String meetingTitle;
    private String otherParticipants;
    private LocalDate trgScheduledDate;
    @Schema(description = "Attachment details")
    private List<Attachment> attachments;
}
