package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.Attachment;
import com.ford.grid.model.entity.Audit;
import com.ford.grid.model.entity.Contacts;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

@Data
@EqualsAndHashCode(callSuper = false)
public class TrgScheduleRequest extends Audit {

    @Schema(example = "64b7f9f0e1d2c3a4b5c6d7e8")
    @JsonProperty("id")
    private String id;
    @Schema(example = "UH033")
    @JsonProperty("issueNumber")
    private String issueNumber;
    @Schema(example = "IMP123")
    @JsonProperty("implId")
    private String implId;
    @Schema(example = "POP456")
    @JsonProperty("populationId")
    private String populationId;
    private List<TrgAgendaDto> trgSchedule;
    @Schema(example = "[\"file1.pdf\", \"file2.docx\"]")
    @JsonProperty("deletedAttachments")
    private List<String> deletedAttachments;
}
