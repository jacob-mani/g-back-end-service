package com.ford.grid.model.dto.request;

import com.ford.grid.model.entity.KeyStatus;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UploadClosureDocRequest {
    @Schema(example = "25-001", description = "Issue number")
    private String issueNumber;

    @Schema(description = "List of meeting notes types")
    private List<String> meetingNotesType;

    @Schema(description = "List of key status items")
    private List<KeyStatus> keyStatusArr;

    @Schema(example = "JDOE123", description = "User CDSID who triggered the upload")
    private String uploadedBy;
}