package com.ford.grid.model.dto.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UploadGCSFileRequest {

    private String issueNumber;
    private String implId;
    private String populationId;
    private String fsaNumber;
    private String region;
    private String brand;
    private boolean multiBrand;
}
