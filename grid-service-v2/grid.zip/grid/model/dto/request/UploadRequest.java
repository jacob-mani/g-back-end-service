package com.ford.grid.model.dto.request;

import com.ford.grid.model.dto.response.CloudFileName;
import lombok.Builder;
import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Data
@Builder
public class UploadRequest {
    private String issueNumber;
    private String screenType;
    private List<CloudFileName> cloudFileNames;
    private List<MultipartFile> files;
}
