package com.ford.grid.model.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserAccessRequestNotificationRequest {
    private Boolean notifyAdmin;
    private String newUserCdsId;
    private String role;
    private String reason;
    private String accessRequestedBy;
}

