package com.ford.grid.model.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Field;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserNotifications {
    @Field("act_actions")
    private List<NotificationDetails> activeActions;
    @Field("act_events")
    private List<NotificationDetails> activeEvents;
    @Field("act_deadLines")
    private List<NotificationDetails> activeDeadlines;
    @Field("act_userAccessRequest")
    private List<NotificationDetails> activeUserAccessRequest;
    @Field("clr_actions")
    private List<NotificationDetails> clearedActions;
    @Field("clr_events")
    private List<NotificationDetails> clearedEvents;
    @Field("clr_deadLines")
    private List<NotificationDetails> clearedDeadlines;
    @Field("clr_userAccessRequest")
    private List<NotificationDetails> clearedUserAccessRequest;
    @Field("snz_actions")
    private List<NotificationDetails> snoozedActions;
    @Field("snz_deadLines")
    private List<NotificationDetails> snoozedDeadlines;
    @Field("snz_userAccessRequest")
    private List<NotificationDetails> snoozedUserAccessRequest;
}