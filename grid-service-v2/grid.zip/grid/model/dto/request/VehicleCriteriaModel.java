package com.ford.grid.model.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.dto.request.vern.CriteriaDetail;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class VehicleCriteriaModel {

    @JsonProperty("modelYear")
    private CriteriaDetail modelYear;

    @JsonProperty("brand")
    private CriteriaDetail brand;

    @JsonProperty("vehicleLine")
    private CriteriaDetail vehicleLine;
}
