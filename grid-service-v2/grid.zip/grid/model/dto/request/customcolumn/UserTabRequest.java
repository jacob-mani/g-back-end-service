package com.ford.grid.model.dto.request.customcolumn;

import lombok.Data;

@Data
public class UserTabRequest {
    private String cdsId;
}
