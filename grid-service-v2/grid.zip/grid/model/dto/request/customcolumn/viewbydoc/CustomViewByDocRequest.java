package com.ford.grid.model.dto.request.customcolumn.viewbydoc;

import lombok.Data;

import java.util.List;

/**
 * Request DTO for fetching issue data from view_by_issue.
 *
 * <p>The caller provides the {@code customViewId} (the {@code _id} of the document
 * in {@code user_custom_preferences}). The service resolves {@code activeColumns},
 * {@code myIssues}, and {@code combinedFilterQuery} from that document,
 * then queries {@code view_by_issue}.
 */
@Data
public class CustomViewByDocRequest {

    /** The _id of the user_custom_preferences document — used to resolve the column/filter configuration. */
    private String customViewId;

    // ---- Resolved internally from user_custom_preferences (not supplied by the caller) ----
    private String cdsId;
    private List<String> activeColumns;
    private Boolean myIssues;
    private List<Object> activeFilters;

    /**
     * Combined MongoDB filter query string from the saved preference document.
     * When non-null/non-blank, this raw JSON query is parsed and applied directly.
     */
    private String combinedFilterQuery;

    // ---- Caller-supplied as query params ----
    private int page = 0;
    private int size = 20;
    private String sortBy = "issueNumber";
    private String sortDirection = "ASC";

    /**
     * Optional free-text search term supplied by the caller.
     * When present, a case-insensitive regex search is applied across only the
     * activeColumns the user has selected — i.e., what is visible in the response.
     */
    private String search;
}

