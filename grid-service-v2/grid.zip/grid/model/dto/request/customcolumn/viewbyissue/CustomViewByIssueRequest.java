package com.ford.grid.model.dto.request.customcolumn.viewbyissue;

import lombok.Data;

import java.util.List;

/**
 * Request DTO for fetching issue data from view_by_issue.
 *
 * <p>The caller provides the {@code customViewId} (the {@code _id} of the document
 * in {@code user_custom_preferences}). The service resolves {@code activeColumns},
 * {@code myIssues}, and {@code combinedFilterQuery} from that document,
 * then queries {@code view_by_issue}.
 */
@Data
public class CustomViewByIssueRequest {

    private String customViewId;

    private String cdsId;
    private List<String> activeColumns;
    private Boolean myIssues;
    private List<Object> activeFilters;
    private String combinedFilterQuery;

    private int page = 0;
    private int size = 20;
    private String sortBy = "issueNumber";
    private String sortDirection = "ASC";

    private String search;
}

