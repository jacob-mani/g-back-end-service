package com.ford.grid.model.dto.request.customcolumn.viewbyrepairprofile;

import lombok.Data;

import java.util.List;

@Data
public class CustomViewByRepairProfileRequest {

    private String customViewId;

    private String cdsId;
    private List<String> activeColumns;
    private Boolean myIssues;
    private List<Object> activeFilters;
    private String combinedFilterQuery;

    private int page = 0;
    private int size = 10;
    private String sortBy = "issueNumber";
    private String sortDirection = "ASC";

    private String search;
}

