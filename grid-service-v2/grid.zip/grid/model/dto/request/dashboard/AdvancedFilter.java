package com.ford.grid.model.dto.request.dashboard;

import lombok.Builder;

import java.util.List;

@Builder
public record AdvancedFilter(
        String filterName,
        String filterOptions,
        List<Integer> colIds,
        boolean myIssues,
        List<String> issueIds,
        String viewBy
) {
}