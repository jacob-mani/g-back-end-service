package com.ford.grid.model.dto.request.dashboard;

import lombok.Builder;

import java.util.List;

@Builder
public record CustomFiltersDTO(
        String category,
        String condition,
        List<String> criteria
) {
}