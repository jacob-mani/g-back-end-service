package com.ford.grid.model.dto.request.dashboard;

import lombok.Builder;

import java.util.List;

@Builder
public record DashboardPreference(
        int myIssuesCustomColId,
        List<String> list1,
        List<String> list2
) {
}