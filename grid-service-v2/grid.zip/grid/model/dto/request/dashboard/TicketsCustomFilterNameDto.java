package com.ford.grid.model.dto.request.dashboard;

import java.util.List;

public record TicketsCustomFilterNameDto(
        String filterName,
        List<CustomFiltersDTO> customFilterNames
) {
}
