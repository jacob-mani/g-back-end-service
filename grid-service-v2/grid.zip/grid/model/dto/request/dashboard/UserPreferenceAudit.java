package com.ford.grid.model.dto.request.dashboard;

import lombok.Builder;

import java.time.LocalDateTime;

@Builder
public record UserPreferenceAudit(
        LocalDateTime createdTime,
        LocalDateTime lastUpdatedTime,
        String lastUpdatedBy,
        String updatedBy
) {
}
