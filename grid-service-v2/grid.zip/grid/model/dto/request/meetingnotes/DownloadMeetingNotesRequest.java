package com.ford.grid.model.dto.request.meetingnotes;

import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
public class DownloadMeetingNotesRequest {

    private String leadRegion;
    private List<String> forumType;
    private List<String> issueNumbers;
    private Map<String, List<String>> forumIssueNumbers;

    private String cdsid;
    private List<String> hideIssues;
    private List<String> segment;
    private List<String> issuePhase;
    private List<String> mtngTypes;
    private String hideFromDate;
    private String hideToDate;
    private String noteFromDate;
    private String noteToDate;
    private List<String> agencyList;
    private boolean monitor;
    private boolean hideRCO;
    private boolean myIssues;
    private List<ExportNoteItem> ccrgLst;
    private List<ExportNoteItem> csfLst;
    private List<ExportNoteItem> eprcLst;
    private List<ExportNoteItem> govtLst;
    private String exportTtl;
    private boolean recentNotesChecked;

    /**
     * Field name to sort by. Matches table header column keys.
     * Supported values: "issueId", "phase", "age", "date", "desc" (issueTitle).
     * null or empty = default sort (by issueNumber ascending).
     */
    private String sortField;

    /**
     * Sort direction: "asc" or "desc". Default "asc" if not specified.
     */
    private String sortDirection;

    /**
     * When true, include the full Monitor (LOM) detail section in the export.
     * When false, only the Monitor index is generated (no note body).
     * Default: true (preserves existing behavior unless explicitly opted out).
     */
    private boolean includeMonitorDetail = true;
}
