package com.ford.grid.model.dto.request.meetingnotes;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Request DTO for exporting meeting notes as a Word document.
 * <p>
 * Valid meeting notes types include:
 * - EPRC: Engineering Pre-Approval Review Committee
 * - CSF: Customer Satisfaction Forum
 * - CCRG: Customer Concerns Review Group
 * - GOVERNMENT: Government meeting notes
 * - TRG: Technical Review Group
 * - FRC: Final Review Committee
 * - 14D: 14-Day Defect reporting
 * - CARB: California Air Resources Board
 * - TC: Technical Committee
 * - EMM: Engineering Meeting Minutes
 * </p>
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ExportMeetingNotesDocumentRequest {
    

    private String issueNumber;
    private String levelOfMeetingNotes;
    private String cdsid;
    
    @NotEmpty(message = "Meeting notes types cannot be null or empty")
    private List<String> meetingNotesTypes;

}

