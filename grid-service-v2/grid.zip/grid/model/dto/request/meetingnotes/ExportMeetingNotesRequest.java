package com.ford.grid.model.dto.request.meetingnotes;

import lombok.Data;

import java.util.List;

@Data
public class ExportMeetingNotesRequest {

    private List<String> hideIssues;
    private List<String> segment;
    private String cdsid;
    /**
     * One or more forum types selected by the user.
     * Changed from String to List<String> to support multi-forum single-call fetch.
     * Backend processes all forums in a single request; frontend handles pagination client-side.
     */
    private List<String> forumType;
    private String leadRegion;
    private List<String> issuePhase;
    private List<String> mtngTypes;
    private String hideFromDate;
    private String hideToDate;
    private String noteFromDate;
    private String noteToDate;
    private List<String> agencyList;
    private boolean monitor;
    private boolean hideRCO;
    private boolean myIssues;
    private List<ExportNoteItem> ccrgLst;
    private List<ExportNoteItem> csfLst;
    private List<ExportNoteItem> eprcLst;
    private List<ExportNoteItem> govtLst;
    private String exportTtl;
    private boolean recentNotesChecked;
    private List<String> issueNumbers;

    /** 0-based page number for server-side pagination. Default 0 (first page). */
    private int page;
    /** Number of items per page. 0 or negative = return ALL (no pagination). */
    private int pageSize;

    /**
     * Field name to sort by. Matches table header column keys.
     * Supported values: "issueId", "phase", "age", "date", "desc" (issueTitle).
     * null or empty = default sort (by issueNumber ascending).
     */
    private String sortField;

    /**
     * Sort direction: "asc" or "desc". Default "asc" if not specified.
     */
    private String sortDirection;
}
