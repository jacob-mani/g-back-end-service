package com.ford.grid.model.dto.request.meetingnotes;

import lombok.Data;

import java.util.List;

@Data
public class ExportNoteItem {
    private String issueId;
    private List<String> memoIds;
    private boolean monitor;
}

