package com.ford.grid.model.dto.request.meetingnotes;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MeetingNotesDetails {
    private int sequenceId;
    private String author;
    private String creationDate;
    private String title;
    private String notes;
    private boolean isCardBeingEdited;
    private String currentlyEditedBy;
}