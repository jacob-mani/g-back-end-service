package com.ford.grid.model.dto.request.meetingnotes;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import lombok.Builder;

@Builder
public record MeetingNotesEdit(
        @Min(value = 1, message = "sequenceId must be greater than 0") int sequenceId,
        @NotBlank(message = "Issue Number cannot be empty") String issueNumber,
        @NotBlank(message = "Category cannot be empty") String category,
        String implId,
        String populationId,
        String editSection
) {
}
