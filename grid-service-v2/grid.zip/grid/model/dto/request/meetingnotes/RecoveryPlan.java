package com.ford.grid.model.dto.request.meetingnotes;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RecoveryPlan {
    private String recoveryPlanDate;
    private String recoveryPlanNotes;
    private Boolean isCardBeingEdited;
    private String currentlyEditedBy;
}