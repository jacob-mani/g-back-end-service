package com.ford.grid.model.dto.request.meetingnotes;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.ford.grid.serializer.LowerCaseDeserializer;
import com.ford.grid.serializer.ToLowerCase;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Field;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RegionAndFSANotes {
    @ToLowerCase
    @NotBlank
    @JsonDeserialize(using = LowerCaseDeserializer.class)
    private String region;
    @ToLowerCase
    @NotBlank
    @JsonDeserialize(using = LowerCaseDeserializer.class)
    private String fsaNumber;
    @ToLowerCase
    @NotBlank
    @JsonDeserialize(using = LowerCaseDeserializer.class)
    private String role;
    private String title;
    private String notes;
    @JsonProperty("isCardBeingEdited")
    private boolean isCardBeingEdited;
    @JsonProperty("currentlyEditedBy")
    private String currentlyEditedBy;
    @JsonProperty("isNoteActive")
    @Field("isNoteActive")
    private boolean isNoteActive = true;
    private String workLoad;
}