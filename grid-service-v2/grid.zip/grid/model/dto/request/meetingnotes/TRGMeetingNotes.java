package com.ford.grid.model.dto.request.meetingnotes;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class TRGMeetingNotes {
    private int sequenceId;
    private TRGMeetingNotesDetails meetingnotes;
    private RecoveryPlan recoveryplan;
}