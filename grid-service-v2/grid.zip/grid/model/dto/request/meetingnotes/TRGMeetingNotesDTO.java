package com.ford.grid.model.dto.request.meetingnotes;


import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TRGMeetingNotesDTO {
    private int sequenceId;

    @NotBlank(message = "Implementation ID is required")
    private String implId;

    @NotBlank(message = "Population ID is required")
    private String populationId;

    private TRGMeetingNotesDetails meetingnotes;
    private RecoveryPlan recoveryplan;
}
