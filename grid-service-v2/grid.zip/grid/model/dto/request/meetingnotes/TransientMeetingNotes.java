package com.ford.grid.model.dto.request.meetingnotes;

import com.ford.grid.model.dto.request.GeneralNotes;
import lombok.Data;
import java.util.List;

@Data
public class TransientMeetingNotes {
    private GeneralNotes general;
    private RegionAndFSANotes regionandfsa;
    private List<GeneralNotes> generalList;
    private List<RegionAndFSANotes> regionandfsaList;
}