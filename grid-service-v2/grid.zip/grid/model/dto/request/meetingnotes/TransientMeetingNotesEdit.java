package com.ford.grid.model.dto.request.meetingnotes;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import lombok.Builder;

@Builder
public record TransientMeetingNotesEdit(
        //key represents "forumType" in "general" and "title" in regionandfsa
        @NotBlank(message = "key cannot be empty") String key,
        @NotBlank(message = "Issue Number cannot be empty") String issueNumber,
        @NotBlank(message = "Category cannot be empty") String category
) {
}
