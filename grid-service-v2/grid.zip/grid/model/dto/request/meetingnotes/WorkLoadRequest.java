package com.ford.grid.model.dto.request.meetingnotes;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class WorkLoadRequest {
    @NotBlank(message = "key must not be blank")
    private String key;
    @NotBlank(message = "value must not be blank")
    private String value;
}
