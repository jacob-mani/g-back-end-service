package com.ford.grid.model.dto.request.scheduler;

import lombok.Builder;

@Builder
public record MonitorComebackJobRequest(
        String issueNumber,
        String forumType,
        Boolean dryRun,
        Boolean force
) {
}

