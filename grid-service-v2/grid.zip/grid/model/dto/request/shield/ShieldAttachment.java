package com.ford.grid.model.dto.request.shield;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ShieldAttachment {
    @Size(max = 500, message = "File name cannot exceed 500 characters")
    @Schema(maxLength = 500, pattern = "^[a-zA-Z0-9_\\-\\s.]+$", example = "report.pdf")
    private String fileName;

    @Size(max = 2048, message = "GCP signed URL cannot exceed 2048 characters")
    @Schema(maxLength = 2048, pattern = "^https://[\\S]+$", example = "https://storage.googleapis.com/bucket/file.pdf")
    private String gcpSignedUrl;
}

