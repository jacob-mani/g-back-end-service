package com.ford.grid.model.dto.request.shield;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.grid.model.entity.Audit;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.LocalDate;
import java.util.List;

@Data
@EqualsAndHashCode(callSuper = false)
public class ShieldCreateIssueRequest extends Audit {

    // === Issue Creation Fields ===

    @NotNull(message = "Opened date must not be null")
    private LocalDate openedDate;

    @NotBlank(message = "Issue title must not be null or blank")
    @Size(max = 500, message = "Issue title cannot exceed 500 characters")
    @Schema(maxLength = 500, pattern = "^[\\s\\S]{1,500}$", example = "Engine misfire under load")
    private String issueTitle;

    @NotBlank(message = "Issue description must not be null or blank")
    @Size(max = 5000, message = "Description cannot exceed 5000 characters")
    @Schema(maxLength = 5000, pattern = "^[\\s\\S]{1,5000}$", example = "Intermittent engine misfire reported under high load conditions")
    private String issueDescription;

    @NotBlank(message = "Lead region must not be null or blank")
    @Size(max = 100, message = "Lead region cannot exceed 100 characters")
    @Schema(maxLength = 100, pattern = "^[a-zA-Z0-9_\\-\\s]+$", example = "NA")
    private String leadRegion;

    @NotBlank(message = "Segment must not be null or blank")
    @Size(max = 100, message = "Segment cannot exceed 100 characters")
    @Schema(maxLength = 100, pattern = "^[a-zA-Z0-9_\\-\\s]+$", example = "Trucks")
    private String segment;

    @NotEmpty(message = "Causal types must not be null or empty")
    @Size(max = 50, message = "Causal types list cannot exceed 50 items")
    @ArraySchema(maxItems = 50, schema = @Schema(type = "integer", minimum = "0", maximum = "999999", example = "1"))
    private List<@Min(value = 0, message = "Causal type value must be at least 0") @Max(value = 999999, message = "Causal type value must not exceed 999999") Integer> causalTypes;

    @NotBlank(message = "Forum type must not be null or blank")
    @Pattern(regexp = "^(1|2|3|4)$", message = "Forum type must be one of: 1, 2, 3, 4")
    @Schema(example = "1", allowableValues = {"1", "2", "3", "4"})
    private String forumType;

    @Size(max = 200, message = "Agency cannot exceed 200 characters")
    @Schema(maxLength = 200, pattern = "^[a-zA-Z0-9_\\-\\s]*$", example = "NHTSA")
    private String agency;

    @NotNull(message = "Forum open date must not be null")
    private LocalDate forumOpenDate;

    @Size(max = 2000, message = "Issue related items cannot exceed 2000 characters")
    @Schema(maxLength = 2000, pattern = "^[\\s\\S]*$", example = "Related to recall campaign RC-2024-001")
    private String issueRelatedItems;

    @Size(max = 100, message = "Issue type cannot exceed 100 characters")
    @Schema(maxLength = 100, pattern = "^[a-zA-Z0-9_\\-\\s]*$", example = "Safety")
    private String issueType;

    // status is inherited from Audit — no need to redeclare

    // === SHIELD-specific Fields (stored in recall_issue) ===

    @NotBlank(message = "Alert ID must not be null or blank")
    @Size(max = 200, message = "Alert ID cannot exceed 200 characters")
    @Schema(maxLength = 200, pattern = "^[a-zA-Z0-9_\\-]+$", example = "ALERT-2024-001")
    private String alertId;

    @ArraySchema(maxItems = 100, schema = @Schema(type = "string", maxLength = 200, pattern = "^[a-zA-Z0-9_\\-]+$", example = "PRO-001"))
    private List<@Size(max = 200, message = "Pro ID cannot exceed 200 characters") String> proIds;

    @ArraySchema(maxItems = 100, schema = @Schema(type = "string", maxLength = 200, pattern = "^[a-zA-Z0-9_\\-]+$", example = "ALERT-2024-002"))
    private List<@Size(max = 200, message = "Related alert ID cannot exceed 200 characters") String> relatedAlertIds;

    // === Vehicle Info (converted to BaseVehicleCriteria) ===

    @NotEmpty(message = "Vehicle info must not be null or empty")
    @Valid
    @ArraySchema(maxItems = 100)
    private List<ShieldVehicleInfo> vehicleInfo;

    // === Investigation Fields (stored in forum_investigation_analysis.problemCategory) ===

    @JsonProperty("effectOnVehicleOperationSectionCustomerExperienceField")
    @Size(max = 5000, message = "Customer experience field cannot exceed 5000 characters")
    @Schema(maxLength = 5000, pattern = "^[\\s\\S]*$", example = "Customer may experience reduced performance")
    private String effectOnVehicleOperationSectionCustomerExperienceField;

    @JsonProperty("effectOnVehicleOperationSectionSafetyEnvironmentRegulatoryImpactField")
    @Size(max = 5000, message = "Safety/environment/regulatory impact field cannot exceed 5000 characters")
    @Schema(maxLength = 5000, pattern = "^[\\s\\S]*$", example = "No immediate safety concern identified")
    private String effectOnVehicleOperationSectionSafetyEnvironmentRegulatoryImpactField;

    @JsonProperty("effectOnVehicleWarningsOrIndicators")
    @Size(max = 5000, message = "Warnings/indicators field cannot exceed 5000 characters")
    @Schema(maxLength = 5000, pattern = "^[\\s\\S]*$", example = "Check engine light may illuminate")
    private String effectOnVehicleWarningsOrIndicators;

    @JsonProperty("defineRootCauseSectionPotentialRootCauseField")
    @Size(max = 5000, message = "Potential root cause field cannot exceed 5000 characters")
    @Schema(maxLength = 5000, pattern = "^[\\s\\S]*$", example = "Potential software calibration issue")
    private String defineRootCauseSectionPotentialRootCauseField;

    @JsonProperty("defineRootCauseSectionContainmentActionsField")
    @Size(max = 5000, message = "Containment actions field cannot exceed 5000 characters")
    @Schema(maxLength = 5000, pattern = "^[\\s\\S]*$", example = "Software update deployed to affected vehicles")
    private String defineRootCauseSectionContainmentActionsField;

    @JsonProperty("suspectVehiclePopulationSectionTotalSuspectVehiclePopulation")
    @Size(max = 100, message = "Total suspect vehicle population cannot exceed 100 characters")
    @Schema(maxLength = 100, pattern = "^[0-9,\\s]*$", example = "15000")
    private String suspectVehiclePopulationSectionTotalSuspectVehiclePopulation;

    @JsonProperty("occurrenceInitialFindingsPatientZero")
    @Size(max = 5000, message = "Initial findings field cannot exceed 5000 characters")
    @Schema(maxLength = 5000, pattern = "^[\\s\\S]*$", example = "Initial occurrence reported on 2024-01-15")
    private String occurrenceInitialFindingsPatientZero;

    @JsonProperty("VOQs")
    @Size(max = 2000, message = "VOQs field cannot exceed 2000 characters")
    @Schema(maxLength = 2000, pattern = "^[\\s\\S]*$", example = "VOQ data summary")
    private String VOQs;

    @JsonProperty("warrantyPostWarrantyAnalysis")
    @Size(max = 5000, message = "Warranty analysis field cannot exceed 5000 characters")
    @Schema(maxLength = 5000, pattern = "^[\\s\\S]*$", example = "Warranty analysis pending")
    private String warrantyPostWarrantyAnalysis;

    @JsonProperty("highSeverityFieldReports")
    @Size(max = 5000, message = "High severity field reports cannot exceed 5000 characters")
    @Schema(maxLength = 5000, pattern = "^[\\s\\S]*$", example = "No high severity field reports")
    private String highSeverityFieldReports;

    // === Contact Fields ===

    @JsonProperty("preInvestigationLead")
    @Size(max = 200, message = "Pre-investigation lead cannot exceed 200 characters")
    @Schema(maxLength = 200, pattern = "^[a-zA-Z0-9_\\-@.\\s]*$", example = "jdoe@ford.com")
    private String preInvestigationLead;

    @JsonProperty("14DAuthorLL6OrTS")
    @Size(max = 200, message = "14D Author field cannot exceed 200 characters")
    @Schema(maxLength = 200, pattern = "^[a-zA-Z0-9_\\-@.\\s]*$", example = "jsmith@ford.com")
    private String fourteenDAuthorLL6OrTS;

    // === Attachments (copied to GRID's GCS bucket, stored in forum_agenda.attachments) ===

    @Valid
    @ArraySchema(maxItems = 50)
    private List<ShieldAttachment> attachments;
}




