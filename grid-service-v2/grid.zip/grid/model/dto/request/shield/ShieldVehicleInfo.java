package com.ford.grid.model.dto.request.shield;

import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ShieldVehicleInfo {
    @Size(max = 50, message = "Model year list cannot exceed 50 items")
    @ArraySchema(maxItems = 50, schema = @Schema(type = "integer", minimum = "1900", maximum = "2100", example = "2024"))
    private List<@Min(value = 1900, message = "Model year must be at least 1900") @Max(value = 2100, message = "Model year must not exceed 2100") Integer> modelYear;

    @Size(max = 100, message = "Brand cannot exceed 100 characters")
    @Schema(maxLength = 100, pattern = "^[a-zA-Z0-9_\\-\\s]+$", example = "Ford")
    private String brand;

    @Size(max = 200, message = "Vehicle line cannot exceed 200 characters")
    @Schema(maxLength = 200, pattern = "^[a-zA-Z0-9_\\-\\s]+$", example = "Explorer")
    private String vehicleLine;
}

