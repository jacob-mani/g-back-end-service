package com.ford.grid.model.dto.request.vehicleparts;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CalculatePartsRequest {
    private String issueNumber;
    private String implId;
    private String populationId;
    private String vernNumber;
    private int vernRevision;
    private String regionCode;
    private String regionName;
    private List<ProfileRateDetails> profileRateDetails;
}
