package com.ford.grid.model.dto.request.vehicleparts;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class CountryData {
    @JsonProperty("country")
    private String countryName;

    @JsonProperty("vehicles")
    private List<Vehicles> vehicles;
}