package com.ford.grid.model.dto.request.vehicleparts;

import com.ford.grid.model.dto.request.vern.WersItem;
import lombok.Builder;

import java.time.LocalDate;
import java.util.List;

@Builder
public record DefineProfileDetails(
        String issueNumber,
        String implId,
        String populationId,
        String vernNumber,
        int vernVersion,
        int vernRevision,
        List<ProfileDetailKeyValue> multiParts,
        LocalDate receivedDate,
        List<VehicleLineProfileDTO> profileDetails,
        boolean isVfdApplicable,
        List<WersItem> attributeItems
) {
}