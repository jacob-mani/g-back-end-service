package com.ford.grid.model.dto.request.vehicleparts;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigInteger;
import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DefineProfileRequest {
    private int vernVersion;
    private int vernRevision;
    @NotBlank private String issueNumber;
    @NotBlank private String implId;
    @NotBlank private String vernNumber;
    @NotBlank private String populationId;

    private int labourHour;
    private String profileId;
    @NotBlank private String profileName;
    @NotBlank private String multipleRepairs;
    @NotBlank private String remedyExplanation;

    //Common profile filters
    private List<Integer> modelYears;
    private List<String> vehicleLines;
    private List<String> countries;
    private List<String> regions;

    //VFD attribute filters
    private BigInteger vfdImpactedVehicleCount;
    private String vfdImpactedVehicleCount_display;
    private List<String> attribute1;
    private List<String> attribute2;
    private List<String> attribute3;
    private List<String> attribute4;
    private List<String> attribute5;
    private List<String> attribute6;
    private List<String> attribute7;
    private List<String> attribute8;
    private List<String> attribute9;
    private List<String> attribute10;
}