package com.ford.grid.model.dto.request.vehicleparts;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class EditProfileRequest {
    private String profileId;
    private String populationId;
    private String profileName;
}
