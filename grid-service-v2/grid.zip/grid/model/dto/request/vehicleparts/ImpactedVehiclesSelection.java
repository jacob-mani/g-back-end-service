package com.ford.grid.model.dto.request.vehicleparts;

import lombok.Builder;

@Builder
public record ImpactedVehiclesSelection(
        String region,
        String country,
        int modelYear,
        String vehicleLine
) {
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ImpactedVehiclesSelection that = (ImpactedVehiclesSelection) o;
        return modelYear == that.modelYear &&
                java.util.Objects.equals(region, that.region) &&
                java.util.Objects.equals(country, that.country) &&
                java.util.Objects.equals(vehicleLine, that.vehicleLine);
    }

    @Override
    public int hashCode() {
        return java.util.Objects.hash(region, country, modelYear, vehicleLine);
    }
}