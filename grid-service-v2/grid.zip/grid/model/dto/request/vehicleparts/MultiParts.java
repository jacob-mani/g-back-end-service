package com.ford.grid.model.dto.request.vehicleparts;

import lombok.Builder;

@Builder
public record MultiParts(String key, String value) {
}