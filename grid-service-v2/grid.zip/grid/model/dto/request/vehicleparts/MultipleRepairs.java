package com.ford.grid.model.dto.request.vehicleparts;

import lombok.Getter;

@Getter
public enum MultipleRepairs {
    Y("Yes (Based On Vehicle, Region & Country)"),
    N("No (Will include All Vehicles)"),
    W("Yes (Based on WERS max: 10)");

    public final String description;

    MultipleRepairs(String description) {
        this.description = description;
    }
}