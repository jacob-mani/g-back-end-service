package com.ford.grid.model.dto.request.vehicleparts;

import java.util.List;

public record ProfileCountry(
        String country,
        List<ProfileVehicle> vehicles
) {
}
