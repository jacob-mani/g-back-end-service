package com.ford.grid.model.dto.request.vehicleparts;

import lombok.Builder;

@Builder
public record ProfileDetailKeyValue(
        String key,
        String value,
        boolean isSelectable
) {
}