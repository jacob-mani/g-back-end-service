package com.ford.grid.model.dto.request.vehicleparts;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.math.BigInteger;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProfileRateDetails {
    private String profileId;
    private String profileName;
    private BigDecimal soldUio;
    private BigDecimal soldResponseRate;
    private BigDecimal soldLaunchQuantity;
    private BigDecimal unSoldUio;
    private BigDecimal unSoldResponseRate;
    private BigDecimal unSoldLaunchQuantity;
    private BigInteger soldCount;
    private BigInteger unSoldCount;
    //private BigInteger totalCount;
}
