package com.ford.grid.model.dto.request.vehicleparts;

import lombok.Builder;

import java.math.BigDecimal;

@Builder
public record ProfileRegion(
        String region,
        BigDecimal soldUio,
        BigDecimal soldResponseRate,
        BigDecimal soldLaunchQuantity,
        BigDecimal unSoldUio,
        BigDecimal unSoldResponseRate,
        BigDecimal unSoldLaunchQuantity
) {
}