package com.ford.grid.model.dto.request.vehicleparts;

import jakarta.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class ProfileRequest {
    @NotNull private String populationId;
    @NotNull private String profileName;

    private List<Integer> modelYear;
    private List<String> vehicleLines;
    private List<String> regions;
    private List<String> countries;
}