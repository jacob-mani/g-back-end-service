package com.ford.grid.model.dto.request.vehicleparts;

public record ProfileVehicle(
        String vehicleLine,
        String model,
        String brand
) {
}