package com.ford.grid.model.dto.request.vehicleparts;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class RegionData {
    @JsonProperty("region")
    private String regionName;

    @JsonProperty("regionDetails")
    private List<CountryData> countries;
}